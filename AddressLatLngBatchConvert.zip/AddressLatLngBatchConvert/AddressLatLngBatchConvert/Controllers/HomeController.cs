﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;

namespace AddressLatLngBatchConvert.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewData["Message"] = "ASP.NET MVC へようこそ";

            return View();
        }

        public ActionResult About()
        {
            return View();
        }

        [ValidateInput(false)]
        [HttpPost]
        public ActionResult Convert(string content)
        {
            if (String.IsNullOrWhiteSpace(content))
            {
                //no content input . ignore
            }
            else
            {
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                System.Text.RegularExpressions.Regex reg = new System.Text.RegularExpressions.Regex((@"1[0-8][0-9]\.[0-9]{3,}[,\|\-:\u0020\t]+[1-9][0-9]\.[0-9]{3,}"));
                Dictionary<string, string> dicProcessed = new Dictionary<string, string>();
                Cache[""] = null;
                using (StringReader reader = new StringReader(content))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        line = line.Trim();
                        if (line.StartsWith("通信エラー"))
                        {
                            line = line.Substring(5).Trim();
                        }
                        if (line.StartsWith("GEOCODE結果無"))
                        {
                            line = line.Substring(10).Trim();
                        }
                        if (String.IsNullOrWhiteSpace(line))
                        {
                            //blank input
                            sb.AppendLine("## 空行 ##");
                        }
                        else if (line.StartsWith("##") && line.EndsWith("##"))
                        {
                            sb.AppendLine(line);
                        }
                        else
                        {
                            var tmpmatch = reg.Match(line);
                            if (tmpmatch.Success)
                            {
                                //lat lng data inside
                                string[] arr = tmpmatch.Value.Split(new char[] { ',', '|', '-', ':', ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                                if (arr == null || arr.Length != 2)
                                {
                                    sb.AppendLine("## 入力内容処理エラー ##");
                                }

                                if (dicProcessed.ContainsKey(arr[0] + "," + arr[1]))
                                {
                                    sb.AppendLine(dicProcessed[arr[0] + "," + arr[1]]);
                                }
                                else
                                {
                                    var requestUri = string.Format("https://maps.googleapis.com/maps/api/geocode/xml?latlng={0},{1}&language=ja", arr[1], arr[0]);
                                    var request = System.Net.WebRequest.Create(requestUri);
                                    System.Net.WebResponse response = null;
                                    try
                                    {
                                        response = request.GetResponse();
                                    }
                                    catch (Exception e)
                                    {
                                        sb.AppendLine("通信エラー\t" + arr[0] + "," + arr[1]);
                                        continue;
                                    }
                                    var xdoc = System.Xml.Linq.XDocument.Load(response.GetResponseStream());
                                    var s = from lv1 in xdoc.Descendants("status")
                                            select lv1.Value;
                                    if (s.FirstOrDefault() == "OK")
                                    {
                                        var tmpnode = xdoc.Descendants("result").FirstOrDefault();
                                        var tmpaddress = tmpnode.Descendants("formatted_address").FirstOrDefault().Value;
                                        var tmpcountry = tmpnode.Descendants("address_component").FirstOrDefault(r => r.Descendants("type").Any(o => o.Value == "country"));
                                        var tmppostal = tmpnode.Descendants("address_component").FirstOrDefault(r => r.Descendants("type").Any(o => o.Value == "postal_code"));
                                        if (tmpcountry != null)
                                        {
                                            tmpaddress = tmpaddress.Trim();
                                            string tmpctr = tmpcountry.Descendants("long_name").FirstOrDefault().Value + "、";
                                            if (tmpaddress.StartsWith(tmpctr))
                                            {
                                                if (tmpaddress.Length > tmpctr.Length)
                                                    tmpaddress = tmpaddress.Substring(tmpctr.Length);
                                            }
                                        }
                                        if (tmppostal != null)
                                        {
                                            tmpaddress = tmpaddress.Trim();
                                            string t = "〒" + tmppostal.Descendants("long_name").FirstOrDefault().Value;
                                            if (tmpaddress.StartsWith(t))
                                                if (tmpaddress.Length > t.Length)
                                                    tmpaddress = tmpaddress.Substring(t.Length);
                                        }
                                        tmpaddress = tmpaddress.Trim();
                                        var tmpaccuracy = tmpnode.Element("geometry").Element("location_type").Value;
                                        dicProcessed.Add(arr[0] + "," + arr[1], "## " + arr[0] + "," + arr[1] + "\t" + tmpaccuracy + "\t" + tmpaddress + " ##");
                                        sb.AppendLine("## " + arr[0] + "," + arr[1] + "\t" + tmpaccuracy + "\t" + tmpaddress + " ##");
                                    }
                                    else
                                    {
                                        //add code here
                                        sb.AppendLine("GEOCODE結果無\t" + arr[0] + "," + arr[1]);
                                        ViewData["error"] = xdoc.ToString();
                                    }
                                }
                            }
                            else
                            {
                                //pure address data
                                if (dicProcessed.ContainsKey(line))
                                {
                                    sb.AppendLine(dicProcessed[line]);
                                }
                                else
                                {
                                    var requestUri = string.Format("http://maps.googleapis.com/maps/api/geocode/xml?address={0}&sensor=false&language=ja", Uri.EscapeDataString(line));
                                    var request = System.Net.WebRequest.Create(requestUri);
                                    System.Net.WebResponse response = null;
                                    try
                                    {
                                        response = request.GetResponse();
                                    }
                                    catch (Exception e)
                                    {
                                        sb.AppendLine("通信エラー\t" + line);
                                        continue;
                                    }
                                    var xdoc = System.Xml.Linq.XDocument.Load(response.GetResponseStream());
                                    var s = from lv1 in xdoc.Descendants("status")
                                            select lv1.Value;
                                    if (s.FirstOrDefault() == "OK")
                                    {
                                        var s2 = from lv1 in xdoc.Descendants("result")
                                                 from lv2 in lv1.Descendants("geometry")
                                                 from lv3 in lv2.Descendants("location")
                                                 select new { Lat = lv3.Element("lat").Value, Lng = lv3.Element("lng").Value };

                                        string lat = s2.FirstOrDefault().Lat;
                                        string lng = s2.FirstOrDefault().Lng;
                                        var tmpaccuracy = xdoc.Descendants("result").FirstOrDefault().Element("geometry").Element("location_type").Value;
                                        dicProcessed.Add(line, "## " + lng + "," + lat + "\t" + tmpaccuracy + "\t" + line + " ##");
                                        sb.AppendLine("## " + lng + "," + lat + "\t" + tmpaccuracy + "\t" + line + " ##");
                                    }
                                    else
                                    {
                                        //add code here
                                        sb.AppendLine("GEOCODE結果無\t" + line);
                                        ViewData["error"] = xdoc.ToString();
                                    }
                                }
                            }
                        }
                    }
                    ViewData["data"] = sb.ToString();
                }
                //user input ...
            }
            return View();
        }

        protected override void OnException(ExceptionContext filterContext)
        {
            if (filterContext.ExceptionHandled)
            {
                return;
            }
            filterContext.Result = new ContentResult() { ContentEncoding = System.Text.Encoding.UTF8, ContentType = "text/html", Content = "<html><head><title>エラー発生</title></head><body><h2>エラーが発生しました。</h2></body></html>" };
            filterContext.ExceptionHandled = true;
        }
    }
}
