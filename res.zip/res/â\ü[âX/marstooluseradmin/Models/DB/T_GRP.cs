﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.DB
{
    public class T_GRP
    {
        [Key]
        public string GRPNAME { get; set; }

        public string P1 { get; set; }
        public string P2 { get; set; }
        public string P3 { get; set; }
        public string P4 { get; set; }
        public string P5 { get; set; }
        public string P6 { get; set; }
        public string P7 { get; set; }
        public string P8 { get; set; }
        public string P9 { get; set; }
        public string P10 { get; set; }
        public string P11 { get; set; }
        public string P12 { get; set; }
        public string P13 { get; set; }
        public string P14 { get; set; }
        public string P15 { get; set; }
        public string P16 { get; set; }
        public string P17 { get; set; }
        public string P18 { get; set; }
        public string P19 { get; set; }
        public string P20 { get; set; }
        public string P21 { get; set; }
        public string P22 { get; set; }
        public string P23 { get; set; }
        public string P24 { get; set; }
        public string P25 { get; set; }
        public string P26 { get; set; }
        public string P27 { get; set; }
        public string P28 { get; set; }
        public string P29 { get; set; }
        public string P30 { get; set; }
        public string P31 { get; set; }
        public string P32 { get; set; }

        [NotMapped]
        public string SUBSYSLIST
        {
            get
            {
                return (P1 + " " + P2 + " " + P3 + " " + P4 + " " + P5 + " " + P6 + " " + P7 + " " + P8 + " " + P9 + " " + P10
                    + " " + P11 + " " + P12 + " " + P13 + " " + P14 + " " + P15 + " " + P16 + " " + P17 + " " + P18 + " " + P19 + " " + P20 + " "
                    + P21 + " " + P22 + " " + P23 + " " + P24 + " " + P25 + " " + P26 + " " + P27 + " " + P28 + " " + P29 + " " + P30 + " " + P31 + " " + P32);
            }

            set
            {
                string ipt = value;
                ipt = (ipt + "").ToUpper();
                List<string> tmp = new List<string>();
                tmp.AddRange(ipt.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries));
                tmp = tmp.Distinct().ToList();
                int cnt = tmp.Count;
                if (cnt > 32)
                    throw new Exception("所属ごとに最大３２サブシステムへの編集権限を付与できる");
                for (int i = tmp.Count; i < 32; i++)
                {
                    tmp.Add(null);
                }
                P1 = tmp[0];
                P2 = tmp[1];
                P3 = tmp[2];
                P4 = tmp[3];
                P5 = tmp[4];
                P6 = tmp[5];
                P7 = tmp[6];
                P8 = tmp[7];
                P9 = tmp[8];
                P10 = tmp[9];
                P11 = tmp[10];
                P12 = tmp[11];
                P13 = tmp[12];
                P14 = tmp[13];
                P15 = tmp[14];
                P16 = tmp[15];
                P17 = tmp[16];
                P18 = tmp[17];
                P19 = tmp[18];
                P20 = tmp[19];
                P21 = tmp[20];
                P22 = tmp[21];
                P23 = tmp[22];
                P24 = tmp[23];
                P25 = tmp[24];
                P26 = tmp[25];
                P27 = tmp[26];
                P28 = tmp[27];
                P29 = tmp[28];
                P30 = tmp[29];
                P31 = tmp[30];
                P32 = tmp[31];
            }
        }
    }
}
