﻿using MarsTool.Common.Forms;
using MarsTool.Models;
using MarsTool.Models.DB;
using MarsTool.Properties;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace MarsTool
{
    /// <summary>
    /// グループ名選択画面
    /// </summary>
    public partial class GroupForm : MarsForm
    {
        private int RowIndex { get; set; }

        public string GroupNm { get; private set; }

        private T_PHYITM PhyItem { get; set; }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public GroupForm(T_PHYITM　phyItem, VersionModel version) : base(version)
        {
            InitializeComponent();

            this.txtGroupNm.Text = phyItem.PHYITM_GROUP;
            this.GroupNm = phyItem.PHYITM_GROUP;
            this.PhyItem = phyItem;
        }

        /// <summary>
        /// グループ名一覧を検索
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                this.dgvGroup.Rows.Clear();
                this.dgvKoho.Rows.Clear();
                this.RowIndex = -1;

                var groupArray = this.Context.T_KOHO.AsNoTracking().Select(r => r.KOHO_GROUP)
                    .Where(g => g.Contains(this.txtGroupNm.Text)).Distinct().ToArray();
                if (groupArray == null || groupArray.Length == 0)
                {
                    this.btnSelect.Enabled = false;
                    MessageBox.Show("候補値グループ名が存在しませんでした。",
                        Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                var fields = new List<string>();
                foreach (var group in groupArray)
                {
                    fields.Clear();
                    // グループ
                    fields.Add(group);

                    this.dgvGroup.Rows.Add(fields.ToArray());
                }

                this.SearchKohoCode(groupArray[0]);
                this.RowIndex = 0;

                this.btnSelect.Enabled = true;
            }
            catch (Exception ex)
            {
                this.Logger.Error(ex.Message);
                var msg = $"{MessageId.TSR00012_E}\n{ex.Message}";
                MessageBox.Show(msg, Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// グループ名選択
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DgvGroup_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            this.RowIndex = e.RowIndex;
            this.SearchKohoCode(this.dgvGroup.Rows[e.RowIndex].Cells["GROUP"].Value.ToString());
        }

        private void SearchKohoCode(string group)
        {
            if (string.IsNullOrWhiteSpace(group)) return;

            try
            {
                this.dgvKoho.Rows.Clear();
                var kohoList = this.Context.T_KOHO.AsNoTracking()
                    .Where(r => r.KOHO_GROUP.Equals(group)).OrderBy(r => r.KOHO_ORDER).ToArray();
                var fields = new List<string>();
                foreach (var record in kohoList)
                {
                    fields.Clear();
                    // 順序
                    fields.Add(record.KOHO_ORDER.ToString());
                    // コード
                    fields.Add(record.KOHO_CODE);
                    // 内容
                    fields.Add(record.KOHO_CONTENT);

                    this.dgvKoho.Rows.Add(fields.ToArray());
                }
            }
            catch (Exception ex)
            {
                this.Logger.Error(ex.Message);
                var msg = $"{MessageId.TSR00012_E}\n{ex.Message}";
                MessageBox.Show(msg, Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 選択したグループ名が呼出元に戻る
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnSelect_Click(object sender, EventArgs e)
        {
            if (this.RowIndex < 0 || this.RowIndex >= this.dgvGroup.Rows.Count)
            {
                MessageBox.Show("グループ名を選択してください。",
                    Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            this.GroupNm = this.dgvGroup.Rows[this.RowIndex].Cells["GROUP"].Value.ToString();
            this.Close();
        }

        /// <summary>
        /// グループ名の紐付け関係を削除
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnUnRel_Click(object sender, EventArgs e)
        {
            this.GroupNm = string.Empty;
            this.Close();
        }
    }
}
