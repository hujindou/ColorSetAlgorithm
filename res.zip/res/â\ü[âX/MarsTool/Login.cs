﻿using MarsTool.LGC;
using MarsTool.Models;
using MarsTool.Models.DB;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarsTool
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        /// <summary>
        /// ログインボタン押す処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            var xx = this.comboBox1.SelectedItem as VersionModel;
            string userid = this.userid.Text;
            string password = this.password.Text;

            if (xx != null && !String.IsNullOrWhiteSpace(userid) && !String.IsNullOrEmpty(password))
            {
                if (String.IsNullOrWhiteSpace(xx.Vername))
                {
                    MessageBox.Show(Properties.Resources.LGN_VERSION_NOSELECT, Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                T_USER user = null;

                try
                {
                    using (var context = new commondbcontext())
                    {
                        user = context.T_USERS.AsNoTracking().FirstOrDefault(r => r.USERID == userid && r.PASSWORD == password);

                        if (user != null)
                        {
                            if ((user.ROLE + "").Trim() == "X" || (user.ROLE + "").Trim() == "x" || (user.ROLE + "").Trim() == "ｘ")
                            {
                                MessageBox.Show("当ユーザーIDは次期マルスツールへのアクセス権限がありません", Properties.Resources.ATTENTION, System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                                return;
                            }
                        }
                        else
                        {
                            logger.Info($"{userid} ログイン 失敗");
                        }

                    }
                }
                catch (Exception exp)
                {
                    MessageBox.Show("DBエラーが発生しました", Properties.Resources.ERROR, System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    logger.Error(exp,"Login DBエラー");
                    return;
                }


                if (user != null)
                {

                    Dictionary<string, List<string>> pri = null;

                    try
                    {
                        pri = Fct.getPRI();
                    }
                    catch (Exception exp)
                    {
                        MessageBox.Show(exp.Message, Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    xx.setDBContext(new mysqlcontext(xx.ConnectString), user, pri);

                    if (xx.context.Database.Exists())
                    {
                        logger.Info($"{userid} ログイン 成功");
                        MarsTool.MainForm mf = new MarsTool.MainForm(xx);
                        mf.Show(this);
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("選択した世代DBへアクセスできません。", Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    MessageBox.Show(Properties.Resources.LGN_PWD_WRONG, Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show(Properties.Resources.LGN_UIDPWD_EMPTY, Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

        }


        public void resetUI()
        {
            this.userid.Text = "";
            this.password.Text = "";
            this.comboBox1.SelectedIndex = 0;
        }

        private void Login_Load(object sender, EventArgs e)
        {

            List<VersionModel> res = new List<VersionModel>();
            res.Add(new VersionModel());

            try
            {
                res.AddRange(Fct.getAllVersion());
            }
            catch
            {
                MessageBox.Show("世代管理コンフィグファイルの中身は不正", Properties.Resources.ATTENTION, System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
            }

            this.comboBox1.DataSource = res;
            this.comboBox1.DisplayMember = "Vername";

        }

        private void Login_VisibleChanged(object sender, EventArgs e)
        {
            resetUI();
        }

        private NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

    }
}
