﻿using MarsTool.LGC;
using MarsTool.Models;
using MarsTool.Models.DB;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarsTool
{
    public partial class MForm : Form
    {
        /// <summary>
        /// 一番目の情報部のX座標
        /// </summary>
        public const int X_Start = 5;
        /// <summary>
        /// 一番目の情報部のY座標
        /// </summary>
        public const int Y_Start = 56;
        /// <summary>
        /// 情報部の広さ
        /// </summary>
        public const int W = 72;
        /// <summary>
        /// 情報部の高さ
        /// </summary>
        public const int H = 72;
        /// <summary>
        /// 属性の高さ
        /// </summary>
        public const int PH = 30;

        private ViewPattern jnPattern = null;

        private Color bkgColor = Color.FromArgb(223, 229, 219);

        private Dictionary<Button, ViewInfoBlock> dic = new Dictionary<Button, ViewInfoBlock>();
        private Dictionary<string, Models.DB.T_CPYPHY> quickDic = new Dictionary<string, Models.DB.T_CPYPHY>();

        private NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        private VersionModel version;

        public MForm(string value, VersionModel p)
        {
            InitializeComponent();
            jnPattern = new ViewPattern();
            jnPattern.JN_INFOBLOCKS = new List<ViewInfoBlock>();
            jnPattern.JN_PATTERNID = value;
            version = p;
        }

        public MForm()
        {
            InitializeComponent();
            jnPattern = new ViewPattern();
            jnPattern.JN_INFOBLOCKS = new List<ViewInfoBlock>();
        }

        /// <summary>
        /// 情報部追加
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            //right click no effect
            var xx = e as MouseEventArgs;
            if (xx != null && xx.Button == MouseButtons.Right)
                return;

            if (dic.Count >= 44)
                return;

            InfoblockSearch f = new InfoblockSearch(version);
            if (f.ShowDialog(this) == DialogResult.OK)
            {

                Button bt = new Button();
                bt.Text = f.infoBlock.CPYPHY_BCPNM;

                bt.Height = H;
                bt.Width = W;

                bt.Left = pictureBox1.Left;

                bt.Top = Y_Start;
                bt.FlatStyle = FlatStyle.Flat;
                bt.FlatAppearance.BorderSize = 1;

                //mouse over color
                bt.FlatAppearance.MouseOverBackColor = bkgColor;

                bt.Click += btclick;
                bt.MouseDown += btmd;
                bt.MouseUp += btmu;
                bt.MouseMove += btmov;

                //bt.ContextMenu = ctm;

                pictureBox1.Left += bt.Width - 1;

                this.panel1.Controls.Add(bt);
                ViewInfoBlock tmpblock = new ViewInfoBlock { JN_NAME = bt.Text, JN_SIZE = f.infoBlock.CPYPHY_SIZE, JN_INTERFACEID = f.infoBlock.CPYPHY_INFOID };
                jnPattern.JN_INFOBLOCKS.Add(tmpblock);
                dic.Add(bt, tmpblock);
                this.panel1.Refresh();

                //削除された物理コピー句を使う時、ジャーナルパターンを未使用に変更する
                if (f.infoBlock.CPYPHY_STATUS == Common.ConstantUtils.STATUS_DELELTE)
                {
                    if (this.inuse.Checked && MessageBox.Show("選択した情報部は論理削除されたので、ジャーナルパターンを「未使用」に変更しますか？", Properties.Resources.ATTENTION, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
                    {
                        this.obsolete.PerformClick();
                    }

                }

            }
            else
            {

            }
            f.Dispose();

        }

        private Control clickedcontrol;
        private Point previousLocation;
        //button mouse up
        private void btmu(object sender, MouseEventArgs e)
        {
            this.ActiveControl = null;
            clickedcontrol = null;
            var tmplst = dic.Keys.OrderBy(r => r.Left);
            int tmpleft = X_Start;
            foreach (var tmp in tmplst)
            {
                tmp.Left = tmpleft + this.panel1.AutoScrollPosition.X;
                tmp.Top = Y_Start;
                tmpleft += tmp.Width - 1;
            }
            this.panel1.Refresh();
            Cursor.Clip = Rectangle.Empty;
        }
        //button mouse down
        private void btmd(object sender, MouseEventArgs e)
        {
            //Ctrl
            if (ModifierKeys.HasFlag(Keys.Control))
            {
                ((Button)sender).BackColor = bkgColor;
            }
            else if (ModifierKeys.HasFlag(Keys.Shift))
            {
                ((Button)sender).BackColor = bkgColor;
            }
            else
            {
                if (((Button)sender).BackColor.ToArgb() == bkgColor.ToArgb() && e.Button == MouseButtons.Right)
                {
                }
                else
                {
                    foreach (Control tmp in this.panel1.Controls)
                    {
                        if (tmp is Button)
                        {
                            tmp.BackColor = Color.White;
                        }
                    }
                    ((Button)sender).BackColor = bkgColor;
                }
            }
            if (e.Button == MouseButtons.Right)
            {
                if (this.radioButton1.Checked)
                    ctm2.Show(sender as Control, e.Location);
                else if (this.radioButton2.Checked)
                    ctm.Show(sender as Control, e.Location);
            }

            this.panel1.Controls.SetChildIndex(((Button)sender), 0);

            clickedcontrol = sender as Control;
            previousLocation = e.Location;

            if (e.Button == MouseButtons.Left)
            {
                Cursor.Clip = new Rectangle(0, Cursor.Position.Y, 4096, 1);
            }
        }

        /// <summary>
        /// 情報部の移動は固有属性、複数選択移動、MAX移動、その他の影響で、強制的に属性を削除
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btmov(object sender, MouseEventArgs e)
        {
            //属性設定モードは移動機能禁止
            if (this.radioButton2.Checked)
            {
                return;
            }

            if (clickedcontrol == null || clickedcontrol != sender || e.Button != MouseButtons.Left)
                return;

            //情報部の位置を再設定
            var location = clickedcontrol.Location;
            location.Offset(e.Location.X - previousLocation.X, e.Location.Y - previousLocation.Y);
            clickedcontrol.Location = location;
            var tmplst = dic.Keys.OrderBy(r => r.Left);
            int tmpleft = X_Start;
            foreach (var tmp in tmplst)
            {
                if (tmp != sender)
                {
                    tmp.Left = tmpleft + this.panel1.AutoScrollPosition.X;
                    tmpleft += tmp.Width - 1;
                }
                else
                {
                    //tmp.Top = Y_Start;
                    tmpleft += tmp.Width - 1;
                }
            }
            this.panel1.Refresh();
        }

        /// <summary>
        /// 情報部をクリックする時の処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btclick(object sender, EventArgs e)
        {
            //((Button)sender).BackColor = Color.FromArgb(223, 229, 219);
            //this.ActiveControl = null;
        }

        private ContextMenu ctm = null;
        private ContextMenu ctm2 = null;

        private void MForm_Load(object sender, EventArgs e)
        {
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            this.Location = new Point(40, 20);
            this.pictureBox1.Left = X_Start;
            this.pictureBox1.Top = Y_Start;
            ctm = new ContextMenu();
            ctm2 = new ContextMenu();

            MenuItem m9 = new MenuItem(Properties.Resources.CONTROLTEXT_JNL_INFOSEGDEL, m9click); ;
            MenuItem m100 = new MenuItem(Properties.Resources.CONTROLTEXT_JNL_INFOSEGDETAIL, m10click);

            //属性設定モードのメニュー設定
            ctm.MenuItems.Add(Properties.Resources.JNL_L1, p1set);
            ctm.MenuItems.Add(Properties.Resources.JNL_L2, p2set);
            ctm.MenuItems.Add(Properties.Resources.JNL_L3, p3set);
            ctm.MenuItems.Add(Properties.Resources.JNL_L4, p4set);
            ctm.MenuItems.Add(Properties.Resources.JNL_L5, p5set);
            ctm.MenuItems.Add(Properties.Resources.CONTROLTEXT_JNL_KY, m9_1click);
            ctm.MenuItems.Add(Properties.Resources.CONTROLTEXT_JNL_INFOSEGDETAIL, m10click);

            //構成設定モードのメニュー設定
            ctm2.MenuItems.Add(m9);
            ctm2.MenuItems.Add(m100);

            this.panel1.Paint += paint;

            try
            {
                if (jnPattern.JN_PATTERNID != null)
                {
                    var jp = version.context.V_JNPT.AsNoTracking().FirstOrDefault(r => r.JNL_PATTERNID == jnPattern.JN_PATTERNID);
                    if (jp != null)
                    {
                        jnPattern.JN_ANS = jp.JNL_ANS;
                        jnPattern.JN_COMMNENT = jp.JNL_COMMNENT;
                        jnPattern.JN_CUPID = jp.JNL_CUPID;
                        jnPattern.JN_OPTYPE = jp.JNL_OPTYPE;
                        jnPattern.JN_PATTERNNO = jp.JNL_PATTERNNO;
                        jnPattern.JN_TYPE = jp.JNL_TYPE;
                        jnPattern.Enabled = jp.JNL_ENABLEFLG;
                        jnPattern.JN_SUBORDER = jp.JNL_SUBORDER;
                        jnPattern.DT = jp.JNL_UPDTIME;
                        foreach (var tmp in jp.JNL_INFOBLOCKS.OrderBy(r => r.JNL_ORDER))
                        {
                            jnPattern.JN_INFOBLOCKS.Add(new ViewInfoBlock
                            {
                                JN_INTERFACEID = tmp.JNL_INFOID,
                                JN_PATTERNID = tmp.JNL_PATTERNID,
                                JN_PROPERTY2 = tmp.JNL_PROPERTY2,
                                JN_PROPERTY3 = tmp.JNL_PROPERTY3,
                                JN_PROPERTY4 = tmp.JNL_PROPERTY4,
                                JN_PROPERTY5 = tmp.JNL_PROPERTY5,
                                JN_REQRESFLG = tmp.JNL_REQRESFLG,
                                JN_SIZE = tmp.JNL_SIZE,
                                JN_ORDER = tmp.JNL_ORDER,
                                JN_NAME = tmp.JNL_NAME,
                                INHERENTPROPERTY = tmp.JNL_INHERENT
                            });
                        }
                    }
                }
            }
            catch (Exception exp)
            {
                logger.Error(exp, Properties.Resources.DBERROR);
                MessageBox.Show(Properties.Resources.DBERROR_FORM_NOOPEN, Properties.Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Dispose();
            }

            this.textBox5.Text = jnPattern.JN_ANS;

            this.textBox7.Text = jnPattern.JN_COMMNENT;
            this.textBox6.Text = jnPattern.JN_OPTYPE;

            this.textBox2.Text = jnPattern.JN_CUPID;
            this.textBox3.Text = jnPattern.JN_PATTERNNO;
            this.textBox4.Text = jnPattern.JN_TYPE;
            this.textBox8.Text = jnPattern.JN_SUBORDER;

            if (jnPattern.Enabled == 0)
            {
                this.obsolete.Checked = true;
            }
            else if (jnPattern.Enabled == 1)
            {
                this.inuse.Checked = true;
            }
            else
            {
                this.rdoBlank.Checked = true;

                setLost();
            }

            foreach (var tmp in jnPattern.JN_INFOBLOCKS)
            {
                Button bt = new Button();

                if (String.IsNullOrWhiteSpace(tmp.JN_NAME))
                {
                    bt.Text = tmp.JN_INTERFACEID + "\n" + Properties.Resources.JNL_INTERFACENOTREGISTER_HINTTEXT;
                    bt.ForeColor = Color.Red;
                }
                else
                {
                    bt.Text = tmp.JN_NAME;
                }

                bt.Height = H;
                bt.Width = W;

                bt.Left = pictureBox1.Left;

                bt.Top = Y_Start;
                bt.FlatStyle = FlatStyle.Flat;
                bt.FlatAppearance.BorderSize = 1;
                bt.FlatAppearance.BorderColor = Color.Black;

                //mouse over color
                bt.FlatAppearance.MouseOverBackColor = bkgColor;

                bt.Click += btclick;
                bt.MouseDown += btmd;
                bt.MouseUp += btmu;
                bt.MouseMove += btmov;

                bt.ContextMenu = ctm;
                pictureBox1.Left += bt.Width - 1;

                this.panel1.Controls.Add(bt);
                dic.Add(bt, tmp);
            }

            var data = dic.OrderBy(r => r.Key.Left).ToList();
            setStringList(data);

            //編集のTABを選択
            this.tabControl1.SelectedTab = this.tabPage2;

            if (!version.hasSubsysModifyPrivilege("JM"))
            {
                this.groupBox1.Enabled = false;
                this.button1.Enabled = false;
                this.radioButton1.Enabled = false;
                this.radioButton2.Enabled = false;
                foreach (var tmpbt in dic)
                {
                    tmpbt.Key.Enabled = false;
                }
                this.pictureBox1.Enabled = false;
                this.hintlbl.Text = "ジャーナルの編集権限がありません";
            }
            else
            {
                logger.Info($"{version.User.USERID} ジャーナル編集開始");
            }

        }

        private void p1set(object sender, EventArgs e)
        {
            L1FM f = new L1FM();
            var res = f.ShowDialog(this);
            string xx = null;
            if (res == DialogResult.Ignore)
            {
                xx = f.ResultString;

                //選択しない場合、設定しないこと
                if (xx == null)
                {
                    return;
                }
            }
            else
                return;

            //選択した情報部の数を計算
            int totalCnt = 0;
            foreach (var s in dic.Keys)
            {
                if (s.BackColor.ToArgb() == bkgColor.ToArgb())
                {
                    totalCnt++;
                }
            }

            if (totalCnt >= 1)
            {
                foreach (var s in dic.Keys)
                {
                    if (s.BackColor.ToArgb() == bkgColor.ToArgb())
                    {
                        if (!String.IsNullOrWhiteSpace(xx))
                        {
                            if (dic.ContainsKey(s))
                            {
                                dic[s].JN_PROPERTY3 = xx.Trim();
                            }

                        }
                        else
                        {
                            if (dic.ContainsKey(s))
                            {
                                dic[s].JN_PROPERTY3 = null;
                            }
                        }
                    }
                }

                this.panel1.Refresh();
            }
        }
        private void p2set(object sender, EventArgs e)
        {
            ImportantFM f = new ImportantFM(Properties.Resources.JNL_L2);
            var res = f.ShowDialog(this);
            string xx = null;
            if (res == DialogResult.Ignore)
            {
                xx = f.textBox1.Text;
            }
            else
                return;

            //選択した情報部の数を計算
            int totalCnt = 0;
            foreach (var s in dic.Keys)
            {
                if (s.BackColor.ToArgb() == bkgColor.ToArgb())
                {
                    totalCnt++;
                }
            }

            if (totalCnt >= 1)
            {
                foreach (var s in dic.Keys)
                {
                    if (s.BackColor.ToArgb() == bkgColor.ToArgb())
                    {
                        if (!String.IsNullOrWhiteSpace(xx))
                        {
                            if (dic.ContainsKey(s))
                            {
                                dic[s].JN_PROPERTY4 = xx.Trim();
                            }

                        }
                        else
                        {
                            if (dic.ContainsKey(s))
                            {
                                dic[s].JN_PROPERTY4 = null;
                            }
                        }
                    }
                }

                this.panel1.Refresh();
            }
        }
        private void p3set(object sender, EventArgs e)
        {
            ImportantFM f = new ImportantFM(Properties.Resources.JNL_L3);
            var res = f.ShowDialog(this);
            string xx = null;
            if (res == DialogResult.Ignore)
            {
                xx = f.textBox1.Text;
            }
            else
                return;

            //選択した情報部の数を計算
            int totalCnt = 0;
            foreach (var s in dic.Keys)
            {
                if (s.BackColor.ToArgb() == bkgColor.ToArgb())
                {
                    totalCnt++;
                }
            }

            if (totalCnt >= 1)
            {
                foreach (var s in dic.Keys)
                {
                    if (s.BackColor.ToArgb() == bkgColor.ToArgb())
                    {
                        if (!String.IsNullOrWhiteSpace(xx))
                        {
                            if (dic.ContainsKey(s))
                            {
                                dic[s].JN_REQRESFLG = xx.Trim();
                            }

                        }
                        else
                        {
                            if (dic.ContainsKey(s))
                            {
                                dic[s].JN_REQRESFLG = null;
                            }
                        }
                    }
                }

                this.panel1.Refresh();
            }
        }
        private void p4set(object sender, EventArgs e)
        {
            ImportantFM f = new ImportantFM(Properties.Resources.JNL_L4);
            var res = f.ShowDialog(this);
            string xx = null;
            if (res == DialogResult.Ignore)
            {
                xx = f.textBox1.Text;
            }
            else
                return;

            //選択した情報部の数を計算
            int totalCnt = 0;
            foreach (var s in dic.Keys)
            {
                if (s.BackColor.ToArgb() == bkgColor.ToArgb())
                {
                    totalCnt++;
                }
            }

            if (totalCnt >= 1)
            {
                foreach (var s in dic.Keys)
                {
                    if (s.BackColor.ToArgb() == bkgColor.ToArgb())
                    {
                        if (!String.IsNullOrWhiteSpace(xx))
                        {
                            if (dic.ContainsKey(s))
                            {
                                dic[s].JN_PROPERTY2 = xx.Trim();
                            }

                        }
                        else
                        {
                            if (dic.ContainsKey(s))
                            {
                                dic[s].JN_PROPERTY2 = null;
                            }
                        }
                    }
                }

                //update string list
                var data = dic.OrderBy(r => r.Key.Left).ToList();
                setStringList(data);

                this.panel1.Refresh();
            }
        }
        private void p5set(object sender, EventArgs e)
        {
            ImportantFM f = new ImportantFM(Properties.Resources.JNL_L5);
            var res = f.ShowDialog(this);
            string xx = null;
            int cnt = 0;
            if (res == DialogResult.Ignore)
            {
                xx = f.textBox1.Text;
                if (!int.TryParse(xx, out cnt))
                {
                    MessageBox.Show("レベル５属性は半角整数に設定してください", Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

            }
            else
                return;

            //選択した情報部の数を計算
            int totalCnt = 0;
            foreach (var s in dic.Keys)
            {
                if (s.BackColor.ToArgb() == bkgColor.ToArgb())
                {
                    totalCnt++;
                }
            }

            if (totalCnt >= 1)
            {
                foreach (var s in dic.Keys)
                {
                    if (s.BackColor.ToArgb() == bkgColor.ToArgb())
                    {
                        if (!String.IsNullOrWhiteSpace(xx))
                        {
                            if (dic.ContainsKey(s))
                            {
                                dic[s].JN_PROPERTY5 = $"MAX({cnt})";
                            }

                        }
                        else
                        {
                            if (dic.ContainsKey(s))
                            {
                                dic[s].JN_PROPERTY5 = null;
                            }
                        }
                    }
                }

                this.panel1.Refresh();
            }
        }

        /// <summary>
        /// 固有属性設定
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void m9_1click(object sender, EventArgs e)
        {
            ImportantFM f = new ImportantFM("");
            var res = f.ShowDialog(this);
            string xx = null;
            if (res == DialogResult.Ignore)
            {
                xx = f.textBox1.Text;
            }
            else
                return;

            //選択した情報部の数を計算
            int totalCnt = 0;
            foreach (var s in dic.Keys)
            {
                if (s.BackColor.ToArgb() == bkgColor.ToArgb())
                {
                    totalCnt++;
                }
            }

            if (totalCnt == 1)
            {
                Button tmp = null;
                foreach (var s in dic.Keys)
                {
                    if (s.BackColor.ToArgb() == bkgColor.ToArgb())
                    {
                        if (!String.IsNullOrWhiteSpace(xx))
                        {
                            if (dic.ContainsKey(s))
                            {
                                dic[s].INHERENTPROPERTY = xx.Trim();
                                tmp = s;
                                break;
                            }

                        }
                        else
                        {
                            if (dic.ContainsKey(s))
                            {
                                dic[s].INHERENTPROPERTY = null;
                                tmp = s;
                                break;
                            }
                        }
                    }
                }

                var data = dic.OrderBy(r => r.Key.Left).ToList();
                setStringList(data);

                this.panel1.Refresh();
            }
            else
            {
                MessageBox.Show("固有属性の設定は１個だけの情報部に対する操作です", Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        /// <summary>
        /// 情報部詳細を確認する画面を開く
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void m10click(object sender, EventArgs e)
        {
            // 選択した情報部の数を計算
            int totalCnt = 0;
            Button key = null;
            foreach (var s in dic.Keys)
            {
                if (s.BackColor.ToArgb() == bkgColor.ToArgb())
                {
                    key = s;
                    totalCnt++;
                }
            }

            if (totalCnt == 1)
            {
                string infoid = dic[key].JN_INTERFACEID;
                T_PHYITM res = version.context.T_PHYITM.FirstOrDefault(r => r.PHYITM_INFOID == infoid);
                if (res != null)
                {
                    Interface form = new Interface(res, version, "JNL");
                    form.ShowDialog(this);
                }
                else
                {
                    MessageBox.Show("該当情報部の「アイテム構成図・説明書参照」情報はありません", Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

            }
            else
            {
                MessageBox.Show("複数の情報部の「アイテム構成図・説明書参照」を確認できません", Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }


        }

        /// <summary>
        /// 情報部の削除
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void m9click(object sender, EventArgs e)
        {
            var itm = sender as MenuItem;
            var p1 = itm.Parent as ContextMenu;
            var s = p1.SourceControl as Button;

            // 選択した情報部の数を計算
            int totalCnt = 0;
            foreach (var t in dic.Keys)
            {
                if (t.BackColor.ToArgb() == bkgColor.ToArgb())
                {
                    totalCnt++;
                }
            }

            if (totalCnt != 1)
            {
                MessageBox.Show("一つの情報部を選択して削除してください", Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (dic.ContainsKey(s))
            {
                jnPattern.JN_INFOBLOCKS.Remove(dic[s]);
                dic.Remove(s);
                this.panel1.Controls.Remove(s);

                var tmplst = dic.Keys.OrderBy(r => r.Left);
                int tmpleft = X_Start;
                foreach (var tmp in tmplst)
                {
                    tmp.Left = tmpleft + this.panel1.AutoScrollPosition.X;
                    tmp.Top = Y_Start;
                    tmpleft += tmp.Width - 1;
                }
                this.pictureBox1.Left = this.pictureBox1.Left - (s.Width - 1);
                this.panel1.Refresh();
            }
        }

        /// <summary>
        /// 先乗列車、後乗列車、区間１、区間２など
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void m6click(object sender, EventArgs e)
        {
            var tmplst = new List<string>();
            tmplst.AddRange(p2dic.Keys.Where(r => !(r + "").Contains("INHERENTPROPERTY:")));
            OtherFM f = new OtherFM(tmplst);
            var res = f.ShowDialog(this);
            string xx = null;
            if (res == DialogResult.Yes)
            {
                xx = f.comboBox1.SelectedItem as string;
            }
            else if (res == DialogResult.Ignore)
            {
                xx = f.textBox1.Text;
            }
            else
            {
                return;
            }

            foreach (var s in dic.Keys)
            {
                if (s.BackColor.ToArgb() == bkgColor.ToArgb())
                {
                    if (!String.IsNullOrWhiteSpace(xx))
                    {
                        if (dic.ContainsKey(s))
                        {
                            dic[s].JN_PROPERTY2 = xx.Trim();
                        }
                    }
                    else
                    {
                        if (dic.ContainsKey(s))
                        {
                            dic[s].JN_PROPERTY2 = null;
                        }
                    }
                }
            }

            //update string list
            var data = dic.OrderBy(r => r.Key.Left).ToList();
            setStringList(data);

            this.panel1.Refresh();
        }

        /// <summary>
        /// 重複設定
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void m5click(object sender, EventArgs e)
        {
            RepeatFM f = new RepeatFM();
            if (f.ShowDialog(this) == DialogResult.OK)
            {
                string xx = f.textBox1.Text.Trim();
                var itm = sender as MenuItem;

                int count = 0;

                foreach (var s in dic.Keys)
                {
                    if (s.BackColor.ToArgb() == bkgColor.ToArgb())
                    {
                        count++;
                    }
                }

                foreach (var s in dic.Keys)
                {
                    if (s.BackColor.ToArgb() == bkgColor.ToArgb())
                    {
                        if (xx == "1" || xx == "0" || xx == "")
                        {
                            dic[s].JN_PROPERTY5 = null;
                        }
                        else
                        {
                            if (count > 1)
                            {
                                dic[s].JN_PROPERTY5 = "*MAX(" + xx + ")";
                            }
                            else
                            {
                                dic[s].JN_PROPERTY5 = "MAX(" + xx + ")";
                            }

                        }
                    }
                }

                this.panel1.Refresh();
            }
            else
            {

            }
            f.Dispose();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="g"></param>
        /// <param name="content"></param>
        /// <param name="x">文字の中央点</param>
        /// <param name="y">文字の中央点</param>
        private void drawText(Graphics g, string content, float x, float y)
        {
            if (content == null) content = "";

            Font stringFont = new Font("MS UI Gothic", 9);

            // Measure string.
            SizeF stringSize = new SizeF();
            stringSize = g.MeasureString(content, stringFont);

            float a = x - stringSize.Width / 2 - 2;
            float b = y - stringSize.Height / 2;

            // Draw rectangle representing size of string.
            g.FillRectangle(Brushes.White, a, b, stringSize.Width + 4, stringSize.Height);

            // Draw string to screen.
            g.DrawString(content, stringFont, Brushes.Black, new PointF(a + 2F, b + 2F));

            stringFont.Dispose();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="g"></param>
        /// <param name="content"></param>
        /// <param name="x">文字の中央点</param>
        /// <param name="y">文字の中央点</param>
        private void drawSize(Graphics g, string content, float x, float y)
        {
            if (String.IsNullOrWhiteSpace(content)) content = "??";

            Font stringFont = new Font("MS UI Gothic", 9);

            // Measure string.
            SizeF stringSize = new SizeF();
            stringSize = g.MeasureString(content, stringFont);

            float a = x - stringSize.Width / 2 - 2;
            float b = y - stringSize.Height / 2;

            // Draw rectangle representing size of string.
            g.FillRectangle(Brushes.White, a, b, stringSize.Width + 4, stringSize.Height);

            // Draw string to screen.
            g.DrawString(content, stringFont, Brushes.Black, new PointF(a + 2F, b + 2F));

            stringFont.Dispose();
        }


        //その他情報文字列を保存するため
        private Dictionary<string, int> p2dic = new Dictionary<string, int>();

        /// <summary>
        /// サイズ、要求/回答、予約/解約などの属性描き
        /// 
        /// paintで線、文字の描きより、完全的にControlの追加で対応する
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void paint(object sender, PaintEventArgs e)
        {
            Pen clear_flight_line_pen = new Pen(System.Drawing.Color.Black, 1);
            Pen dashpen = new Pen(System.Drawing.Color.Black, 1);
            dashpen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dot;
            Graphics formGraphics = e.Graphics;

            var data = dic.OrderBy(r => r.Key.Left).ToList();


            if (data.Count > 0)
            {

                //サイズ情報
                for (int i = 0; i < data.Count; i++)
                {
                    formGraphics.DrawLine(clear_flight_line_pen,
                        data[i].Key.Left,
                        data[i].Key.Height + Y_Start,
                        data[i].Key.Left,
                        data[i].Key.Height + Y_Start + PH);
                    formGraphics.DrawLine(clear_flight_line_pen,
                        data[i].Key.Left + data[i].Key.Width - 1,
                        data[i].Key.Height + Y_Start,
                        data[i].Key.Left + data[i].Key.Width - 1,
                        data[i].Key.Height + Y_Start + PH);
                    formGraphics.DrawLine(clear_flight_line_pen,
                        data[i].Key.Left,
                        data[i].Key.Height + Y_Start + PH / 2,
                        data[i].Key.Left + data[i].Key.Width - 1,
                        data[i].Key.Height + Y_Start + PH / 2);

                    drawSize(formGraphics, data[i].Value.JN_SIZE.ToString(), data[i].Key.Left + (data[i].Key.Width - 1) / 2, data[i].Key.Height + Y_Start + PH / 2);

                }

                bool P34Flag = false;
                bool P4Flag = false;
                bool P2Flag = false;
                bool ReqResFlag = false;
                int offset = 0;

                //Property 3
                for (int i = 0; i < data.Count; i++)
                {
                    if (!String.IsNullOrWhiteSpace(data[i].Value.JN_PROPERTY3))
                    {
                        if (i >= 1 && data[i].Value.JN_PROPERTY3 == data[i - 1].Value.JN_PROPERTY3)
                        {
                            //already set .
                        }
                        else
                        {
                            int endblock = 0;
                            for (int k = i + 1; k < data.Count; k++)
                            {
                                if (data[i].Value.JN_PROPERTY3 != data[k].Value.JN_PROPERTY3)
                                {
                                    endblock = k - i - 1;
                                    break;
                                }
                                if (k == data.Count - 1)
                                {
                                    endblock = k - i;
                                }
                            }
                            formGraphics.DrawLine(clear_flight_line_pen,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH + PH);
                            formGraphics.DrawLine(clear_flight_line_pen,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH + PH);
                            formGraphics.DrawLine(clear_flight_line_pen,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH + PH / 2,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH + PH / 2);

                            drawText(formGraphics,
                                data[i].Value.JN_PROPERTY3,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1) / 2,
                                data[i].Key.Height + Y_Start + PH + PH / 2);

                            P34Flag = true;
                        }
                    }
                }
                if (P34Flag)
                {
                    offset = offset + PH;
                }

                //Property 4
                for (int i = 0; i < data.Count; i++)
                {
                    if (!String.IsNullOrWhiteSpace(data[i].Value.JN_PROPERTY4))
                    {
                        if (i >= 1 && data[i].Value.JN_PROPERTY4 == data[i - 1].Value.JN_PROPERTY4)
                        {
                            //already set .
                        }
                        else
                        {
                            int endblock = 0;
                            for (int k = i + 1; k < data.Count; k++)
                            {
                                if (data[i].Value.JN_PROPERTY4 != data[k].Value.JN_PROPERTY4)
                                {
                                    endblock = k - i - 1;
                                    break;
                                }
                                if (k == data.Count - 1)
                                {
                                    endblock = k - i;
                                }
                            }
                            formGraphics.DrawLine(clear_flight_line_pen,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH + offset,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset);
                            formGraphics.DrawLine(clear_flight_line_pen,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH + offset,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset);
                            formGraphics.DrawLine(clear_flight_line_pen,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset);

                            drawText(formGraphics,
                                data[i].Value.JN_PROPERTY4,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1) / 2,
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset);

                            P4Flag = true;
                        }
                    }
                }
                if (P4Flag)
                {
                    offset = offset + PH;
                }

                //要求回答
                for (int i = 0; i < data.Count; i++)
                {
                    if (!String.IsNullOrWhiteSpace(data[i].Value.JN_REQRESFLG))
                    {
                        if (i >= 1 && data[i].Value.JN_REQRESFLG == data[i - 1].Value.JN_REQRESFLG)
                        {
                            //already set .
                        }
                        else
                        {
                            int endblock = 0;
                            for (int k = i + 1; k < data.Count; k++)
                            {
                                if (data[i].Value.JN_REQRESFLG != data[k].Value.JN_REQRESFLG)
                                {
                                    endblock = k - i - 1;
                                    break;
                                }
                                if (k == data.Count - 1)
                                {
                                    endblock = k - i;
                                }
                            }
                            ReqResFlag = true;
                            formGraphics.DrawLine(clear_flight_line_pen,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH + offset,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset);
                            formGraphics.DrawLine(clear_flight_line_pen,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH + offset,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset);
                            formGraphics.DrawLine(clear_flight_line_pen,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset);

                            drawText(formGraphics,
                                data[i].Value.JN_REQRESFLG,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1) / 2,
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset);
                        }
                    }
                }
                if (ReqResFlag)
                {
                    offset = offset + PH;
                }

                //Property 2
                for (int i = 0; i < data.Count; i++)
                {
                    if (!String.IsNullOrWhiteSpace(data[i].Value.JN_PROPERTY2))
                    {
                        if (i >= 1 && data[i].Value.JN_PROPERTY2 == data[i - 1].Value.JN_PROPERTY2)
                        {
                            //already set .
                        }
                        else
                        {
                            int endblock = 0;
                            for (int k = i + 1; k < data.Count; k++)
                            {
                                if (data[i].Value.JN_PROPERTY2 != data[k].Value.JN_PROPERTY2)
                                {
                                    endblock = k - i - 1;
                                    break;
                                }
                                if (k == data.Count - 1)
                                {
                                    endblock = k - i;
                                }
                            }

                            P2Flag = true;

                            formGraphics.DrawLine(clear_flight_line_pen,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH + offset,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset);
                            formGraphics.DrawLine(clear_flight_line_pen,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH + offset,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset);
                            formGraphics.DrawLine(clear_flight_line_pen,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset);

                            drawText(formGraphics,
                                "* " + p2dic[data[i].Value.JN_PROPERTY2],
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1) / 2,
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset);
                        }
                    }
                }

                if (P2Flag)
                {
                    offset = offset + PH;
                }

                //Property 5
                for (int i = 0; i < data.Count; i++)
                {
                    if (!String.IsNullOrWhiteSpace(data[i].Value.JN_PROPERTY5))
                    {
                        if (i >= 1 && data[i].Value.JN_PROPERTY5 == data[i - 1].Value.JN_PROPERTY5)
                        {
                            //already set .
                        }
                        else
                        {
                            int endblock = 0;
                            //if (data[i].Value.JN_PROPERTY5.StartsWith("*"))
                            //{
                            for (int k = i + 1; k < data.Count; k++)
                            {
                                if (data[k].Value.JN_PROPERTY5 != data[i].Value.JN_PROPERTY5)
                                {
                                    endblock = k - i - 1;
                                    break;
                                }
                                if (k == data.Count - 1)
                                {
                                    endblock = k - i;
                                }
                            }
                            //}
                            formGraphics.DrawLine(clear_flight_line_pen,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH + offset,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset);
                            formGraphics.DrawLine(clear_flight_line_pen,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH + offset,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset);
                            formGraphics.DrawLine(clear_flight_line_pen,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset);

                            drawText(formGraphics,
                                data[i].Value.JN_PROPERTY5,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1) / 2,
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset);
                        }

                    }
                }

                //P2 text
                if (p2dic.Count > 0)
                {
                    Font stringFont = new Font("MS UI Gothic", 9);

                    // Measure string.
                    SizeF s = new SizeF();

                    int tmpcnt = 0;
                    float tmpmaxwidth = 0;

                    var lst = p2dic.OrderBy(r => r.Value);
                    float tmpx = data[0].Key.Left;
                    float tmpy = 320;
                    foreach (var t in lst)
                    {
                        s = formGraphics.MeasureString("* " + t.Value + " : " + c(t.Key), stringFont);

                        if (s.Width > tmpmaxwidth)
                            tmpmaxwidth = s.Width;

                        formGraphics.DrawString("* " + t.Value + " : " + c(t.Key), stringFont, Brushes.Black, tmpx, tmpy);
                        tmpy += s.Height;
                        tmpcnt++;
                        if (tmpcnt % 4 == 0)
                        {
                            tmpy = 320;
                            tmpx = tmpx + tmpmaxwidth + 10;
                            tmpmaxwidth = 0;
                        }
                    }
                    stringFont.Dispose();
                }
            }

            clear_flight_line_pen.Dispose();
            dashpen.Dispose();
            formGraphics.Dispose();
        }

        private string c(string p)
        {
            int location = p.IndexOf("INHERENTPROPERTY:");
            if (location >= 0)
            {
                return p.Substring(location + "INHERENTPROPERTY:".Length);
            }
            else
            {
                return p;
            }
        }

        /// <summary>
        /// 文字列辞典
        /// </summary>
        /// <param name="data"></param>
        private void setStringList(List<KeyValuePair<Button, ViewInfoBlock>> p)
        {
            if (p == null || p.Count == 0) return;

            p2dic.Clear();

            for (int i = 0; i < p.Count; i++)
            {
                //PROPERTY2の設定
                if (!String.IsNullOrWhiteSpace(p[i].Value.JN_PROPERTY2))
                {
                    if (p2dic.Any(r => r.Key == p[i].Value.JN_PROPERTY2))
                    {
                        //do nothing
                    }
                    else
                    {
                        if (p2dic.Count == 0)
                            p2dic.Add(p[i].Value.JN_PROPERTY2, 1);
                        else
                            p2dic.Add(p[i].Value.JN_PROPERTY2, p2dic.Values.Max() + 1);
                    }
                }
            }

            //固有情報の辞典設定
            for (int i = 0; i < p.Count; i++)
            {
                if (!String.IsNullOrWhiteSpace(p[i].Value.INHERENTPROPERTY))
                {
                    if (p2dic.Count == 0)
                    {
                        p2dic.Add(i + "INHERENTPROPERTY:" + p[i].Value.INHERENTPROPERTY, 1);
                        int lastlocation = p[i].Key.Text.LastIndexOf(" *");

                        if (lastlocation > -1)
                        {
                            int restint = 0;
                            string resstr = p[i].Key.Text.Substring(lastlocation + 2);
                            if (int.TryParse(resstr, out restint))
                            {
                                string ttt = p[i].Key.Text.Substring(0, p[i].Key.Text.Length - resstr.Length - 2);
                                p[i].Key.Text = ttt;
                            }
                        }

                        p[i].Key.Text = p[i].Key.Text + " *" + 1.ToString();
                    }
                    else
                    {
                        int tmpmax = p2dic.Values.Max() + 1;
                        p2dic.Add(i + "INHERENTPROPERTY:" + p[i].Value.INHERENTPROPERTY, tmpmax);
                        int lastlocation = p[i].Key.Text.LastIndexOf(" *");

                        if (lastlocation > -1)
                        {
                            int restint = 0;
                            string resstr = p[i].Key.Text.Substring(lastlocation + 2);
                            if (int.TryParse(resstr, out restint))
                            {
                                string ttt = p[i].Key.Text.Substring(0, p[i].Key.Text.Length - resstr.Length - 2);
                                p[i].Key.Text = ttt;
                            }
                        }
                        p[i].Key.Text = p[i].Key.Text + " *" + tmpmax.ToString();
                    }
                }
                else
                {
                    int lastlocation = p[i].Key.Text.LastIndexOf(" *");
                    if (lastlocation > -1)
                    {
                        int restint = 0;
                        string resstr = p[i].Key.Text.Substring(lastlocation + 2);
                        if (int.TryParse(resstr, out restint))
                        {
                            string ttt = p[i].Key.Text.Substring(0, p[i].Key.Text.Length - resstr.Length - 2);
                            p[i].Key.Text = ttt;
                        }
                    }
                }
            }
        }

        private void m3click(object sender, EventArgs e)
        {
            var itm = sender as MenuItem;

            foreach (var s in dic.Keys)
            {
                if (s.BackColor.ToArgb() == bkgColor.ToArgb())
                {
                    if (itm.Text == Properties.Resources.JNL_MENU_YYK || itm.Text == Properties.Resources.JNL_MENU_KYK)
                    {
                        dic[s].JN_PROPERTY3 = null;
                        dic[s].JN_PROPERTY4 = null;
                        dic[s].JN_PROPERTY3 = itm.Text;
                    }
                    else if (itm.Text == Properties.Resources.JNL_MENU_BEF || itm.Text == Properties.Resources.JNL_MENU_AFT)
                    {
                        dic[s].JN_PROPERTY3 = null;
                        dic[s].JN_PROPERTY4 = null;
                        dic[s].JN_PROPERTY4 = itm.Text.Replace("変更", "");
                    }
                    else
                    {
                        dic[s].JN_PROPERTY3 = null;
                        dic[s].JN_PROPERTY4 = null;
                    }
                }
            }

            this.panel1.Refresh();
        }

        /// <summary>
        /// 要求回答設定
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void m2click(object sender, EventArgs e)
        {
            var itm = sender as MenuItem;

            foreach (var s in dic.Keys)
            {
                if (s.BackColor.ToArgb() == bkgColor.ToArgb())
                {
                    if (itm.Text != Properties.Resources.JNL_MENU_CEL)
                    {
                        dic[s].JN_REQRESFLG = itm.Text;
                    }
                    else
                    {
                        dic[s].JN_REQRESFLG = null;
                    }
                }
            }

            this.panel1.Refresh();
        }

        //選択した情報部を設定する
        private void m11click(object sender, EventArgs e)
        {
            InfoblockSearch f = new InfoblockSearch(version);
            if (f.ShowDialog(this) == DialogResult.OK)
            {
                foreach (var s in dic.Keys)
                {
                    if (s.BackColor.ToArgb() == bkgColor.ToArgb())
                    {
                        s.Text = f.infoBlock.CPYPHY_BCPNM;
                        dic[s].JN_SIZE = f.infoBlock.CPYPHY_SIZE;
                        dic[s].JN_NAME = f.infoBlock.CPYPHY_BCPNM;
                        dic[s].JN_INTERFACEID = f.infoBlock.CPYPHY_INFOID;
                    }
                }

                this.panel1.Refresh();
            }
            else
            {

            }
            f.Dispose();
        }

        //情報部設定
        private void m1click(object sender, EventArgs e)
        {
            var itm = sender as MenuItem;

            foreach (var s in dic.Keys)
            {
                if (s.BackColor.ToArgb() == bkgColor.ToArgb())
                {
                    s.Text = quickDic[itm.Text].CPYPHY_BCPNM;
                    dic[s].JN_NAME = s.Text;
                    dic[s].JN_SIZE = quickDic[itm.Text].CPYPHY_SIZE;
                    dic[s].JN_INTERFACEID = quickDic[itm.Text].CPYPHY_INFOID;
                }
            }

            this.panel1.Refresh();
        }

        /// <summary>
        /// 属性設定モードへ切り替え
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void radioButton2_MouseDown(object sender, MouseEventArgs e)
        {
            if (!this.radioButton2.Checked)
            {
                if (MessageBox.Show(Properties.Resources.JNL_MODECHANGE_TONORMAL, Properties.Resources.ATTENTION, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
                {
                    this.radioButton2.Checked = true;


                    var data = dic.OrderBy(r => r.Key.Left).ToList();
                    setStringList(data);

                }
            }
        }


        /// <summary>
        /// 構成設定モードへ切り替え
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void radioButton1_MouseDown(object sender, MouseEventArgs e)
        {
            if (!this.radioButton1.Checked)
            {
                if (MessageBox.Show(Properties.Resources.JNL_MODECHANGE_TOA, Properties.Resources.ATTENTION, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
                {
                    this.radioButton1.Checked = true;

                    foreach (var tmp in dic)
                    {
                        tmp.Value.JN_REQRESFLG = null;
                        tmp.Value.JN_PROPERTY2 = null;
                        tmp.Value.JN_PROPERTY3 = null;
                        tmp.Value.JN_PROPERTY4 = null;
                        tmp.Value.JN_PROPERTY5 = null;
                        tmp.Value.INHERENTPROPERTY = null;
                    }

                    var data = dic.OrderBy(r => r.Key.Left).ToList();
                    setStringList(data);

                    this.panel1.Refresh();
                }
            }

        }

        /// <summary>
        /// DBにジャーナルパターン情報を保存する
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            //権限ない場合
            if (!version.hasSubsysModifyPrivilege("JM"))
            {
                return;
            }
            //save data to data base
            try
            {
                System.Text.RegularExpressions.Regex reg2 = new System.Text.RegularExpressions.Regex(@"^([0-9]+[-][0-9]+[-][0-9]+|[0-9]+[-][0-9]|[0-9]+)$", System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                jnPattern.JN_ANS = this.textBox5.Text.Trim();
                jnPattern.JN_COMMNENT = this.textBox7.Text;
                jnPattern.JN_CUPID = this.textBox2.Text.Trim();
                jnPattern.JN_OPTYPE = this.textBox6.Text;
                jnPattern.JN_PATTERNNO = this.textBox3.Text.Trim();
                jnPattern.JN_TYPE = this.textBox4.Text.Trim();
                jnPattern.JN_SUBORDER = this.textBox8.Text.Trim();
                jnPattern.USERID = version.User.USERID;

                var m2 = reg2.Match(jnPattern.JN_SUBORDER);

                if (!m2.Success)
                {
                    MessageBox.Show(Properties.Resources.JNL_PATTERNORDER_FORMAT_WRONG, Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (jnPattern.Enabled == 0 || jnPattern.Enabled == 1)
                {
                    //データチェック
                    if (jnPattern.JN_INFOBLOCKS.Count < 1)
                    {
                        MessageBox.Show(Properties.Resources.JNL_INFOBLOCKS_NO_ELEMENT, Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    if (String.IsNullOrWhiteSpace(jnPattern.JN_CUPID))
                    {
                        MessageBox.Show(Properties.Resources.JNL_CUPID_EMPTY, Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    if (String.IsNullOrWhiteSpace(jnPattern.JN_SUBORDER))
                    {
                        MessageBox.Show(Properties.Resources.JNL_PATTERNORDER_EMPTY, Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    if (String.IsNullOrWhiteSpace(jnPattern.JN_PATTERNNO))
                    {
                        MessageBox.Show(Properties.Resources.JNL_PATTERNNO_EMPTY, Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    if (String.IsNullOrWhiteSpace(jnPattern.JN_ANS))
                    {
                        MessageBox.Show(Properties.Resources.JNL_ANS_EMPTY, Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    if (String.IsNullOrWhiteSpace(jnPattern.JN_OPTYPE))
                    {
                        MessageBox.Show(Properties.Resources.JNL_OPERATION_EMPTY, Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }

                //自動採番
                if (jnPattern.JN_PATTERNID == null)
                    jnPattern.JN_PATTERNID = version.genSequenceID("T_JNLPT");

                Models.DB.T_JNLPT jp = jnPattern;

                string a = jnPattern.JN_PATTERNNO;
                string b = jnPattern.JN_ANS;
                string c = jnPattern.JN_OPTYPE;
                string ee = jnPattern.JN_CUPID;
                string ff = jnPattern.JN_TYPE;
                string odr = jnPattern.JN_SUBORDER;
                string ptid = jnPattern.JN_PATTERNID;
                string key = jnPattern.JNSEGKEY;
                int d = jnPattern.Enabled;

                var exist = version.context.T_JNPT.FirstOrDefault(r => r.JNL_PATTERNID == jnPattern.JN_PATTERNID);
                var d2 = version.context.T_JNPT.AsNoTracking().FirstOrDefault(r => r.JNL_PATTERNID == jnPattern.JN_PATTERNID);
                if (exist != null && d2 != null && DateTime.Compare(jnPattern.DT.Value, d2.JNL_UPDTIME.Value) == 0)
                {
                    T_JNLPT tmpSame = null;
                    if (jnPattern.Enabled == 2)
                    {
                        tmpSame = version.context.T_JNPT.AsNoTracking().FirstOrDefault(r => r.JNL_CUPID == ee && r.JNL_TYPE == ff && r.JNL_SUBORDER == odr && r.JNL_ENABLEFLG == d && r.JNL_PATTERNID != ptid);
                    }
                    else
                    {
                        tmpSame = version.context.T_JNPT.AsNoTracking().FirstOrDefault(r => r.JNL_CUPID == ee && r.JNL_TYPE == ff && r.JNL_PATTERNNO == a && r.JNL_ANS == b && r.JNL_OPTYPE == c && r.JNL_ENABLEFLG == d && r.JNL_PATTERNID != ptid && r.JNL_KEY == key);
                    }

                    if (tmpSame != null)
                    {
                        MessageBox.Show("同じパターン番号、ANS、操作種別、情報部リストのジャーナルパターンがすでに存在するので、今の編集は保存不可", Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    foreach (var tmpsegs in exist.JNL_INFOBLOCKS.ToList())
                    {
                        version.context.T_JNSEGS.Remove(tmpsegs);
                    }
                    version.context.T_JNPT.Remove(exist);

                    version.context.T_JNPT.Add(jp);
                    version.context.SaveChanges();

                    MessageBox.Show(Properties.Resources.JNL_UPDATE_SUCCESS, Properties.Resources.SUCCESS, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    logger.Info($"{version.User.USERID} ジャーナル編集保存");

                }
                else
                {
                    MessageBox.Show("編集中のジャーナルパターンは別の端末で編集されたので、保存できません", Properties.Resources.FAILURE, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    logger.Warn($"{version.User.USERID} 編集中のジャーナルパターンは別の端末で編集されたので、保存できません");
                }

                this.Dispose();

            }
            catch (Exception exp)
            {
                logger.Error(exp, $"{version.User.USERID} DBエラー");
                MessageBox.Show(Properties.Resources.JNL_UPDATE_ERROR, Properties.Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Dispose();
            }

        }

        //タブ切替の場合、CUP-IDリストの取得
        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.tabControl1.SelectedTab == this.tabPage2)
            {
                this.Width = 1010;
                this.Height = 686;
            }
            else if (this.tabControl1.SelectedTab == this.tabPage3)
            {
                this.Width = 740;
                this.Height = 370;
                try
                {
                    using (var context = new mysqlcontext(version.ConnectString))
                    {
                        List<string> lst = context.T_JNPT.AsNoTracking().Select(r => r.JNL_CUPID).Distinct().ToList();
                        lst.Add(Properties.Resources.JNL_LIST_ALL);
                        lst.Insert(0, "");
                        this.comboBox1.DataSource = lst;
                    }
                }
                catch (Exception exp)
                {
                    this.comboBox1.DataSource = new List<string>();
                    logger.Error(exp, Properties.Resources.DBERROR);
                    MessageBox.Show(Properties.Resources.DBERROR, Properties.Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void inuse_CheckedChanged(object sender, EventArgs e)
        {
            if (inuse.Checked)
            {
                jnPattern.Enabled = 1;
            }
        }

        /// <summary>
        /// 使用中/未使用設定
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void obsolete_CheckedChanged(object sender, EventArgs e)
        {
            if (obsolete.Checked)
            {
                jnPattern.Enabled = 0;
            }
        }

        /// <summary>
        /// COPY FROM FileLoadForm
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {
            using (var fbd = new FolderBrowserDialog())
            {
                DialogResult result = fbd.ShowDialog();

                if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(fbd.SelectedPath))
                {
                    this.textBox1.Text = fbd.SelectedPath;
                }
            }
        }

        /// <summary>
        /// COPY FROM FileLoadForm
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button4_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrWhiteSpace(this.textBox1.Text))
            {
                MessageBox.Show(Properties.Resources.JNL_MSG1, Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (String.IsNullOrWhiteSpace(this.comboBox1.SelectedItem.ToString()))
            {
                MessageBox.Show(Properties.Resources.JNL_MSG2, Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (!System.IO.Directory.Exists(this.textBox1.Text))
            {
                MessageBox.Show("出力先は存在しない", Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string condition = this.comboBox1.SelectedItem.ToString();
            List<ViewPattern> lst = new List<ViewPattern>();

            FileOutputOfficeCom fop = new FileOutputOfficeCom();
            fop.readJNLData(condition, lst, version, this.richTextBox2);
            fop.writeDataToExcel(lst, this.textBox1.Text, this.richTextBox2);
        }

        /// <summary>
        /// 「欠番」を押す時の処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void rdoBlank_MouseDown(object sender, MouseEventArgs e)
        {
            if (!this.rdoBlank.Checked)
            {
                if (MessageBox.Show(Properties.Resources.JNL_MODE_TOBLK, Properties.Resources.ATTENTION, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
                {
                    jnPattern.Enabled = 2;

                    foreach (var tmp in dic)
                    {
                        jnPattern.JN_INFOBLOCKS.Remove(tmp.Value);
                        this.panel1.Controls.Remove(tmp.Key);
                    }
                    dic.Clear();
                    setLost();

                    this.panel1.Refresh();
                }
            }
        }

        private void setLost()
        {
            this.pictureBox1.Left = X_Start;
            this.panel1.Enabled = false;
            this.radioButton1.Enabled = false;
            this.radioButton2.Enabled = false;

            this.textBox5.Text = " ";
            this.textBox7.Text = " ";
            //this.textBox2.Text = " ";
            this.textBox6.Text = " ";
            this.textBox3.Text = " ";
            //this.textBox4.Text = " ";

            this.textBox5.Enabled = false;
            this.textBox7.Enabled = false;
            this.textBox2.Enabled = false;
            this.textBox6.Enabled = false;
            this.textBox3.Enabled = false;
            this.textBox4.Enabled = false;

            this.rdoBlank.Checked = true;
            this.inuse.Enabled = false;
            this.obsolete.Enabled = false;
        }

    }
}
