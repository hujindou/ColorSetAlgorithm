﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MarsTool.Models;
using MarsTool.Models.DB;

namespace MarsTool
{
    public partial class InfoblockSearch : Form
    {
        public InfoblockSearch()
        {
            InitializeComponent();
        }

        public InfoblockSearch(VersionModel p) : this()
        {
            version = p;
        }

        private VersionModel version;

        public T_CPYPHY infoBlock { get; set; }

        private Dictionary<string, T_CPYPHY> dic = new Dictionary<string, T_CPYPHY>();

        private void linkLabel1_Click(object sender, EventArgs e)
        {
            var lbl = sender as LinkLabel;
            if (lbl == null) return;
            infoBlock = dic[lbl.Text];
            this.button2.PerformClick();
        }

        private string keyword;

        private void button1_Click(object sender, EventArgs e)
        {
            keyword = this.textBox1.Text.Trim();

            var res = version.context.T_CPYPHY.AsNoTracking().Where(r =>
            (r.CPYPHY_INFOID.StartsWith("!") && r.CPYPHY_INFOID.EndsWith("!")
            || r.CPYPHY_INFOID.StartsWith("#") && r.CPYPHY_INFOID.EndsWith("#")
            || r.CPYPHY_INFOID.StartsWith("$") && r.CPYPHY_INFOID.EndsWith("$")
            || r.CPYPHY_INFOID.StartsWith("%") && r.CPYPHY_INFOID.EndsWith("%")
            || r.CPYPHY_INFOID.StartsWith("*") && r.CPYPHY_INFOID.EndsWith("*")
            || r.CPYPHY_INFOID.StartsWith("&") && r.CPYPHY_INFOID.EndsWith("&")
            || r.CPYPHY_INFOID.StartsWith("@") && r.CPYPHY_INFOID.EndsWith("@"))
            && r.CPYPHY_BCPNM.Contains(keyword)).OrderBy(o => o.CPYPHY_BCPNM);

            int cnt = res.Count();
            //this.button1.Text = cnt.ToString();
            this.panel1.Controls.Clear();
            this.panel2.Controls.Clear();
            dic.Clear();
            if (cnt == 0)
            {
                Label l = new Label();
                l.Text = "検索結果はありません";
                this.panel2.Controls.Add(l);
            }
            else if (cnt < 10)
            {
                int left = (this.panel2.Width - (11 + 1) * 3) / 2;
                Label l = new Label();
                l.Text = "<";
                this.panel2.Controls.Add(l);
                l.Left = left;
                l.AutoSize = true;
                left += l.Width + 1;

                l = new Label();
                l.Text = 1.ToString();
                this.panel2.Controls.Add(l);
                l.Left = left;
                l.AutoSize = true;
                l.ForeColor = Color.Blue;
                left += l.Width + 1;

                l = new Label();
                l.Text = ">";
                this.panel2.Controls.Add(l);
                l.Left = left;
                l.AutoSize = true;
                left += l.Width + 1;

                var lst = res.Take(10);
                int tmptop = 5;
                foreach (var tmp in lst)
                {
                    //12 105
                    LinkLabel lbl = new LinkLabel();
                    lbl.Text = gen(tmp);
                    //if (lbl.Text.StartsWith("(")) lbl.LinkColor = Color.Red;
                    this.panel1.Controls.Add(lbl);
                    lbl.Left = 2;
                    lbl.Top = tmptop;
                    lbl.AutoSize = true;
                    lbl.Click += new System.EventHandler(this.linkLabel1_Click);
                    dic.Add(lbl.Text, tmp);
                    tmptop += lbl.Size.Height + 8;
                }
            }
            else
            {
                int a = cnt / 10;
                int b = cnt % 10;
                if (b != 0) a++;
                bool nextflg = false;

                if (a > 9)
                {
                    a = 9;
                    nextflg = true;
                }

                //11 = label width after auto fit
                int tmpleft = (this.panel2.Width - (11 + 1) * (a + 2)) / 2;
                Label l = new Label();
                l.Text = "<";
                this.panel2.Controls.Add(l);
                l.Left = tmpleft;
                l.AutoSize = true;
                tmpleft += l.Width + 1;

                for (int i = 0; i < a; i++)
                {
                    LinkLabel lbl = new LinkLabel();
                    lbl.Text = (i + 1).ToString();
                    this.panel2.Controls.Add(lbl);
                    lbl.Left = tmpleft;
                    lbl.AutoSize = true;
                    lbl.Click += new System.EventHandler(this.naviLink);
                    tmpleft += lbl.Width + 1;
                }

                Label l2 = new Label();
                l2.Text = ">";
                this.panel2.Controls.Add(l2);
                l2.Left = tmpleft;
                l2.AutoSize = true;
                if (nextflg)
                    l2.ForeColor = Color.Blue;
                tmpleft += l2.Width + 1;

                var lst = res.Skip(0).Take(10);
                int tmptop = 2;

                foreach (var tmp in lst)
                {
                    //12 105
                    LinkLabel lbl = new LinkLabel();
                    lbl.Text = gen(tmp);
                    //if (lbl.Text.StartsWith("(")) lbl.LinkColor = Color.Red;
                    this.panel1.Controls.Add(lbl);
                    lbl.Left = 2;
                    lbl.Top = tmptop;
                    lbl.AutoSize = true;
                    lbl.Click += new System.EventHandler(this.linkLabel1_Click);
                    dic.Add(lbl.Text, tmp);
                    tmptop += lbl.Size.Height + 8;
                }
            }
        }

        private void naviLink(object sender, EventArgs e)
        {
            var res = version.context.T_CPYPHY.AsNoTracking().Where(r =>
            (r.CPYPHY_INFOID.StartsWith("!") && r.CPYPHY_INFOID.EndsWith("!")
            || r.CPYPHY_INFOID.StartsWith("#") && r.CPYPHY_INFOID.EndsWith("#")
            || r.CPYPHY_INFOID.StartsWith("$") && r.CPYPHY_INFOID.EndsWith("$")
            || r.CPYPHY_INFOID.StartsWith("%") && r.CPYPHY_INFOID.EndsWith("%")
            || r.CPYPHY_INFOID.StartsWith("*") && r.CPYPHY_INFOID.EndsWith("*")
            || r.CPYPHY_INFOID.StartsWith("&") && r.CPYPHY_INFOID.EndsWith("&")
            || r.CPYPHY_INFOID.StartsWith("@") && r.CPYPHY_INFOID.EndsWith("@"))
            && r.CPYPHY_BCPNM.Contains(keyword)).OrderBy(o => o.CPYPHY_BCPNM);
            int cnt = res.Count();
            //this.button1.Text = cnt.ToString();
            this.panel1.Controls.Clear();
            this.panel2.Controls.Clear();
            dic.Clear();
            if (cnt == 0)
            {
                Label l = new Label();
                l.Text = "検索結果はありません";
                this.panel2.Controls.Add(l);
            }
            else if (cnt < 10)
            {
                int left = (this.panel2.Width - (11 + 1) * 3) / 2;
                Label l = new Label();
                l.Text = "<";
                this.panel2.Controls.Add(l);
                l.Left = left;
                l.AutoSize = true;
                left += l.Width + 1;

                l = new Label();
                l.Text = 1.ToString();
                this.panel2.Controls.Add(l);
                l.Left = left;
                l.AutoSize = true;
                l.ForeColor = Color.Blue;
                left += l.Width + 1;

                l = new Label();
                l.Text = ">";
                this.panel2.Controls.Add(l);
                l.Left = left;
                l.AutoSize = true;
                left += l.Width + 1;

                var lst = res.Take(10);
                int tmptop = 5;
                foreach (var tmp in lst)
                {
                    //12 105
                    LinkLabel lbl = new LinkLabel();
                    lbl.Text = gen(tmp);
                    //if (lbl.Text.StartsWith("(")) lbl.LinkColor = Color.Red;
                    this.panel1.Controls.Add(lbl);
                    lbl.Left = 2;
                    lbl.Top = tmptop;
                    lbl.AutoSize = true;
                    lbl.Click += new System.EventHandler(this.linkLabel1_Click);
                    dic.Add(lbl.Text, tmp);
                    tmptop += lbl.Size.Height + 8;
                }
            }
            else
            {
                int a = cnt / 10;
                int b = cnt % 10;
                if (b != 0) a++;
                int start = 0;
                bool preflg = false;
                bool nextflg = false;

                var nm = sender as LinkLabel;
                int clickednm = int.Parse(nm.Text);

                if (a > 9)
                {
                    if (clickednm - 4 > 0)
                    {
                        start = clickednm - 4 - 1;

                        if (clickednm + 4 > a)
                        {
                            start = a - 9;
                        }

                        if (a > start + 9)
                        {
                            a = start + 9;
                            nextflg = true;
                        }

                        if (start > 0) preflg = true;
                    }
                    else
                    {
                        start = 0;
                        a = start + 9;
                        nextflg = true;
                    }
                }



                //11 = label width after auto fit
                int tmpleft = (this.panel2.Width - (11 + 1) * (a + 2)) / 2;
                Label l = new Label();
                l.Text = "<";
                this.panel2.Controls.Add(l);
                l.Left = tmpleft;
                l.AutoSize = true;
                if (preflg) l.ForeColor = Color.Blue;
                tmpleft += l.Width + 1;

                for (int i = start; i < a; i++)
                {
                    LinkLabel lbl = new LinkLabel();
                    lbl.Text = (i + 1).ToString();
                    this.panel2.Controls.Add(lbl);
                    lbl.Left = tmpleft;
                    lbl.AutoSize = true;
                    lbl.Click += new System.EventHandler(this.naviLink);
                    tmpleft += lbl.Width + 1;
                }

                Label l2 = new Label();
                l2.Text = ">";
                this.panel2.Controls.Add(l2);
                l2.Left = tmpleft;
                l2.AutoSize = true;
                tmpleft += l2.Width + 1;
                if (nextflg) l2.ForeColor = Color.Blue;

                var lst = res.Skip(10 * (clickednm - 1)).Take(10);
                int tmptop = 2;

                foreach (var tmp in lst)
                {
                    //12 105
                    LinkLabel lbl = new LinkLabel();
                    lbl.Text = gen(tmp);
                    //if (lbl.Text.StartsWith("(")) lbl.LinkColor = Color.Red;
                    this.panel1.Controls.Add(lbl);
                    lbl.Left = 2;
                    lbl.Top = tmptop;
                    lbl.AutoSize = true;
                    lbl.Click += new System.EventHandler(this.linkLabel1_Click);
                    dic.Add(lbl.Text, tmp);
                    tmptop += lbl.Size.Height + 8;
                }
            }

        }

        private string gen(T_CPYPHY tmp)
        {
            return tmp.CPYPHY_BCPNM;
        }
    }
}
