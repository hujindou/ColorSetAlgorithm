﻿using MarsTool.Models;
using MarsTool.Models.DB;
using MarsTool.RData.Info;
using NLog;
using System.Windows.Forms;

namespace MarsTool.RData
{
    /// <summary>
    /// ＲＤＡＴＡ編集ベースクラス
    /// </summary>
    public abstract class EditorBase
    {
        protected Logger Logger = NLog.LogManager.GetCurrentClassLogger();

        public RDataEditor RDataEditor { get; private set; }

        /// <summary>
        /// ＲＤＡＴＡ情報
        /// </summary>
        private RDataInfo _rdataInfo = null;
        public RDataInfo RDataInfo
        {
            set
            {
                if (value == null) return;
                this._rdataInfo = value;
                this.RDataEditor.SetForm(this._rdataInfo);
            }

            get
            {
                return this._rdataInfo;
            }
        }

        /// <summary>
        /// バージョンモデル
        /// </summary>
        public VersionModel Version { get; private set; }

        /// <summary>
        /// バージョンモデル
        /// </summary>
        protected mysqlcontext Context
        {
            get
            {
                return Version.context;
            }
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public EditorBase(RDataEditor rdataEditor, VersionModel version)
        {
            this.RDataEditor = rdataEditor;
            this.Version = version;
            this.RDataEditor.SetSubSysId(this.Version.getModifiableSubsysList().ToArray());
        }
    }
}
