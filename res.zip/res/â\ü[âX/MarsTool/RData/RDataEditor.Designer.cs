﻿namespace MarsTool.RData
{
    partial class RDataEditor
    {
        /// <summary> 
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region コンポーネント デザイナーで生成されたコード

        /// <summary> 
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を 
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.cbSubSysId = new System.Windows.Forms.ComboBox();
            this.lblMbTable = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMaxEntryCnt = new System.Windows.Forms.TextBox();
            this.cbExpand = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtCopyId = new System.Windows.Forms.TextBox();
            this.cbExt = new System.Windows.Forms.ComboBox();
            this.txtFileGroup = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.cbSort = new System.Windows.Forms.ComboBox();
            this.label38 = new System.Windows.Forms.Label();
            this.cbStructType = new System.Windows.Forms.ComboBox();
            this.label39 = new System.Windows.Forms.Label();
            this.txtKey = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.txtKeyLen = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.txtKeyLoc = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.txtFilename = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.txtBlkLen = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.txtTableId = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.txtSubSysNm = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.txtSysNm = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.txtTableNm = new System.Windows.Forms.TextBox();
            this.tabGroups = new System.Windows.Forms.TabControl();
            this.tpInterface = new System.Windows.Forms.TabPage();
            this.dgvInterface = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tpCtrlInfo1 = new System.Windows.Forms.TabPage();
            this.dgvCtrl1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tpCommInfo = new System.Windows.Forms.TabPage();
            this.dgvCommon = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tpUserInfo = new System.Windows.Forms.TabPage();
            this.dgvUser = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tpEntryInfo = new System.Windows.Forms.TabPage();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.dgvEntry = new System.Windows.Forms.DataGridView();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.dgvEntryComment = new System.Windows.Forms.DataGridView();
            this.COMTFLG = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.dgvEntryItem = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn40 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn41 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn42 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn43 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn44 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn45 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tpCtrlInfo2 = new System.Windows.Forms.TabPage();
            this.dgvCtrl2 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn57 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn58 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn59 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn60 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn61 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn62 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn49 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.tabGroups.SuspendLayout();
            this.tpInterface.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInterface)).BeginInit();
            this.tpCtrlInfo1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCtrl1)).BeginInit();
            this.tpCommInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCommon)).BeginInit();
            this.tpUserInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUser)).BeginInit();
            this.tpEntryInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEntry)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEntryComment)).BeginInit();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEntryItem)).BeginInit();
            this.tpCtrlInfo2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCtrl2)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.groupBox14);
            this.splitContainer1.Panel1MinSize = 125;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.tabGroups);
            this.splitContainer1.Size = new System.Drawing.Size(1080, 680);
            this.splitContainer1.SplitterDistance = 132;
            this.splitContainer1.TabIndex = 37;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.cbSubSysId);
            this.groupBox14.Controls.Add(this.lblMbTable);
            this.groupBox14.Controls.Add(this.label2);
            this.groupBox14.Controls.Add(this.txtMaxEntryCnt);
            this.groupBox14.Controls.Add(this.cbExpand);
            this.groupBox14.Controls.Add(this.label1);
            this.groupBox14.Controls.Add(this.txtCopyId);
            this.groupBox14.Controls.Add(this.cbExt);
            this.groupBox14.Controls.Add(this.txtFileGroup);
            this.groupBox14.Controls.Add(this.label37);
            this.groupBox14.Controls.Add(this.cbSort);
            this.groupBox14.Controls.Add(this.label38);
            this.groupBox14.Controls.Add(this.cbStructType);
            this.groupBox14.Controls.Add(this.label39);
            this.groupBox14.Controls.Add(this.txtKey);
            this.groupBox14.Controls.Add(this.label40);
            this.groupBox14.Controls.Add(this.txtKeyLen);
            this.groupBox14.Controls.Add(this.label41);
            this.groupBox14.Controls.Add(this.txtKeyLoc);
            this.groupBox14.Controls.Add(this.label42);
            this.groupBox14.Controls.Add(this.label43);
            this.groupBox14.Controls.Add(this.txtFilename);
            this.groupBox14.Controls.Add(this.label44);
            this.groupBox14.Controls.Add(this.label45);
            this.groupBox14.Controls.Add(this.label46);
            this.groupBox14.Controls.Add(this.txtBlkLen);
            this.groupBox14.Controls.Add(this.label47);
            this.groupBox14.Controls.Add(this.txtTableId);
            this.groupBox14.Controls.Add(this.label48);
            this.groupBox14.Controls.Add(this.txtSubSysNm);
            this.groupBox14.Controls.Add(this.label49);
            this.groupBox14.Controls.Add(this.txtSysNm);
            this.groupBox14.Controls.Add(this.label50);
            this.groupBox14.Controls.Add(this.label51);
            this.groupBox14.Controls.Add(this.txtTableNm);
            this.groupBox14.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox14.Location = new System.Drawing.Point(0, 0);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(1080, 114);
            this.groupBox14.TabIndex = 37;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "ヘッダ部情報";
            // 
            // cbSubSysId
            // 
            this.cbSubSysId.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSubSysId.FormattingEnabled = true;
            this.cbSubSysId.Location = new System.Drawing.Point(98, 40);
            this.cbSubSysId.Name = "cbSubSysId";
            this.cbSubSysId.Size = new System.Drawing.Size(72, 20);
            this.cbSubSysId.TabIndex = 44;
            // 
            // lblMbTable
            // 
            this.lblMbTable.AutoSize = true;
            this.lblMbTable.ForeColor = System.Drawing.Color.Blue;
            this.lblMbTable.Location = new System.Drawing.Point(780, 0);
            this.lblMbTable.Name = "lblMbTable";
            this.lblMbTable.Size = new System.Drawing.Size(98, 12);
            this.lblMbTable.TabIndex = 43;
            this.lblMbTable.Text = "※ＭB管理テーブル";
            this.lblMbTable.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(178, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 12);
            this.label2.TabIndex = 42;
            this.label2.Text = "キー長";
            // 
            // txtMaxEntryCnt
            // 
            this.txtMaxEntryCnt.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtMaxEntryCnt.Location = new System.Drawing.Point(771, 89);
            this.txtMaxEntryCnt.MaxLength = 9;
            this.txtMaxEntryCnt.Name = "txtMaxEntryCnt";
            this.txtMaxEntryCnt.Size = new System.Drawing.Size(117, 19);
            this.txtMaxEntryCnt.TabIndex = 13;
            this.txtMaxEntryCnt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NumbericTextbox_KeyPress);
            // 
            // cbExpand
            // 
            this.cbExpand.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbExpand.FormattingEnabled = true;
            this.cbExpand.Location = new System.Drawing.Point(994, 64);
            this.cbExpand.Name = "cbExpand";
            this.cbExpand.Size = new System.Drawing.Size(58, 20);
            this.cbExpand.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(962, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 39;
            this.label1.Text = "展開";
            // 
            // txtCopyId
            // 
            this.txtCopyId.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtCopyId.Location = new System.Drawing.Point(771, 65);
            this.txtCopyId.MaxLength = 20;
            this.txtCopyId.Name = "txtCopyId";
            this.txtCopyId.Size = new System.Drawing.Size(117, 19);
            this.txtCopyId.TabIndex = 12;
            this.txtCopyId.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.AlpahNumbericTextbox_KeyPress);
            // 
            // cbExt
            // 
            this.cbExt.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbExt.FormattingEnabled = true;
            this.cbExt.Location = new System.Drawing.Point(994, 16);
            this.cbExt.Name = "cbExt";
            this.cbExt.Size = new System.Drawing.Size(58, 20);
            this.cbExt.TabIndex = 14;
            // 
            // txtFileGroup
            // 
            this.txtFileGroup.Location = new System.Drawing.Point(771, 41);
            this.txtFileGroup.MaxLength = 60;
            this.txtFileGroup.Name = "txtFileGroup";
            this.txtFileGroup.Size = new System.Drawing.Size(117, 19);
            this.txtFileGroup.TabIndex = 11;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(692, 44);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(77, 12);
            this.label37.TabIndex = 35;
            this.label37.Text = "ファイルグループ";
            // 
            // cbSort
            // 
            this.cbSort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSort.FormattingEnabled = true;
            this.cbSort.Location = new System.Drawing.Point(994, 88);
            this.cbSort.Name = "cbSort";
            this.cbSort.Size = new System.Drawing.Size(58, 20);
            this.cbSort.TabIndex = 17;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(950, 20);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(41, 12);
            this.label38.TabIndex = 33;
            this.label38.Text = "拡張子";
            // 
            // cbStructType
            // 
            this.cbStructType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbStructType.FormattingEnabled = true;
            this.cbStructType.Items.AddRange(new object[] {
            "4",
            "5"});
            this.cbStructType.Location = new System.Drawing.Point(994, 40);
            this.cbStructType.Name = "cbStructType";
            this.cbStructType.Size = new System.Drawing.Size(58, 20);
            this.cbStructType.TabIndex = 15;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(298, 92);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(25, 12);
            this.label39.TabIndex = 27;
            this.label39.Text = "キー";
            // 
            // txtKey
            // 
            this.txtKey.Location = new System.Drawing.Point(325, 89);
            this.txtKey.MaxLength = 60;
            this.txtKey.Name = "txtKey";
            this.txtKey.Size = new System.Drawing.Size(338, 19);
            this.txtKey.TabIndex = 9;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(695, 92);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(74, 12);
            this.label40.TabIndex = 25;
            this.label40.Text = "最大エントリ数";
            // 
            // txtKeyLen
            // 
            this.txtKeyLen.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtKeyLen.Location = new System.Drawing.Point(221, 89);
            this.txtKeyLen.MaxLength = 10;
            this.txtKeyLen.Name = "txtKeyLen";
            this.txtKeyLen.Size = new System.Drawing.Size(68, 19);
            this.txtKeyLen.TabIndex = 5;
            this.txtKeyLen.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NumbericTextbox_KeyPress);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(24, 92);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(73, 12);
            this.label41.TabIndex = 23;
            this.label41.Text = "キー相対位置";
            // 
            // txtKeyLoc
            // 
            this.txtKeyLoc.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtKeyLoc.Location = new System.Drawing.Point(98, 89);
            this.txtKeyLoc.MaxLength = 10;
            this.txtKeyLoc.Name = "txtKeyLoc";
            this.txtKeyLoc.Size = new System.Drawing.Size(72, 19);
            this.txtKeyLoc.TabIndex = 4;
            this.txtKeyLoc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NumbericTextbox_KeyPress);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(909, 92);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(82, 12);
            this.label42.TabIndex = 21;
            this.label42.Text = "ローダ時のソート";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(211, 44);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(74, 12);
            this.label43.TabIndex = 19;
            this.label43.Text = "サブシステム名";
            // 
            // txtFilename
            // 
            this.txtFilename.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtFilename.Location = new System.Drawing.Point(771, 17);
            this.txtFilename.MaxLength = 16;
            this.txtFilename.Name = "txtFilename";
            this.txtFilename.Size = new System.Drawing.Size(117, 19);
            this.txtFilename.TabIndex = 10;
            this.txtFilename.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.AlpahNumbericTextbox_KeyPress);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(230, 20);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(55, 12);
            this.label44.TabIndex = 17;
            this.label44.Text = "システム名";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(936, 44);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(55, 12);
            this.label45.TabIndex = 15;
            this.label45.Text = "構成タイプ";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(48, 20);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(50, 12);
            this.label46.TabIndex = 13;
            this.label46.Text = "ブロック長";
            // 
            // txtBlkLen
            // 
            this.txtBlkLen.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtBlkLen.Location = new System.Drawing.Point(98, 17);
            this.txtBlkLen.MaxLength = 9;
            this.txtBlkLen.Name = "txtBlkLen";
            this.txtBlkLen.Size = new System.Drawing.Size(72, 19);
            this.txtBlkLen.TabIndex = 1;
            this.txtBlkLen.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NumbericTextbox_KeyPress);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(713, 68);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(56, 12);
            this.label47.TabIndex = 11;
            this.label47.Text = "コピー句ＩＤ";
            // 
            // txtTableId
            // 
            this.txtTableId.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtTableId.Location = new System.Drawing.Point(98, 65);
            this.txtTableId.MaxLength = 10;
            this.txtTableId.Name = "txtTableId";
            this.txtTableId.Size = new System.Drawing.Size(72, 19);
            this.txtTableId.TabIndex = 3;
            this.txtTableId.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.AlpahNumbericTextbox_KeyPress);
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(43, 68);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(55, 12);
            this.label48.TabIndex = 9;
            this.label48.Text = "テーブルＩＤ";
            // 
            // txtSubSysNm
            // 
            this.txtSubSysNm.Location = new System.Drawing.Point(286, 41);
            this.txtSubSysNm.MaxLength = 100;
            this.txtSubSysNm.Name = "txtSubSysNm";
            this.txtSubSysNm.Size = new System.Drawing.Size(377, 19);
            this.txtSubSysNm.TabIndex = 7;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(230, 68);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(55, 12);
            this.label49.TabIndex = 7;
            this.label49.Text = "テーブル名";
            // 
            // txtSysNm
            // 
            this.txtSysNm.Location = new System.Drawing.Point(286, 17);
            this.txtSysNm.MaxLength = 60;
            this.txtSysNm.Name = "txtSysNm";
            this.txtSysNm.Size = new System.Drawing.Size(377, 19);
            this.txtSysNm.TabIndex = 6;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(24, 44);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(74, 12);
            this.label50.TabIndex = 5;
            this.label50.Text = "サブシステムＩＤ";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(679, 20);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(90, 12);
            this.label51.TabIndex = 3;
            this.label51.Text = "RDATAファイル名";
            // 
            // txtTableNm
            // 
            this.txtTableNm.Location = new System.Drawing.Point(286, 65);
            this.txtTableNm.MaxLength = 60;
            this.txtTableNm.Name = "txtTableNm";
            this.txtTableNm.Size = new System.Drawing.Size(377, 19);
            this.txtTableNm.TabIndex = 8;
            // 
            // tabGroups
            // 
            this.tabGroups.Controls.Add(this.tpInterface);
            this.tabGroups.Controls.Add(this.tpCtrlInfo1);
            this.tabGroups.Controls.Add(this.tpCommInfo);
            this.tabGroups.Controls.Add(this.tpUserInfo);
            this.tabGroups.Controls.Add(this.tpEntryInfo);
            this.tabGroups.Controls.Add(this.tpCtrlInfo2);
            this.tabGroups.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabGroups.Location = new System.Drawing.Point(0, 0);
            this.tabGroups.Name = "tabGroups";
            this.tabGroups.SelectedIndex = 0;
            this.tabGroups.Size = new System.Drawing.Size(1080, 544);
            this.tabGroups.TabIndex = 18;
            this.tabGroups.SelectedIndexChanged += new System.EventHandler(this.SelectedIndexChanged);
            // 
            // tpInterface
            // 
            this.tpInterface.BackColor = System.Drawing.SystemColors.Control;
            this.tpInterface.Controls.Add(this.dgvInterface);
            this.tpInterface.Location = new System.Drawing.Point(4, 22);
            this.tpInterface.Name = "tpInterface";
            this.tpInterface.Padding = new System.Windows.Forms.Padding(3);
            this.tpInterface.Size = new System.Drawing.Size(1072, 518);
            this.tpInterface.TabIndex = 6;
            this.tpInterface.Text = "ローダインタフェース";
            // 
            // dgvInterface
            // 
            this.dgvInterface.AllowUserToAddRows = false;
            this.dgvInterface.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInterface.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10});
            this.dgvInterface.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvInterface.Location = new System.Drawing.Point(3, 3);
            this.dgvInterface.MultiSelect = false;
            this.dgvInterface.Name = "dgvInterface";
            this.dgvInterface.ReadOnly = true;
            this.dgvInterface.RowHeadersWidth = 25;
            this.dgvInterface.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvInterface.RowTemplate.Height = 21;
            this.dgvInterface.Size = new System.Drawing.Size(1066, 512);
            this.dgvInterface.TabIndex = 19;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "項目名";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn2.Width = 160;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "データ型";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn3.Width = 60;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "サイズ";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn4.Width = 60;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "データ内容";
            this.dataGridViewTextBoxColumn8.MaxInputLength = 100;
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn8.Width = 200;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.HeaderText = "チェック種別";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.HeaderText = "コメント";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // tpCtrlInfo1
            // 
            this.tpCtrlInfo1.BackColor = System.Drawing.SystemColors.Control;
            this.tpCtrlInfo1.Controls.Add(this.dgvCtrl1);
            this.tpCtrlInfo1.Location = new System.Drawing.Point(4, 22);
            this.tpCtrlInfo1.Name = "tpCtrlInfo1";
            this.tpCtrlInfo1.Padding = new System.Windows.Forms.Padding(3);
            this.tpCtrlInfo1.Size = new System.Drawing.Size(1072, 518);
            this.tpCtrlInfo1.TabIndex = 1;
            this.tpCtrlInfo1.Text = "制御情報部１";
            // 
            // dgvCtrl1
            // 
            this.dgvCtrl1.AllowUserToAddRows = false;
            this.dgvCtrl1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCtrl1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.Column13,
            this.Column14,
            this.Column15});
            this.dgvCtrl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvCtrl1.Location = new System.Drawing.Point(3, 3);
            this.dgvCtrl1.MultiSelect = false;
            this.dgvCtrl1.Name = "dgvCtrl1";
            this.dgvCtrl1.ReadOnly = true;
            this.dgvCtrl1.RowHeadersWidth = 25;
            this.dgvCtrl1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvCtrl1.RowTemplate.Height = 21;
            this.dgvCtrl1.Size = new System.Drawing.Size(1066, 512);
            this.dgvCtrl1.TabIndex = 20;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.HeaderText = "項目名";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn12.Width = 160;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.HeaderText = "データ型";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn13.Width = 60;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.HeaderText = "サイズ";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            this.dataGridViewTextBoxColumn14.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn14.Width = 60;
            // 
            // Column13
            // 
            this.Column13.HeaderText = "データ内容";
            this.Column13.MaxInputLength = 100;
            this.Column13.Name = "Column13";
            this.Column13.ReadOnly = true;
            this.Column13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column13.Width = 200;
            // 
            // Column14
            // 
            this.Column14.HeaderText = "チェック種別";
            this.Column14.Name = "Column14";
            this.Column14.ReadOnly = true;
            this.Column14.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column15
            // 
            this.Column15.HeaderText = "コメント";
            this.Column15.Name = "Column15";
            this.Column15.ReadOnly = true;
            this.Column15.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // tpCommInfo
            // 
            this.tpCommInfo.BackColor = System.Drawing.SystemColors.Control;
            this.tpCommInfo.Controls.Add(this.dgvCommon);
            this.tpCommInfo.Location = new System.Drawing.Point(4, 22);
            this.tpCommInfo.Name = "tpCommInfo";
            this.tpCommInfo.Padding = new System.Windows.Forms.Padding(3);
            this.tpCommInfo.Size = new System.Drawing.Size(1072, 518);
            this.tpCommInfo.TabIndex = 2;
            this.tpCommInfo.Text = "共通情報部";
            // 
            // dgvCommon
            // 
            this.dgvCommon.AllowUserToAddRows = false;
            this.dgvCommon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCommon.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn20});
            this.dgvCommon.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvCommon.Location = new System.Drawing.Point(3, 3);
            this.dgvCommon.MultiSelect = false;
            this.dgvCommon.Name = "dgvCommon";
            this.dgvCommon.ReadOnly = true;
            this.dgvCommon.RowHeadersWidth = 25;
            this.dgvCommon.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvCommon.RowTemplate.Height = 21;
            this.dgvCommon.Size = new System.Drawing.Size(1066, 512);
            this.dgvCommon.TabIndex = 21;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "項目名";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn5.Width = 160;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "データ型";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn6.Width = 60;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "サイズ";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn7.Width = 60;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.HeaderText = "データ内容";
            this.dataGridViewTextBoxColumn17.MaxInputLength = 100;
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.ReadOnly = true;
            this.dataGridViewTextBoxColumn17.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn17.Width = 200;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.HeaderText = "チェック種別";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            this.dataGridViewTextBoxColumn18.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.HeaderText = "コメント";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.ReadOnly = true;
            this.dataGridViewTextBoxColumn20.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // tpUserInfo
            // 
            this.tpUserInfo.BackColor = System.Drawing.SystemColors.Control;
            this.tpUserInfo.Controls.Add(this.dgvUser);
            this.tpUserInfo.Location = new System.Drawing.Point(4, 22);
            this.tpUserInfo.Name = "tpUserInfo";
            this.tpUserInfo.Padding = new System.Windows.Forms.Padding(3);
            this.tpUserInfo.Size = new System.Drawing.Size(1072, 518);
            this.tpUserInfo.TabIndex = 3;
            this.tpUserInfo.Text = "ユーザ任意情報";
            // 
            // dgvUser
            // 
            this.dgvUser.AllowUserToAddRows = false;
            this.dgvUser.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUser.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn30,
            this.dataGridViewTextBoxColumn31,
            this.dataGridViewTextBoxColumn32,
            this.dataGridViewTextBoxColumn33,
            this.dataGridViewTextBoxColumn34,
            this.dataGridViewTextBoxColumn35});
            this.dgvUser.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvUser.Location = new System.Drawing.Point(3, 3);
            this.dgvUser.MultiSelect = false;
            this.dgvUser.Name = "dgvUser";
            this.dgvUser.RowHeadersWidth = 25;
            this.dgvUser.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvUser.RowTemplate.Height = 21;
            this.dgvUser.Size = new System.Drawing.Size(1066, 512);
            this.dgvUser.TabIndex = 22;
            this.dgvUser.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.Item_CellFormatting);
            this.dgvUser.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.CellMouseClick);
            this.dgvUser.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.Item_CellValidating);
            this.dgvUser.MouseClick += new System.Windows.Forms.MouseEventHandler(this.DgvMouseClick);
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.HeaderText = "項目名";
            this.dataGridViewTextBoxColumn30.MaxInputLength = 100;
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            this.dataGridViewTextBoxColumn30.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn30.Width = 160;
            // 
            // dataGridViewTextBoxColumn31
            // 
            this.dataGridViewTextBoxColumn31.HeaderText = "データ型";
            this.dataGridViewTextBoxColumn31.MaxInputLength = 6;
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            this.dataGridViewTextBoxColumn31.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn31.Width = 60;
            // 
            // dataGridViewTextBoxColumn32
            // 
            this.dataGridViewTextBoxColumn32.HeaderText = "サイズ";
            this.dataGridViewTextBoxColumn32.MaxInputLength = 10;
            this.dataGridViewTextBoxColumn32.Name = "dataGridViewTextBoxColumn32";
            this.dataGridViewTextBoxColumn32.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn32.Width = 60;
            // 
            // dataGridViewTextBoxColumn33
            // 
            this.dataGridViewTextBoxColumn33.HeaderText = "データ内容";
            this.dataGridViewTextBoxColumn33.MaxInputLength = 100;
            this.dataGridViewTextBoxColumn33.Name = "dataGridViewTextBoxColumn33";
            this.dataGridViewTextBoxColumn33.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn33.Width = 200;
            // 
            // dataGridViewTextBoxColumn34
            // 
            this.dataGridViewTextBoxColumn34.HeaderText = "チェック種別";
            this.dataGridViewTextBoxColumn34.MaxInputLength = 10;
            this.dataGridViewTextBoxColumn34.Name = "dataGridViewTextBoxColumn34";
            this.dataGridViewTextBoxColumn34.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn35
            // 
            this.dataGridViewTextBoxColumn35.HeaderText = "コメント";
            this.dataGridViewTextBoxColumn35.MaxInputLength = 100;
            this.dataGridViewTextBoxColumn35.Name = "dataGridViewTextBoxColumn35";
            this.dataGridViewTextBoxColumn35.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // tpEntryInfo
            // 
            this.tpEntryInfo.BackColor = System.Drawing.SystemColors.Control;
            this.tpEntryInfo.Controls.Add(this.splitContainer2);
            this.tpEntryInfo.Location = new System.Drawing.Point(4, 22);
            this.tpEntryInfo.Name = "tpEntryInfo";
            this.tpEntryInfo.Padding = new System.Windows.Forms.Padding(3);
            this.tpEntryInfo.Size = new System.Drawing.Size(1072, 518);
            this.tpEntryInfo.TabIndex = 4;
            this.tpEntryInfo.Text = "エントリ部";
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.IsSplitterFixed = true;
            this.splitContainer2.Location = new System.Drawing.Point(3, 3);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.groupBox8);
            this.splitContainer2.Panel1MinSize = 560;
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.splitContainer3);
            this.splitContainer2.Size = new System.Drawing.Size(1066, 512);
            this.splitContainer2.SplitterDistance = 560;
            this.splitContainer2.TabIndex = 13;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.dgvEntry);
            this.groupBox8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox8.Location = new System.Drawing.Point(0, 0);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(560, 512);
            this.groupBox8.TabIndex = 12;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "エントリ一覧";
            // 
            // dgvEntry
            // 
            this.dgvEntry.AllowUserToAddRows = false;
            this.dgvEntry.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvEntry.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEntry.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column17,
            this.dataGridViewTextBoxColumn49,
            this.Column4});
            this.dgvEntry.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvEntry.Location = new System.Drawing.Point(3, 15);
            this.dgvEntry.MultiSelect = false;
            this.dgvEntry.Name = "dgvEntry";
            this.dgvEntry.RowHeadersWidth = 25;
            this.dgvEntry.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvEntry.RowTemplate.Height = 21;
            this.dgvEntry.Size = new System.Drawing.Size(554, 494);
            this.dgvEntry.TabIndex = 23;
            this.dgvEntry.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvEntry_CellClick);
            this.dgvEntry.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvEntry_CellEnter);
            this.dgvEntry.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.CellMouseClick);
            this.dgvEntry.MouseClick += new System.Windows.Forms.MouseEventHandler(this.DgvMouseClick);
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.IsSplitterFixed = true;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.groupBox6);
            this.splitContainer3.Panel1MinSize = 160;
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.groupBox7);
            this.splitContainer3.Size = new System.Drawing.Size(502, 512);
            this.splitContainer3.SplitterDistance = 160;
            this.splitContainer3.TabIndex = 0;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.dgvEntryComment);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox6.Location = new System.Drawing.Point(0, 0);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(502, 160);
            this.groupBox6.TabIndex = 10;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "改修コメント";
            // 
            // dgvEntryComment
            // 
            this.dgvEntryComment.AllowUserToAddRows = false;
            this.dgvEntryComment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEntryComment.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.COMTFLG,
            this.dataGridViewTextBoxColumn1});
            this.dgvEntryComment.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvEntryComment.Location = new System.Drawing.Point(3, 15);
            this.dgvEntryComment.MultiSelect = false;
            this.dgvEntryComment.Name = "dgvEntryComment";
            this.dgvEntryComment.RowHeadersWidth = 25;
            this.dgvEntryComment.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvEntryComment.RowTemplate.Height = 21;
            this.dgvEntryComment.Size = new System.Drawing.Size(496, 142);
            this.dgvEntryComment.TabIndex = 24;
            this.dgvEntryComment.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.CellMouseClick);
            this.dgvEntryComment.MouseClick += new System.Windows.Forms.MouseEventHandler(this.DgvMouseClick);
            // 
            // COMTFLG
            // 
            this.COMTFLG.HeaderText = "フラグ";
            this.COMTFLG.Name = "COMTFLG";
            this.COMTFLG.Width = 180;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "内容";
            this.dataGridViewTextBoxColumn1.MaxInputLength = 100;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn1.Width = 360;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.dgvEntryItem);
            this.groupBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox7.Location = new System.Drawing.Point(0, 0);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(502, 348);
            this.groupBox7.TabIndex = 11;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "エントリ項目情報";
            // 
            // dgvEntryItem
            // 
            this.dgvEntryItem.AllowUserToAddRows = false;
            this.dgvEntryItem.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEntryItem.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn40,
            this.dataGridViewTextBoxColumn41,
            this.dataGridViewTextBoxColumn42,
            this.dataGridViewTextBoxColumn43,
            this.dataGridViewTextBoxColumn44,
            this.dataGridViewTextBoxColumn45});
            this.dgvEntryItem.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvEntryItem.Location = new System.Drawing.Point(3, 15);
            this.dgvEntryItem.MultiSelect = false;
            this.dgvEntryItem.Name = "dgvEntryItem";
            this.dgvEntryItem.RowHeadersWidth = 25;
            this.dgvEntryItem.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvEntryItem.RowTemplate.Height = 21;
            this.dgvEntryItem.Size = new System.Drawing.Size(496, 330);
            this.dgvEntryItem.TabIndex = 25;
            this.dgvEntryItem.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.Item_CellFormatting);
            this.dgvEntryItem.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.CellMouseClick);
            this.dgvEntryItem.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.Item_CellValidating);
            this.dgvEntryItem.MouseClick += new System.Windows.Forms.MouseEventHandler(this.DgvMouseClick);
            // 
            // dataGridViewTextBoxColumn40
            // 
            this.dataGridViewTextBoxColumn40.HeaderText = "項目名";
            this.dataGridViewTextBoxColumn40.MaxInputLength = 100;
            this.dataGridViewTextBoxColumn40.Name = "dataGridViewTextBoxColumn40";
            this.dataGridViewTextBoxColumn40.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn40.Width = 160;
            // 
            // dataGridViewTextBoxColumn41
            // 
            this.dataGridViewTextBoxColumn41.HeaderText = "データ型";
            this.dataGridViewTextBoxColumn41.MaxInputLength = 6;
            this.dataGridViewTextBoxColumn41.Name = "dataGridViewTextBoxColumn41";
            this.dataGridViewTextBoxColumn41.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn41.Width = 60;
            // 
            // dataGridViewTextBoxColumn42
            // 
            this.dataGridViewTextBoxColumn42.HeaderText = "サイズ";
            this.dataGridViewTextBoxColumn42.MaxInputLength = 10;
            this.dataGridViewTextBoxColumn42.Name = "dataGridViewTextBoxColumn42";
            this.dataGridViewTextBoxColumn42.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn42.Width = 60;
            // 
            // dataGridViewTextBoxColumn43
            // 
            this.dataGridViewTextBoxColumn43.HeaderText = "データ内容";
            this.dataGridViewTextBoxColumn43.MaxInputLength = 100;
            this.dataGridViewTextBoxColumn43.Name = "dataGridViewTextBoxColumn43";
            this.dataGridViewTextBoxColumn43.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn43.Width = 300;
            // 
            // dataGridViewTextBoxColumn44
            // 
            this.dataGridViewTextBoxColumn44.HeaderText = "チェック種別";
            this.dataGridViewTextBoxColumn44.MaxInputLength = 10;
            this.dataGridViewTextBoxColumn44.Name = "dataGridViewTextBoxColumn44";
            this.dataGridViewTextBoxColumn44.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn45
            // 
            this.dataGridViewTextBoxColumn45.HeaderText = "コメント";
            this.dataGridViewTextBoxColumn45.MaxInputLength = 100;
            this.dataGridViewTextBoxColumn45.Name = "dataGridViewTextBoxColumn45";
            this.dataGridViewTextBoxColumn45.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // tpCtrlInfo2
            // 
            this.tpCtrlInfo2.BackColor = System.Drawing.SystemColors.Control;
            this.tpCtrlInfo2.Controls.Add(this.dgvCtrl2);
            this.tpCtrlInfo2.Location = new System.Drawing.Point(4, 22);
            this.tpCtrlInfo2.Name = "tpCtrlInfo2";
            this.tpCtrlInfo2.Padding = new System.Windows.Forms.Padding(3);
            this.tpCtrlInfo2.Size = new System.Drawing.Size(1072, 518);
            this.tpCtrlInfo2.TabIndex = 5;
            this.tpCtrlInfo2.Text = "制御情報部２";
            // 
            // dgvCtrl2
            // 
            this.dgvCtrl2.AllowUserToAddRows = false;
            this.dgvCtrl2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCtrl2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn57,
            this.dataGridViewTextBoxColumn58,
            this.dataGridViewTextBoxColumn59,
            this.dataGridViewTextBoxColumn60,
            this.dataGridViewTextBoxColumn61,
            this.dataGridViewTextBoxColumn62});
            this.dgvCtrl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvCtrl2.Location = new System.Drawing.Point(3, 3);
            this.dgvCtrl2.MultiSelect = false;
            this.dgvCtrl2.Name = "dgvCtrl2";
            this.dgvCtrl2.ReadOnly = true;
            this.dgvCtrl2.RowHeadersWidth = 25;
            this.dgvCtrl2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvCtrl2.RowTemplate.Height = 21;
            this.dgvCtrl2.Size = new System.Drawing.Size(1066, 512);
            this.dgvCtrl2.TabIndex = 26;
            // 
            // dataGridViewTextBoxColumn57
            // 
            this.dataGridViewTextBoxColumn57.HeaderText = "項目名";
            this.dataGridViewTextBoxColumn57.Name = "dataGridViewTextBoxColumn57";
            this.dataGridViewTextBoxColumn57.ReadOnly = true;
            this.dataGridViewTextBoxColumn57.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn57.Width = 160;
            // 
            // dataGridViewTextBoxColumn58
            // 
            this.dataGridViewTextBoxColumn58.HeaderText = "データ型";
            this.dataGridViewTextBoxColumn58.Name = "dataGridViewTextBoxColumn58";
            this.dataGridViewTextBoxColumn58.ReadOnly = true;
            this.dataGridViewTextBoxColumn58.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn58.Width = 60;
            // 
            // dataGridViewTextBoxColumn59
            // 
            this.dataGridViewTextBoxColumn59.HeaderText = "サイズ";
            this.dataGridViewTextBoxColumn59.Name = "dataGridViewTextBoxColumn59";
            this.dataGridViewTextBoxColumn59.ReadOnly = true;
            this.dataGridViewTextBoxColumn59.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn59.Width = 60;
            // 
            // dataGridViewTextBoxColumn60
            // 
            this.dataGridViewTextBoxColumn60.HeaderText = "データ内容";
            this.dataGridViewTextBoxColumn60.MaxInputLength = 100;
            this.dataGridViewTextBoxColumn60.Name = "dataGridViewTextBoxColumn60";
            this.dataGridViewTextBoxColumn60.ReadOnly = true;
            this.dataGridViewTextBoxColumn60.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn60.Width = 200;
            // 
            // dataGridViewTextBoxColumn61
            // 
            this.dataGridViewTextBoxColumn61.HeaderText = "チェック種別";
            this.dataGridViewTextBoxColumn61.Name = "dataGridViewTextBoxColumn61";
            this.dataGridViewTextBoxColumn61.ReadOnly = true;
            this.dataGridViewTextBoxColumn61.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn62
            // 
            this.dataGridViewTextBoxColumn62.HeaderText = "コメント";
            this.dataGridViewTextBoxColumn62.Name = "dataGridViewTextBoxColumn62";
            this.dataGridViewTextBoxColumn62.ReadOnly = true;
            this.dataGridViewTextBoxColumn62.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column17
            // 
            this.Column17.HeaderText = "番号";
            this.Column17.Name = "Column17";
            this.Column17.ReadOnly = true;
            this.Column17.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column17.Width = 35;
            // 
            // dataGridViewTextBoxColumn49
            // 
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn49.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewTextBoxColumn49.HeaderText = "エントリコメント";
            this.dataGridViewTextBoxColumn49.MaxInputLength = 200;
            this.dataGridViewTextBoxColumn49.Name = "dataGridViewTextBoxColumn49";
            this.dataGridViewTextBoxColumn49.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn49.Width = 360;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "削除コメント";
            this.Column4.MaxInputLength = 100;
            this.Column4.Name = "Column4";
            this.Column4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column4.Width = 120;
            // 
            // RDataEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.splitContainer1);
            this.Name = "RDataEditor";
            this.Size = new System.Drawing.Size(1080, 680);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.tabGroups.ResumeLayout(false);
            this.tpInterface.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvInterface)).EndInit();
            this.tpCtrlInfo1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCtrl1)).EndInit();
            this.tpCommInfo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCommon)).EndInit();
            this.tpUserInfo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvUser)).EndInit();
            this.tpEntryInfo.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEntry)).EndInit();
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEntryComment)).EndInit();
            this.groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEntryItem)).EndInit();
            this.tpCtrlInfo2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCtrl2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.ComboBox cbExpand;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCopyId;
        private System.Windows.Forms.ComboBox cbExt;
        private System.Windows.Forms.TextBox txtFileGroup;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.ComboBox cbSort;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.ComboBox cbStructType;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txtKey;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox txtKeyLen;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox txtKeyLoc;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox txtFilename;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox txtBlkLen;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox txtTableId;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox txtSubSysNm;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox txtSysNm;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox txtTableNm;
        private System.Windows.Forms.TabControl tabGroups;
        private System.Windows.Forms.TabPage tpInterface;
        private System.Windows.Forms.DataGridView dgvInterface;
        private System.Windows.Forms.TabPage tpCtrlInfo1;
        private System.Windows.Forms.DataGridView dgvCtrl1;
        private System.Windows.Forms.TabPage tpCommInfo;
        private System.Windows.Forms.DataGridView dgvCommon;
        private System.Windows.Forms.TabPage tpUserInfo;
        private System.Windows.Forms.DataGridView dgvUser;
        private System.Windows.Forms.TabPage tpEntryInfo;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.DataGridView dgvEntry;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.DataGridView dgvEntryItem;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.DataGridView dgvEntryComment;
        private System.Windows.Forms.TabPage tpCtrlInfo2;
        private System.Windows.Forms.DataGridView dgvCtrl2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMaxEntryCnt;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.Label lblMbTable;
        private System.Windows.Forms.ComboBox cbSubSysId;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn32;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn33;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn34;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn35;
        private System.Windows.Forms.DataGridViewComboBoxColumn COMTFLG;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn57;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn58;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn59;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn60;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn61;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn62;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn40;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn41;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn42;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn43;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn44;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn45;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn49;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
    }
}
