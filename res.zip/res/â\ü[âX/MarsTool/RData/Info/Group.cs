﻿using System.Collections.Generic;

namespace MarsTool.RData.Info
{
    /// <summary>
    /// ＲＤＡＴＡ情報部クラス
    /// </summary>
    public abstract class Group
    {
        /// <summary>
        /// 情報部種別
        ///  1：ローダインタフェース情報部
        ///  2：制御情報部１
        ///  3：共通情報部
        ///  4：共通情報部・ユーザ任意情報
        ///  5：エントリ部
        ///  6：制御情報部２
        /// </summary>
        public enum GroupType { Interface = 1, Ctrl1, Common, User, Entry, Ctrl2 }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public Group(HeaderInfo headerInfo, GroupType type)
        {
            this._headerInfo = headerInfo;
            this._type = type;
        }

        /// <summary>
        /// ＲＤＡＴＡ共通情報
        /// </summary>
        private HeaderInfo _headerInfo = null;
        public HeaderInfo HeaderInfo
        {
            get
            {
                return this._headerInfo;
            }
        }

        /// <summary>
        /// 情報部名
        /// </summary>
        public abstract string Name
        {
            get;
        }

        /// <summary>
        /// 情報部種別
        /// </summary>
        private GroupType _type;
        public GroupType Type
        {
            get
            {
                return this._type;
            }
        }

        /// <summary>
        /// 情報部レコード
        /// </summary>
        private List<RecordInfo> _recordList = new List<RecordInfo>();
        public List<RecordInfo> RecordList
        {
            get
            {
                return this._recordList;
            }
        }

        /// <summary>
        /// 情報部レコード追加
        /// </summary>
        /// <param name="record">情報部レコード</param>
        public virtual void Add(RecordInfo record)
        {
            this._recordList.Add(record);
        }

        /// <summary>
        /// フィールド定義リスト
        /// </summary>
        private List<FieldDefine> _fieldDefList = new List<FieldDefine>();
        public List<FieldDefine> FieldDefList
        {
            get
            {
                return this._fieldDefList;
            }
        }
    }

    /// <summary>
    /// ローダインタフェース情報部クラス
    /// </summary>
    public class GroupInterface : Group
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public GroupInterface(HeaderInfo headerInfo) : base(headerInfo, GroupType.Interface) { }

        /// <summary>
        /// 情報部名
        /// </summary>
        public override string Name
        {
            get
            {
                return "ローダインタフェース";
            }
        }
    }

    /// <summary>
    /// 共通情報部クラス
    /// </summary>
    public class GroupCommon : Group
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public GroupCommon(HeaderInfo headerInfo) : base(headerInfo, GroupType.Common) { }

        /// <summary>
        /// 情報部名
        /// </summary>
        public override string Name
        {
            get
            {
                if (this.HeaderInfo.IsMBTable)
                {
                    return "ＤＳＭＢ管理Ｔ共通情報";
                }
                else
                {
                    return "共通情報部";
                }
            }
        }
    }

    /// <summary>
    /// /// 共通情報部・ユーザ任意情報クラス
    /// /// </summary>
    public class GroupUser : Group
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public GroupUser(HeaderInfo headerInfo) : base(headerInfo, GroupType.User) { }

        /// <summary>
        /// 情報部名
        /// </summary>
        public override string Name
        {
            get
            {
                return "--共通情報部・ユーザ任意情報--";
            }
        }
    }

    /// <summary>
    /// 制御情報部１クラス
    /// </summary>
    public class GroupCtrl1 : Group
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public GroupCtrl1(HeaderInfo headerInfo) : base(headerInfo, GroupType.Ctrl1) { }

        /// <summary>
        /// 情報部名
        /// </summary>
        public override string Name
        {
            get
            {
                if (this.HeaderInfo.IsMBTable)
                {
                    return "制御部１";
                }
                else
                {
                    return "制御情報部１";
                }
            }
        }
    }

    /// <summary>
    /// エントリ部クラス
    /// </summary>
    public class GroupEntry : Group
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public GroupEntry(HeaderInfo headerInfo) : base(headerInfo, GroupType.Entry) { }

        /// <summary>
        /// 情報部名
        /// </summary>
        public override string Name
        {
            get
            {
                if (this.HeaderInfo.IsMBTable)
                {
                    return "ＤＳＭＢ管理Ｔエントリ部";
                }
                else
                {
                    return "エントリ部";
                }
            }
        }
    }

    /// <summary>
    /// 制御情報部２クラス
    /// </summary>
    public class GroupCtrl2 : Group
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public GroupCtrl2(HeaderInfo headerInfo) : base(headerInfo, GroupType.Ctrl2) { }

        /// <summary>
        /// 情報部名
        /// </summary>
        public override string Name
        {
            get
            {
                if (this.HeaderInfo.IsMBTable)
                {
                    return "制御部２";
                }
                else
                {
                    return "制御情報部２";
                }
            }
        }
    }
}
