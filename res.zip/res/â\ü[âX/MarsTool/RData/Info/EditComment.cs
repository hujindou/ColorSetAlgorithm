﻿using MarsTool.Common;
using System.Text.RegularExpressions;

namespace MarsTool.RData.Info
{
    /// <summary>
    /// 改修コメントクラス
    /// </summary>
    public class EditComment
    {
        public const string START_COMMENT = @"^[*]{2}\s*S\s*[*]{2}\s*([^\s].*[^\s])?\s*$";
        public const string END_COMMENT = @"^[*]{2}\s*E\s*[*]{2}\s*([^\s].*[^\s])?\s*$";

        /// <summary>
        /// コメントフラグ
        ///  1：エントリの前後に表示  ** S **、** E **  追加/置換
        ///  2：エントリの頭部に表示** S **  追加/置換
        ///  3：エントリの後部に表示** E **  追加/置換
        /// </summary>
        public enum CommentFlg { StartEnd = 1, Start, End }

        public static EditComment Parse(string line, CommentFlg flg)
        {
            if (string.IsNullOrWhiteSpace(line)) return null;

            var pattern = (flg == CommentFlg.Start) ? START_COMMENT : END_COMMENT;
            var match = Regex.Match(line, pattern);
            if (match.Success)
            {
                var comment = new EditComment();
                // コメントフラグ
                comment.Flag = flg;

                if (match.Groups.Count > 1)
                {
                    // コメント内容
                    comment.Content = match.Groups[1].Value;
                }

                return comment;
            }

            return null;
        }

        /// <summary>
        /// コメント内容
        /// </summary>
        private string _content;
        public string Content
        {
            set
            {
                this._content = value;
            }
            get
            {
                return Utils.TrimString(this._content);
            }
        }

        /// <summary>
        /// 順序
        /// </summary>
        private int _order = 0;
        public int Order
        {
            get
            {
                return this._order;
            }
            set
            {
                this._order = value;
            }
        }

        /// <summary>
        /// コメントフラグ
        /// </summary>
        private CommentFlg _commentFlg;
        public CommentFlg Flag
        {
            get
            {
                return this._commentFlg;
            }
            set
            {
                this._commentFlg = value;
            }
        }
    }
}
