﻿using System.Linq;
using MarsTool.Common;
using MarsTool.RData.Text;
using System.Collections.Generic;

namespace MarsTool.RData.Info
{
    /// <summary>
    /// レコードクラス
    /// </summary>
    public class RecordInfo
    {
        /// <summary>
        /// エントリ番号
        /// </summary>
        private int _entryNo;
        public int EntryNo
        {
            set
            {
                this._entryNo = value;
            }
            get
            {
                return this._entryNo;
            }
        }

        /// <summary>
        /// エントリコメント
        /// </summary>
        private string _comment;
        public string Comment
        {
            set
            {
                this._comment = value;
            }
            get
            {
                return Utils.TrimString(this._comment);
            }
        }

        /// <summary>
        /// 削除コメント
        /// </summary>
        private string _delComment;
        public string DelComment
        {
            set
            {
                this._delComment = value;
            }
            get
            {
                return Utils.TrimString(this._delComment);
            }
        }

        /// <summary>
        /// 改修コメントリスト
        /// </summary>
        private List<EditComment> _editCommentList = new List<EditComment>();
        public List<EditComment> EditCommentList
        {
            get
            {
                return this._editCommentList;
            }
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public RecordInfo(int entryNo)
        {
            this._entryNo = entryNo;
        }

        public RecordInfo() : this(1)
        {
            // エントリ番号がデフォールト：１
        }

        /// <summary>
        /// 改修コメントリスト追加
        /// </summary>
        public void AddEditComments(List<EditComment> editComments)
        {
            this._editCommentList.AddRange(editComments);
        }

        private Dictionary<int, FieldInfo> _dicFields = new Dictionary<int, FieldInfo>();
        public FieldInfo this[int key]
        {
            get
            {
                if (this._dicFields.ContainsKey(key))
                {
                    return this._dicFields[key];
                }

                return null;
            }
        }

        public void Remove(int key)
        {
            this._dicFields.Remove(key);
        }

        public void Add(FieldInfo fieldInfo)
        {
            if (fieldInfo.Key == -1) return;

            if (this._dicFields.ContainsKey(fieldInfo.Key))
            {
                this._dicFields[fieldInfo.Key].Value = fieldInfo.Value;
            }
            else
            {
                this._dicFields[fieldInfo.Key] = fieldInfo;
            }
        }

        public void Clear()
        {
            this._dicFields.Clear();
        }

        public bool IsEmpty(List<FieldDefine> fieldDefines)
        {
            if (fieldDefines == null) return true;

            return fieldDefines.All(d =>
            {
                var fieldInfo = this[d.Key];
                if (fieldInfo == null) return true;
                return string.IsNullOrEmpty(fieldInfo.Value);
            });
        }
    }
}
