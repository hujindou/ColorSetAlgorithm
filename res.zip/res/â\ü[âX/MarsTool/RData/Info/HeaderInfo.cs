﻿using MarsTool.Common;
using MarsTool.Models.DB;

namespace MarsTool.RData.Info
{
    /// <summary>
    /// ＲＤＡＴＡファイルヘッダ部共通情報
    /// </summary>
    public class HeaderInfo
    {
        /// <summary>
        /// 展開
        /// </summary>
        public string ExpandFlg { set; get; }
        public string Expand
        {
            set
            {
                this.ExpandFlg = "要".Equals(value) ? "1" : "0";
            }
            get
            {
                return "1".Equals(this.ExpandFlg) ? "要" : "不要";
            }
        }
        /// <summary>
        /// システム名
        /// </summary>
        public string SystemNm { set; get; }
        /// <summary>
        /// サブシステム名
        /// </summary>
        public string SubSystemNm { set; get; }
        /// <summary>
        /// サブシステムID
        /// </summary>
        public string SubSystemId { set; get; }
        /// <summary>
        /// テーブル名
        /// </summary>
        public string TableNm { set; get; }
        /// <summary>
        /// テーブルID
        /// </summary>
        public string TableId { set; get; }
        /// <summary>
        /// コピー句ID
        /// </summary>
        public string CopyId { set; get; }
        /// <summary>
        /// ファイルグループ
        /// </summary>
        public string FileGroup { set; get; }
        /// <summary>
        /// ブロック長
        /// </summary>
        public string BlockLen { set; get; }
        /// <summary>
        /// 構成タイプ
        /// </summary>
        private string _structType = null;
        public string StructType {
            set
            {
                this._structType = value;
            }
            get
            {
                if (string.IsNullOrEmpty(this._structType)) return "5";
                return this._structType;
            }
        }
        /// <summary>
        /// ローダ時ソート要
        /// </summary>
        public string SortFlg { set; get; }
        public string Sort
        {
            set
            {
                this.SortFlg = "要".Equals(value) ? "1" : "0";
            }
            get
            {
                return "1".Equals(this.SortFlg) ? "要" : "不要";
            }
        }
        /// <summary>
        /// キー相対位置
        /// </summary>
        public string KeyLoc { set; get; }
        /// <summary>
        /// キー長
        /// </summary>
        public string KeyLen { set; get; }
        /// <summary>
        /// キー
        /// </summary>
        public string Key { set; get; }
        /// <summary>
        /// ユーザー任意情報
        /// </summary>
        public string UserInfo { set; get; }
        /// <summary>
        /// 最大エントリ数
        /// </summary>
        public int MaxEntryCnt { set; get; }
        /// <summary>
        /// ＲＤＡＴＡファイル名
        /// </summary>
        public string Filename { set; get; }
        /// <summary>
        /// ＲＤＡＴＡファイル名の拡張子
        /// </summary>
        public string ExtFlg { set; get; }
        public string Extension
        {
            set
            {
                if (value == null) return;
                this.ExtFlg = "csv".Equals(value.ToLower()) ? "1" : "2";
            }
            get
            {
                return "1".Equals(this.ExtFlg) ? "csv" : "txt";
            }
        }
        /// <summary>
        /// 共通情報長
        /// </summary>
        public int CommonInfoLen { set; get; }
        /// <summary>
        /// 任意情報長
        /// </summary>
        public int UserInfoLen { set; get; }
        /// <summary>
        /// エントリ数
        /// </summary>
        public int EntryCnt { set; get; }
        /// <summary>
        /// エントリ長
        /// </summary>
        public int EntryLen { set; get; }
        /// <summary>
        /// テーブル全体長
        /// </summary>
        public int TableAllLen { set; get; }
        /// <summary>
        /// ＲＤＡＴＡ共通情報
        /// </summary>
        public T_RDATA T_RDATA { set; get; }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public HeaderInfo()
        {
        }

        /// <summary>
        /// ＭＢ管理テーブルフラグ
        /// </summary>
        internal bool IsMBTable
        {
            get
            {
                return Utils.IsMBTable(this.Filename);
            }
        }
    }
}
