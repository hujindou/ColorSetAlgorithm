﻿using MarsTool.Models;
using MarsTool.Models.DB;
using MarsTool.Properties;
using MarsTool.RData.Info;
using MarsTool.RData.IO.DB;
using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace MarsTool.RData
{
    /// <summary>
    /// ＲＤＡＴＡ新規登録タブクラス
    /// </summary>
    public class NewInsert : EditorBase
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public NewInsert(
            RDataEditor rdataEditor,
            VersionModel version) : base(rdataEditor, version)
        {
        }

        /// <summary>
        /// 画面初期化
        /// </summary>
        public void Init()
        {
            this.RDataInfo = new RDataInfo();
        }

        public bool PreInsert()
        {
            if (!this.RDataEditor.IsValidate()) return false;
            this.RDataEditor.GetForm(this.RDataInfo);

            var subSysId = this.RDataInfo.HeaderInfo.SubSystemId;
            var tableId = this.RDataInfo.HeaderInfo.TableId;

            var dbAccess = new RDataDBAccess(this.Version);
            if (dbAccess.Exists(subSysId, tableId))
            {
                MessageBox.Show($"ＲＤＡＴＡ情報が既に登録済みです。" +
                    $"サブシステムＩＤ:{subSysId}, テーブルＩＤ:{tableId}",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        /// <summary>
        /// ＲＤＡＴＡ情報がＤＢに登録
        /// </summary>
        public void Insert(BackgroundWorker worker, DoWorkEventArgs e)
        {
            try
            {
                using (var context = new mysqlcontext(this.Version.ConnectString))
                {
                    var dbAccess = new RDataDBAccess(worker, this.Version, context);
                    dbAccess.Insert(this.RDataInfo);
                }

                e.Result = "ＲＤＡＴＡ情報が正常に登録されました。" +
                    "\n該当するＲＤＡＴＡファイルを出力タブより出力して下さい。";
            }
            catch (Exception ex)
            {
                this.Logger.Error(ex.Message);
                e.Result = $"E{MessageId.TSR00012_E}\n{ex.Message}";
            }
        }
    }
}
