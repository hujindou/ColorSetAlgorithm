﻿using MarsTool.Properties;
using System;
using System.IO;
using System.Windows.Forms;

namespace MarsTool.RData
{
    /// <summary>
    /// ファイル出力コントロールクラス
    /// </summary>
    public partial class RDataOutput : UserControl
    {
        public FolderBrowserDialog FolderDialog { set; get; }

        /// <summary>
        /// 格納場所
        /// </summary>
        public string SelectedPath
        {
            get
            {
                return this.txtFolder.Text;
            }
        }

        /// <summary>
        /// ＲＤＡＴＡファイル出力
        /// </summary>
        public bool IsOutputFile
        {
            get
            {
                return this.chkFile.Checked;
            }
        }

        /// <summary>
        /// ＲＤＡＴＡ帳票出力
        /// </summary>
        public bool IsOutputExcel
        {
            get
            {
                return this.chkExcel.Checked;
            }
        }

        public Button BtnOutput
        {
            get
            {
                return this.btnOutput;
            }
        }

        public RDataOutput()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 入力検証
        /// </summary>
        /// <returns></returns>
        public bool IsValidate()
        {
            if (!Directory.Exists(this.txtFolder.Text))
            {
                MessageBox.Show("指定した格納フォルダが存在しません。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        /// <summary>
        /// フォルダ選択
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnSelectFolder_Click(object sender, EventArgs e)
        {
            if (this.FolderDialog == null) return;

            if (this.FolderDialog.ShowDialog() == DialogResult.OK)
            {
                this.txtFolder.Text = this.FolderDialog.SelectedPath;
            }
        }

        private void StatusChanged(object sender, EventArgs e)
        {
            this.btnOutput.Enabled = !string.IsNullOrWhiteSpace(this.txtFolder.Text) &&
                (this.chkFile.Checked || this.chkExcel.Checked);
        }
    }
}
