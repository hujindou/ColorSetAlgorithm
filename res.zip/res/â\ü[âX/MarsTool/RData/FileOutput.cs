﻿using MarsTool.Models;
using MarsTool.Models.DB;
using MarsTool.Properties;
using MarsTool.RData.Info;
using MarsTool.RData.IO.DB;
using MarsTool.RData.IO.Excel;
using MarsTool.RData.IO.Text;
using MarsTool.Search;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MarsTool.RData
{
    /// <summary>
    /// ファイル出力タブクラス
    /// </summary>
    class FileOutput : SearchBase<T_RDATA>
    {
        /// <summary>
        /// テーブルＩＤ
        /// </summary>
        private RadioButton RdoRDataTbId { set; get; }

        /// <summary>
        /// テーブル名
        /// </summary>
        private RadioButton RdoRDataTbNm { set; get; }

        /// <summary>
        /// テンプレートファイル
        /// </summary>
        private string TempFile { set; get; }

        /// <summary>
        /// 出力エリア
        /// </summary>
        private RDataOutput RDataOutput { set; get; }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public FileOutput(
            ComboBox subSysIdsCtl,
            RadioButton rdoRDataTbId,
            RadioButton rdoRDataTbNm,
            DataGridView dgv,
            RDataOutput rdataOutput,
            VersionModel version)
            : base(subSysIdsCtl, dgv, version)
        {
            this.TempFile = ConfigurationManager.AppSettings["rdataFileTemplateLocation"];
            this.RdoRDataTbId = rdoRDataTbId;
            this.RdoRDataTbNm = rdoRDataTbNm;
            this.RDataOutput = rdataOutput;
        }

        /// <summary>
        /// サブシステム設定
        /// </summary>
        protected override string[] SearchSysIds()
        {
            return this.Context.T_RDATA.AsNoTracking()
                .Select(r => r.RDATA_SUBSYSID).Distinct().OrderBy(id => id).ToArray();
        }

        /// <summary>
        /// 検索
        /// </summary>
        /// <param name="dgv"></param>
        protected override List<T_RDATA> SearchData(out int count)
        {
            count = 0;

            List<T_RDATA> rdata = null;

            if (this.RdoRDataTbId.Checked)
            {
                // テーブルＩＤ
                var tableId = (this.RdoRDataTbId.Tag as TextBox).Text;
                tableId = string.IsNullOrWhiteSpace(tableId) ? string.Empty : tableId;
                rdata = this.Context.T_RDATA.AsNoTracking().Where(
                    r => r.RDATA_TABLEID.Contains(tableId) &&
                    (r.RDATA_SUBSYSID == this.SubSysId || string.Empty.Equals(this.SubSysId))
                    ).Take(MAX_COUNT + 1).ToList();

                count = rdata.Count();
                if (count > MAX_COUNT)
                {
                    count = this.Context.T_RDATA.AsNoTracking().Count(
                        r => r.RDATA_TABLEID.Contains(tableId) &&
                        (r.RDATA_SUBSYSID == this.SubSysId || string.Empty.Equals(this.SubSysId)));
                }
            }
            else
            {
                // テーブル名
                var tableNm = (this.RdoRDataTbNm.Tag as TextBox).Text;
                tableNm = string.IsNullOrWhiteSpace(tableNm) ? string.Empty : tableNm;
                rdata = this.Context.T_RDATA.AsNoTracking().Where(
                    r => r.RDATA_TABLENM.Contains(tableNm) &&
                    (r.RDATA_SUBSYSID == this.SubSysId || string.Empty.Equals(this.SubSysId))
                    ).Take(MAX_COUNT + 1).ToList();

                count = rdata.Count();
                if (count > MAX_COUNT)
                {
                    count = this.Context.T_RDATA.AsNoTracking().Count(
                        r => r.RDATA_TABLENM.Contains(tableNm) &&
                        (r.RDATA_SUBSYSID == this.SubSysId || string.Empty.Equals(this.SubSysId)));
                }
            }

            return rdata.Take(MAX_COUNT).ToList();
        }

        /// <summary>
        /// 検索されたデータが一覧に表示する
        /// </summary>
        /// <param name="queryDatas"></param>
        protected override void SetDgv(List<T_RDATA> queryDatas)
        {
            var fields = new List<string>();
            foreach (var record in queryDatas.ToList())
            {
                fields.Clear();
                // 選択列
                fields.Add("0");
                // サブシステムＩＤ
                fields.Add(record.RDATA_SUBSYSID);
                // テーブルＩＤ
                fields.Add(record.RDATA_TABLEID);
                // テーブル名
                fields.Add(record.RDATA_TABLENM);
                // コピー句ＩＤ
                fields.Add(record.RDATA_COPYID);
                // ＲＤＡＴＡファイル名
                fields.Add(record.RDATA_RDATAFNM);
                // 拡張子
                fields.Add("1".Equals(record.RDATA_RDATAFEXT) ? "csv" : "txt");

                var index = this.Dgv.Rows.Add(fields.ToArray());
                this.Dgv.Rows[index].Tag = record;
            }
        }

        protected override void ChangeStatus(bool nodata)
        {
            this.RDataOutput.Enabled = !nodata;
        }

        public bool PreOutput()
        {
            if (!this.RDataOutput.IsValidate()) return false;
            if (this.RDataOutput.IsOutputExcel && !File.Exists(this.TempFile))
            {
                MessageBox.Show($"コンフィグファイルに指定したテンプレートファイルが存在しません。\n[{this.TempFile}]",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        /// <summary>
        /// ファイル出力
        /// </summary>
        /// <param name="worker"></param>
        /// <param name="e"></param>
        public void Output(BackgroundWorker worker, DoWorkEventArgs e)
        {
            using (var context = new mysqlcontext(this.Version.ConnectString))
            {
                var dbAccess = new RDataDBAccess(this.Version, context);

                var rows = this.Dgv.Rows.Cast<DataGridViewRow>().Where(r => "1".Equals(r.Cells[0].Value));
                foreach (DataGridViewRow row in rows)
                {
                    row.Cells[0].Value = "0";

                    var statusCell = row.Cells["Status"];
                    try
                    {
                        statusCell.Style.ForeColor = Color.Blue;
                        statusCell.Value = "処理中。。。";

                        var rdata = row.Tag as T_RDATA;
                        if (rdata == null) continue;

                        worker.ReportProgress(0);

                        var rdataInfos = dbAccess.Select(rdata.RDATA_SUBSYSID, rdata.RDATA_TABLEID);
                        if (rdataInfos == null)
                        {
                            statusCell.Style.ForeColor = Color.Red;
                            statusCell.Value = "ＤＢにデータ存在しません。";
                            continue;
                        }

                        if (this.RDataOutput.IsOutputFile) this.OutputFile(rdataInfos[0]);
                        if (this.RDataOutput.IsOutputExcel) this.OutputExcel(worker, rdataInfos[0]);

                        worker.ReportProgress(100);

                        statusCell.Value = "出力しました。";
                    }
                    catch (Exception ex)
                    {
                        statusCell.Style.ForeColor = Color.Red;
                        statusCell.Value = ex.Message;
                        this.Logger.Error(ex.Message);
                    }
                    finally
                    {
                        Application.DoEvents();
                    }
                }
            }

            e.Result = "出力処理が完了しました。";
        }

        public void AfterOutput()
        {
            var rows = this.Dgv.Rows.Cast<DataGridViewRow>();
            var hasSelectedRow = rows.Any(r => "1".Equals(r.Cells[0].Value));
            this.ChangeStatus(!hasSelectedRow);

            if (this.Dgv.Tag is CheckBox chkbox) chkbox.Checked = hasSelectedRow;
        }

        /// <summary>
        /// ＲＤＡＴＡファイル出力
        /// </summary>
        /// <param name="rdataInfo"></param>
        private void OutputFile(RDataInfo rdataInfo)
        {
            var folder = this.RDataOutput.SelectedPath;
            var headerInfo = rdataInfo.HeaderInfo;
            var filename = $"{headerInfo.Filename}.{headerInfo.Extension}";

            var writer = new RDataFileWriter(rdataInfo);
            writer.Write(Path.Combine(folder, filename), Encoding.GetEncoding("Shift_JIS"));
        }

        /// <summary>
        /// ＲＤＡＴＡ帳票出力
        /// </summary>
        /// <param name="rdataInfo"></param>
        private void OutputExcel(BackgroundWorker worker, RDataInfo rdataInfo)
        {
            var folder = this.RDataOutput.SelectedPath;
            var headerInfo = rdataInfo.HeaderInfo;
            var filename = $"{headerInfo.Filename}.xlsx";
            var fullname = Path.Combine(folder, filename);

            File.Copy(this.TempFile, fullname);

            var writer = new ExcelWriter(rdataInfo);
            writer.Write(worker, fullname);
        }
    }
}
