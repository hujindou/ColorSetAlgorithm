﻿using MarsTool.RData.Info;

namespace MarsTool.RData.IO.Text
{
    /// <summary>
    /// ＲＤＡＴＡ情報部書込ベースクラス
    /// </summary>
    public abstract class GroupWriterBase : TextWriterBase
    {
        /// <summary>
        /// ＲＤＡＴＡ情報部
        /// </summary>
        private Group _group = null;
        public Group Group
        {
            get
            {
                return this._group;
            }
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>

        public GroupWriterBase(Group group)
        {
            this._group = group;
        }

        /// <summary>
        /// 情報部のヘッダ部書込
        /// </summary>
        /// <returns></returns>
        protected virtual void WriteHeader()
        {
            // ＭＢ管理テーブルの場合
            if (this.Group.HeaderInfo.IsMBTable)
            {
                this.Add(GROUP_HEADER_COMMENT_LINE);
                this.Add(string.Format("*,{0}", this._group.Name));
                this.Add(GROUP_HEADER_COMMENT_LINE);
            }
            else
            {
                this.Add(this._group.Name);
            }
        }

        /// <summary>
        /// エントリレコード書込
        /// </summary>
        public virtual void WriteRecord()
        {
            // レコード情報ライター
            new RecordWriter(this._group, this.Lines).Write();
        }

        /// <summary>
        /// 書込処理
        /// </summary>
        public override void Write()
        {
            // 情報部のヘッダ部書込
            this.WriteHeader();

            // レコード書込
            this.WriteRecord();
        }
    }

    /// <summary>
    /// ローダインタフェース情報部読込クラス
    /// </summary>
    public class GroupInterfaceWriter : GroupWriterBase
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public GroupInterfaceWriter(GroupInterface groupInterface) : base(groupInterface) { }

        /// <summary>
        /// 情報部のヘッダ部書込
        /// </summary>
        /// <returns></returns>
        protected override void WriteHeader()
        {
            this.Add(this.Group.Name);
        }

        /// <summary>
        /// 書込処理
        /// </summary>
        public override void Write()
        {
            if (this.Group.RecordList.Count > 0)
            {
                base.Write();
                this.Add(COMMENT_LINE);
            }
        }
    }

    /// <summary>
    /// 制御情報部１書込クラス
    /// </summary>
    public class GroupCtrl1Writer : GroupWriterBase
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public GroupCtrl1Writer(GroupCtrl1 groupCtrl1) : base(groupCtrl1) { }

        /// <summary>
        /// 書込処理
        /// </summary>
        public override void Write()
        {
            base.Write();

            // ＭＢ管理テーブル以外の場合
            if (!this.Group.HeaderInfo.IsMBTable)
            {
                this.Add(COMMENT_LINE);
            }
        }
    }

    /// <summary>
    /// 共通情報部書込クラス
    /// </summary>
    public class GroupCommonWriter : GroupWriterBase
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public GroupCommonWriter(GroupCommon groupCommon) : base(groupCommon) { }

        /// <summary>
        /// 書込処理
        /// </summary>
        public override void Write()
        {
            base.Write();

            // ＭＢ管理テーブル以外の場合
            if (!this.Group.HeaderInfo.IsMBTable)
            {
                this.Add(COMMENT_LINE);
            }
        }
    }

    /// <summary>
    /// 共通情報部・ユーザ任意情報書込クラス
    /// </summary>
    public class GroupUserWriter : GroupWriterBase
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public GroupUserWriter(GroupUser groupUser) : base(groupUser) { }

        /// <summary>
        /// 情報部のヘッダ部書込
        /// </summary>
        /// <returns></returns>
        protected override void WriteHeader()
        {
            this.Add(this.Group.Name);
        }

        /// <summary>
        /// 書込処理
        /// </summary>
        public override void Write()
        {
            if (this.Group.RecordList.Count > 0)
            {
                base.Write();
                this.Add(COMMENT_LINE);
            }
        }
    }

    /// <summary>
    /// エントリ部書込クラス
    /// </summary>
    public class GroupEntryWriter : GroupWriterBase
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public GroupEntryWriter(GroupEntry groupEntry) : base(groupEntry) { }

        /// <summary>
        /// エントリレコード書込
        /// </summary>
        public override void WriteRecord()
        {
            // レコード情報リーダー
            new EntryRecordWriter(this.Group, this.Lines).Write();
        }

        /// <summary>
        /// 情報部のヘッダ部書込
        /// </summary>
        /// <returns></returns>
        protected override void WriteHeader()
        {
            // ＭＢ管理テーブルの場合
            if (this.Group.HeaderInfo.IsMBTable)
            {
                this.Add("*,ＭＢテーブルの詳細はＭＤＣＥ－Ｓのデータ仕様書を参照。");
                this.Add("*,ＭＢテーブルは、１つのＭＢ種別を１ブロック内に定義するため、");
                this.Add("*,ＭＢ種別の間に境界調整要のヨビがある点に注意");
                this.Add("*,　例：ＭＢ種別=Tは16エントリ後にヨビが248ﾊﾞｲﾄある。");
                this.Add("*,　　　208 × 16 + 248 = 3576 （１ブロック長）");
                this.Add(GROUP_HEADER_COMMENT_LINE);
                this.Add(string.Format("*,{0}", this.Group.Name));
                this.Add(GROUP_HEADER_COMMENT_LINE);
            }
            else
            {
                this.Add(this.Group.Name + "START");
            }
        }

        /// <summary>
        /// 情報部のフッター部書込
        /// </summary>
        /// <returns></returns>
        protected void WriteFooter()
        {
            // ＭＢ管理テーブル以外の場合
            if (!this.Group.HeaderInfo.IsMBTable)
            {
                this.Add(this.Group.Name + "END");
                this.Add(COMMENT_LINE);
            }
        }

        /// <summary>
        /// 書込処理
        /// </summary>
        public override void Write()
        {
            // 情報部のヘッダ部書込
            this.WriteHeader();

            // レコード書込
            this.WriteRecord();

            // 情報部のフッター部書込
            this.WriteFooter();
        }
    }

    /// <summary>
    /// 制御情報部２書込クラス
    /// </summary>
    public class GroupCtrl2Writer : GroupWriterBase
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public GroupCtrl2Writer(GroupCtrl2 groupCtrl2) : base(groupCtrl2) { }

        /// <summary>
        /// 書込処理
        /// </summary>
        public override void Write()
        {
            base.Write();

            this.Add("**** CSV出力終了 ****");
        }
    }
}
