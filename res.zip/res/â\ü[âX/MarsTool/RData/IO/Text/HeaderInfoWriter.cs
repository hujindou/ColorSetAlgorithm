﻿using MarsTool.Common;
using MarsTool.RData.Info;

namespace MarsTool.RData.IO.Text
{
    /// <summary>
    /// ヘッダ部共通項目書込クラス
    /// </summary>
    public class HeaderInfoWriter : TextWriterBase
    {
        /// <summary>
        /// ヘッダ部共通項目
        /// </summary>
        private HeaderInfo _headerInfo = null;

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public HeaderInfoWriter(HeaderInfo headerInfo)
        {
            this._headerInfo = headerInfo;
        }

        /// <summary>
        /// 書込処理
        /// </summary>
        public override void Write()
        {
            // ＭＢ管理テーブル
            if (this._headerInfo.IsMBTable)
            {
                // 一行目
                this.Add("CSV,,,,,,");
                // ブロック長
                this.Add(string.Format("TBL,{0},,,,,,", this._headerInfo.BlockLen));
            }
            else
            {
                // 一行目
                this.Add("CSV");
                // ブロック長
                this.Add(string.Format("TBL,{0}", this._headerInfo.BlockLen));
            }

            this.Add(COMMENT_LINE);

            // システム名
            this.Add(string.Format("*  システム名      {0}", this._headerInfo.SystemNm));
            this.Add(BLANK_LINE);

            // サブシステム名
            this.Add(string.Format("*  サブシステム名  {0}（{1}）",
                this._headerInfo.SubSystemNm,
                Utils.ToZenkaku(this._headerInfo.SubSystemId)));
            this.Add(BLANK_LINE);

            // テーブル名
            this.Add(string.Format("*  テーブル名      {0}（{1}）",
                this._headerInfo.TableNm,
                this._headerInfo.TableId));
            this.Add(BLANK_LINE);

            // コピー句ＩＤ
            this.Add(string.Format(
                "*    コピー句ＩＤ            {0}", this._headerInfo.CopyId));
            // ファイルグループ
            this.Add(string.Format(
                "*    ファイルグループ        {0}", Utils.ToZenkaku(this._headerInfo.FileGroup)));
            // ブロック長（バイト）
            this.Add(string.Format(
                "*    ブロック長（バイト）    {0}", Utils.ToZenkaku(this._headerInfo.BlockLen)));
            // ファイル構成タイプ
            this.Add(string.Format(
                "*    ファイル構成タイプ      {0}", Utils.ToZenkaku(this._headerInfo.StructType)));
            // ローダ時のソート
            this.Add(string.Format(
                "*    ローダ時のソート        {0}", Utils.ToZenkaku(this._headerInfo.Sort)));
            if ("要".Equals(this._headerInfo.Sort))
            {
                // キー
                this.Add(string.Format("*    キー                    {0}", this._headerInfo.Key));
                // キー位置・キー長
                this.Add(string.Format("*    キー位置・キー長        {0}－{1}",
                    Utils.ToZenkaku(this._headerInfo.KeyLoc),
                    Utils.ToZenkaku(this._headerInfo.KeyLen)));
            }
            this.Add(BLANK_LINE);
            this.Add(COMMENT_LINE);
            this.Add(FIELDS_LINE);
        }
    }
}
