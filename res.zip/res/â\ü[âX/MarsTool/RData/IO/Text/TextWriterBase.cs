﻿namespace MarsTool.RData.IO.Text
{
    /// <summary>
    /// テキスト書込ベースクラス
    /// </summary>
    public abstract class TextWriterBase
    {
        public const string COMMENT_LINE = "*-------------------------------------------------------------------------------";
        public const string BLANK_LINE = "*";
        public const string GROUP_HEADER_COMMENT_LINE = "*******************************************************";
        public const string RECORD_HEADER_COMMENT_LINE = "****************************************";
        public const string FIELDS_LINE = "*,項目名,データ型,サイズ,データ内容,チェック種別,コメント";

        /// <summary>
        /// ファイル行情報
        /// </summary>
        private LinesWrapper _linesWrapper = null;
        public LinesWrapper Lines
        {
            set
            {
                this._linesWrapper = value;
            }
            get
            {
                return this._linesWrapper;
            }
        }

        public void Add(string line)
        {
            if (this._linesWrapper == null) return;

            this._linesWrapper.Add(line);
        }
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public TextWriterBase() { }
        
        /// <summary>
        /// 書込処理
        /// </summary>
        public abstract void Write();
    }
}
