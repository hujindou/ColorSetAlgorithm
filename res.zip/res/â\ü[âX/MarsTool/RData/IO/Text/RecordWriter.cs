﻿using MarsTool.Common;
using MarsTool.RData.Info;
using System.Collections.Generic;
using System.Linq;
using Regular = System.Text.RegularExpressions;

namespace MarsTool.RData.IO.Text
{
    /// <summary>
    /// レコード情報書込クラス
    /// </summary>
    public class RecordWriter : TextWriterBase
    {
        /// <summary>
        /// ＲＤＡＴＡ情報部
        /// </summary>
        private Group _group = null;
        public Group Group
        {
            get
            {
                return this._group;
            }
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public RecordWriter(Group group, LinesWrapper lines)
        {
            this._group = group;
            this.Lines = lines;
        }

        /// <summary>
        /// 項目書込処理
        /// </summary>
        protected virtual void WriteItems(RecordInfo record)
        {
            foreach (var fieldDef in this._group.FieldDefList)
            {
                // データ内容
                var value = string.Empty;
                // チェック種別
                var chkType = string.Empty;
                // コメント
                var comment = string.Empty;

                var fieldInfo = record[fieldDef.Key];
                if (fieldInfo != null)
                {
                    value = fieldInfo.Value;
                    chkType = fieldInfo.CheckType;
                    comment = fieldInfo.Comment;
                }

                // ＭＢ管理テーブルの場合
                if (this.Group.HeaderInfo.IsMBTable)
                {
                    this.Lines.Add(
                    $",{fieldDef.ItemName}," +
                    $"{fieldDef.DataAttr}," +
                    $"{fieldDef.Size}," +
                    $"{value}," +
                    $"{chkType}," +
                    $"{comment}");
                }
                else
                {
                    this.Lines.Add(
                    $",{fieldDef.ItemName}," +
                    $"{fieldDef.DataAttr}," +
                    $"{fieldDef.Size}," +
                    $"{value}");
                }
            }

            // ＭＢ管理テーブルの場合
            if (this.Group.HeaderInfo.IsMBTable && this.Group is GroupCommon)
            {
                for (var i = 0; i < 35; i++)
                {
                    this.Lines.Add(",FILLER,YOBI,100,,,");
                }
                this.Lines.Add(",FILLER,YOBI,36,,,");
            }
        }

        /// <summary>
        /// 書込処理
        /// </summary>
        public override void Write()
        {
            if (this._group.RecordList.Count > 0)
            {
                this.WriteItems(this._group.RecordList[0]);
            }
        }
    }

    /// <summary>
    /// エントリレコード情報書込クラス
    /// </summary>
    public class EntryRecordWriter : RecordWriter
    {
        /// <summary>
        /// 開始コメントリスト
        /// </summary>
        private List<string> _startComments = new List<string>();

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public EntryRecordWriter(Group group, LinesWrapper lines) : base(group, lines) { }

        /// <summary>
        /// 書込処理
        /// </summary>
        public override void Write()
        {
            // ＭＢ管理テーブルの場合
            if (this.Group.HeaderInfo.IsMBTable)
            {
                this.Group.RecordList.ForEach(r => this.WriteRecord(r));
            }
            else
            {
                var preDelComment = string.Empty;
                var delEntryCnt = 0;
                foreach (var record in this.Group.RecordList)
                {
                    if (string.IsNullOrWhiteSpace(record.DelComment))
                    {
                        this.WriteDelRecord(delEntryCnt, preDelComment);
                        preDelComment = string.Empty;
                        delEntryCnt = 0;

                        this.WriteRecord(record);
                        continue;
                    }

                    if (preDelComment.Equals(record.DelComment))
                    {
                        delEntryCnt += this.GetDelEntryCnt(record.Comment);
                    }
                    else
                    {
                        this.WriteDelRecord(delEntryCnt, preDelComment);
                        preDelComment = record.DelComment;
                        delEntryCnt = this.GetDelEntryCnt(record.Comment);
                    }
                }
                this.WriteDelRecord(delEntryCnt, preDelComment);
            }
        }
        
        private int GetDelEntryCnt(string comment)
        {
            var match = Regular.Regex.Match(comment, "^(.+)エントリ$");
            if (match.Success)
            {
                var strEntryCnt = Utils.ToHankaku(match.Groups[1].Value);
                if (int.TryParse(strEntryCnt, out int entryCnt))
                {
                    return entryCnt;
                }
            }

            return 1;
        }

        /// <summary>
        /// レコード書込
        /// </summary>
        /// <returns></returns>
        private void WriteRecord(RecordInfo record)
        {
            // 開始コメント書込
            this.WriteComments(record, EditComment.CommentFlg.Start);

            // ヘッダ部書込
            this.WriteHeader(record);

            // 項目書込
            this.WriteItems(record);

            // 終了コメント書込
            this.WriteComments(record, EditComment.CommentFlg.End);
        }

        /// <summary>
        /// 削除されたレコード書込
        /// </summary>
        /// <param name="delEntryCnt"></param>
        /// <param name="delComment"></param>
        private void WriteDelRecord(int delEntryCnt, string delComment)
        {
            if (delEntryCnt <= 0) return;

            this.Lines.Add($"削除・{Utils.ToZenkaku(delEntryCnt.ToString())}エントリ・{delComment}");
        }

        /// <summary>
        /// レコードのコメント書込
        /// </summary>
        /// <returns></returns>
        private void WriteComments(RecordInfo record, EditComment.CommentFlg flg)
        {
            var comments = record.EditCommentList.Where(
                item =>
                item.Flag == EditComment.CommentFlg.StartEnd ||
                item.Flag == flg);
            if (comments == null) return;

            if (EditComment.CommentFlg.Start == flg)
            {
                foreach(var comment in comments)
                {
                    this.Lines.Add($"** S ** {comment.Content}");
                    this._startComments.Add(comment.Content);
                }
            }
            else
            {
                var endComments = comments.OrderByDescending(
                    comment => this._startComments.IndexOf(comment.Content));
                foreach (var comment in endComments)
                {
                    this.Lines.Add($"** E ** {comment.Content}");
                }
            }
        }

        /// <summary>
        /// レコードのヘッダ部書込
        /// </summary>
        /// <returns></returns>
        private void WriteHeader(RecordInfo record)
        {
            this.Lines.Add(RECORD_HEADER_COMMENT_LINE);

            var header = string.Empty;
            // ＭＢ管理テーブルの場合
            if (this.Group.HeaderInfo.IsMBTable)
            {
                var entryNo = Utils.ToZenkaku(record.EntryNo.ToString());
                header = $"*,ＤＳＭＢ管理Ｔエントリ（{entryNo}）";
            }
            else
            {
                header = string.Format("* {0}", record.Comment);
            }

            if (!string.IsNullOrWhiteSpace(record.DelComment))
            {
                header += " 削除・" + record.DelComment;
            }
            this.Lines.Add(header);

            this.Lines.Add(RECORD_HEADER_COMMENT_LINE);
        }

        /// <summary>
        /// 項目書込処理
        /// </summary>
        protected override void WriteItems(RecordInfo record)
        {
            base.WriteItems(record);

            var header = this.Group.HeaderInfo;
            var entryCnt = this.Group.RecordList.Count;

            // ＭＢ管理テーブルの場合
            if (this.Group.HeaderInfo.IsMBTable)
            {
                if (record.EntryNo % 16 == 0 && record.EntryNo != entryCnt)
                {
                    this.Lines.Add(",FILLER,YOBI,50,,,");
                    this.Lines.Add(",FILLER,YOBI,50,,,");
                    this.Lines.Add(",FILLER,YOBI,50,,,");
                    this.Lines.Add(",FILLER,YOBI,50,,,");
                    this.Lines.Add(",FILLER,YOBI,48,,,");
                }
            }
        }
    }
}
