﻿using MarsTool.Common;
using MarsTool.RData.Info;
using System;
using System.Text.RegularExpressions;

namespace MarsTool.RData.IO.Text
{
    /// <summary>
    /// ヘッダ部共通項目読込クラス
    /// </summary>
    public class HeaderInfoReader : TextReaderBase
    {
        /// <summary>
        /// ヘッダ部共通項目
        /// </summary>
        private HeaderInfo _headerInfo = null;

        public HeaderInfoReader(HeaderInfo headerInfo)
        {
            this._headerInfo = headerInfo;
        }

        /// <summary>
        /// 読込処理
        /// </summary>
        public override void Read()
        {
            // 一行目
            var line = this.Next();
            if (line == null || !line.StartsWith("CSV"))
            {
                throw new Exception("ＲＤＡＴＡファイルのフォーマットが不正。");
            }

            // ブロック長
            line = this.Next();
            var fields = line.Split(',');
            if (fields.Length < 2 || string.IsNullOrWhiteSpace(fields[1]))
            {
                throw new Exception("二行目からブロック長が取得失敗しました。");
            }
            this._headerInfo.BlockLen = fields[1];

            // システム名
            line = this.Next();
            var matches = Regex.Match(line, @"^[*]\s*システム名\s*([^\s].*[^\s])\s*$");
            if (!matches.Success)
            {
                throw new Exception("システム名が取得失敗しました。");
            }
            this._headerInfo.SystemNm = matches.Groups[1].Value;

            // サブシステム名
            line = this.Next();
            matches = Regex.Match(line, @"^[*]\s*サブシステム名\s*([^\s]+)\s*[（](.*)[）]\s*$");
            if (!matches.Success)
            {
                throw new Exception("サブシステム名またはサブシステムＩＤが取得失敗しました。");
            }
            this._headerInfo.SubSystemNm = matches.Groups[1].Value;
            this._headerInfo.SubSystemId = Utils.ToHankaku(matches.Groups[2].Value);
            if (this._headerInfo.SubSystemId.Length > 4)
            {
                throw new Exception("サブシステムＩＤの長さが4文字数を超過する。");
            }

            // テーブル名
            line = this.Next();
            matches = Regex.Match(line, @"^[*]\s*テーブル名\s*([^\s]+)\s*[（](.*)[）]\s*$");
            if (!matches.Success)
            {
                throw new Exception("テーブル名またはテーブルＩＤが取得失敗しました。");
            }
            this._headerInfo.TableNm = matches.Groups[1].Value;
            this._headerInfo.TableId = matches.Groups[2].Value;
            if (this._headerInfo.TableId.Length > 10)
            {
                throw new Exception("テーブルＩＤの長さが10文字数を超過する。");
            }

            // コピー句ＩＤ
            line = this.Next();
            matches = Regex.Match(line, @"^[*]\s*コピー句ＩＤ\s*([^\s].*[^\s])\s*$");
            if (!matches.Success)
            {
                throw new Exception("コピー句ＩＤが取得失敗しました。");
            }
            this._headerInfo.CopyId = matches.Groups[1].Value;
            if (this._headerInfo.CopyId.Length > 20)
            {
                throw new Exception("コピー句ＩＤの長さが20文字数を超過する。");
            }

            // ファイルグループ
            line = this.Next();
            matches = Regex.Match(line, @"^[*]\s*ファイルグループ\s*([^\s].*[^\s])\s*$");
            if (!matches.Success)
            {
                throw new Exception("ファイルグループが取得失敗しました。");
            }
            this._headerInfo.FileGroup = Utils.ToHankaku(matches.Groups[1].Value);

            // ブロック長（バイト）
            line = this.Next();
            matches = Regex.Match(line, @"^[*]\s*ブロック長[（]バイト[）]\s*([^\s]+)\s*$");
            if (!matches.Success)
            {
                throw new Exception("ブロック長が取得失敗しました。");
            }

            // ファイル構成タイプ
            line = this.Next();
            matches = Regex.Match(line, @"^[*]\s*ファイル構成タイプ\s*([^\s]+)\s*$");
            if (!matches.Success)
            {
                throw new Exception("ファイル構成タイプが取得失敗しました。");
            }
            this._headerInfo.StructType = Utils.ToHankaku(matches.Groups[1].Value);

            // ローダ時のソート
            line = this.Next();
            matches = Regex.Match(line, @"^[*]\s*ローダ時のソート\s*([^\s]+)\s*$");
            if (!matches.Success)
            {
                throw new Exception("ローダ時のソートが取得失敗しました。");
            }
            this._headerInfo.Sort = matches.Groups[1].Value;

            if ("要".Equals(this._headerInfo.Sort))
            {
                // キー
                line = this.Next();
                matches = Regex.Match(line, @"^[*]\s*キー\s*([^\s]+)\s*$");
                if (!matches.Success)
                {
                    throw new Exception("キーが取得失敗しました。");
                }
                this._headerInfo.Key = matches.Groups[1].Value;

                // キー位置・キー長
                line = this.Next();
                matches = Regex.Match(line, @"^[*]\s*キー位置・キー長\s*([^\s]+)[－]([^\s]+)\s*$");
                if (!matches.Success)
                {
                    throw new Exception("キー位置まはたキー長が取得失敗しました。");
                }
                this._headerInfo.KeyLoc = Utils.ToHankaku(matches.Groups[1].Value);
                this._headerInfo.KeyLen = Utils.ToHankaku(matches.Groups[2].Value);
            }
        }
    }
}
