﻿using MarsTool.Exceptions;
using MarsTool.Models;
using MarsTool.Models.DB;
using MarsTool.RData.Info;
using MarsTool.RData.Text;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using static MarsTool.RData.Info.EditComment;
using static MarsTool.RData.Info.Group;

namespace MarsTool.RData.IO.DB
{
    /// <summary>
    /// ＤＢのＲＤＡＴＡ情報アクセスクラス
    /// </summary>
    class RDataDBAccess
    {
        private BackgroundWorker Worker { set; get; }

        /// <summary>
        /// バージョンモデル
        /// </summary>
        private VersionModel Version { get; set; }

        /// <summary>
        /// バージョンモデル
        /// </summary>
        private mysqlcontext Context { set; get; }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public RDataDBAccess(VersionModel version, mysqlcontext context)
        {
            this.Version = version;
            this.Context = context;
        }
        public RDataDBAccess(VersionModel version) : this(version, version.context) { }
        public RDataDBAccess(BackgroundWorker worker, VersionModel version, mysqlcontext context)
            : this(version, context)
        {
            this.Worker = worker;
        }

        public bool Exists(string subSysId, string tableId)
        {
            return this.Context.T_RDATA.AsNoTracking()
                .Any(r => r.RDATA_SUBSYSID == subSysId && r.RDATA_TABLEID == tableId);
        }

        /// <summary>
        /// ＲＤＡＴＡ共通情報
        /// </summary>
        private bool SelectHeader(HeaderInfo headerInfo1, HeaderInfo headerInfo2)
        {
            // サブシステムID
            var subSysId = headerInfo1.SubSystemId;
            // テーブルID
            var tableId = headerInfo1.TableId;
            var rdatas = this.Context.T_RDATA.AsNoTracking()
                .Where(r => r.RDATA_SUBSYSID == subSysId && r.RDATA_TABLEID == tableId);
            if (rdatas == null || rdatas.Count() <= 0)
            {
                return false;
            }

            var rdata = rdatas.First();
            // 展開
            headerInfo1.ExpandFlg = rdata.RDATA_EXPAND;
            headerInfo2.ExpandFlg = rdata.RDATA_EXPAND;
            // システム名
            headerInfo1.SystemNm = rdata.RDATA_SYSNM;
            headerInfo2.SystemNm = rdata.RDATA_SYSNM;
            // サブシステム名
            headerInfo1.SubSystemNm = rdata.RDATA_SUBSYSNM;
            headerInfo2.SubSystemNm = rdata.RDATA_SUBSYSNM;
            // テーブル名
            headerInfo1.TableNm = rdata.RDATA_TABLENM;
            headerInfo2.TableNm = rdata.RDATA_TABLENM;
            // ブロック長
            headerInfo1.BlockLen = rdata.RDATA_BLKLEN.ToString();
            headerInfo2.BlockLen = rdata.RDATA_BLKLEN.ToString();
            // サブシステムＩＤ
            headerInfo1.SubSystemId = rdata.RDATA_SUBSYSID;
            headerInfo2.SubSystemId = rdata.RDATA_SUBSYSID;
            // テーブルＩＤ
            headerInfo1.TableId = rdata.RDATA_TABLEID;
            headerInfo2.TableId = rdata.RDATA_TABLEID;
            // RDATAファイル名
            headerInfo1.Filename = rdata.RDATA_RDATAFNM;
            headerInfo2.Filename = rdata.RDATA_RDATAFNM;
            // 拡張子
            headerInfo1.ExtFlg = rdata.RDATA_RDATAFEXT;
            headerInfo2.ExtFlg = rdata.RDATA_RDATAFEXT;
            // コピー句ＩＤ
            headerInfo1.CopyId = rdata.RDATA_COPYID;
            headerInfo2.CopyId = rdata.RDATA_COPYID;
            // ファイルグループ
            headerInfo1.FileGroup = rdata.RDATA_FILEGRP;
            headerInfo2.FileGroup = rdata.RDATA_FILEGRP;
            // 構成タイプ
            headerInfo1.StructType = rdata.RDATA_STUTYPE;
            headerInfo2.StructType = rdata.RDATA_STUTYPE;
            // ローダ時のソート
            headerInfo1.SortFlg = rdata.RDATA_SORT;
            headerInfo2.SortFlg = rdata.RDATA_SORT;
            // キー相対位置
            headerInfo1.KeyLoc = rdata.RDATA_KEYLOC;
            headerInfo2.KeyLoc = rdata.RDATA_KEYLOC;
            // キー長
            headerInfo1.KeyLen = rdata.RDATA_KEYLEN;
            headerInfo2.KeyLen = rdata.RDATA_KEYLEN;
            // キー
            headerInfo1.Key = rdata.RDATA_KEY;
            headerInfo2.Key = rdata.RDATA_KEY;
            // 最大エントリ数
            headerInfo1.MaxEntryCnt = rdata.RDATA_MAXENTRY;
            headerInfo2.MaxEntryCnt = rdata.RDATA_MAXENTRY;

            headerInfo1.T_RDATA = rdata;
            headerInfo2.T_RDATA = rdata;

            return true;
        }

        private void SetItems(Group group1, Group group2, List<T_RDTITEM> iItems)
        {
            this.SetItems(group1, group2, new RecordInfo(), new RecordInfo(), iItems);
        }

        private void SetItems(
            Group group1,
            Group group2,
            RecordInfo record1,
            RecordInfo record2,
            List<T_RDTITEM> iItems)
        {
            var isFirst = group1.FieldDefList.Count == 0;
            FieldDefine fieldDef = null;
            var count = iItems.Count;
            for (var i = 0; i < count; i++)
            {
                var item = iItems[i];

                if (isFirst || i >= group1.FieldDefList.Count)
                {
                    fieldDef = new FieldDefine
                    {
                        // 項目名
                        ItemName = item.RDTITM_ITEMNM,
                        // データ型
                        DataAttr = item.RDTITM_DATATYPE,
                        // サイズ
                        Size = item.RDTITM_SIZE.ToString()
                    };
                    group1.FieldDefList.Add(fieldDef);
                    group2.FieldDefList.Add(new FieldDefine(fieldDef));
                }
                else
                {
                    fieldDef = group1.FieldDefList[i];
                }

                var field = new FieldInfo(fieldDef.Key)
                {
                    // データ内容
                    Value = item.RDTITM_DATA,
                    // チェック種別
                    CheckType = item.RDTITM_CHKTYPE,
                    // コメント
                    Comment = item.RDTITM_COMMENT
                };
                record1.Add(field);
                record2.Add(new FieldInfo(field));
            }

            group1.Add(record1);
            group2.Add(record2);
        }

        /// <summary>
        /// ＲＤＡＴＡ情報部
        /// </summary>
        private void SelectGroup(RDataInfo rdataInfo1, RDataInfo rdataInfo2)
        {
            // サブシステムID
            var subSysId = rdataInfo1.HeaderInfo.SubSystemId;
            // テーブルID
            var tableId = rdataInfo1.HeaderInfo.TableId;
            
            // ＲＤＡＴＡ情報部
            var groups = this.Context.T_RDTINF.AsNoTracking()
                .Where(r => r.RDTINF_SUBSYSID == subSysId &&
                r.RDTINF_TABLEID == tableId).ToArray();

            // ＲＤＡＴＡ改修コメント
            var comments = this.Context.T_RDTCOMT.AsNoTracking()
                .Where(r => r.RDTCOMT_SUBSYSID == subSysId &&
                r.RDTCOMT_TABLEID == tableId).ToArray();

            // ＲＤＡＴＡ項目情報
            var items = this.Context.T_RDTITEM.AsNoTracking()
                .Where(r => r.RDTITM_SUBSYSID == subSysId &&
                r.RDTITM_TABLEID == tableId).ToArray();

            // １：ローダインタフェース情報部
            var infType = ((int)GroupType.Interface).ToString();
            var iItems = items.Where(r => r.RDTITM_INFTYPE == infType)
                .OrderBy(r => r.RDTITM_ITEMNO).ToList();
            if (iItems.Count() > 0)
            {
                SetItems(rdataInfo1.Interface, rdataInfo2.Interface, iItems);
            }

            //２：制御情報部１
            infType = ((int)GroupType.Ctrl1).ToString();
            iItems = items.Where(r => r.RDTITM_INFTYPE == infType)
                .OrderBy(r => r.RDTITM_ITEMNO).ToList();
            if (iItems.Count() > 0)
            {
                SetItems(rdataInfo1.GroupCtrl1, rdataInfo2.GroupCtrl1, iItems);
            }

            //３：共通情報部
            infType = ((int)GroupType.Common).ToString();
            iItems = items.Where(r => r.RDTITM_INFTYPE == infType)
                .OrderBy(r => r.RDTITM_ITEMNO).ToList();
            if (iItems.Count() > 0)
            {
                SetItems(rdataInfo1.GroupCommon, rdataInfo2.GroupCommon, iItems);
            }

            //４：共通情報部・ユーザ任意情報
            infType = ((int)GroupType.User).ToString();
            iItems = items.Where(r => r.RDTITM_INFTYPE == infType)
                .OrderBy(r => r.RDTITM_ITEMNO).ToList();
            if (iItems.Count() > 0)
            {
                SetItems(rdataInfo1.GroupUser, rdataInfo2.GroupUser, iItems);
            }

            //５：エントリ部
            infType = ((int)GroupType.Entry).ToString();
            var groupInfos = groups.Where(r => r.RDTINF_INFTYPE == infType)
                .OrderBy(r => r.RDTINF_ENTNO);
            foreach (var group in groupInfos)
            {
                // 該当するエントリが削除された場合
                if (!string.IsNullOrWhiteSpace(group.RDTINF_DELCOMT))
                {
                    rdataInfo1.GroupEntry.Add(this.NewEntryRecord(group, comments));
                    rdataInfo2.GroupEntry.Add(this.NewEntryRecord(group, comments));
                    continue;
                }

                var entryNo = group.RDTINF_ENTNO;
                iItems = items.Where(r => r.RDTITM_INFTYPE == infType && r.RDTITM_ENTNO == entryNo)
                    .OrderBy(r => r.RDTITM_ITEMNO).ToList();
                if (iItems.Count() > 0)
                {
                    SetItems(
                        rdataInfo1.GroupEntry,
                        rdataInfo2.GroupEntry,
                        this.NewEntryRecord(group, comments),
                        this.NewEntryRecord(group, comments),
                        iItems);
                }
            }

            //６：制御情報部２
            infType = ((int)GroupType.Ctrl2).ToString();
            iItems = items.Where(r => r.RDTITM_INFTYPE == infType)
                .OrderBy(r => r.RDTITM_ITEMNO).ToList();
            if (iItems.Count() > 0)
            {
                SetItems(rdataInfo1.GroupCtrl2, rdataInfo2.GroupCtrl2, iItems);
            }
        }

        /// <summary>
        /// 新しいエントリレコード作成
        /// </summary>
        /// <param name="group"></param>
        /// <param name="comments"></param>
        /// <returns></returns>
        private RecordInfo NewEntryRecord(T_RDTINF group, T_RDTCOMT[] comments)
        {
            var entryNo = group.RDTINF_ENTNO;
            var record = new RecordInfo(entryNo);
            record.Comment = group.RDTINF_ENTCOMT;
            record.DelComment = group.RDTINF_DELCOMT;

            var editComments = comments.Where(r => r.RDTCOMT_ENTNO == entryNo)
                .OrderBy(r => r.RDTCOMT_ORDER);
            foreach (var comment in editComments)
            {
                var editComment = new EditComment();
                editComment.Content = comment.RDTCOMT_COMT;
                editComment.Order = comment.RDTCOMT_ORDER;
                switch (comment.RDTCOMT_COMTFLG)
                {
                    case "1":
                        editComment.Flag = CommentFlg.StartEnd;
                        break;

                    case "2":
                        editComment.Flag = CommentFlg.Start;
                        break;

                    default:
                        editComment.Flag = CommentFlg.End;
                        break;
                }

                record.EditCommentList.Add(editComment);
            }

            return record;
        }

        /// <summary>
        /// ＲＤＡＴＡ情報取得
        /// </summary>
        /// <param name="subSysId"></param>
        /// <param name="tableId"></param>
        /// <returns></returns>
        public RDataInfo[] Select(string subSysId, string tableId)
        {
            var rdataInfo1 = new RDataInfo();
            var rdataInfo2 = new RDataInfo();

            // サブシステムID
            rdataInfo1.HeaderInfo.SubSystemId = subSysId;
            rdataInfo2.HeaderInfo.SubSystemId = subSysId;
            // テーブルID
            rdataInfo1.HeaderInfo.TableId = tableId;
            rdataInfo2.HeaderInfo.TableId = tableId;

            // ＲＤＡＴＡ共通情報
            if (!this.SelectHeader(rdataInfo1.HeaderInfo, rdataInfo2.HeaderInfo))
            {
                return null;
            }

            this.SelectGroup(rdataInfo1, rdataInfo2);

            return new RDataInfo[] { rdataInfo1, rdataInfo2 };
        }

        /// <summary>
        /// ＲＤＡＴＡ情報変更判定
        /// </summary>
        /// <param name="before"></param>
        /// <param name="after"></param>
        /// <returns></returns>
        public bool IsRDataChanged(RDataInfo before, RDataInfo after)
        {
            // ヘッダ部
            if (this.IsHeaderChanged(before, after)) return true;

            // １：ローダインタフェース情報部
            if (this.IsGroupChanged(before.Interface, after.Interface)) return true;

            //２：制御情報部１
            if (this.IsGroupChanged(before.GroupCtrl1, after.GroupCtrl1)) return true;

            //３：共通情報部
            if (this.IsGroupChanged(before.GroupCommon, after.GroupCommon)) return true;

            //４：共通情報部・ユーザ任意情報
            if (this.IsGroupChanged(before.GroupUser, after.GroupUser)) return true;

            //５：エントリ部
            if (this.IsGroupChanged(before.GroupEntry, after.GroupEntry)) return true;

            //６：制御情報部２
            if (this.IsGroupChanged(before.GroupCtrl2, after.GroupCtrl2)) return true;

            return false;
        }

        /// <summary>
        /// ＲＤＡＴＡヘッダ部情報変更判定
        /// </summary>
        /// <param name="before"></param>
        /// <param name="after"></param>
        /// <returns></returns>
        private bool IsHeaderChanged(RDataInfo before, RDataInfo after)
        {
            var beforeHeader = before.HeaderInfo;
            var afterHeader = after.HeaderInfo;

            // システム名
            if (!string.Equals(beforeHeader.SystemNm, afterHeader.SystemNm)) return true;
            // サブシステム名
            if (!string.Equals(beforeHeader.SubSystemNm, afterHeader.SubSystemNm)) return true;
            // テーブル名
            if (!string.Equals(beforeHeader.TableNm, afterHeader.TableNm)) return true;
            // ブロック長
            if (!string.Equals(beforeHeader.BlockLen, afterHeader.BlockLen)) return true;
            // サブシステムＩＤ
            if (!string.Equals(beforeHeader.SubSystemId, afterHeader.SubSystemId)) return true;
            // テーブルＩＤ
            if (!string.Equals(beforeHeader.TableId, afterHeader.TableId)) return true;
            // RDATAファイル名
            if (!string.Equals(beforeHeader.Filename, afterHeader.Filename)) return true;
            // 拡張子
            if (!string.Equals(beforeHeader.Extension, afterHeader.Extension)) return true;
            // コピー句ＩＤ
            if (!string.Equals(beforeHeader.CopyId, afterHeader.CopyId)) return true;
            // ファイルグループ
            if (!string.Equals(beforeHeader.FileGroup, afterHeader.FileGroup)) return true;
            // 構成タイプ
            if (!string.Equals(beforeHeader.StructType, afterHeader.StructType)) return true;
            // ローダ時のソート
            if (!string.Equals(beforeHeader.Sort, afterHeader.Sort)) return true;
            // キー相対位置
            if (!string.Equals(beforeHeader.KeyLoc, afterHeader.KeyLoc)) return true;
            // キー長
            if (!string.Equals(beforeHeader.KeyLen, afterHeader.KeyLen)) return true;
            // キー
            if (!string.Equals(beforeHeader.Key, afterHeader.Key)) return true;

            return false;
        }

        /// <summary>
        /// 項目定義変更判定
        /// </summary>
        /// <param name="before"></param>
        /// <param name="after"></param>
        /// <returns></returns>
        private bool IsFieldDefChanged(Group before, Group after)
        {
            var count = before.FieldDefList.Count();
            if (count != after.FieldDefList.Count()) return true;

            for (var i = 0; i < count; i++)
            {
                var beforeDef = before.FieldDefList[i];
                var afterDef = after.FieldDefList[i];

                // 項目名
                if (!string.Equals(beforeDef.ItemName, afterDef.ItemName)) return true;
                // データ属性
                if (!string.Equals(beforeDef.DataAttr, afterDef.DataAttr)) return true;
                // サイズ
                if (!string.Equals(beforeDef.Size, afterDef.Size)) return true;
            }

            return false;
        }

        /// <summary>
        /// 情報部変更判定
        /// </summary>
        /// <param name="before"></param>
        /// <param name="after"></param>
        /// <returns></returns>
        private bool IsGroupChanged(Group before, Group after)
        {
            if (this.IsFieldDefChanged(before, after)) return true;

            var count = before.RecordList.Count();
            if (count != after.RecordList.Count()) return true;
            for (var i = 0; i < count; i++)
            {
                var beforeRec = before.RecordList[i];
                var afterRec = after.RecordList[i];

                // エントリ番号
                if (beforeRec.EntryNo != afterRec.EntryNo) return true;
                // エントリコメント
                if (!string.Equals(beforeRec.Comment, afterRec.Comment)) return true;
                // 削除コメント
                if (!string.Equals(beforeRec.DelComment, afterRec.DelComment)) return true;

                if (string.IsNullOrWhiteSpace(beforeRec.DelComment))
                {
                    if (this.IsRecordChanged(beforeRec, afterRec, before.FieldDefList)) return true;
                }
            }

            return false;
        }

        /// <summary>
        /// エントリ情報変更判定
        /// </summary>
        /// <param name="beforeRec"></param>
        /// <param name="afterRec"></param>
        /// <param name="fieldDefines"></param>
        /// <returns></returns>
        public bool IsRecordChanged(
            RecordInfo beforeRec,
            RecordInfo afterRec,
            List<FieldDefine> fieldDefines)
        {
            var count = beforeRec.EditCommentList.Count();
            if (count != afterRec.EditCommentList.Count()) return true;
            for (var i = 0; i < count; i++)
            {
                var beforeCom = beforeRec.EditCommentList[i];
                var afterCom = afterRec.EditCommentList[i];

                // 順序
                if (beforeCom.Order != afterCom.Order) return true;
                // コメント内容
                if (!string.Equals(beforeCom.Content, afterCom.Content)) return true;
                // コメントフラグ
                if (beforeCom.Flag != afterCom.Flag) return true;
            }

            foreach (var def in fieldDefines)
            {
                var beforeField = beforeRec[def.Key];
                var afterField = afterRec[def.Key];

                if (beforeField == null && afterField == null) continue;

                if (beforeField == null || afterField == null) return true;

                // データ内容
                if (!string.Equals(beforeField.Value, afterField.Value)) return true;
                // チェック種別
                if (!string.Equals(beforeField.CheckType, afterField.CheckType)) return true;
                // コメント
                if (!string.Equals(beforeField.Comment, afterField.Comment)) return true;
            }

            return false;
        }

        /// <summary>
        /// ＲＤＡＴＡ情報がＤＢに更新
        /// </summary>
        /// <param name="before"></param>
        /// <param name="after"></param>
        public void Update(RDataInfo before, RDataInfo after)
        {
            var rdata = before.HeaderInfo.T_RDATA;
            if (rdata == null)
            {
                throw new ExclusiveException();
            }

            // ＲＤＡＴＡ共通情報テーブル
            var rtn = this.Context.Database.ExecuteSqlCommand($"UPDATE T_RDATA " +
                $" SET RDATA_UPDTIME       = '{DateTime.Now.ToString()}'" +
                $" WHERE RDATA_SUBSYSID    = '{rdata.RDATA_SUBSYSID}'" +
                $"   AND RDATA_TABLEID     = '{rdata.RDATA_TABLEID}'" +
                $"   AND RDATA_UPDTIME     = '{rdata.RDATA_UPDTIME}'");
            this.Context.SaveChanges();
            if (rtn == 0)
            {
                throw new ExclusiveException();
            }

            using (var tran = this.Context.Database.BeginTransaction())
            {
                this.UpdateHeader(after.HeaderInfo);

                this.UpdateGroup(before, after);

                tran.Commit();
            }
        }

        /// <summary>
        /// ＲＤＡＴＡヘッダ部情報がＤＢに更新
        /// </summary>
        /// <param name="headerInfo"></param>
        private void UpdateHeader(HeaderInfo headerInfo)
        {
            // ＲＤＡＴＡ共通情報
            this.Context.Database.ExecuteSqlCommand($"UPDATE T_RDATA " +
                $" SET  RDATA_SYSNM       = '{headerInfo.SystemNm}'," +            // システム名称
                $"      RDATA_TABLENM     = '{headerInfo.TableNm}'," +             // テーブル名
                $"      RDATA_RDATAFNM    = '{headerInfo.Filename}'," +            // ＲＤＡＴＡファイル名
                $"      RDATA_RDATAFEXT   = '{headerInfo.ExtFlg}'," +              // ＲＤＡＴＡファイル名の拡張子
                $"      RDATA_FILEGRP     = '{headerInfo.FileGroup}'," +           // ファイルグループ
                $"      RDATA_BLKLEN      = '{headerInfo.BlockLen.ToString()}'," + // ブロック長
                $"      RDATA_STUTYPE     = '{headerInfo.StructType}'," +          // 構成タイプ
                $"      RDATA_SUBSYSNM    = '{headerInfo.SubSystemNm}'," +         // サブシステム名称
                $"      RDATA_COPYID      = '{headerInfo.CopyId}'," +              // コピー句ＩＤ
                $"      RDATA_SORT        = '{headerInfo.SortFlg}'," +             // ローダ時のソート
                $"      RDATA_KEYLOC      = '{headerInfo.KeyLoc}'," +              // キー相対位置
                $"      RDATA_KEYLEN      = '{headerInfo.KeyLen}'," +              // キー長
                $"      RDATA_KEY         = '{headerInfo.Key}'," +                 // キー
                $"      RDATA_EXPAND      = '{headerInfo.ExpandFlg}'," +           // 展開
                $"      RDATA_MAXENTRY    = '{headerInfo.MaxEntryCnt}'," +         // 最大エントリ数
                $"      RDATA_USERID      = '{this.Version.User.USERID}'," +       // 更新ユーザＩＤ
                $"      RDATA_UPDTIME     = '{DateTime.Now.ToString()}' " +        // 更新日時
                $" WHERE RDATA_SUBSYSID   = '{headerInfo.SubSystemId}'" +          // サブシステムＩＤ
                $"   AND RDATA_TABLEID    = '{headerInfo.TableId}'");              // テーブルＩＤ
        }

        /// <summary>
        /// ＲＤＡＴＡ各情報部がＤＢに更新
        /// </summary>
        /// <param name="before"></param>
        /// <param name="after"></param>
        private void UpdateGroup(RDataInfo before, RDataInfo after)
        {
            // １：ローダインタフェース情報部
            if (this.IsGroupChanged(before.Interface, after.Interface))
            {
                this.UpdateGroupItem(after.Interface);
            }

            //２：制御情報部１
            if (this.IsGroupChanged(before.GroupCtrl1, after.GroupCtrl1))
            {
                this.UpdateGroupItem(after.GroupCtrl1);
            }

            //３：共通情報部
            if (this.IsGroupChanged(before.GroupCommon, after.GroupCommon))
            {
                this.UpdateGroupItem(after.GroupCommon);
            }

            //４：共通情報部・ユーザ任意情報
            if (this.IsGroupChanged(before.GroupUser, after.GroupUser))
            {
                this.UpdateGroupItem(after.GroupUser);
            }

            //５：エントリ部
            if (this.IsGroupChanged(before.GroupEntry, after.GroupEntry))
            {
                this.UpdateEntryGroupItem(after.GroupEntry);
            }

            //６：制御情報部２
            if (this.IsGroupChanged(before.GroupCtrl2, after.GroupCtrl2))
            {
                this.UpdateGroupItem(after.GroupCtrl2);
            }
        }

        /// <summary>
        /// ＲＤＡＴＡ情報部（エントリ部以外）の項目がＤＢに更新
        /// </summary>
        /// <param name="group"></param>
        private void UpdateGroupItem(Group group)
        {
            // サブシステムＩＤ
            var subSysId = group.HeaderInfo.SubSystemId;
            // テーブルＩＤ
            var tableId = group.HeaderInfo.TableId;
            // 情報部種別
            var infType = (int)group.Type;

            // ＲＤＡＴＡ項目情報
            this.Context.Database.ExecuteSqlCommand(
                "DELETE FROM T_RDTITEM " +
                $" WHERE RDTITM_SUBSYSID  = '{subSysId}'" +
                $"   AND RDTITM_TABLEID   = '{tableId}'" +
                $"   AND RDTITM_INFTYPE   = '{infType}'");

            if (group.RecordList.Count() > 0)
            {
                this.InsertRecord(group, group.RecordList.First());
            }
        }

        /// <summary>
        /// ＲＤＡＴＡのエントリの項目がＤＢに更新
        /// </summary>
        /// <param name="after"></param>
        private void UpdateEntryGroupItem(Group after)
        {
            // サブシステムＩＤ
            var subSysId = after.HeaderInfo.SubSystemId;
            // テーブルＩＤ
            var tableId = after.HeaderInfo.TableId;
            // 情報部種別
            var infType = (int)after.Type;

            //  ＲＤＡＴＡ情報部
            this.Context.Database.ExecuteSqlCommand(
                "DELETE FROM T_RDTINF " +
                $" WHERE RDTINF_SUBSYSID  = '{subSysId}'" +
                $"   AND RDTINF_TABLEID   = '{tableId}'" +
                $"   AND RDTINF_INFTYPE   = '{infType}'");

            // ＲＤＡＴＡ改修コメント
            this.Context.Database.ExecuteSqlCommand(
                "DELETE FROM T_RDTCOMT " +
                $" WHERE RDTCOMT_SUBSYSID  = '{subSysId}'" +
                $"   AND RDTCOMT_TABLEID   = '{tableId}'");

            // ＲＤＡＴＡ項目情報
            this.Context.Database.ExecuteSqlCommand(
                "DELETE FROM T_RDTITEM " +
                $" WHERE RDTITM_SUBSYSID  = '{subSysId}'" +
                $"   AND RDTITM_TABLEID   = '{tableId}'" +
                $"   AND RDTITM_INFTYPE   = '{infType}'");

            this.InsertEntryGroup(after);
        }

        /// <summary>
        /// キーによって、ＲＤＡＴＡ情報を削除
        /// </summary>
        /// <param name="subSysId"></param>
        /// <param name="tableId"></param>
        public void Delete(string subSysId, string tableId)
        {
            // ＲＤＡＴＡ共通情報
            this.Context.Database.ExecuteSqlCommand(
                "DELETE FROM T_RDATA " +
                $" WHERE RDATA_SUBSYSID  = '{subSysId}'" +
                $"   AND RDATA_TABLEID   = '{tableId}'");

            //  ＲＤＡＴＡ情報部
            this.Context.Database.ExecuteSqlCommand(
                "DELETE FROM T_RDTINF " +
                $" WHERE RDTINF_SUBSYSID  = '{subSysId}'" +
                $"   AND RDTINF_TABLEID   = '{tableId}'");

            // ＲＤＡＴＡ改修コメント
            this.Context.Database.ExecuteSqlCommand(
                "DELETE FROM T_RDTCOMT " +
                $" WHERE RDTCOMT_SUBSYSID  = '{subSysId}'" +
                $"   AND RDTCOMT_TABLEID   = '{tableId}'");

            // ＲＤＡＴＡ項目情報
            this.Context.Database.ExecuteSqlCommand(
                "DELETE FROM T_RDTITEM " +
                $" WHERE RDTITM_SUBSYSID  = '{subSysId}'" +
                $"   AND RDTITM_TABLEID   = '{tableId}'");
        }

        /// <summary>
        /// ＲＤＡＴＡ情報がＤＢに登録
        /// </summary>
        /// <param name="rdataInfo"></param>
        public void Insert(RDataInfo rdataInfo)
        {
            using (var tran = this.Context.Database.BeginTransaction())
            {
                // 最大エントリ数
                var entryCnt = rdataInfo.GroupEntry.RecordList.Count;
                if (rdataInfo.HeaderInfo.MaxEntryCnt < entryCnt)
                {
                    rdataInfo.HeaderInfo.MaxEntryCnt = entryCnt;
                }

                // ＲＤＡＴＡ共通情報
                this.InsertHeaderInfo(rdataInfo.HeaderInfo);

                //  ＲＤＡＴＡ情報部
                this.InsertGroup(rdataInfo);

                tran.Commit();
            }
        }

        /// <summary>
        /// ＲＤＡＴＡヘッダ部情報がＤＢに登録
        /// </summary>
        /// <param name="headerInfo"></param>
        private void InsertHeaderInfo(HeaderInfo headerInfo)
        {
            this.Context.Database.ExecuteSqlCommand(
                        "INSERT INTO T_RDATA " +
                        "           (RDATA_SUBSYSID," +  // サブシステムＩＤ
                        "            RDATA_TABLEID," +   // テーブルＩＤ
                        "            RDATA_SYSNM," +     // システム名称
                        "            RDATA_TABLENM," +   // テーブル名
                        "            RDATA_RDATAFNM," +  // ＲＤＡＴＡファイル名
                        "            RDATA_RDATAFEXT," + // ＲＤＡＴＡファイル名の拡張子
                        "            RDATA_FILEGRP," +   // ファイルグループ
                        "            RDATA_BLKLEN," +    // ブロック長
                        "            RDATA_STUTYPE," +   // 構成タイプ
                        "            RDATA_SUBSYSNM," +  // サブシステム名称
                        "            RDATA_COPYID," +    // コピー句ＩＤ
                        "            RDATA_SORT," +      // ローダ時のソート
                        "            RDATA_KEYLOC," +    // キー相対位置
                        "            RDATA_KEYLEN," +    // キー長
                        "            RDATA_KEY," +       // キー
                        "            RDATA_EXPAND," +    // 展開
                        "            RDATA_MAXENTRY," +  // 最大エントリ数
                        "            RDATA_USERID," +    // 更新ユーザＩＤ
                        "            RDATA_UPDTIME)" +   // 更新日時
                        "     VALUES(" +
                        $"           '{headerInfo.SubSystemId}'," +
                        $"           '{headerInfo.TableId}'," +
                        $"           '{headerInfo.SystemNm}'," +
                        $"           '{headerInfo.TableNm}'," +
                        $"           '{headerInfo.Filename}'," +
                        $"           '{headerInfo.ExtFlg}'," +
                        $"           '{headerInfo.FileGroup}'," +
                        $"           '{headerInfo.BlockLen}'," +
                        $"           '{headerInfo.StructType}'," +
                        $"           '{headerInfo.SubSystemNm}'," +
                        $"           '{headerInfo.CopyId}'," +
                        $"           '{headerInfo.SortFlg}'," +
                        $"           '{headerInfo.KeyLoc}'," +
                        $"           '{headerInfo.KeyLen}'," +
                        $"           '{headerInfo.Key}'," +
                        $"           '{headerInfo.ExpandFlg}'," +
                        $"           '{headerInfo.MaxEntryCnt}'," +
                        $"           '{this.Version.User.USERID}'," +
                        $"           '{DateTime.Now.ToString()}'" +
                        "           )");
        }

        /// <summary>
        /// ＲＤＡＴＡ情報部がＤＢに登録
        /// </summary>
        /// <param name="group"></param>
        private void InsertGroup(Group group)
        {
            if (group.RecordList.Count <= 0) return;

            this.Context.Database.ExecuteSqlCommand(
                    "INSERT INTO T_RDTINF " +
                    "           (RDTINF_SUBSYSID," +  // サブシステムＩＤ
                    "            RDTINF_TABLEID," +   // テーブルＩＤ
                    "            RDTINF_INFTYPE," +   // 情報部種別
                    "            RDTINF_ENTNO)" +     // エントリ番号
                    "     VALUES(" +
                    $"           '{group.HeaderInfo.SubSystemId}'," +
                    $"           '{group.HeaderInfo.TableId}'," +
                    $"           '{(int)group.Type}'," +
                    "            '1')");

            this.InsertRecord(group, group.RecordList[0]);
        }

        /// <summary>
        /// ＲＤＡＴＡのエントリ情報がＤＢに登録
        /// </summary>
        /// <param name="group"></param>
        private void InsertEntryGroup(Group group)
        {
            var count = group.RecordList.Count;
            if (count <= 0) return;

            this.ReportProgress(0);

            var progress = 0;
            for (var i = 0; i < count; i++ )
            {
                var record = group.RecordList[i];
                if (progress < ((i * 100) / count))
                {
                    progress = (i * 100) / count;
                    this.ReportProgress(progress);
                }

                this.Context.Database.ExecuteSqlCommand(
                        "INSERT INTO T_RDTINF " +
                        "           (RDTINF_SUBSYSID," +  // サブシステムＩＤ
                        "            RDTINF_TABLEID," +   // テーブルＩＤ
                        "            RDTINF_INFTYPE," +   // 情報部種別
                        "            RDTINF_ENTNO," +     // エントリ番号
                        "            RDTINF_ENTCOMT," +   // エントリコメント
                        "            RDTINF_DELCOMT)" +   // 削除コメント
                        "     VALUES(" +
                        $"           '{group.HeaderInfo.SubSystemId}'," +
                        $"           '{group.HeaderInfo.TableId}'," +
                        $"           '{(int)group.Type}'," +
                        $"           '{record.EntryNo}'," +
                        $"           '{record.Comment}'," +
                        $"           '{record.DelComment}')");

                this.InsertEditComment(group, record);

                // 削除されたレコードが対象外
                if (string.IsNullOrWhiteSpace(record.DelComment))
                {
                    this.InsertRecord(group, record);
                }
            }

            this.ReportProgress(100);
        }

        /// <summary>
        /// 進行状況設定
        /// </summary>
        /// <param name="progress"></param>
        private void ReportProgress(int progress)
        {
            if (this.Worker != null)
            {
                this.Worker.ReportProgress(progress);
            }
        }

        /// <summary>
        /// ＲＤＡＴＡの改修コメントがＤＢに登録
        /// </summary>
        /// <param name="group"></param>
        /// <param name="record"></param>
        private void InsertEditComment(Group group, RecordInfo record)
        {
            foreach (var comment in record.EditCommentList)
            {
                this.Context.Database.ExecuteSqlCommand(
                    "INSERT INTO T_RDTCOMT " +
                    "           (RDTCOMT_SUBSYSID," +  // サブシステムＩＤ
                    "            RDTCOMT_TABLEID," +   // テーブルＩＤ
                    "            RDTCOMT_ENTNO," +     // エントリ番号
                    "            RDTCOMT_COMT," +      // コメント内容
                    "            RDTCOMT_ORDER," +     // 順序
                    "            RDTCOMT_COMTFLG)" +   // コメントフラグ
                    "     VALUES(" +
                    $"           '{group.HeaderInfo.SubSystemId}'," +
                    $"           '{group.HeaderInfo.TableId}'," +
                    $"           '{record.EntryNo}'," +
                    $"           '{comment.Content}'," +
                    $"           '{comment.Order}'," +
                    $"           '{(int)comment.Flag}')");
            }
        }

        /// <summary>
        /// ＲＤＡＴＡの情報部の項目がＤＢに登録
        /// </summary>
        /// <param name="group"></param>
        /// <param name="record"></param>
        private void InsertRecord(Group group, RecordInfo record)
        {
            var no = 1;
            var count = group.FieldDefList.Count;
            for (var i = 0; i < count; i++)
            {
                var fieldDef = group.FieldDefList[i];

                // データ内容
                var value = string.Empty;
                // チェック種別
                var chkType = string.Empty;
                // コメント
                var comment = string.Empty;

                var fieldInfo = record[fieldDef.Key];
                if (fieldInfo != null)
                {
                    value = fieldInfo.Value;
                    chkType = fieldInfo.CheckType;
                    comment = fieldInfo.Comment;
                }

                this.Context.Database.ExecuteSqlCommand(
                    "INSERT INTO T_RDTITEM " +
                    "           (RDTITM_SUBSYSID," +  // サブシステムＩＤ
                    "            RDTITM_TABLEID," +   // テーブルＩＤ
                    "            RDTITM_INFTYPE," +   // 情報部種別
                    "            RDTITM_ENTNO," +     // エントリ番号
                    "            RDTITM_ITEMNO," +    // 項番
                    "            RDTITM_ITEMNM," +    // 項目名
                    "            RDTITM_DATATYPE," +  // データ型
                    "            RDTITM_SIZE," +      // サイズ
                    "            RDTITM_DATA," +      // データ内容
                    "            RDTITM_CHKTYPE," +   // チェック種別
                    "            RDTITM_COMMENT)" +   // コメント
                    "     VALUES(" +
                    $"           '{group.HeaderInfo.SubSystemId}'," +
                    $"           '{group.HeaderInfo.TableId}'," +
                    $"           '{(int)group.Type}'," +
                    $"           '{record.EntryNo}'," +
                    $"           '{no++}'," +
                    $"           '{fieldDef.ItemName}'," +
                    $"           '{fieldDef.DataAttr}'," +
                    $"           '{fieldDef.Size}'," +
                    $"           '{value}'," +
                    $"           '{chkType}'," +
                    $"           '{comment}')");
            }
        }

        /// <summary>
        /// ＲＤＡＴＡ各情報部内容がＤＢに登録
        /// </summary>
        /// <param name="rdataInfo"></param>
        private void InsertGroup(RDataInfo rdataInfo)
        {
            // １：ローダインタフェース情報部
            this.InsertGroup(rdataInfo.Interface);

            //２：制御情報部１
            this.InsertGroup(rdataInfo.GroupCtrl1);

            //３：共通情報部
            this.InsertGroup(rdataInfo.GroupCommon);

            //４：共通情報部・ユーザ任意情報
            this.InsertGroup(rdataInfo.GroupUser);

            //５：エントリ部
            this.InsertEntryGroup(rdataInfo.GroupEntry);

            //６：制御情報部２
            this.InsertGroup(rdataInfo.GroupCtrl2);
        }
    }
}
