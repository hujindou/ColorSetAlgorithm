﻿using System;

namespace MarsTool.RData.IO.Excel
{
    /// <summary>
    /// シート情報ベースクラス
    /// </summary>
    public abstract class SheetInfo
    {
        /// <summary>
        /// シート名前
        /// </summary>
        private string _name = string.Empty;
        /// <summary>
        /// WorkBookオブジェクト
        /// </summary>
        private WorkBook _wb = null;
        /// <summary>
        /// Worksheetオブジェクト
        /// </summary>
        private WorkSheet _ws = null;
        /// <summary>
        /// 開始カラムオフセット
        /// </summary>
        private int _startColOffset = 0;
        /// <summary>
        /// カレント行
        /// </summary>
        private int _curRow = 7;
        /// <summary>
        /// 警告メッセージ
        /// </summary>
        private string _warnMsg = string.Empty;

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public SheetInfo(string name)
        {
            this._name = name;
        }

        /// <summary>
        /// シート名前を取得
        /// </summary>
        public string Name
        {
            get
            {
                return this._name;
            }
        }
        /// <summary>
        /// WorkBookオブジェクトを取得
        /// </summary>
        public WorkBook WorkBook
        {
            get
            {
                return this._wb;
            }
        }
        /// <summary>
        /// Worksheetオブジェクトを取得
        /// </summary>
        public WorkSheet WorkSheet
        {
            get
            {
                return this._ws;
            }
        }
        /// <summary>
        /// 警告メッセージ
        /// </summary>
        public string WarnMsg
        {
            protected set
            {
                this._warnMsg = value;
            }
            get
            {
                return this._warnMsg;
            }
        }
        /// <summary>
        /// 開始カラムオフセット
        /// </summary>
        protected int StartColOffset
        {
            set
            {
                this._startColOffset = value;
            }
        }
        /// <summary>
        /// カレント行を設定
        /// </summary>
        protected int CurRow
        {
            set
            {                
                this._curRow = value;
            }
        }

        /// <summary>
        /// データロード
        /// </summary>
        public void Load(MarsTool.RData.IO.Excel.WorkBook wb)
        {
            if (wb == null) return;

            this._wb = wb;
            if ((this._ws = wb[this.Name]) == null)
            {
                throw new Exception(string.Format("「{0}」シートが存在しない。", this.Name));
            }

            // データ情報ロード
            this.LoadInfo();
        }

        /// <summary>
        /// 次行情報を取得
        /// </summary>
        protected string[] NextRow()
        {
            if (this.WorkSheet == null) return null;

            return this.WorkSheet.GetRow(this._curRow++, this._startColOffset);
        }

        /// <summary>
        /// データ情報ロード
        /// </summary>
        public abstract void LoadInfo();
    }
}
