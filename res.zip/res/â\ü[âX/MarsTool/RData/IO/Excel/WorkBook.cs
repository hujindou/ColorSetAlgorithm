﻿using System.Collections.Generic;
using ComExcel = Microsoft.Office.Interop.Excel;

namespace MarsTool.RData.IO.Excel
{
    /// <summary>
    /// WorkBookクラス
    /// </summary>
    public class WorkBook
    {
        /// <summary>
        /// ファイル名前
        /// </summary>
        private string _filename;
        /// <summary>
        /// COM WorkBookオブジェクト
        /// </summary>
        private ComExcel.Workbook _wb;
        /// <summary>
        /// WorkSheetオブジェクトリスト
        /// </summary>
        private List<MarsTool.RData.IO.Excel.WorkSheet> _wsList
            = new List<MarsTool.RData.IO.Excel.WorkSheet>();

        /// <summary>
        /// コンストラクタ
        /// </summary>
        internal WorkBook(ComExcel.Workbook wb, string filename)
        {
            this._wb = wb;
            this._filename = filename;

            foreach (ComExcel.Worksheet sheet in _wb.Sheets)
            {
                this._wsList.Add(new MarsTool.RData.IO.Excel.WorkSheet(sheet));
            }
        }

        /// <summary>
        /// ファイル名前
        /// </summary>
        public string Filename
        {
            get
            {
                return this._filename;
            }
        }

        /// <summary>
        /// WorkSheetオブジェクト配列を取得
        /// </summary>
        public MarsTool.RData.IO.Excel.WorkSheet[] Sheets
        {
            get
            {
                return this._wsList.ToArray();
            }
        }

        /// <summary>
        /// 名前によって、WorkSheetオブジェクトを取得
        /// </summary>
        public MarsTool.RData.IO.Excel.WorkSheet this[string sheetName]
        {
            get
            {
                return this._wsList.Find(sheet => sheetName.Equals(sheet.Name));
            }
        }

        /// <summary>
        /// WorkSheet名前配列を取得
        /// </summary>
        public string[] SheetNames
        {
            get
            {
                if (this._wb == null) return null;

                var sheetNames = new List<string>();
                foreach (var sheet in this._wsList)
                {
                    sheetNames.Add(sheet.Name);
                }

                return sheetNames.ToArray();
            }
        }

        /// <summary>
        /// Excelファイルを閉じる
        /// </summary>
        public void Close()
        {
            this.Close(false);
        }
        public void Close(bool save)
        {
            this._wb.Close(save);
            foreach (var ws in this._wsList)
            {
                ws.Release();
            }
            ExcelWrapper.ReleaseObj(this._wb);
        }
    }
}
