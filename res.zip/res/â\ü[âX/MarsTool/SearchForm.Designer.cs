﻿namespace MarsTool
{
    partial class SearchForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.txtInitKey = new System.Windows.Forms.TextBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.delRDataProgressBar = new System.Windows.Forms.ToolStripProgressBar();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dgvInit = new System.Windows.Forms.DataGridView();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.txtInitInfoId = new System.Windows.Forms.TextBox();
            this.rdoInitInfoId = new System.Windows.Forms.RadioButton();
            this.rdoInitKey = new System.Windows.Forms.RadioButton();
            this.label12 = new System.Windows.Forms.Label();
            this.combInitSubSysID = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.btnInitSearch = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rtxtItemInfo = new System.Windows.Forms.RichTextBox();
            this.tabCtlSearch = new System.Windows.Forms.TabControl();
            this.tabInit = new System.Windows.Forms.TabPage();
            this.tabTel = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.dgvTel = new System.Windows.Forms.DataGridView();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtTelSubSysId = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.combTelSubSysID = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnTelSearch = new System.Windows.Forms.Button();
            this.rdoTelEde = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.rdoTelBoth = new System.Windows.Forms.RadioButton();
            this.txtTelPatternNo = new System.Windows.Forms.TextBox();
            this.rdoTelEdr = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.tabRData = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.chkRDataAll = new System.Windows.Forms.CheckBox();
            this.dgvRData = new System.Windows.Forms.DataGridView();
            this.Column21 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Privilege = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnRDataDel = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.rdoRDataTbNm = new System.Windows.Forms.RadioButton();
            this.rdoRDataTbId = new System.Windows.Forms.RadioButton();
            this.txtRDataTbId = new System.Windows.Forms.TextBox();
            this.txtRDataTbNm = new System.Windows.Forms.TextBox();
            this.combRDataSubSysID = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btnRDataSearch = new System.Windows.Forms.Button();
            this.tabJNL = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.jnlchkall = new System.Windows.Forms.CheckBox();
            this.jndatagridview = new System.Windows.Forms.DataGridView();
            this.Column23 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.segname = new System.Windows.Forms.TextBox();
            this.chksegname = new System.Windows.Forms.RadioButton();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.chksegid = new System.Windows.Forms.RadioButton();
            this.segid = new System.Windows.Forms.TextBox();
            this.tktype = new System.Windows.Forms.TextBox();
            this.cupid = new System.Windows.Forms.TextBox();
            this.ptno = new System.Windows.Forms.TextBox();
            this.button7 = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.jnldel = new System.Windows.Forms.Button();
            this.statusStrip1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInit)).BeginInit();
            this.groupBox8.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabCtlSearch.SuspendLayout();
            this.tabInit.SuspendLayout();
            this.tabTel.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTel)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.tabRData.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRData)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.tabJNL.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.jndatagridview)).BeginInit();
            this.groupBox9.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtInitKey
            // 
            this.txtInitKey.Enabled = false;
            this.txtInitKey.Location = new System.Drawing.Point(102, 63);
            this.txtInitKey.Name = "txtInitKey";
            this.txtInitKey.Size = new System.Drawing.Size(518, 19);
            this.txtInitKey.TabIndex = 5;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.delRDataProgressBar});
            this.statusStrip1.Location = new System.Drawing.Point(0, 579);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(722, 22);
            this.statusStrip1.TabIndex = 16;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // delRDataProgressBar
            // 
            this.delRDataProgressBar.Name = "delRDataProgressBar";
            this.delRDataProgressBar.Size = new System.Drawing.Size(200, 16);
            this.delRDataProgressBar.Visible = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dgvInit);
            this.groupBox2.Location = new System.Drawing.Point(5, 113);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(705, 309);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "項目パス一覧";
            // 
            // dgvInit
            // 
            this.dgvInit.AllowUserToAddRows = false;
            this.dgvInit.AllowUserToResizeRows = false;
            this.dgvInit.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInit.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column11,
            this.Column14,
            this.Column2,
            this.Column1});
            this.dgvInit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvInit.Location = new System.Drawing.Point(3, 15);
            this.dgvInit.MultiSelect = false;
            this.dgvInit.Name = "dgvInit";
            this.dgvInit.ReadOnly = true;
            this.dgvInit.RowHeadersVisible = false;
            this.dgvInit.RowTemplate.Height = 21;
            this.dgvInit.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvInit.Size = new System.Drawing.Size(699, 291);
            this.dgvInit.TabIndex = 7;
            // 
            // Column11
            // 
            this.Column11.HeaderText = "サブシステムＩＤ";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            // 
            // Column14
            // 
            this.Column14.HeaderText = "情報部ＩＤ";
            this.Column14.Name = "Column14";
            this.Column14.ReadOnly = true;
            this.Column14.Width = 80;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "項目名";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "項目パス";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 300;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.txtInitInfoId);
            this.groupBox8.Controls.Add(this.rdoInitInfoId);
            this.groupBox8.Controls.Add(this.rdoInitKey);
            this.groupBox8.Controls.Add(this.label12);
            this.groupBox8.Controls.Add(this.combInitSubSysID);
            this.groupBox8.Controls.Add(this.label14);
            this.groupBox8.Controls.Add(this.btnInitSearch);
            this.groupBox8.Controls.Add(this.txtInitKey);
            this.groupBox8.Location = new System.Drawing.Point(5, 2);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(705, 106);
            this.groupBox8.TabIndex = 11;
            this.groupBox8.TabStop = false;
            // 
            // txtInitInfoId
            // 
            this.txtInitInfoId.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtInitInfoId.Location = new System.Drawing.Point(102, 38);
            this.txtInitInfoId.Name = "txtInitInfoId";
            this.txtInitInfoId.Size = new System.Drawing.Size(65, 19);
            this.txtInitInfoId.TabIndex = 3;
            // 
            // rdoInitInfoId
            // 
            this.rdoInitInfoId.AutoSize = true;
            this.rdoInitInfoId.Checked = true;
            this.rdoInitInfoId.Location = new System.Drawing.Point(20, 39);
            this.rdoInitInfoId.Name = "rdoInitInfoId";
            this.rdoInitInfoId.Size = new System.Drawing.Size(77, 16);
            this.rdoInitInfoId.TabIndex = 2;
            this.rdoInitInfoId.TabStop = true;
            this.rdoInitInfoId.Text = "情報部ＩＤ：";
            this.rdoInitInfoId.UseVisualStyleBackColor = true;
            this.rdoInitInfoId.CheckedChanged += new System.EventHandler(this.rdoInit_CheckedChanged);
            // 
            // rdoInitKey
            // 
            this.rdoInitKey.AutoSize = true;
            this.rdoInitKey.Location = new System.Drawing.Point(20, 64);
            this.rdoInitKey.Name = "rdoInitKey";
            this.rdoInitKey.Size = new System.Drawing.Size(77, 16);
            this.rdoInitKey.TabIndex = 4;
            this.rdoInitKey.TabStop = true;
            this.rdoInitKey.Text = "キーワード：";
            this.rdoInitKey.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(100, 85);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(431, 12);
            this.label12.TabIndex = 19;
            this.label12.Text = "※１．スペース区切りで複数キーワードが検索可能　２．キーワードは部分一致で検索可能";
            // 
            // combInitSubSysID
            // 
            this.combInitSubSysID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combInitSubSysID.FormattingEnabled = true;
            this.combInitSubSysID.Location = new System.Drawing.Point(102, 12);
            this.combInitSubSysID.Name = "combInitSubSysID";
            this.combInitSubSysID.Size = new System.Drawing.Size(65, 20);
            this.combInitSubSysID.TabIndex = 1;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(20, 15);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(80, 12);
            this.label14.TabIndex = 17;
            this.label14.Text = "サブシステムＩＤ：";
            // 
            // btnInitSearch
            // 
            this.btnInitSearch.Location = new System.Drawing.Point(632, 61);
            this.btnInitSearch.Name = "btnInitSearch";
            this.btnInitSearch.Size = new System.Drawing.Size(54, 23);
            this.btnInitSearch.TabIndex = 6;
            this.btnInitSearch.Text = "検索";
            this.btnInitSearch.UseVisualStyleBackColor = true;
            this.btnInitSearch.Click += new System.EventHandler(this.btnInitSearch_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rtxtItemInfo);
            this.groupBox1.Location = new System.Drawing.Point(5, 428);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(705, 121);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "項目情報";
            // 
            // rtxtItemInfo
            // 
            this.rtxtItemInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.rtxtItemInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtxtItemInfo.Location = new System.Drawing.Point(3, 15);
            this.rtxtItemInfo.Name = "rtxtItemInfo";
            this.rtxtItemInfo.ReadOnly = true;
            this.rtxtItemInfo.Size = new System.Drawing.Size(699, 103);
            this.rtxtItemInfo.TabIndex = 0;
            this.rtxtItemInfo.Text = "";
            // 
            // tabCtlSearch
            // 
            this.tabCtlSearch.Controls.Add(this.tabInit);
            this.tabCtlSearch.Controls.Add(this.tabTel);
            this.tabCtlSearch.Controls.Add(this.tabRData);
            this.tabCtlSearch.Controls.Add(this.tabJNL);
            this.tabCtlSearch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabCtlSearch.Location = new System.Drawing.Point(0, 0);
            this.tabCtlSearch.Name = "tabCtlSearch";
            this.tabCtlSearch.SelectedIndex = 0;
            this.tabCtlSearch.Size = new System.Drawing.Size(722, 579);
            this.tabCtlSearch.TabIndex = 18;
            this.tabCtlSearch.SelectedIndexChanged += new System.EventHandler(this.tabCtlSearch_SelectedIndexChanged);
            // 
            // tabInit
            // 
            this.tabInit.BackColor = System.Drawing.SystemColors.Control;
            this.tabInit.Controls.Add(this.groupBox2);
            this.tabInit.Controls.Add(this.groupBox1);
            this.tabInit.Controls.Add(this.groupBox8);
            this.tabInit.Location = new System.Drawing.Point(4, 22);
            this.tabInit.Name = "tabInit";
            this.tabInit.Padding = new System.Windows.Forms.Padding(3);
            this.tabInit.Size = new System.Drawing.Size(714, 553);
            this.tabInit.TabIndex = 0;
            this.tabInit.Text = "インタフェース";
            // 
            // tabTel
            // 
            this.tabTel.BackColor = System.Drawing.SystemColors.Control;
            this.tabTel.Controls.Add(this.groupBox7);
            this.tabTel.Controls.Add(this.groupBox4);
            this.tabTel.Location = new System.Drawing.Point(4, 22);
            this.tabTel.Name = "tabTel";
            this.tabTel.Padding = new System.Windows.Forms.Padding(3);
            this.tabTel.Size = new System.Drawing.Size(714, 553);
            this.tabTel.TabIndex = 3;
            this.tabTel.Text = "電文構成";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.dgvTel);
            this.groupBox7.Location = new System.Drawing.Point(5, 71);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(705, 479);
            this.groupBox7.TabIndex = 18;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "電文構成パターン物理情報一覧";
            // 
            // dgvTel
            // 
            this.dgvTel.AllowUserToAddRows = false;
            this.dgvTel.AllowUserToResizeRows = false;
            this.dgvTel.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTel.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column9,
            this.Column13,
            this.Column12,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn9,
            this.Column17,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn1,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column15,
            this.Column16});
            this.dgvTel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTel.Location = new System.Drawing.Point(3, 15);
            this.dgvTel.MultiSelect = false;
            this.dgvTel.Name = "dgvTel";
            this.dgvTel.ReadOnly = true;
            this.dgvTel.RowHeadersVisible = false;
            this.dgvTel.RowTemplate.Height = 21;
            this.dgvTel.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTel.Size = new System.Drawing.Size(699, 461);
            this.dgvTel.TabIndex = 8;
            // 
            // Column9
            // 
            this.Column9.HeaderText = "コメント";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            this.Column9.Width = 150;
            // 
            // Column13
            // 
            this.Column13.HeaderText = "サブシステムID";
            this.Column13.Name = "Column13";
            this.Column13.ReadOnly = true;
            // 
            // Column12
            // 
            this.Column12.HeaderText = "相手サブシステムＩＤ";
            this.Column12.Name = "Column12";
            this.Column12.ReadOnly = true;
            this.Column12.Width = 125;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.HeaderText = "要求応答区分";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.HeaderText = "パターン番号";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Width = 90;
            // 
            // Column17
            // 
            this.Column17.HeaderText = "情報部グループＩＤ";
            this.Column17.Name = "Column17";
            this.Column17.ReadOnly = true;
            this.Column17.Width = 120;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.HeaderText = "物理ID1";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.Width = 80;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "物理ID2";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 80;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "物理ID3";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 80;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "物理ID4";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 80;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "物理ID5";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 80;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "物理ID6";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.Width = 80;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "物理ID7";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            this.Column7.Width = 80;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "物理ID8";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            this.Column8.Width = 80;
            // 
            // Column15
            // 
            this.Column15.HeaderText = "物理ID9";
            this.Column15.Name = "Column15";
            this.Column15.ReadOnly = true;
            this.Column15.Width = 80;
            // 
            // Column16
            // 
            this.Column16.HeaderText = "物理ID10";
            this.Column16.Name = "Column16";
            this.Column16.ReadOnly = true;
            this.Column16.Width = 80;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtTelSubSysId);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.combTelSubSysID);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.btnTelSearch);
            this.groupBox4.Controls.Add(this.rdoTelEde);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.rdoTelBoth);
            this.groupBox4.Controls.Add(this.txtTelPatternNo);
            this.groupBox4.Controls.Add(this.rdoTelEdr);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Location = new System.Drawing.Point(5, 2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(705, 65);
            this.groupBox4.TabIndex = 19;
            this.groupBox4.TabStop = false;
            // 
            // txtTelSubSysId
            // 
            this.txtTelSubSysId.Location = new System.Drawing.Point(120, 39);
            this.txtTelSubSysId.Name = "txtTelSubSysId";
            this.txtTelSubSysId.Size = new System.Drawing.Size(65, 19);
            this.txtTelSubSysId.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 12);
            this.label1.TabIndex = 22;
            this.label1.Text = "相手サブシステムＩＤ：";
            // 
            // combTelSubSysID
            // 
            this.combTelSubSysID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combTelSubSysID.FormattingEnabled = true;
            this.combTelSubSysID.Location = new System.Drawing.Point(120, 12);
            this.combTelSubSysID.Name = "combTelSubSysID";
            this.combTelSubSysID.Size = new System.Drawing.Size(65, 20);
            this.combTelSubSysID.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 12);
            this.label4.TabIndex = 20;
            this.label4.Text = "サブシステムＩＤ：";
            // 
            // btnTelSearch
            // 
            this.btnTelSearch.Location = new System.Drawing.Point(639, 35);
            this.btnTelSearch.Name = "btnTelSearch";
            this.btnTelSearch.Size = new System.Drawing.Size(54, 23);
            this.btnTelSearch.TabIndex = 7;
            this.btnTelSearch.Text = "検索";
            this.btnTelSearch.UseVisualStyleBackColor = true;
            this.btnTelSearch.Click += new System.EventHandler(this.btnTelSearch_Click);
            // 
            // rdoTelEde
            // 
            this.rdoTelEde.AutoSize = true;
            this.rdoTelEde.Location = new System.Drawing.Point(347, 14);
            this.rdoTelEde.Name = "rdoTelEde";
            this.rdoTelEde.Size = new System.Drawing.Size(30, 16);
            this.rdoTelEde.TabIndex = 2;
            this.rdoTelEde.Text = "E";
            this.rdoTelEde.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(261, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 12);
            this.label3.TabIndex = 18;
            this.label3.Text = "要求応答区分：";
            // 
            // rdoTelBoth
            // 
            this.rdoTelBoth.AutoSize = true;
            this.rdoTelBoth.Checked = true;
            this.rdoTelBoth.Location = new System.Drawing.Point(418, 14);
            this.rdoTelBoth.Name = "rdoTelBoth";
            this.rdoTelBoth.Size = new System.Drawing.Size(54, 16);
            this.rdoTelBoth.TabIndex = 4;
            this.rdoTelBoth.TabStop = true;
            this.rdoTelBoth.Text = "BOTH";
            this.rdoTelBoth.UseVisualStyleBackColor = true;
            // 
            // txtTelPatternNo
            // 
            this.txtTelPatternNo.Location = new System.Drawing.Point(347, 39);
            this.txtTelPatternNo.Name = "txtTelPatternNo";
            this.txtTelPatternNo.Size = new System.Drawing.Size(48, 19);
            this.txtTelPatternNo.TabIndex = 6;
            // 
            // rdoTelEdr
            // 
            this.rdoTelEdr.AutoSize = true;
            this.rdoTelEdr.Location = new System.Drawing.Point(382, 14);
            this.rdoTelEdr.Name = "rdoTelEdr";
            this.rdoTelEdr.Size = new System.Drawing.Size(31, 16);
            this.rdoTelEdr.TabIndex = 3;
            this.rdoTelEdr.Text = "R";
            this.rdoTelEdr.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(261, 42);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 12);
            this.label5.TabIndex = 15;
            this.label5.Text = "パターン番号：";
            // 
            // tabRData
            // 
            this.tabRData.BackColor = System.Drawing.SystemColors.Control;
            this.tabRData.Controls.Add(this.groupBox5);
            this.tabRData.Controls.Add(this.btnRDataDel);
            this.tabRData.Controls.Add(this.groupBox3);
            this.tabRData.Location = new System.Drawing.Point(4, 22);
            this.tabRData.Name = "tabRData";
            this.tabRData.Padding = new System.Windows.Forms.Padding(3);
            this.tabRData.Size = new System.Drawing.Size(714, 553);
            this.tabRData.TabIndex = 1;
            this.tabRData.Text = "ＲＤＡＴＡ";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.chkRDataAll);
            this.groupBox5.Controls.Add(this.dgvRData);
            this.groupBox5.Location = new System.Drawing.Point(5, 46);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(705, 475);
            this.groupBox5.TabIndex = 19;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "ＲＤＡＴＡ情報一覧";
            // 
            // chkRDataAll
            // 
            this.chkRDataAll.AutoSize = true;
            this.chkRDataAll.Enabled = false;
            this.chkRDataAll.Location = new System.Drawing.Point(8, 19);
            this.chkRDataAll.Name = "chkRDataAll";
            this.chkRDataAll.Size = new System.Drawing.Size(15, 14);
            this.chkRDataAll.TabIndex = 7;
            this.chkRDataAll.UseVisualStyleBackColor = true;
            // 
            // dgvRData
            // 
            this.dgvRData.AllowUserToAddRows = false;
            this.dgvRData.AllowUserToResizeRows = false;
            this.dgvRData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRData.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column21,
            this.Column10,
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewTextBoxColumn20,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn17,
            this.Privilege});
            this.dgvRData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvRData.Location = new System.Drawing.Point(3, 15);
            this.dgvRData.MultiSelect = false;
            this.dgvRData.Name = "dgvRData";
            this.dgvRData.ReadOnly = true;
            this.dgvRData.RowHeadersVisible = false;
            this.dgvRData.RowTemplate.Height = 21;
            this.dgvRData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvRData.Size = new System.Drawing.Size(699, 457);
            this.dgvRData.TabIndex = 8;
            // 
            // Column21
            // 
            this.Column21.FalseValue = "0";
            this.Column21.HeaderText = "";
            this.Column21.Name = "Column21";
            this.Column21.ReadOnly = true;
            this.Column21.TrueValue = "1";
            this.Column21.Width = 20;
            // 
            // Column10
            // 
            this.Column10.HeaderText = "サブシステムＩＤ";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.HeaderText = "テーブルＩＤ";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.HeaderText = "テーブル名";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.ReadOnly = true;
            this.dataGridViewTextBoxColumn20.Width = 200;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.HeaderText = "コピー句ＩＤ";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.HeaderText = "ＲＤＡＴＡファイル名";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.ReadOnly = true;
            this.dataGridViewTextBoxColumn17.Width = 140;
            // 
            // Privilege
            // 
            this.Privilege.HeaderText = "権限";
            this.Privilege.Name = "Privilege";
            this.Privilege.ReadOnly = true;
            this.Privilege.Visible = false;
            // 
            // btnRDataDel
            // 
            this.btnRDataDel.Enabled = false;
            this.btnRDataDel.Location = new System.Drawing.Point(652, 525);
            this.btnRDataDel.Name = "btnRDataDel";
            this.btnRDataDel.Size = new System.Drawing.Size(54, 23);
            this.btnRDataDel.TabIndex = 9;
            this.btnRDataDel.Text = "削除";
            this.btnRDataDel.UseVisualStyleBackColor = true;
            this.btnRDataDel.Click += new System.EventHandler(this.btnRDataDel_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.rdoRDataTbNm);
            this.groupBox3.Controls.Add(this.rdoRDataTbId);
            this.groupBox3.Controls.Add(this.txtRDataTbId);
            this.groupBox3.Controls.Add(this.txtRDataTbNm);
            this.groupBox3.Controls.Add(this.combRDataSubSysID);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.btnRDataSearch);
            this.groupBox3.Location = new System.Drawing.Point(5, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(705, 39);
            this.groupBox3.TabIndex = 8;
            this.groupBox3.TabStop = false;
            // 
            // rdoRDataTbNm
            // 
            this.rdoRDataTbNm.AutoSize = true;
            this.rdoRDataTbNm.Location = new System.Drawing.Point(355, 15);
            this.rdoRDataTbNm.Margin = new System.Windows.Forms.Padding(0);
            this.rdoRDataTbNm.Name = "rdoRDataTbNm";
            this.rdoRDataTbNm.Size = new System.Drawing.Size(79, 16);
            this.rdoRDataTbNm.TabIndex = 4;
            this.rdoRDataTbNm.Text = "テーブル名：";
            this.rdoRDataTbNm.UseVisualStyleBackColor = true;
            // 
            // rdoRDataTbId
            // 
            this.rdoRDataTbId.AutoSize = true;
            this.rdoRDataTbId.Checked = true;
            this.rdoRDataTbId.Location = new System.Drawing.Point(173, 15);
            this.rdoRDataTbId.Margin = new System.Windows.Forms.Padding(0);
            this.rdoRDataTbId.Name = "rdoRDataTbId";
            this.rdoRDataTbId.Size = new System.Drawing.Size(79, 16);
            this.rdoRDataTbId.TabIndex = 2;
            this.rdoRDataTbId.TabStop = true;
            this.rdoRDataTbId.Text = "テーブルＩＤ：";
            this.rdoRDataTbId.UseVisualStyleBackColor = true;
            this.rdoRDataTbId.CheckedChanged += new System.EventHandler(this.rdoRData_CheckedChanged);
            // 
            // txtRDataTbId
            // 
            this.txtRDataTbId.Location = new System.Drawing.Point(252, 14);
            this.txtRDataTbId.Name = "txtRDataTbId";
            this.txtRDataTbId.Size = new System.Drawing.Size(85, 19);
            this.txtRDataTbId.TabIndex = 3;
            // 
            // txtRDataTbNm
            // 
            this.txtRDataTbNm.Enabled = false;
            this.txtRDataTbNm.Location = new System.Drawing.Point(434, 14);
            this.txtRDataTbNm.Name = "txtRDataTbNm";
            this.txtRDataTbNm.Size = new System.Drawing.Size(120, 19);
            this.txtRDataTbNm.TabIndex = 5;
            // 
            // combRDataSubSysID
            // 
            this.combRDataSubSysID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combRDataSubSysID.FormattingEnabled = true;
            this.combRDataSubSysID.Location = new System.Drawing.Point(90, 13);
            this.combRDataSubSysID.Name = "combRDataSubSysID";
            this.combRDataSubSysID.Size = new System.Drawing.Size(65, 20);
            this.combRDataSubSysID.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 17);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 12);
            this.label9.TabIndex = 17;
            this.label9.Text = "サブシステムＩＤ：";
            // 
            // btnRDataSearch
            // 
            this.btnRDataSearch.Location = new System.Drawing.Point(639, 11);
            this.btnRDataSearch.Name = "btnRDataSearch";
            this.btnRDataSearch.Size = new System.Drawing.Size(54, 23);
            this.btnRDataSearch.TabIndex = 6;
            this.btnRDataSearch.Text = "検索";
            this.btnRDataSearch.UseVisualStyleBackColor = true;
            this.btnRDataSearch.Click += new System.EventHandler(this.btnRDataSearch_Click);
            // 
            // tabJNL
            // 
            this.tabJNL.BackColor = System.Drawing.SystemColors.Control;
            this.tabJNL.Controls.Add(this.groupBox6);
            this.tabJNL.Controls.Add(this.groupBox9);
            this.tabJNL.Controls.Add(this.jnldel);
            this.tabJNL.Location = new System.Drawing.Point(4, 22);
            this.tabJNL.Name = "tabJNL";
            this.tabJNL.Padding = new System.Windows.Forms.Padding(3);
            this.tabJNL.Size = new System.Drawing.Size(714, 553);
            this.tabJNL.TabIndex = 4;
            this.tabJNL.Text = "ジャーナル";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.jnlchkall);
            this.groupBox6.Controls.Add(this.jndatagridview);
            this.groupBox6.Location = new System.Drawing.Point(5, 84);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(705, 436);
            this.groupBox6.TabIndex = 28;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "ジャーナル情報一覧";
            // 
            // jnlchkall
            // 
            this.jnlchkall.Enabled = false;
            this.jnlchkall.Location = new System.Drawing.Point(10, 19);
            this.jnlchkall.Margin = new System.Windows.Forms.Padding(0);
            this.jnlchkall.Name = "jnlchkall";
            this.jnlchkall.Size = new System.Drawing.Size(15, 14);
            this.jnlchkall.TabIndex = 26;
            this.jnlchkall.UseVisualStyleBackColor = true;
            // 
            // jndatagridview
            // 
            this.jndatagridview.AllowUserToAddRows = false;
            this.jndatagridview.AllowUserToDeleteRows = false;
            this.jndatagridview.AllowUserToResizeRows = false;
            this.jndatagridview.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.jndatagridview.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.jndatagridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.jndatagridview.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column23,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn24,
            this.dataGridViewTextBoxColumn25,
            this.dataGridViewTextBoxColumn22,
            this.dataGridViewTextBoxColumn23,
            this.dataGridViewTextBoxColumn26,
            this.dataGridViewTextBoxColumn27,
            this.dataGridViewTextBoxColumn28,
            this.dataGridViewTextBoxColumn29,
            this.dataGridViewTextBoxColumn30,
            this.Column19,
            this.dataGridViewTextBoxColumn31,
            this.dataGridViewTextBoxColumn32,
            this.dataGridViewTextBoxColumn33});
            this.jndatagridview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jndatagridview.Location = new System.Drawing.Point(3, 15);
            this.jndatagridview.MultiSelect = false;
            this.jndatagridview.Name = "jndatagridview";
            this.jndatagridview.ReadOnly = true;
            this.jndatagridview.RowHeadersVisible = false;
            this.jndatagridview.RowTemplate.Height = 21;
            this.jndatagridview.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.jndatagridview.Size = new System.Drawing.Size(699, 418);
            this.jndatagridview.TabIndex = 24;
            // 
            // Column23
            // 
            this.Column23.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Column23.FalseValue = "0";
            this.Column23.Frozen = true;
            this.Column23.HeaderText = "";
            this.Column23.Name = "Column23";
            this.Column23.ReadOnly = true;
            this.Column23.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column23.TrueValue = "1";
            this.Column23.Width = 24;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn16.HeaderText = "JN_ID";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            this.dataGridViewTextBoxColumn16.Visible = false;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn19.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewTextBoxColumn19.FillWeight = 152.2843F;
            this.dataGridViewTextBoxColumn19.HeaderText = "パターン番号";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            this.dataGridViewTextBoxColumn19.Width = 91;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn24.FillWeight = 73.85786F;
            this.dataGridViewTextBoxColumn24.HeaderText = "ＣＵＰ－ＩＤ";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.ReadOnly = true;
            this.dataGridViewTextBoxColumn24.Width = 81;
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn25.FillWeight = 73.85786F;
            this.dataGridViewTextBoxColumn25.HeaderText = "券種別";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            this.dataGridViewTextBoxColumn25.ReadOnly = true;
            this.dataGridViewTextBoxColumn25.Width = 66;
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn22.HeaderText = "ANS";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.ReadOnly = true;
            this.dataGridViewTextBoxColumn22.Width = 53;
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn23.HeaderText = "情報部ID１";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.ReadOnly = true;
            this.dataGridViewTextBoxColumn23.Width = 85;
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn26.HeaderText = "情報部ID２";
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            this.dataGridViewTextBoxColumn26.ReadOnly = true;
            this.dataGridViewTextBoxColumn26.Width = 85;
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.HeaderText = "情報部ID３";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            this.dataGridViewTextBoxColumn27.ReadOnly = true;
            this.dataGridViewTextBoxColumn27.Width = 85;
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.HeaderText = "情報部ID４";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            this.dataGridViewTextBoxColumn28.ReadOnly = true;
            this.dataGridViewTextBoxColumn28.Width = 85;
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.HeaderText = "情報部ID５";
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            this.dataGridViewTextBoxColumn29.ReadOnly = true;
            this.dataGridViewTextBoxColumn29.Width = 85;
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.HeaderText = "情報部ID６";
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            this.dataGridViewTextBoxColumn30.ReadOnly = true;
            this.dataGridViewTextBoxColumn30.Width = 85;
            // 
            // Column19
            // 
            this.Column19.HeaderText = "情報部ID７";
            this.Column19.Name = "Column19";
            this.Column19.ReadOnly = true;
            this.Column19.Width = 85;
            // 
            // dataGridViewTextBoxColumn31
            // 
            this.dataGridViewTextBoxColumn31.HeaderText = "情報部ID８";
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            this.dataGridViewTextBoxColumn31.ReadOnly = true;
            this.dataGridViewTextBoxColumn31.Width = 85;
            // 
            // dataGridViewTextBoxColumn32
            // 
            this.dataGridViewTextBoxColumn32.HeaderText = "情報部ID９";
            this.dataGridViewTextBoxColumn32.Name = "dataGridViewTextBoxColumn32";
            this.dataGridViewTextBoxColumn32.ReadOnly = true;
            this.dataGridViewTextBoxColumn32.Width = 85;
            // 
            // dataGridViewTextBoxColumn33
            // 
            this.dataGridViewTextBoxColumn33.HeaderText = "情報部ID１０";
            this.dataGridViewTextBoxColumn33.Name = "dataGridViewTextBoxColumn33";
            this.dataGridViewTextBoxColumn33.ReadOnly = true;
            this.dataGridViewTextBoxColumn33.Width = 93;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.segname);
            this.groupBox9.Controls.Add(this.chksegname);
            this.groupBox9.Controls.Add(this.label16);
            this.groupBox9.Controls.Add(this.label15);
            this.groupBox9.Controls.Add(this.chksegid);
            this.groupBox9.Controls.Add(this.segid);
            this.groupBox9.Controls.Add(this.tktype);
            this.groupBox9.Controls.Add(this.cupid);
            this.groupBox9.Controls.Add(this.ptno);
            this.groupBox9.Controls.Add(this.button7);
            this.groupBox9.Controls.Add(this.label18);
            this.groupBox9.Location = new System.Drawing.Point(5, 2);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(705, 74);
            this.groupBox9.TabIndex = 27;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "パターン番号、CUP－ID、券種別、情報部ID、情報部名で検索";
            // 
            // segname
            // 
            this.segname.Enabled = false;
            this.segname.Location = new System.Drawing.Point(335, 43);
            this.segname.Name = "segname";
            this.segname.Size = new System.Drawing.Size(130, 19);
            this.segname.TabIndex = 32;
            // 
            // chksegname
            // 
            this.chksegname.AutoSize = true;
            this.chksegname.Location = new System.Drawing.Point(254, 44);
            this.chksegname.Margin = new System.Windows.Forms.Padding(0);
            this.chksegname.Name = "chksegname";
            this.chksegname.Size = new System.Drawing.Size(77, 16);
            this.chksegname.TabIndex = 29;
            this.chksegname.Text = "情報部名：";
            this.chksegname.UseVisualStyleBackColor = true;
            this.chksegname.CheckedChanged += new System.EventHandler(this.chksegname_CheckedChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(509, 21);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(47, 12);
            this.label16.TabIndex = 28;
            this.label16.Text = "券種別：";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(278, 21);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(51, 12);
            this.label15.TabIndex = 27;
            this.label15.Text = "CUP-ID：";
            // 
            // chksegid
            // 
            this.chksegid.AutoSize = true;
            this.chksegid.Checked = true;
            this.chksegid.Location = new System.Drawing.Point(8, 44);
            this.chksegid.Margin = new System.Windows.Forms.Padding(0);
            this.chksegid.Name = "chksegid";
            this.chksegid.Size = new System.Drawing.Size(76, 16);
            this.chksegid.TabIndex = 26;
            this.chksegid.TabStop = true;
            this.chksegid.Text = "情報部ID：";
            this.chksegid.UseVisualStyleBackColor = true;
            this.chksegid.CheckedChanged += new System.EventHandler(this.chksegid_CheckedChanged);
            // 
            // segid
            // 
            this.segid.Location = new System.Drawing.Point(84, 43);
            this.segid.Name = "segid";
            this.segid.Size = new System.Drawing.Size(130, 19);
            this.segid.TabIndex = 25;
            // 
            // tktype
            // 
            this.tktype.Location = new System.Drawing.Point(562, 18);
            this.tktype.Name = "tktype";
            this.tktype.Size = new System.Drawing.Size(130, 19);
            this.tktype.TabIndex = 23;
            // 
            // cupid
            // 
            this.cupid.Location = new System.Drawing.Point(335, 18);
            this.cupid.Name = "cupid";
            this.cupid.Size = new System.Drawing.Size(130, 19);
            this.cupid.TabIndex = 22;
            // 
            // ptno
            // 
            this.ptno.Location = new System.Drawing.Point(84, 18);
            this.ptno.Name = "ptno";
            this.ptno.Size = new System.Drawing.Size(130, 19);
            this.ptno.TabIndex = 21;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(638, 41);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(54, 23);
            this.button7.TabIndex = 19;
            this.button7.Text = "検索";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(10, 21);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(72, 12);
            this.label18.TabIndex = 20;
            this.label18.Text = "パターン番号：";
            // 
            // jnldel
            // 
            this.jnldel.Enabled = false;
            this.jnldel.Location = new System.Drawing.Point(652, 525);
            this.jnldel.Name = "jnldel";
            this.jnldel.Size = new System.Drawing.Size(54, 23);
            this.jnldel.TabIndex = 25;
            this.jnldel.Text = "削除";
            this.jnldel.UseVisualStyleBackColor = true;
            this.jnldel.Click += new System.EventHandler(this.button9_Click);
            // 
            // SearchForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(722, 601);
            this.Controls.Add(this.tabCtlSearch);
            this.Controls.Add(this.statusStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SearchForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "検索画面";
            this.Load += new System.EventHandler(this.SelectForm_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvInit)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.tabCtlSearch.ResumeLayout(false);
            this.tabInit.ResumeLayout(false);
            this.tabTel.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTel)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabRData.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRData)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabJNL.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.jndatagridview)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtInitKey;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RichTextBox rtxtItemInfo;
        private System.Windows.Forms.DataGridView dgvInit;
        private System.Windows.Forms.TabControl tabCtlSearch;
        private System.Windows.Forms.TabPage tabInit;
        private System.Windows.Forms.TabPage tabRData;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnRDataSearch;
        private System.Windows.Forms.DataGridView dgvRData;
        private System.Windows.Forms.TabPage tabTel;
        private System.Windows.Forms.TabPage tabJNL;
        private System.Windows.Forms.ComboBox combRDataSubSysID;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtRDataTbId;
        private System.Windows.Forms.TextBox txtRDataTbNm;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.ComboBox combInitSubSysID;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btnInitSearch;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtInitInfoId;
        private System.Windows.Forms.RadioButton rdoInitInfoId;
        private System.Windows.Forms.RadioButton rdoInitKey;
        private System.Windows.Forms.CheckBox chkRDataAll;
        private System.Windows.Forms.Button btnRDataDel;
        private System.Windows.Forms.Button jnldel;
        private System.Windows.Forms.CheckBox jnlchkall;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox segname;
        private System.Windows.Forms.RadioButton chksegname;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.RadioButton chksegid;
        private System.Windows.Forms.TextBox segid;
        private System.Windows.Forms.TextBox tktype;
        private System.Windows.Forms.TextBox cupid;
        private System.Windows.Forms.TextBox ptno;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.DataGridView dgvTel;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtTelSubSysId;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox combTelSubSysID;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnTelSearch;
        private System.Windows.Forms.RadioButton rdoTelEde;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton rdoTelBoth;
        private System.Windows.Forms.TextBox txtTelPatternNo;
        private System.Windows.Forms.RadioButton rdoTelEdr;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton rdoRDataTbNm;
        private System.Windows.Forms.RadioButton rdoRDataTbId;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column21;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Privilege;
        private System.Windows.Forms.DataGridView jndatagridview;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn32;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn33;
        private System.Windows.Forms.ToolStripProgressBar delRDataProgressBar;
    }
}