﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using MySql.Data.MySqlClient;
using MarsTool.Models;
using MarsTool.Common;
using MarsTool.Exceptions;
using MarsTool.Properties;

namespace MarsTool.Daos
{
    class SetConDBConnectivity
    {
        #region variable

        //Specify instance of DBConnectivity
        //DBConnectivityのインスタンスを指定
        private static SetConDBConnectivity instance;

        //To connect to database
        //データベースを接続
        private static MySqlConnection connection;

        private VersionModel version;

        #endregion

        #region private method

        /// <summary>
        /// データベース接続を取得<br/>
        /// Get Connection to database<br/>
        /// </summary>
        /// <remarks>
        /// 2018/03/07 新規作成<br/>
        /// </remarks>
        private SetConDBConnectivity(VersionModel v)
        {
            connection = new MySqlConnection(v.ConnectString);
            version = v;
        }

        #endregion

        #region public method

        /// <summary>
        /// Get Connection to database<br/>
        /// データベース接続を取得<br/>
        /// </summary>
        /// <returns>
        /// Return DBConnectivity instance.<br/>
        /// DBConnectivityインスタンスを返却<br/>
        /// </returns>
        /// <remarks>
        /// 2018/03/07 新規作成<br/>
        /// </remarks>
        public static SetConDBConnectivity getInstance(VersionModel v)
        {
            if (instance == null)
            {
                instance = new SetConDBConnectivity(v);
            }
            return instance;
        }

        /// <summary>
        /// To select mapping data from database table.<br/>
        /// データベーステーブルからマッピングデータを選択<br/>
        /// </summary>
        /// <param name="phyConModel">
        /// phyConModel is used to find Mapping Data.<br/>
        /// マッピングデータを検索するため、phyConModelを利用<br/>
        /// </param>
        /// <returns>
        /// Return setting condition data list according to input parameter key.<br/>
        /// 入力パラメータキーにより、設定条件データリストを返却<br/>
        /// </returns>
        /// <exception cref="SettingConditionException">
        /// Throw exception if exception occurs.<br/>
        /// 例外が発生する場合、例外をスロー<br/>
        /// </exception>
        /// <remarks>
        /// 2018/05/22 修正<br/>
        /// </remarks>
        public void SeletDataFromDb(PhySettingConMappingModel phyConModel)
        {
            try
            {
                string selectQuery = "SELECT cpy.CPYPHY_SUBSYSID,cpy.CPYPHY_BCPID,cpy.CPYPHY_BCPNM,phy.PHYITM_LEVEL,phy.PHYITM_ITEMNM,"
                                    + " phy.PHYITM_SEQ,con.COND_OUTPUTORDER,con.COND_OPNM,con.COND_SETCOND"
                                    + " FROM t_cpyphy cpy"
                                    + " LEFT JOIN t_phyitm phy ON ( cpy.CPYPHY_SUBSYSID = phy.PHYITM_SUBSYSID AND cpy.CPYPHY_INFOID = phy.PHYITM_INFOID)"
                                    + " LEFT JOIN t_condition con ON ( phy.PHYITM_SEQ = con.COND_SEQ)";

                connection.Open();

                MySqlCommand command = null;

                if (phyConModel.Cpyphy_bcpid.Equals(string.Empty))
                {
                    selectQuery += " WHERE cpy.CPYPHY_BCPNM = @Name ORDER BY phy.PHYITM_ITEMNO;";

                    command = new MySqlCommand(selectQuery, connection);
                    command.Parameters.Add(new MySqlParameter("@Name", phyConModel.Cpyphy_bcpnm));
                }
                else if (phyConModel.Cpyphy_bcpnm.Equals(string.Empty))
                {
                    selectQuery += " WHERE cpy.CPYPHY_BCPID = @id ORDER BY phy.PHYITM_ITEMNO;";

                    command = new MySqlCommand(selectQuery, connection);
                    command.Parameters.Add(new MySqlParameter("@id", phyConModel.Cpyphy_bcpid));
                }
                else
                {
                    selectQuery += " WHERE cpy.CPYPHY_BCPID = @id AND cpy.CPYPHY_BCPNM = @Name ORDER BY phy.PHYITM_ITEMNO;";

                    command = new MySqlCommand(selectQuery, connection);
                    command.Parameters.Add(new MySqlParameter("@id", phyConModel.Cpyphy_bcpid));
                    command.Parameters.Add(new MySqlParameter("@Name", phyConModel.Cpyphy_bcpnm));
                }
                command.CommandTimeout = 0;
                IDataReader reader = command.ExecuteReader();
                phyConModel.phyItmInfoList = new List<PhysicalItmInfoModel>();

                Int64 phyitm_seq = 0;
                int cond_outputorder = 0;
                while (reader.Read())
                {
                    if (string.IsNullOrEmpty(phyConModel.Cpyphy_subsysid))
                    {
                        phyConModel.Cpyphy_subsysid = reader["CPYPHY_SUBSYSID"].ToString();
                        phyConModel.Cpyphy_bcpid = reader["CPYPHY_BCPID"].ToString();
                        phyConModel.Cpyphy_bcpnm = reader["CPYPHY_BCPNM"].ToString();
                    }

                    if (!string.IsNullOrEmpty(reader["PHYITM_SEQ"].ToString()))
                    {
                        PhysicalItmInfoModel phyItmInfo = new PhysicalItmInfoModel();
                        Int64.TryParse(reader["PHYITM_SEQ"].ToString(), out phyitm_seq);
                        phyItmInfo.Phyitm_seq = phyitm_seq;
                        phyItmInfo.Phyitm_level = reader["PHYITM_LEVEL"].ToString();
                        if (reader["PHYITM_ITEMNM"].ToString().Equals(ConstantUtils.FILLER))
                        {
                            phyItmInfo.Phyitm_itemnm = ConstantUtils.YOBI;
                        }
                        else
                        {
                            phyItmInfo.Phyitm_itemnm = reader["PHYITM_ITEMNM"].ToString();
                        }
                        phyItmInfo.logicalOperation = new LogicalOperationModel();
                        int.TryParse(reader["COND_OUTPUTORDER"].ToString(), out cond_outputorder);
                        phyItmInfo.logicalOperation.Cond_outputorder = cond_outputorder;
                        phyItmInfo.logicalOperation.Cond_opnm = reader["COND_OPNM"].ToString();
                        phyItmInfo.logicalOperation.Cond_setcond = reader["COND_SETCOND"].ToString();
                        phyConModel.phyItmInfoList.Add(phyItmInfo);
                    }
                }
                this.CloseConnection();
            }
            catch (Exception e)
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    //Log for confirm Database table.
                    LogUtils.WriteLogInfo(version.User.USERID, LogUtils.GetMsgInfo(Resources.SCT00099_E, e.Message), LogUtils.GetMsgType(ConstantUtils.SCT00099_E), e);
                    this.CloseConnection();
                    //Throw Error SCT00099_E
                    //SCT00099_E　エラーをスロー
                    throw new SettingConditionException(LogUtils.GetMsgInfo(Resources.SCT00099_E, e.Message), e);
                }
                else
                {
                    //log for Database error
                    //データベースにエラーが発生する場合、ログに記録
                    LogUtils.WriteLogInfo(version.User.USERID, LogUtils.GetMsgInfo(Resources.SCT00003_E, e.Message), LogUtils.GetMsgType(ConstantUtils.SCT00003_E), e);
                    //Throw Error SCT00003-E
                    //SCT00003-E　エラーをスロー
                    throw new SettingConditionException(LogUtils.GetMsgInfo(Resources.SCT00003_E, string.Empty));
                }

            }
        }

        // <summary>
        /// To close database connection.<br/>
        /// データベース接続を閉じる<br/>
        /// </summary>
        /// <remarks>
        /// 2018/03/07 新規作成<br/>
        /// </remarks>
        public void CloseConnection()
        {
            if (connection.State == ConnectionState.Open)
            {
                connection.Close();
            }
        }

        #endregion
    }
}
