﻿//-----------------------------------------------------------
// All Rights Reserved , Copyright (C) 2018 , Hitachi , Ltd.
//-----------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Data;
using System.Configuration;
using MySql.Data.MySqlClient;
using MarsTool.Properties;
using MarsTool.Common;
using MarsTool.Models;
using static MarsTool.Common.CommonConstant;
using MarsTool.Exceptions;

namespace MarsTool.Daos
{
    /// <summary>
    /// DenbunDBConnectivity Class<br/>
    /// DenbunDBConnectivity　クラス<br/>
    /// To Connect DataBase.To get data from database<br/>
    /// データベースからデータを取得するため、データベースを接続<br/>
    /// </summary>
    /// <remarks>
    /// 2018/03/07 新規作成<br/>
    /// </remarks>
    class DenbunDBConnectivity
    {
        #region variable

        private NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        //Specify instance of DenbunDBConnectivity
        //DenbunDBConnectivityのインスタンスを指定
        private static DenbunDBConnectivity instance;

        private VersionModel version;

        public DenbunDBConnectivity(VersionModel v)
        {
            version = v;
        }

        #endregion

        #region public method

        /// <summary>
        /// Get Connection to database<br/>
        /// データベース接続を取得<br/>
        /// </summary>
        /// <returns>
        /// Return DenbunDBConnectivity instance.<br/>
        /// DenbunDBConnectivityインスタンスを返却<br/>
        /// </returns>
        /// <remarks>
        /// 2018/03/07 新規作成<br/>
        /// </remarks>
        public static DenbunDBConnectivity getInstance(VersionModel v)
        {
            if (instance == null)
            {
                instance = new DenbunDBConnectivity(v);
            }
            return instance;
        }

        public int SelectPhysicalInfoCntByPK(string subSysID, string telTypeSysID, string telType, string patNo)
        {
            List<PhyDenbunInfo> phyInfos = new List<PhyDenbunInfo>();
            int rowCnt = 0;
            String queryStr = null;
            MySqlConnection connection = null;
            
            try
            {
                connection = new MySqlConnection(version.ConnectString);
                connection.Open();
                //SQL SELECT 文書を作成
                queryStr = "SELECT COUNT(*) FROM " + T_DENSTRB_TB + " WHERE DENSTRB_SUBSYSID = '" + subSysID +
                           "' AND DENSTRB_TELSUBSYSID = '" + telTypeSysID + "' AND DENSTRB_TELTYPE = '" + telType +
                           "' AND DENSTRB_PATNO = '" + patNo + "'";
                //SQL実行
                MySqlCommand cmd = new MySqlCommand(queryStr, connection);

                rowCnt = int.Parse(cmd.ExecuteScalar().ToString());
                connection.Close();
            }
            catch (MySqlException ex)
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    logger.Error(version.User.USERID + SPACE + String.Format(Resources.DEN00026_E, ex));
                    connection.Close();
                    throw new DenbunRegException(Resources.DEN00026_E);
                }
                else
                {
                    throw new DenbunRegException(Resources.DEN00014_E);
                }
            }
            return rowCnt;
        }

        public int SelectPhysicalInfoCntByPhyID(String subSysID, string phyID)
        {
            int phyIDCnt = 0;
            String queryStr = null;
            MySqlConnection connection = null;
            try
            {
                connection = new MySqlConnection(version.ConnectString);
                connection.Open();
                //SQL SELECT 文書を作成
                queryStr = "SELECT COUNT(*) FROM " + T_PHYPRS_TB + " WHERE PHYPRS_SUBSYSID = '" + subSysID +
                                  "' AND PHYPRS_PHYID = '" + phyID + "'";

                //SQL実行
                MySqlCommand cmd = new MySqlCommand(queryStr, connection);
                phyIDCnt = int.Parse(cmd.ExecuteScalar().ToString());
                connection.Close();

            }
            catch (MySqlException ex)
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    logger.Error(version.User.USERID + SPACE + String.Format(Resources.DEN00026_E, ex));
                    connection.Close();
                    throw new DenbunRegException(Resources.DEN00026_E);
                }
                else
                {
                    throw new DenbunRegException(Resources.DEN00014_E);
                }
            }

            return phyIDCnt;
        }

        public int SelectOutputOrderBySysID(string subSysID)
        {
            
            int outOrder = 0;
            String queryStr2 = null;
            MySqlConnection connection = null;

            try
            {
                connection = new MySqlConnection(version.ConnectString);
                connection.Open();

                //サブシステムに対する最大の順序の取得用SQL SELECT 文書を作成
                queryStr2 = "SELECT MAX(DENSTRB_ORDER) FROM " + T_DENSTRB_TB + " WHERE DENSTRB_SUBSYSID = '" + subSysID + "'";

                //SQL実行
                MySqlCommand cmd = new MySqlCommand(queryStr2, connection);

                if (cmd.ExecuteScalar() != DBNull.Value)
                {
                    outOrder = (int)(cmd.ExecuteScalar());
                }

                connection.Close();
            }
            catch (MySqlException ex)
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    logger.Error(version.User.USERID + SPACE + String.Format(Resources.DEN00026_E, ex));
                    connection.Close();
                    throw new DenbunRegException(Resources.DEN00026_E);
                }
                else
                {
                    throw new DenbunRegException(Resources.DEN00014_E);
                }
            }
            return outOrder;
        }

        public void InsertPhysicalInfos(List<PhyDenbunInfo> phyDenbunInfos)
        {
            MySqlConnection connection = null;
            MySqlTransaction transaction = null;
            try
            {
                connection = new MySqlConnection(version.ConnectString);
                connection.Open();
                transaction = connection.BeginTransaction();
                MySqlCommand comm = connection.CreateCommand();

                foreach (PhyDenbunInfo phyDenInfo in phyDenbunInfos)
                {
                    //SQL INSERT 文書を作成
                    comm.CommandText = "INSERT INTO " + T_DENSTRB_TB + "(DENSTRB_SUBSYSID, DENSTRB_TELSUBSYSID, " +
                                      "DENSTRB_TELTYPE, DENSTRB_PATNO, DENSTRB_ORDER, DENSTRB_GROUPID, DENSTRB_COMMENT, DENSTRB_USERID, " +
                                      "DENSTRB_UPDTIME) VALUES(?DENSTRB_SUBSYSID, ?DENSTRB_TELSUBSYSID, " +
                                      "?DENSTRB_TELTYPE, ?DENSTRB_PATNO, ?DENSTRB_ORDER, ?DENSTRB_GROUPID, ?DENSTRB_COMMENT, ?DENSTRB_USERID, " +
                                      "?DENSTRB_UPDTIME)";

                    comm.Parameters.Add("?DENSTRB_SUBSYSID", MySqlDbType.VarChar).Value = phyDenInfo.subSysID;
                    comm.Parameters.Add("?DENSTRB_TELSUBSYSID", MySqlDbType.VarChar).Value = phyDenInfo.telSubSysID;
                    comm.Parameters.Add("?DENSTRB_TELTYPE", MySqlDbType.VarChar).Value = phyDenInfo.telType;
                    comm.Parameters.Add("?DENSTRB_PATNO", MySqlDbType.VarChar).Value = phyDenInfo.patNo;
                    comm.Parameters.Add("?DENSTRB_ORDER", MySqlDbType.Int32).Value = phyDenInfo.order;
                    comm.Parameters.Add("?DENSTRB_GROUPID", MySqlDbType.VarChar).Value = phyDenInfo.groupID;
                    comm.Parameters.Add("?DENSTRB_COMMENT", MySqlDbType.VarChar).Value = phyDenInfo.comment;
                    comm.Parameters.Add("?DENSTRB_USERID", MySqlDbType.VarChar).Value = phyDenInfo.userID;
                    comm.Parameters.Add("?DENSTRB_UPDTIME", MySqlDbType.DateTime).Value = DateTime.Now;
                    comm.ExecuteNonQuery();

                    foreach (PhyDenbunItmInfo itemInfo in phyDenInfo.itemInfos)
                    {
                        comm = connection.CreateCommand();
                        //SQL INSERT 文書を作成
                        comm.CommandText = "INSERT INTO " + T_DENSTRBITM_TB + "(DENSTRBITM_SUBSYSID, DENSTRBITM_TELSUBSYSID, " +
                                          "DENSTRBITM_TELTYPE, DENSTRBITM_PATNO, DENSTRBITM_ORDER, DENSTRBITM_TYPE, DENSTRBITM_PHYID, DENSTRBITM_SEQ, DENSTRBITM_TURN, " +
                                          "DENSTRBITM_YOBISIZE, DENSTRBITM_USERID, DENSTRBITM_UPDTIME) VALUES(?DENSTRBITM_SUBSYSID, ?DENSTRBITM_TELSUBSYSID, " +
                                          "?DENSTRBITM_TELTYPE, ?DENSTRBITM_PATNO, ?DENSTRBITM_ORDER, ?DENSTRBITM_TYPE, ?DENSTRBITM_PHYID, ?DENSTRBITM_SEQ, ?DENSTRBITM_TURN, " +
                                          "?DENSTRBITM_YOBISIZE, ?DENSTRBITM_USERID, ?DENSTRBITM_UPDTIME)";

                        comm.Parameters.Add("?DENSTRBITM_SUBSYSID", MySqlDbType.VarChar).Value = phyDenInfo.subSysID;
                        comm.Parameters.Add("?DENSTRBITM_TELSUBSYSID", MySqlDbType.VarChar).Value = phyDenInfo.telSubSysID;
                        comm.Parameters.Add("?DENSTRBITM_TELTYPE", MySqlDbType.VarChar).Value = phyDenInfo.telType;
                        comm.Parameters.Add("?DENSTRBITM_PATNO", MySqlDbType.VarChar).Value = phyDenInfo.patNo;
                        comm.Parameters.Add("?DENSTRBITM_ORDER", MySqlDbType.VarChar).Value = itemInfo.order;
                        comm.Parameters.Add("?DENSTRBITM_TYPE", MySqlDbType.VarChar).Value = itemInfo.type;
                        comm.Parameters.Add("?DENSTRBITM_PHYID", MySqlDbType.VarChar).Value = itemInfo.phyID;
                        comm.Parameters.Add("?DENSTRBITM_SEQ", MySqlDbType.VarChar).Value = version.genSequenceID2(T_DENSTRBITM_STR);
                        comm.Parameters.Add("?DENSTRBITM_TURN", MySqlDbType.Int32).Value = itemInfo.turn;
                        comm.Parameters.Add("?DENSTRBITM_YOBISIZE", MySqlDbType.Int32).Value = itemInfo.yobiSize;
                        comm.Parameters.Add("?DENSTRBITM_USERID", MySqlDbType.VarChar).Value = phyDenInfo.userID;
                        comm.Parameters.Add("?DENSTRBITM_UPDTIME", MySqlDbType.DateTime).Value = DateTime.Now;
                        comm.ExecuteNonQuery();
                    }
                }

                transaction.Commit();
                connection.Close();
            }
            catch (MySqlException ex)
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    logger.Error(version.User.USERID + SPACE + String.Format(Resources.DEN00026_E, ex));
                    connection.Close();
                    throw new DenbunRegException(Resources.DEN00026_E);
                }
                else
                {
                    throw new DenbunRegException(Resources.DEN00014_E);
                }
            }
        }
        #endregion
    }
}
