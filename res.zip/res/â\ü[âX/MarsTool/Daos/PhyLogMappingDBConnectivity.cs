﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using MarsTool.Properties;
using System.Configuration;
using MarsTool.Models;
using MarsTool.Exceptions;
using MarsTool.Common;
using System.Data;

namespace MarsTool.Daos
{
    /// <summary>
    /// PhyLogMappingDBConnectivity Class<br/>
    /// PhyLogMappingDBConnectivity　クラス<br/>
    /// To Connect DataBase.To get data from database<br/>
    /// データベースからデータを取得するため、データベースを接続<br/>
    /// </summary>
    /// <remarks>
    /// 2018/05/22 修正<br/>
    /// </remarks>
    class PhyLogMappingDBConnectivity
    {
        #region variable

        //Specify instance of PhyLogMappingDBConnectivity
        //PhyLogMappingDBConnectivityのインスタンスを指定
        private static PhyLogMappingDBConnectivity instance;

        //To connect to database
        //データベースを接続
        private static MySqlConnection connection;

        private VersionModel version;

        #endregion

        #region private method

        /// <summary>
        /// データベース接続を取得<br/>
        /// Get Connection to database<br/>
        /// </summary>
        /// <remarks>
        /// 2018/02/28 新規作成<br/>
        /// </remarks>
        private PhyLogMappingDBConnectivity(VersionModel v)
        {
            connection = new MySqlConnection(v.ConnectString);
            version = v;

        }

        #endregion

        #region public method

        /// <summary>
        /// Get Connection to database<br/>
        /// データベース接続を取得<br/>
        /// </summary>
        /// <returns>
        /// Return PhyLogMappingDBConnectivity instance.<br/>
        /// PhyLogMappingDBConnectivityインスタンスを返却<br/>
        /// </returns>
        /// <remarks>
        /// 2018/02/28 新規作成<br/>
        /// </remarks>
        public static PhyLogMappingDBConnectivity getInstance(VersionModel v)
        {
            if (instance == null)
            {
                instance = new PhyLogMappingDBConnectivity(v);
            }
            return instance;
        }

        /// <summary>
        /// To select mapping data from database table.<br/>
        /// データベーステーブルからマッピングデータを選択<br/>
        /// </summary>
        /// <param name="phyLogMap">
        /// phyLogMap is used to find Mapping Data.<br/>
        /// マッピングデータを検索するため、phyLogMap を利用<br/>
        /// </param>
        /// <remarks>
        /// 2018/05/22 修正<br/>
        /// </remarks>
        public void SeletDataFromDb(PhysicalLogicalMappingModel phyLogMap)
        {
            try
            {
                string selectQuery = "SELECT cpy.CPYPHY_SUBSYSID,cpy.CPYPHY_BCPID,cpy.CPYPHY_BCPNM," +
                                    " phy.PHYITM_SEQ,phy.PHYITM_ITEMNM,phy.PHYITM_DTTYPE,phy.PHYITM_DTLEN,phy.PHYITM_OCCURS,phy.PHYITM_ITEMFLG," +
                                    " clog.CPYLGC_LCPID,clog.CPYLGC_OPNM,clog.CPYLGC_OUTPUTORDER" +
                                    " FROM t_cpyphy cpy" +
                                    " LEFT JOIN t_phyitm phy ON (cpy.CPYPHY_SUBSYSID = phy.PHYITM_SUBSYSID AND cpy.CPYPHY_INFOID = phy.PHYITM_INFOID) " +
                                    " LEFT JOIN t_logitm litm ON (phy.PHYITM_SEQ = litm.LOGITM_SEQ and litm.LOGITM_SUBSYSIDL = @LogSubSysID) " +
                                    " LEFT JOIN t_cpylog clog ON (clog.CPYLGC_LCPID = litm.LOGITM_LCPID)";

                connection.Open();

                MySqlCommand command = null;

                if (phyLogMap.Cpyphy_bcpid.Equals(string.Empty))
                {
                    selectQuery += " WHERE cpy.CPYPHY_BCPNM = @Name ORDER BY phy.PHYITM_ITEMNO;";
                    command = new MySqlCommand(selectQuery, connection);
                    command.Parameters.Add(new MySqlParameter("@Name", phyLogMap.Cpyphy_bcpnm));
                    command.Parameters.Add(new MySqlParameter("@LogSubSysID", phyLogMap.Logitm_subsysidl));
                }
                else if (phyLogMap.Cpyphy_bcpnm.Equals(string.Empty))
                {
                    selectQuery += " WHERE cpy.CPYPHY_BCPID = @id ORDER BY phy.PHYITM_ITEMNO;";
                    command = new MySqlCommand(selectQuery, connection);
                    command.Parameters.Add(new MySqlParameter("@id", phyLogMap.Cpyphy_bcpid));
                    command.Parameters.Add(new MySqlParameter("@LogSubSysID", phyLogMap.Logitm_subsysidl));
                }
                else
                {
                    selectQuery += " WHERE cpy.CPYPHY_BCPID = @id AND cpy.CPYPHY_BCPNM = @Name ORDER BY phy.PHYITM_ITEMNO;";
                    command = new MySqlCommand(selectQuery, connection);
                    command.Parameters.Add(new MySqlParameter("@id", phyLogMap.Cpyphy_bcpid));
                    command.Parameters.Add(new MySqlParameter("@Name", phyLogMap.Cpyphy_bcpnm));
                    command.Parameters.Add(new MySqlParameter("@LogSubSysID", phyLogMap.Logitm_subsysidl));
                }
                command.CommandTimeout = 0;
                IDataReader reader = command.ExecuteReader();

                phyLogMap.phyItmInfoList = new List<PhysicalLogicalItmInfoModel>();

                Int64 phyitm_seq = 0;
                int cpylgc_outputorder = 0;
                while (reader.Read())
                {
                    if (string.IsNullOrEmpty(phyLogMap.Cpyphy_subsysid))
                    {
                        phyLogMap.Cpyphy_subsysid = reader["CPYPHY_SUBSYSID"].ToString();
                        phyLogMap.Cpyphy_bcpid = reader["CPYPHY_BCPID"].ToString();
                        phyLogMap.Cpyphy_bcpnm = reader["CPYPHY_BCPNM"].ToString();
                    }

                    if (!string.IsNullOrEmpty(reader["PHYITM_SEQ"].ToString()))
                    {
                        PhysicalLogicalItmInfoModel phyItmInfo = new PhysicalLogicalItmInfoModel();
                        Int64.TryParse(reader["PHYITM_SEQ"].ToString(), out phyitm_seq);
                        phyItmInfo.Phyitm_seq = phyitm_seq;
                        if (reader["PHYITM_ITEMNM"].ToString().Equals(ConstantUtils.FILLER))
                        {
                            phyItmInfo.Phyitm_itemnm = ConstantUtils.YOBI;
                        }
                        else
                        {
                            phyItmInfo.Phyitm_itemnm = reader["PHYITM_ITEMNM"].ToString();
                        }
                        phyItmInfo.Phyitm_itemflag = reader["PHYITM_ITEMFLG"].ToString();
                        phyItmInfo.Phyitm_dttype = reader["PHYITM_DTTYPE"].ToString();
                        phyItmInfo.Phyitm_dtlen = reader["PHYITM_DTLEN"].ToString();
                        phyItmInfo.Phyitm_occurs = reader["PHYITM_OCCURS"].ToString();

                        phyItmInfo.logicalOperation = new PhysicalLogicalOperationModel();
                        phyItmInfo.logicalOperation.Cpylgc_lcpid = reader["CPYLGC_LCPID"].ToString();
                        phyItmInfo.logicalOperation.Cpylgc_opnm = reader["CPYLGC_OPNM"].ToString();
                        int.TryParse(reader["CPYLGC_OUTPUTORDER"].ToString(), out cpylgc_outputorder);
                        phyItmInfo.logicalOperation.Cpylgc_outputorder = cpylgc_outputorder;
                        phyLogMap.phyItmInfoList.Add(phyItmInfo);
                    }
                }
                this.CloseConnection();
            }
            catch (Exception e)
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    //Log for confirm Database table.
                    LogUtils.WriteLogInfo(version.User.USERID, LogUtils.GetMsgInfo(Resources.PLM00099_E, e.Message), LogUtils.GetMsgType(ConstantUtils.PLM00099_E), e);
                    this.CloseConnection();
                    //Throw Error PLM00099_E
                    //PLM00099_E　エラーをスロー
                    throw new PhysicalLogicalMappingException(LogUtils.GetMsgInfo(Resources.PLM00099_E, e.Message), e);
                }
                else
                {
                    //log for Database error
                    //データベースにエラーが発生する場合、ログに記録
                    LogUtils.WriteLogInfo(version.User.USERID, LogUtils.GetMsgInfo(Resources.PLM00003_E, e.Message), LogUtils.GetMsgType(ConstantUtils.PLM00003_E), e);
                    //Throw Error PLM00003_E
                    //PLM00003_E　エラーをスロー
                    throw new PhysicalLogicalMappingException(LogUtils.GetMsgInfo(Resources.PLM00003_E, string.Empty));
                }
            }
        }

        /// <summary>
        /// To close database connection.<br/>
        /// データベース接続を閉じる<br/>
        /// </summary>
        /// <remarks>
        /// 2018/02/28 新規作成<br/>
        /// </remarks>
        public void CloseConnection()
        {
            if (connection.State == ConnectionState.Open)
            {
                connection.Close();
            }
        }

        #endregion
    }
}
