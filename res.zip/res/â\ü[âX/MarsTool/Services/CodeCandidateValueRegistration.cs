﻿//-----------------------------------------------------------
// All Rights Reserved , Copyright (C) 2018 , Hitachi , Ltd.
//-----------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.IO;
using System.Linq;
using Excel = Microsoft.Office.Interop.Excel;
using MarsTool.Common;
using MarsTool.Daos;
using MarsTool.Models;
using MarsTool.Properties;
using MarsTool.Exceptions;

namespace MarsTool.Services
{
    /// <summary>
    /// CodeCandidateValueRegistration class<br/>
    ///　CodeCandidateValueRegistration　クラス<br/>
    /// To read code candidate value from excel file and export to Database.<br/>
    /// エクセルファイルからコード候補値を読み込み、データベースにエクスポート<br/>
    /// </summary>
    /// <remarks>
    /// 2018/04/02 新規作成<br/>
    /// </remarks>
    class CodeCandidateValueRegistration
    {
        private static CodeCandidateValueRegistration instance;
        private VersionModel ver;

        public CodeCandidateValueRegistration(VersionModel v)
        {
            ver = v;
        }
        public static CodeCandidateValueRegistration getInstance(VersionModel v)
        {
            if (instance == null)
            {
                instance = new CodeCandidateValueRegistration(v);
            }
            return instance;
        }
        #region public Method

        /// <summary>
        /// Export Code candidate Data to database.<br/>
        /// データベースにコード候補データをエクスポート<br/>
        /// </summary>
        /// <param name="inputFilePath">
        /// inputFilePath is used to read code candidate value excel file.<br/>
        /// コード候補値エクセルファイルを読み込むため、inputFilePathを使用<br/>
        /// </param>
        /// <param name="userID">
        /// userId is used to register UserID column.<br/>
        /// UserID列に登録するためuserIdを使用<br/>
        /// </param>
        /// <returns>
        /// Return Boolean true if export to database or false if error is occured.<br/>
        /// データベースにエクスポートした場合、ブーリアン「True」に返却し、エラーが発生した場合、「False」に返却<br/>
        /// </returns>
        /// <exception cref="CodeCadidateRegException">
        /// Throw exception if exception occurs.<br/>
        /// 例外が発生する場合、例外をスロー<br/>
        /// </exception>
        /// <remarks>
        /// 2018/05/24 新規作成<br/>
        /// </remarks>
        public bool RegisterCodeCandidate(string inputFilePath)
        {
            bool isExport = false;
            try
            {
                //Get Maximun columns length of specify table
                //指定したテーブルの列の最大長を取得
                Dictionary<string, int> maxColLength = KohoDBConnectivity.getInstance(ver).SelectMaxColLen();

                if (maxColLength.Count < ConstantUtils.COLLIST.Length)
                {
                    //Log for confirm Database table.
                    //データベーステーブルの確認のため、ログに記録
                    LogUtils.WriteLogInfo(ver.User.USERID, LogUtils.GetMsgInfo(Resources.CVR00015_E, ConstantUtils.TABLENAME), LogUtils.GetMsgType(ConstantUtils.CVR00015_E));

                    //Throw Error CVR00015-E
                    //CVR00015-E　エラーをスロー
                    throw new CodeCadidateRegException(LogUtils.GetMsgInfo(Resources.CVR00015_E, ConstantUtils.TABLENAME));
                }

                if (ver.User.USERID.Length > maxColLength[ConstantUtils.COLLIST[3]])
                {
                    // Log for lenght of user id is greate than maximun column length.
                    // user idの長さは列の最大長さより大きい場合、ログに記録
                    LogUtils.WriteLogInfo(ver.User.USERID, LogUtils.GetMsgInfo(Resources.CVR00006_E, ver.User.USERID, maxColLength[ConstantUtils.COLLIST[3]].ToString()), LogUtils.GetMsgType(ConstantUtils.CVR00004_W));
                    //Throw Error CVR00006-E
                    //CVR00006-E　エラーをスロー
                    throw new CodeCadidateRegException(LogUtils.GetMsgInfo(Resources.CVR00006_E, ver.User.USERID, maxColLength[ConstantUtils.COLLIST[3]].ToString()));
                }

                //Read code candidate information from excel
                //エクセルからコード候補情報を読み込む
                List<CodeCandidateModel> codeCandidateValueList = ReadCodeCandidateExcelFile(inputFilePath, maxColLength);

                //Check code candidate value exists or not.
                //コード候補値は存在しているかチェック
                if (codeCandidateValueList.Count == 0)
                {
                    //Log for there is no code candidate data.
                    //コード候補データはない場合、ログに記録
                    LogUtils.WriteLogInfo(ver.User.USERID, Resources.CVR00010_E, LogUtils.GetMsgType(ConstantUtils.CVR00010_E));

                    return true;
                }

                //Log for code candidate data reading process is finished.
                // コード候補データの読み込む処理は終了した場合、ログに記録
                LogUtils.WriteLogInfo(ver.User.USERID, Resources.CVR00001_I, LogUtils.GetMsgType(ConstantUtils.CVR00001_I));

                int regCnt = KohoDBConnectivity.getInstance(ver).InsertCodeCandidateList(codeCandidateValueList);

                if (regCnt > 0)
                {
                    //Log for code candidate value register processing is finished.
                    // コード候補値の登録処理は終了した場合、ログに記録
                    LogUtils.WriteLogInfo(ver.User.USERID, Resources.CVR00002_I, LogUtils.GetMsgType(ConstantUtils.CVR00002_I));

                    isExport = true;
                }
            }
            catch (CodeCadidateRegException e)
            {
                //Throw Error 
                //エラーをスロー
                throw new CodeCadidateRegException(e.GetMessage());
            }
            catch (Exception e)
            {
                //Log for unexpected error
                //想定外エラーが発生する場合、ログに記録
                LogUtils.WriteLogInfo(ver.User.USERID, LogUtils.GetMsgInfo(Resources.CVR00099_E, e.Message), LogUtils.GetMsgType(ConstantUtils.CVR00099_E), e);

                //Throw Error CVR00099-E
                //CVR00099-E　エラーをスロー
                throw new CodeCadidateRegException(LogUtils.GetMsgInfo(Resources.CVR00099_E, e.Message), e);
            }
            return isExport;
        }

        #endregion

        #region private method

        /// <summary>
        /// Export Code candidate Data to database.<br/>
        /// データベースにコード候補データをエクスポート<br/>
        /// </summary>
        /// <param name="inputFilePath">
        /// inputFilePath is used to read code candidate value excel file.<br/>
        /// エクセルファイルからコード候補値を読み込むため、inputFilePath　を使用<br/>
        /// </param>
        /// <param name="maxColLength">
        /// maxColLength is used to check value length.<br/>
        /// 値の長さをチェックするため、maxColLengthを使用<br/>
        /// </param>
        /// <returns>
        /// Return code candidate value list for registration.<br/>
        /// 登録するため、コード候補値を返却<br/>
        /// </returns>
        /// <exception cref="CodeCadidateRegException">
        /// Throw exception if exception occurs.<br/>
        /// 例外が発生する場合、例外をスロー<br/>
        /// </exception>
        /// <remarks>
        /// 2018/05/24 新規作成<br/>
        /// </remarks>
        private List<CodeCandidateModel> ReadCodeCandidateExcelFile(string inputFilePath, Dictionary<string, int> maxColLength)
        {
            Excel.Application xlApp = null;
            Excel.Workbook xlWorkBook = null;
            Excel.Worksheet xlWorkSheet = null;

            List<CodeCandidateModel> codeCandidateList = new List<CodeCandidateModel>();
            try
            {
                xlApp = new Excel.Application();
                xlApp.DisplayAlerts = false;
                xlApp.Visible = false;
                xlWorkBook = xlApp.Workbooks.Open(inputFilePath, ReadOnly: true);

                for (int i = 1; i <= xlWorkBook.Worksheets.Count; i++)
                {
                    xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(i);

                    //Check Template File
                    //テンプレートファイルをチェック
                    if (xlWorkSheet.Range[ConstantUtils.ITEMNO_CELLADD_STR].Text.Contains(ConstantUtils.ITEMNO_STR) &&
                        xlWorkSheet.Range[ConstantUtils.CANDIDATEVALUE_CELLADD].Text.Contains(ConstantUtils.CANDIDATEVALUE) &&
                        xlWorkSheet.Range[ConstantUtils.CANDIDATECONTENT_CELLADD].Text.Contains(ConstantUtils.CANDIDATECONTENT))
                    {
                        CodeCandidateModel codeCandidateValue = new CodeCandidateModel();

                        //Get group name
                        codeCandidateValue.Koho_group = xlWorkSheet.Range[ConstantUtils.GROUP_CELLADD].Text.Trim();

                        if (string.IsNullOrEmpty(codeCandidateValue.Koho_group))
                        {
                            //Log for Group Name is Empty.
                            LogUtils.WriteLogInfo(ver.User.USERID, LogUtils.GetMsgInfo(Resources.CVR00005_W, ConstantUtils.GROUP_NAME, xlWorkSheet.Name),
                                                    LogUtils.GetMsgType(ConstantUtils.CVR00004_W));
                        }
                        else if (codeCandidateValue.Koho_group.Length > maxColLength[ConstantUtils.COLLIST[0]])
                        {
                            //Log for Length of group name is greater than maximun length.
                            LogUtils.WriteLogInfo(ver.User.USERID, LogUtils.GetMsgInfo(Resources.CVR00012_W, ConstantUtils.GROUP_NAME, maxColLength[ConstantUtils.COLLIST[0]].ToString(), xlWorkSheet.Name),
                                                    LogUtils.GetMsgType(ConstantUtils.CVR00012_W));
                        }
                        else if (codeCandidateList.Any(x => x.Koho_group == codeCandidateValue.Koho_group) ||
                                    KohoDBConnectivity.getInstance(ver).CheckGroupName(codeCandidateValue.Koho_group))
                        {
                            //Log for Group Name is duplicate within workbook or aleady exists in database. 
                            LogUtils.WriteLogInfo(ver.User.USERID, LogUtils.GetMsgInfo(Resources.CVR00014_W, codeCandidateValue.Koho_group, xlWorkSheet.Name),
                                                    LogUtils.GetMsgType(ConstantUtils.CVR00014_W));
                        }
                        else
                        {
                            //Get Last row of candidate value column 
                            //候補値列の最終行を取得
                            int valueLastRow = xlWorkSheet.Range[ConstantUtils.CANDIDATEVALUE_COL + xlWorkSheet.Rows.Count.ToString()].get_End(Excel.XlDirection.xlUp).Row;

                            //Get Last row of candidate content column
                            //候補内容列の最終行を取得
                            int contentLastRow = xlWorkSheet.Range[ConstantUtils.CANDIDATECONTENT_COL + xlWorkSheet.Rows.Count.ToString()].get_End(Excel.XlDirection.xlUp).Row;

                            int maxRow = (valueLastRow >= contentLastRow) ? valueLastRow : contentLastRow;

                            if (maxRow >= ConstantUtils.DATASTART_ROW)
                            {
                                object[,] codeValue = xlWorkSheet.Range[ConstantUtils.CANDIDATEVALUE_COL + ConstantUtils.DATASTART_ROW,
                                                        ConstantUtils.CANDIDATECONTENT_COL + maxRow.ToString()].Value;

                                codeCandidateValue.Koho_outputOrder = new List<int>();
                                codeCandidateValue.Koho_code = new List<string>();
                                codeCandidateValue.Koho_content = new List<string>();

                                int outputorder = 0;

                                for (int x = 1; x <= codeValue.GetLength(0); x++)
                                {
                                    if ((codeValue[x, 1] == null || codeValue[x, 1].ToString().Trim() == string.Empty) &&
                                            (codeValue[x, 2] == null || codeValue[x, 2].ToString().Trim() == string.Empty))
                                    {
                                        //Check for next record is empty or not
                                        //次のレコードは空かチェック
                                        if (x < codeValue.GetLength(0) && ((codeValue[x + 1, 1] != null && codeValue[x + 1, 1].ToString().Trim() != string.Empty)
                                            || (codeValue[x + 1, 2] != null && codeValue[x + 1, 2].ToString().Trim() != string.Empty)))
                                        {
                                            //Log for blank line at middle
                                            //真ん中に空白行がある場合、ログに記録
                                            LogUtils.WriteLogInfo(ver.User.USERID,
                                                    LogUtils.GetMsgInfo(Resources.CVR00008_W, xlWorkSheet.Name,
                                                    (x + ConstantUtils.DATASTART_ROW - 1).ToString()), LogUtils.GetMsgType(ConstantUtils.CVR00008_W));
                                        }
                                        codeCandidateValue.Koho_code.Clear();
                                        codeCandidateValue.Koho_content.Clear();
                                        break;
                                    }
                                    else if (codeValue[x, 1] == null || codeValue[x, 1].ToString().Trim() == string.Empty)
                                    {
                                        //Log for Candidate Value is Empty
                                        //候補値は空の場合、ログに記録
                                        LogUtils.WriteLogInfo(ver.User.USERID,
                                                    LogUtils.GetMsgInfo(Resources.CVR00007_W, xlWorkSheet.Name, (x + ConstantUtils.DATASTART_ROW - 1).ToString(),
                                                    ConstantUtils.CANDIDATEVALUE, xlWorkSheet.Name), LogUtils.GetMsgType(ConstantUtils.CVR00007_W));
                                        codeCandidateValue.Koho_code.Clear();
                                        codeCandidateValue.Koho_content.Clear();
                                        break;
                                    }
                                    else if (codeValue[x, 2] == null || codeValue[x, 2].ToString().Trim() == string.Empty)
                                    {
                                        //Log for Candidate Content is Empty
                                        //候補内容は空の場合、ログに記録
                                        LogUtils.WriteLogInfo(ver.User.USERID,
                                                LogUtils.GetMsgInfo(Resources.CVR00007_W, xlWorkSheet.Name, (x + ConstantUtils.DATASTART_ROW - 1).ToString(),
                                                ConstantUtils.CANDIDATECONTENT, xlWorkSheet.Name), LogUtils.GetMsgType(ConstantUtils.CVR00007_W));
                                        codeCandidateValue.Koho_code.Clear();
                                        codeCandidateValue.Koho_content.Clear();
                                        break;
                                    }
                                    else if (codeValue[x, 1].ToString().Trim().Length > maxColLength[ConstantUtils.COLLIST[1]])
                                    {
                                        //Log for length of Candidate Value is greater than maximum length of column.
                                        //候補値の長さは列の最大長より大きい場合、ログに記録
                                        LogUtils.WriteLogInfo(ver.User.USERID,
                                                LogUtils.GetMsgInfo(Resources.CVR00013_W, xlWorkSheet.Name, (x + ConstantUtils.DATASTART_ROW - 1).ToString(),
                                                ConstantUtils.CANDIDATEVALUE, maxColLength[ConstantUtils.COLLIST[1]].ToString(), xlWorkSheet.Name), LogUtils.GetMsgType(ConstantUtils.CVR00013_W));
                                        codeCandidateValue.Koho_code.Clear();
                                        codeCandidateValue.Koho_content.Clear();
                                        break;
                                    }
                                    else if (codeValue[x, 2].ToString().Trim().Length > maxColLength[ConstantUtils.COLLIST[2]])
                                    {
                                        //Log for length of Candidate Content is greater than maximum length of column.
                                        // 候補内容の長さは列の最大長より大きい場合、ログに記録
                                        LogUtils.WriteLogInfo(ver.User.USERID,
                                                LogUtils.GetMsgInfo(Resources.CVR00013_W, xlWorkSheet.Name, (x + ConstantUtils.DATASTART_ROW - 1).ToString(),
                                                ConstantUtils.CANDIDATECONTENT, maxColLength[ConstantUtils.COLLIST[2]].ToString(), xlWorkSheet.Name), LogUtils.GetMsgType(ConstantUtils.CVR00013_W));
                                        codeCandidateValue.Koho_code.Clear();
                                        codeCandidateValue.Koho_content.Clear();
                                        break;
                                    }
                                    else
                                    {
                                        //Add value to Output order list
                                        codeCandidateValue.Koho_outputOrder.Add(++outputorder);

                                        //Add value to Candidate Value list
                                        //候補値リストに値を追加
                                        codeCandidateValue.Koho_code.Add(codeValue[x, 1].ToString().Trim());

                                        //Add value to Candidate Content list
                                        //候補内容リストに値を追加
                                        codeCandidateValue.Koho_content.Add(codeValue[x, 2].ToString().Trim());
                                    }
                                }
                                if (codeCandidateValue.Koho_code.Count != 0 && codeCandidateValue.Koho_content.Count != 0)
                                {
                                    codeCandidateList.Add(codeCandidateValue);
                                }
                            }
                        }
                    }
                    else
                    {
                        //Log for Template file is worng.
                        //テンプレートファイルは間違っている場合、ログに記録
                        LogUtils.WriteLogInfo(ver.User.USERID, LogUtils.GetMsgInfo(Resources.CVR00004_W, xlWorkSheet.Name), LogUtils.GetMsgType(ConstantUtils.CVR00004_W));
                    }
                }
            }
            catch (Exception e)
            {
                //log for Failed to read code candidate value excel file.
                //コード候補値エクセルファイルを読み込む時に失敗した場合、ログに記録
                LogUtils.WriteLogInfo(ver.User.USERID, LogUtils.GetMsgInfo(Resources.CVR00003_E, Path.GetFileName(inputFilePath), e.Message),
                    LogUtils.GetMsgType(ConstantUtils.CVR00003_E));

                //Throw Error CVR00003-E
                //CVR00003-E　エラーをスロー
                throw new CodeCadidateRegException(LogUtils.GetMsgInfo(Resources.CVR00003_E, Path.GetFileName(inputFilePath), e.Message));
            }
            finally
            {
                if (xlWorkSheet != null)
                {
                    Marshal.ReleaseComObject(xlWorkSheet);
                    xlWorkSheet = null;
                }

                if (xlWorkBook != null)
                {
                    xlWorkBook.Close(Type.Missing, Type.Missing, Type.Missing);
                    Marshal.ReleaseComObject(xlWorkBook);
                    xlWorkBook = null;
                }

                if (xlApp != null)
                {
                    xlApp.Quit();
                    Marshal.ReleaseComObject(xlApp);
                    xlApp = null;
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
            return codeCandidateList;
        }

        #endregion
    }
}
