﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Runtime.InteropServices;
using System.IO;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using MarsTool.Models;
using MarsTool.Common;
using MarsTool.Daos;
using MarsTool.Properties;
using MarsTool.Exceptions;
using System.Configuration;

namespace MarsTool.Services
{
    class SetCondTblCreation
    {

        #region public Method
        private static SetCondTblCreation instance;
        private VersionModel ver;

        public SetCondTblCreation(VersionModel v)
        {
            ver = v;
        }
        public static SetCondTblCreation getInstance(VersionModel v)
        {
            if (instance == null)
            {
                instance = new SetCondTblCreation(v);
            }
            return instance;
        }

        /// <summary>
        /// Export Data to Excel.<br/>
        /// データをエクセルにエクスポート<br/>
        /// </summary>
        /// <param name="copyClauseID">
        /// copyClauseID is used to find Mapping Data.<br/>
        /// マッピングデータを検索するため、copyClauseIDを利用<br/>
        /// </param>
        /// <param name="copyClauseName">
        /// copyClauseName is used to find Mapping Data.<br/>
        /// マッピングデータを検索するため、copyClauseName　を使用<br/>
        /// </param>
        /// <param name="outputPath">
        /// output file path<br/>
        /// 出力ファイルパス<br/>
        /// </param>
        /// <returns>
        /// Return Boolean true if export excel file or false if error is occured.<br/>
        /// ブーリアンはtrueの場合はエクスポートエクセルファイルを返却し、falseの場合はエラーが発生<br/>
        /// </returns>
        /// <exception cref="SettingConditionException">
        /// Throw exception if exception occurs.<br/>
        /// 例外が発生する場合、例外をスロー<br/>
        /// </exception>
        /// <remarks>
        /// 2018/05/28 新規作成<br/>
        /// </remarks>
        public bool CreateSettingConditionTable(string copyClauseID, string copyClauseName, string outputPath)
        {
            bool isExport = false;

            PhySettingConMappingModel phyConModel = new PhySettingConMappingModel();
            phyConModel.Cpyphy_bcpid = copyClauseID;
            phyConModel.Cpyphy_bcpnm = copyClauseName;

            //Get Mapping Data from Database
            //データベースからマッピングデータを取得
            SetConDBConnectivity.getInstance(ver).SeletDataFromDb(phyConModel);
            try
            {
                //Check Data is empty or not
                //データは空であるかチェック
                if (string.IsNullOrEmpty(phyConModel.Cpyphy_subsysid))
                {
                    //Log for no data found.
                    //データは見つからない場合、ログに記録
                    LogUtils.WriteLogInfo(ver.User.USERID, Resources.SCT00004_E, LogUtils.GetMsgType(ConstantUtils.SCT00004_E));

                    return false;
                }
                //Check Physical Information is empty or not
                //物理情報は空であるかチェック
                else if (phyConModel.phyItmInfoList.Count == 0)
                {
                    //Log for Physical information doesn't exist.
                    //物理情報は存在しない場合、ログに記録
                    LogUtils.WriteLogInfo(ver.User.USERID, Resources.SCT00005_E, LogUtils.GetMsgType(ConstantUtils.SCT00005_E));

                    return false;
                }
                //Check Settingcondition Infomation is empty or not
                //設定条件情報は空であるかチェック
                else if (!phyConModel.phyItmInfoList.Any(x => x.logicalOperation.Cond_opnm != string.Empty)
                        && !phyConModel.phyItmInfoList.Any(x => x.logicalOperation.Cond_setcond != string.Empty))
                {
                    //Log for settingcondition information doesn't exist.
                    //設定条件情報は存在しない場合、ログに記録
                    LogUtils.WriteLogInfo(ver.User.USERID, Resources.SCT00006_E, LogUtils.GetMsgType(ConstantUtils.SCT00006_E));

                    return false;
                }
                else
                {
                    //log for finsih data acquisition
                    //データの取得は終了する場合、ログに記録
                    LogUtils.WriteLogInfo(ver.User.USERID, Resources.SCT00001_I, LogUtils.GetMsgType(ConstantUtils.SCT00001_I));

                    object[,] headerArr = ConvertHeaderDataTo2DArray(phyConModel.phyItmInfoList);

                    object[,] dataArr = ConvertDataTo2DArray(phyConModel.phyItmInfoList, headerArr);

                    phyConModel.phyItmInfoList.Clear();
                    //Export Data to excel
                    //データをエクセルにエクスポート
                    ExportToExcel(headerArr, dataArr, outputPath, phyConModel);
                    isExport = true;
                    phyConModel = null;
                    headerArr = null;
                    dataArr = null;
                }
            }
            catch (SettingConditionException e)
            {
                //Throw Error 
                //エラーをスロー
                throw new SettingConditionException(e.GetMessage());
            }
            catch (Exception e)
            {
                //Log for unexpected error
                //想定外エラーが発生する場合、ログに記録
                LogUtils.WriteLogInfo(ver.User.USERID, LogUtils.GetMsgInfo(Resources.SCT00099_E, e.Message), LogUtils.GetMsgType(ConstantUtils.SCT00099_E), e);

                //Throw Error SCT00099-E
                //SCT00099-E　エラーをスロー
                throw new SettingConditionException(LogUtils.GetMsgInfo(Resources.SCT00099_E, e.Message), e);
            }
            return isExport;
        }

        #endregion

        #region private method

        /// <summary>
        /// Convert header data to two dimensional array.<br/>
        /// ヘッダデータを二次元配列に変換<br/>
        /// </summary>
        /// <param name="physicalInfoList">
        /// Get header data<br/>
        /// ヘッダデータを取得<br/>
        /// </param>
        /// <returns>
        /// Return header value with two dimensional arrray according to input parameter list.<br/>
        /// 入力パラメータ一覧により、ヘッダ値を二次元配列で返す<br/>
        /// </returns>
        /// <exception cref="SettingConditionException">
        /// Throw exception if exception occurs.<br/>
        /// 例外が発生する場合、例外をスロー<br/>
        /// </exception>
        /// <remarks>
        /// 2018/05/22 新規作成<br/>
        /// </remarks>
        private object[,] ConvertHeaderDataTo2DArray(List<PhysicalItmInfoModel> physicalInfoList)
        {
            object[,] headerArr = null;

            try
            {
                //Get Unique Operation Information
                //ユニーク操作情報を取得
                List<string> uniOperationInfoList = physicalInfoList
                                                    .OrderBy(x => x.logicalOperation.Cond_outputorder)
                                                    .Where(x => x.logicalOperation.Cond_opnm != string.Empty)
                                                    .Select(x => x.logicalOperation.Cond_opnm)
                                                    .Distinct()
                                                    .ToList();

                headerArr = new object[1, uniOperationInfoList.Count];

                //Prepare column data
                //列のデータを準備
                for (int i = 0; i < uniOperationInfoList.Count; i++)
                {
                    headerArr[0, i] = uniOperationInfoList[i];
                }
            }
            catch (Exception e)
            {
                //Log for unexpected error
                //想定外のエラーが発生する場合、ログに記録
                LogUtils.WriteLogInfo(ver.User.USERID, Resources.SCT00099_E, LogUtils.GetMsgType(ConstantUtils.SCT00099_E), e);

                //Throw Error SCT00099-E
                //SCT00099-E　エラーをスロー
                throw new SettingConditionException(LogUtils.GetMsgInfo(Resources.SCT00099_E, e.Message), e);
            }
            return headerArr;
        }

        /// <summary>
        /// Convert Mapping data to two dimensional array.<br/>
        /// マッピングデータを二次元配列に変換<br/>
        /// </summary>
        /// <param name="physicalInfoList">
        /// Get Setting Condition data.<br/>
        /// 設定条件データを取得<br/>
        /// </param>
        /// <param name="headerArr">
        /// To map mapping data of operation ID and header of operation ID.<br/>
        /// 操作IDのマッピングデータと操作IDのヘッダをマップ<br/>
        /// </param>
        /// <returns>
        /// Return Setting Condition value with two dimensional arrray according to input parameter list.<br/>
        ///入力パラメータリストにより、設定条件値を二次元配列で返却 <br/>
        /// </returns>
        /// <exception cref="SettingConditionException">
        /// Throw exception if exception occurs.<br/>
        /// 例外が発生する場合、例外をスロー<br/>
        /// </exception>
        /// <remarks>
        /// 2018/05/22 修正<br/>
        /// </remarks>
        private object[,] ConvertDataTo2DArray(List<PhysicalItmInfoModel> physicalInfoList, object[,] headerArr)
        {
            object[,] dataArr = null;
            try
            {
                //Get Unique Info.
                //ユニーク情報を取得
                List<PhysicalItmInfoModel> uniMappingList = physicalInfoList
                                                            .GroupBy(x => new
                                                            {
                                                                x.Phyitm_seq,
                                                            })
                                                            .Select(o => o.FirstOrDefault())
                                                            .ToList();

                dataArr = new object[uniMappingList.Count, headerArr.GetLength(1) + 3];

                //Prepare data to export
                //エクスポートするため、データを準備
                for (int j = 0; j < uniMappingList.Count; j++)
                {
                    uniMappingList[j].logicalOperationList = physicalInfoList
                                                            .Where(w => w.Phyitm_seq == uniMappingList[j].Phyitm_seq)
                                                            .Select(s => s.logicalOperation)
                                                            .ToList();

                    dataArr[j, 0] = (j + 1).ToString();
                    dataArr[j, 1] = uniMappingList[j].Phyitm_level;
                    dataArr[j, 2] = uniMappingList[j].Phyitm_itemnm;

                    for (int l = 0; l < headerArr.GetLength(1); l++)
                    {
                        for (int k = 0; k < uniMappingList[j].logicalOperationList.Count; k++)
                        {
                            if (headerArr[0, l].ToString() == uniMappingList[j].logicalOperationList[k].Cond_opnm)
                            {
                                dataArr[j, l + 3] = uniMappingList[j].logicalOperationList[k].Cond_setcond;
                            }
                        }
                    }
                }
                physicalInfoList.Clear();
            }
            catch (Exception e)
            {
                //Log for unexpected error
                //想定外のエラーが発生する場合、ログに記録
                LogUtils.WriteLogInfo(ver.User.USERID, LogUtils.GetMsgInfo(Resources.SCT00099_E, e.Message), LogUtils.GetMsgType(ConstantUtils.SCT00099_E), e);

                //Throw Error SCT00099-E
                //SCT00099-E　エラーをスロー
                throw new SettingConditionException(LogUtils.GetMsgInfo(Resources.SCT00099_E, e.Message), e);
            }
            return dataArr;
        }

        /// <summary>
        /// To Export mapping data to excel.<br/>
        /// マッピングデータをエクセルにエクスポート<br/>
        /// </summary>
        /// <param name="headerArr">
        /// Get header data<br/>
        /// ヘッダデータを取得<br/>
        /// </param>
        /// <param name="dataArr">
        /// Get Setting Condition data.<br/>
        /// 設定条件データを取得<br/>
        /// </param>
        /// <param name="outputPath">
        /// Excel file output path.<br/>
        /// エクセルファイル出力パス<br/>
        /// </param>
        /// <param name="phySettingConMap">
        /// Get copy clause ID and copy clause name <br/>
        /// コピー句IDとコピー句名を取得<br/>
        /// </param>
        /// <exception cref="SettingConditionException">
        /// Throw exception if exception occurs.<br/>
        /// 例外が発生する場合、例外をスロー<br/>
        /// </exception>
        /// <remarks>
        /// 2018/05/22 新規作成<br/>
        /// </remarks>
        private void ExportToExcel(object[,] headerArr, object[,] dataArr, string outputPath, PhySettingConMappingModel phySettingConMap)
        {
            Excel.Application xlApp = null;
            Excel.Workbook xlWorkBook = null;
            Excel.Worksheet xlWorkSheet = null;
            Boolean isSheetExists = false;
            try
            {
                xlApp = new Excel.Application();
                xlApp.DisplayAlerts = false;
                xlApp.Visible = false;

                string templateFilePath = ConfigurationManager.AppSettings["settingconditionFileTemplateLocation"];

                //Check Template file exists or not
                //テンプレートファイルは存在するかチェック
                if (!File.Exists(templateFilePath))
                {
                    //Log for template file does not exist.
                    //テンプレートファイルは存在しない場合、ログに記録
                    LogUtils.WriteLogInfo(ver.User.USERID, LogUtils.GetMsgInfo(Resources.SCT00008_E, ConstantUtils.TEMPLATE_FILENAME), LogUtils.GetMsgType(ConstantUtils.SCT00008_E));

                    //Throw Error PLM00008-E
                    //PLM00008-E　エラーをスロー
                    throw new SettingConditionException(LogUtils.GetMsgInfo(Resources.SCT00008_E, ConstantUtils.TEMPLATE_FILENAME));
                }

                xlWorkBook = xlApp.Workbooks.Open(templateFilePath);

                //Check template sheet exists or not
                //テンプレートシートは存在するかチェック
                foreach (Excel.Worksheet sheet in xlWorkBook.Sheets)
                {
                    // Check the name of the current sheet
                    //現在のシートの名称をチェック
                    if (sheet.Name == ConstantUtils.SHEETNAME)
                    {
                        isSheetExists = true;
                        break;
                    }
                }

                if (!isSheetExists)
                {
                    //Log for template sheet doesn't exist
                    //テンプレートシートは存在しない場合、ログに記録
                    LogUtils.WriteLogInfo(ver.User.USERID, LogUtils.GetMsgInfo(Resources.SCT00009_E, ConstantUtils.SHEETNAME), LogUtils.GetMsgType(ConstantUtils.SCT00009_E));

                    //Throw Error PLM00009-E
                    //PLM00009-E　エラーをスロー
                    throw new SettingConditionException(LogUtils.GetMsgInfo(Resources.SCT00009_E, ConstantUtils.SHEETNAME));
                }

                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(ConstantUtils.SHEETNAME);

                //Set Name to sheet Name
                //名称をシート名に設定
                xlWorkSheet.Name = phySettingConMap.Cpyphy_bcpnm.Length < ConstantUtils.MAX_SHEETNAME_LENGTH ?
                                            phySettingConMap.Cpyphy_bcpnm : phySettingConMap.Cpyphy_bcpnm.Substring(0, ConstantUtils.MAX_SHEETNAME_LENGTH); ;

                xlWorkSheet.Range[ConstantUtils.SUBSYSID_CELLADD_2].Value = phySettingConMap.Cpyphy_subsysid;

                xlWorkSheet.Range[ConstantUtils.COPYCLAUSEID_CELLADD].Value = phySettingConMap.Cpyphy_bcpid;

                xlWorkSheet.Range[ConstantUtils.COPYCLAUSENAME_CELLADD].Value = phySettingConMap.Cpyphy_bcpnm;

                Excel.Range headerRng = xlWorkSheet.Range[xlWorkSheet.Cells[ConstantUtils.DATASTART_ROW_2, ConstantUtils.DATASTART_COL + 3], xlWorkSheet.Cells[ConstantUtils.DATASTART_ROW_2, headerArr.GetLength(1) + 3]];

                Excel.Range dataRng = xlWorkSheet.Range[xlWorkSheet.Cells[ConstantUtils.DATASTART_ROW_2 + 1, 1], xlWorkSheet.Cells[dataArr.GetLength(0) + ConstantUtils.DATASTART_ROW_2, dataArr.GetLength(1)]];

                xlWorkSheet.Range[ConstantUtils.LEVEL_CELLADD, ConstantUtils.LEVEL_COLUMNADD + (dataArr.GetLength(0) + ConstantUtils.DATASTART_ROW_2).ToString()].NumberFormat = "@";
                xlWorkSheet.Range[ConstantUtils.SAMPLE_CELLADD].Copy();
                headerRng.PasteSpecial(Excel.XlPasteType.xlPasteFormats);
                headerRng.UnMerge();

                headerRng.Value = headerArr;
                dataRng.Value = dataArr;

                xlWorkSheet.Range[headerRng, dataRng].Borders.get_Item(Excel.XlBordersIndex.xlInsideHorizontal).LineStyle = Excel.XlLineStyle.xlContinuous;
                xlWorkSheet.Range[headerRng, dataRng].Borders.get_Item(Excel.XlBordersIndex.xlInsideVertical).LineStyle = Excel.XlLineStyle.xlContinuous;
                xlWorkSheet.Range[headerRng, dataRng].BorderAround2(Excel.XlLineStyle.xlContinuous);

                xlWorkSheet.UsedRange.Style.Font.Name = ConstantUtils.FONTNAME;

                xlWorkSheet.Range[xlWorkSheet.Cells[ConstantUtils.DATASTART_ROW_2, ConstantUtils.DATASTART_COL + 3],
                                  xlWorkSheet.Cells[dataArr.GetLength(0) + ConstantUtils.DATASTART_ROW_2, headerArr.GetLength(1) + 3]]
                           .Columns
                           .AutoFit();

                //Set WrapText to ItemName Column
                //項目名列に「折り返して全体を表示する」に設定
                xlWorkSheet.Range[xlWorkSheet.Cells[ConstantUtils.DATASTART_ROW_2 + 1, ConstantUtils.DATASTART_COL + 2],
                                    xlWorkSheet.Cells[dataArr.GetLength(0) + ConstantUtils.DATASTART_ROW_2, ConstantUtils.DATASTART_COL + 2]]
                           .Cells.WrapText = true;

                xlWorkSheet.Range[headerRng, xlWorkSheet.Cells[dataArr.GetLength(0) + ConstantUtils.DATASTART_ROW_2, dataArr.GetLength(1)]].Cells.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

                string fileName = DateTime.Now.ToString(ConstantUtils.DATETIMEFORMAT) + "_" + ConstantUtils.OUTPUTFILENAME + "（" + phySettingConMap.Cpyphy_bcpnm + "）.xlsx";

                //Check end of output file path is path separator.
                //出力ファイルパスの終わりがパスセパレータかチェック
                if (!outputPath.EndsWith(Path.DirectorySeparatorChar.ToString()))
                {
                    outputPath += Path.DirectorySeparatorChar;
                }
                xlWorkSheet.Cells[1, 1].Select();
                xlWorkBook.SaveAs(outputPath + fileName);

                //Log for File Export is success
                //ファイルエクスポートは成功する時、ログに記録
                LogUtils.WriteLogInfo(ver.User.USERID, LogUtils.GetMsgInfo(Resources.SCT00002_I, fileName), LogUtils.GetMsgType(ConstantUtils.SCT00002_I));
            }
            catch (SettingConditionException e)
            {
                //Throw Error 
                //エラーをスロー
                throw new SettingConditionException(e.GetMessage());
            }
            catch (Exception e)
            {
                //log for File Export is failed
                //ファイルエクスポートは失敗する時、ログに記録
                LogUtils.WriteLogInfo(ver.User.USERID, LogUtils.GetMsgInfo(Resources.SCT00007_E, e.Message), LogUtils.GetMsgType(ConstantUtils.SCT00007_E), e);
                //Throw Error SCT00007-E
                //SCT00007-E　エラーをスロー
                throw new SettingConditionException(LogUtils.GetMsgInfo(Resources.SCT00007_E, e.Message), e);
            }
            finally
            {
                //Close Work book
                //ワークブックを閉じる
                if (xlWorkSheet != null)
                {
                    Marshal.ReleaseComObject(xlWorkSheet);
                }

                if (xlWorkBook != null)
                {
                    xlWorkBook.Close(Type.Missing, Type.Missing, Type.Missing);
                    Marshal.ReleaseComObject(xlWorkBook);
                }

                if (xlApp != null)
                {
                    xlApp.Quit();
                    Marshal.ReleaseComObject(xlApp);
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }

        #endregion
    }
}
