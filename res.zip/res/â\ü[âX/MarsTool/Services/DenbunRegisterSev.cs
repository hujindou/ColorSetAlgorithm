﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MarsTool.Models;
using MySql.Data.MySqlClient;
using MarsTool.Common;
using MarsTool.Daos;
using MarsTool.Common.Forms;
using MarsTool.Properties;
using System.Text.RegularExpressions;
using static MarsTool.Common.CommonConstant;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;
using MarsTool.Exceptions;

namespace MarsTool.Services
{
    class DenbunRegisterSev
    {
        private NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        //DenbunRegisterSevのインスタンスを指定
        private static DenbunRegisterSev instance;

        private VersionModel version;

        public DenbunRegisterSev(VersionModel v)
        {
            version = v;
        }

        public static DenbunRegisterSev getInstance(VersionModel v)
        {
            if (instance == null)
            {
                instance = new DenbunRegisterSev(v);
            }
            return instance;
        }

        public void PhyDenbunInfoRegisterProcess(string inputFilePath)
        {
            string subSystemID = null;
            string itemNo = null;
            string phyID = null;
            string turn = null;
            bool phyIdEmptyFlg = false;
            int existCnt = 0;
            string comment = null;
            string infoGroupID = null;
            int patternOrder = 0;
            //エクセルのオブジェクトを作成
            Excel.Application xlApp = new Excel.Application();
            Excel.Workbook xlWorkbook = null;
            Excel._Worksheet physicalInfoSheet = null;
            Object[,] dataArr = null;
            try
            {
                int idCnt = 0;

                //入力ファイルのオープン
                xlWorkbook = xlApp.Workbooks.Open(inputFilePath);

                // 各シートをループする
                for (int shCnt = 1; shCnt <= xlWorkbook.Sheets.Count; shCnt++)
                {
                    subSystemID = null;
                    itemNo = null;
                    phyID = null;
                    turn = null;
                    comment = null;
                    infoGroupID = null;
                    dataArr = null;
                    patternOrder = 0;

                    List<PhyDenbunInfo> physicalInfoList = new List<PhyDenbunInfo>();
                    //物理情報シートの取得
                    physicalInfoSheet = xlWorkbook.Sheets[shCnt];

                    //物理情報データの取得
                    dataArr = GetDataFromExcelFile(physicalInfoSheet);

                    //物理情報シート用フォーマットチェック
                    if (dataArr[1, 1] == null || dataArr[4, 1] == null ||
                        dataArr[7, 1] == null || dataArr[7, 2] == null || dataArr[7, 3] == null ||
                        dataArr[7, 4] == null || dataArr[7, 5] == null || dataArr[7, 6] == null || dataArr[7, 7] == null)
                    {
                        // シートフォーマットエラー
                        logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00003_E, physicalInfoSheet.Name));
                        continue;
                    }
                    else
                    {
                      if (!PHYSICAL_SH_TITLE.Equals(dataArr[1, 1]) || !dataArr[4, 1].ToString().Contains(SUB_SYS_ID) ||
                        !NO.Equals(dataArr[7, 1]) || !COMMENT.Equals(dataArr[7, 2]) || !dataArr[7, 3].ToString().Contains(TEL_SUBSYS_ID) ||
                        !dataArr[7, 4].ToString().Contains(REQUEST_CLS) || !dataArr[7, 5].ToString().Contains(PATTERN_NO) ||
                        !dataArr[7, 6].ToString().Contains(INFOGROUP_ID) || !dataArr[7, 7].ToString().Contains(PHYSICALID))
                        {
                            // シートフォーマットエラー
                            logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00003_E, physicalInfoSheet.Name));
                            continue;
                        }
                    }

                    //各入力項目のチェック
                    //物理用サブシステムIDの必須をチェック
                    if (dataArr[4, 4] == null)
                    {
                        //サブシステム名の必須エラー
                        logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00004_E, SUBSYSID, physicalInfoSheet.Name, string.Empty));
                        continue;
                    }
                    else
                    {
                        subSystemID = dataArr[4, 4].ToString();

                        // サブシステムＩＤの最大チェック
                        if (subSystemID.Length > SUBSYSID_LEN)
                        {
                            logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00021_E, SUBSYSID, SUBSYSID_LEN, physicalInfoSheet.Name, string.Empty));
                            continue;
                        }
                        // サブシステムＩＤの半角チェック
                        if (!HankakuCheck(subSystemID))
                        {
                            logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00005_E, physicalInfoSheet.Name, "、項目名：" + SUBSYSID));
                            continue;
                        }
                        
                        // 各行のループ
                        for (int r = 8; r <= dataArr.GetLength(0); r++)
                        {
                            itemNo = null;
                            phyID = null;
                            turn = null;
                            comment = null;
                            infoGroupID = null;
                            patternOrder++;

                            // 最後の行数のチェック
                            if (dataArr[r, 1] != null && dataArr[r, 3] == null && dataArr[r, 4] == null && dataArr[r, 5] == null)
                            {
                                break;
                            }

                            if (dataArr[r, 1] != null)
                            {
                                itemNo = dataArr[r, 1].ToString();
                            }
                            else
                            {
                                itemNo = "";
                            }

                            // 物理電文構成パターンの必須項目チェック
                            bool requiredFlg = this.ItemRequiredCheck(dataArr, r, physicalInfoSheet.Name, itemNo);

                            // 必須エラーが発生した場合、ログファイルに警告メッセージを出力し、該当シートをスキップして次のシートを読み込む
                            if (!requiredFlg)
                            {
                                physicalInfoList = null;
                                break;
                            }

                            // 物理電文構成パターン項目のデータチェック
                            bool dataFlg = this.ItemDataCheck(dataArr, r, physicalInfoSheet.Name, itemNo);

                            // データチェックにエラーが発生した場合、ログファイルに警告メッセージを出力し、該当シートをスキップして次のシートを読み込む
                            if (!dataFlg)
                            {
                                physicalInfoList = null;
                                break;
                            }

                            // 物理電文構成パターンの正常値を取得

                            //コメントの取得
                            if (dataArr[r, COMMENT_COL] != null)
                            {
                                comment = dataArr[r, COMMENT_COL].ToString();
                            }

                            //相手サブシステムＩＤの取得
                            string telSubsysID = dataArr[r, TELSUBSYSID_COL].ToString();

                            //要求応答区分の取得
                            string telType = dataArr[r, TELTYPE_COL].ToString();

                            //ＩＦパターン番号の取得
                            string patNo = dataArr[r, PATNO_COL].ToString();

                            //情報部グループＩＤの取得
                            if (dataArr[r, GROUPID_COL] != null)
                            {
                                infoGroupID = dataArr[r, GROUPID_COL].ToString();
                            }

                            // 物理電文構成パターンがＤＢに既にあるかチェック
                            existCnt = DenbunDBConnectivity.getInstance(version).SelectPhysicalInfoCntByPK(subSystemID, telSubsysID, telType, patNo);

                            if (existCnt != 0)
                            {
                                //警告情報を出力する
                                logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00012_E, physicalInfoSheet.Name, itemNo));
                                physicalInfoList = null;
                                // 当該シートをスキップし、次のシートを読み込む
                                break;
                            }

                            List<PhyDenbunItmInfo> itemInfos = new List<PhyDenbunItmInfo>();
                            idCnt = 0;
                            phyIdEmptyFlg = true;
                            //物理IDの件数をループして、データチェック
                            for (int c = 7; c <= dataArr.GetLength(1); c++)
                            {
                                idCnt++;

                                if (dataArr[7, c] != null)
                                {

                                    // タイトル「物理ＩＤ(ｎ)」がある列まで物理ＩＤを取得
                                    if (dataArr[7, c].ToString().Contains(PHYSICALID) && !(dataArr[r, c] == null))
                                    {
                                        phyIdEmptyFlg = false;

                                        PhyDenbunItmInfo itemInfo = new PhyDenbunItmInfo();

                                        // 物理IDが予備の場合
                                        if (this.YOBIFormatCheck(dataArr[r, c].ToString()))
                                        {
                                            itemInfo.phyID = string.Empty;
                                            int startIdx = dataArr[r, c].ToString().IndexOf("(");
                                            int endIdx = dataArr[r, c].ToString().IndexOf(")");

                                            string yobiSize = dataArr[r, c].ToString().Substring(startIdx + 1, (endIdx - (startIdx + 1)));
                                            if (string.IsNullOrEmpty(yobiSize))
                                            {
                                                logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00008_E, physicalInfoSheet.Name, itemNo, dataArr[7, c].ToString()));
                                                itemInfos = null;
                                                break;
                                            }
                                            if (!Utils.IsNum(yobiSize))
                                            {
                                                logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00023_E, physicalInfoSheet.Name, itemNo, dataArr[7, c].ToString()));
                                                itemInfos = null;
                                                break;
                                            }
                                            // 予備サイズの取得
                                            itemInfo.yobiSize = int.Parse(yobiSize);
                                            // 物理IDが予備の場合は「2」を設定
                                            itemInfo.type = "2";
                                        }
                                        else
                                        {
                                            // 物理ＩＤに繰り返し回数がある場合
                                            if (this.PHYID_TURNFormatCheck(dataArr[r, c].ToString()))
                                            {
                                                int startIdx = dataArr[r, c].ToString().IndexOf("{");
                                                int endIdx = dataArr[r, c].ToString().IndexOf("}");
                                                int starPos = dataArr[r, c].ToString().IndexOf("*");

                                                phyID = dataArr[r, c].ToString().Substring(startIdx + 1, (endIdx - (startIdx + 1)));
                                                turn = dataArr[r, c].ToString().Substring(starPos + 1, (dataArr[r, c].ToString().Length - (starPos + 1)));

                                                if (string.IsNullOrEmpty(phyID))
                                                {
                                                    logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00010_E, physicalInfoSheet.Name, itemNo, dataArr[7, c].ToString()));
                                                    itemInfos = null;
                                                    break;
                                                }
                                                if (string.IsNullOrEmpty(turn))
                                                {
                                                    logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00009_E, physicalInfoSheet.Name, itemNo, dataArr[7, c].ToString()));
                                                    itemInfos = null;
                                                    break;
                                                }
                                                if (!Utils.IsNum(turn))
                                                {
                                                    logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00024_E, physicalInfoSheet.Name, itemNo, dataArr[7, c].ToString()));
                                                    itemInfos = null;
                                                    break;
                                                }
                                                //物理IDの最大チェック
                                                if (phyID.Length > PHYID_LEN)
                                                {
                                                    logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00021_E, PHYSICALID, PHYID_LEN, physicalInfoSheet.Name, NO_STR + itemNo + "、項目名：" + dataArr[7, c].ToString()));
                                                    itemInfos = null;
                                                    break;
                                                }

                                                //物理IDの半角チェック
                                                if (!this.HankakuCheck(phyID))
                                                {
                                                    //物理IDが半角ではない場合
                                                    logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00005_E, physicalInfoSheet.Name, NO_STR + itemNo + "、項目名：" + dataArr[7, c].ToString()));
                                                    itemInfos = null;
                                                    break;
                                                }
                                                // 物理ＩＤの取得
                                                itemInfo.phyID = phyID;
                                                // 繰り返し回数の取得
                                                itemInfo.turn = int.Parse(turn);

                                            }
                                            else
                                            {
                                                //物理IDの最大チェック
                                                if (dataArr[r, c].ToString().Length > PHYID_LEN)
                                                {
                                                    logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00021_E, PHYSICALID, PHYID_LEN, physicalInfoSheet.Name, NO_STR + itemNo + "、項目名：" + dataArr[7, c].ToString()));
                                                    itemInfos = null;
                                                    break;
                                                }

                                                //物理IDの半角チェック
                                                if (!this.HankakuCheck(dataArr[r, c].ToString()))
                                                {
                                                    //物理IDが半角ではない場合
                                                    logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00005_E, physicalInfoSheet.Name, NO_STR + itemNo + "、項目名：" + dataArr[7, c].ToString()));
                                                    itemInfos = null;
                                                    break;
                                                }
                                                // 物理ＩＤの取得
                                                itemInfo.phyID = dataArr[r, c].ToString();
                                                // 繰り返し回数が無い場合、「1」を設定
                                                itemInfo.turn = 1;
                                            }
                                            // 物理IDが予備以外の場合は「0」を設定
                                            itemInfo.yobiSize = 0;
                                            // 物理IDが予備以外の場合は「1」を設定
                                            itemInfo.type = "1";

                                            existCnt = DenbunDBConnectivity.getInstance(version).SelectPhysicalInfoCntByPhyID(subSystemID, itemInfo.phyID);
                                            if (existCnt == 0)
                                            {
                                                logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00011_E, physicalInfoSheet.Name, itemNo, dataArr[7, c].ToString()));
                                                itemInfos = null;
                                                break;
                                            }
                                        }

                                        // 順序を設定
                                        itemInfo.order = idCnt;
                                        itemInfos.Add(itemInfo);

                                    }
                                    else
                                    {
                                        // タイトル「物理ＩＤ(ｎ)」があり、物理ＩＤが空白の場合、ループから抜ける
                                        break;
                                    }
                                }
                                else
                                {
                                    // タイトル「物理ＩＤ(ｎ)」が無いし、物理ＩＤが空白の場合、ループから抜ける
                                    break;
                                }
                            }

                            //物理情報データの取得
                            if (itemInfos != null && !phyIdEmptyFlg)
                            {
                                int dbOutputOrder = DenbunDBConnectivity.getInstance(version).SelectOutputOrderBySysID(subSystemID);

                                PhyDenbunInfo physicalInfo = new PhyDenbunInfo();

                                // サブシステムＩＤの設定
                                physicalInfo.subSysID = subSystemID;
                                // コメントの設定
                                physicalInfo.comment = comment;
                                // 相手サブシステムＩＤの設定
                                physicalInfo.telSubSysID = telSubsysID;
                                // 要求応答区分の設定
                                physicalInfo.telType = telType;
                                // ＩＦパターン番号の設定
                                physicalInfo.patNo = patNo;
                                // 情報部グループＩＤの設定
                                physicalInfo.groupID = infoGroupID;
                                // 項番の設定
                                physicalInfo.order = patternOrder + dbOutputOrder;
                                // ユーザＩＤの設定
                                physicalInfo.userID = version.User.USERID;
                                // 物理ＩＤの設定
                                physicalInfo.itemInfos = itemInfos;

                                // 一行ずつの物理情報データを取得
                                physicalInfoList.Add(physicalInfo);
                            }
                            else
                            {
                                if (phyIdEmptyFlg)
                                {
                                    logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00013_E, physicalInfoSheet.Name, itemNo));
                                }
                                physicalInfoList = null;
                                break;
                            }
                        }
                    }

                    //シートごとの物理情報の登録
                    if (physicalInfoList != null)
                    {
                        DenbunDBConnectivity.getInstance(version).InsertPhysicalInfos(physicalInfoList);
                        logger.Info(version.User.USERID + SPACE + String.Format(Resources.DEN00019_I, physicalInfoSheet.Name));
                    }
                }

                return;
            }
            catch (DenbunRegException denbunEx)
            {
                if (denbunEx.GetMessage().Equals(Resources.DEN00026_E))
                {
                    // 物理電文構成パターンの登録にエラーが発生しました。
                    throw new DenbunRegException(Resources.DEN00015_E);
                }
                else
                {
                    // データベースにアクセスできません。
                    throw new DenbunRegException(Resources.DEN00014_E);
                }
            }
            catch (System.Exception sysEx)
            {
                if(dataArr == null)
                {
                    //ファイル読み込みエラー
                    logger.Error(version.User.USERID + SPACE + String.Format(Resources.DEN00022_E, sysEx));
                    throw new DenbunRegException(String.Format(Resources.DEN00022_E, ERR_MSG));
                }
                else
                {
                    // 予想外エラー
                    logger.Error(version.User.USERID + SPACE + String.Format(Resources.DEN00025_E, sysEx));
                    throw new DenbunRegException(Resources.DEN00016_E);
                }
            }
            finally
            {
                //必ず実行させる処理をfinallyに記述する
                //　ＧＣのＣｏｌｌｅｃｔ
                GC.Collect();
                GC.WaitForPendingFinalizers();
                if(physicalInfoSheet != null)
                {
                    //ＣＯＭオブジェクトの解放
                    Marshal.ReleaseComObject(physicalInfoSheet);
                }
                if(xlWorkbook != null)
                {
                    //エクセルワークブックのクロス・解放
                    xlWorkbook.Close();
                    Marshal.ReleaseComObject(xlWorkbook);
                }
                //エクセルアプリケーションの終了・解放
                xlApp.Quit();
                Marshal.ReleaseComObject(xlApp);


            }
            
        }

        /// <summary>
        /// 数値をExcelのカラム名的なアルファベット文字列へ変換します。
        /// </summary>
        /// <param name="num"></param>
        /// <returns>
        /// Excelのカラム名的なアルファベット文字列。
        /// (変換できない場合は、空文字を返します。)
        /// </returns>
        private string GetColumnName(int num)
        {
            if (num < 1) return string.Empty;

            string strCol = string.Empty;
            do
            {
                strCol = (char)((num - 1) % 26 + 'A') + strCol;
                num = (num - 1) / 26;
            } while (num > 0);

            return strCol;
        }

        /// <summary>
        /// EXCELのデータを範囲で取得
        /// </summary>
        /// <param name="ws"></param>
        /// <returns>
        /// EXCELデータの二次元配列。
        /// </returns>
        private Object[,] GetDataFromExcelFile(Excel._Worksheet ws)
        {
            int usedRows = 0;
            int usedCols = 0;
            string colNm = null;

            //入力シートの行数と列数を取得
            usedRows = ws.Cells.Find("*", System.Reflection.Missing.Value,
                       System.Reflection.Missing.Value, System.Reflection.Missing.Value, Excel.XlSearchOrder.xlByRows,
                       Excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Row;

            usedCols = ws.Cells.Find("*", System.Reflection.Missing.Value,
                       System.Reflection.Missing.Value, System.Reflection.Missing.Value, Excel.XlSearchOrder.xlByColumns,
                       Excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Column;

            colNm = GetColumnName(usedCols);

            //入力シートの受け取るデータの個数分（行、列セル数を指定）
            Object[,] dataArr = new Object[usedRows, usedCols];

            //セルデータを二次元配列にセットする
            dataArr = ws.get_Range("A1", colNm + usedRows).Value;

            return dataArr;
        }

        /// <summary>
        /// 項目の必須チェック
        /// </summary>
        /// <param name="dataArr"></param>
        /// <param name="row"></param>
        /// <param name="sheetNm"></param>
        /// <returns>
        /// true又はfalse
        /// </returns>
        private bool ItemRequiredCheck(Object[,] dataArr, int row, string sheetNm, string itemNo)
        {
            //相手サブシステムＩＤの必須チェック
            if (dataArr[row, TELSUBSYSID_COL] == null)
            {
                //相手サブシステムＩＤの必須エラー
                logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00004_E, TEL_SUBSYS_ID, sheetNm, NO_STR + itemNo));
                return false;
            }
            //要求応答区分の必須チェック
            if (dataArr[row, TELTYPE_COL] == null)
            {
                //要求応答区分の必須エラー
                logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00004_E, REQUEST_CLS, sheetNm, NO_STR + itemNo));
                return false;
            }
            //ＩＦパターン番号の必須チェック
            if (dataArr[row, PATNO_COL] == null)
            {
                //ＩＦパターン番号の必須エラー
                logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00004_E, PATTERN_NO, sheetNm, NO_STR + itemNo));
                return false;
            }
            return true;
        }

        /// <summary>
        /// 項目のデータチェック
        /// </summary>
        /// <param name="dataArr"></param>
        /// <param name="row"></param>
        /// <param name="sheetNm"></param>
        /// <returns>
        /// true又はfalse
        /// </returns>
        private bool ItemDataCheck(Object[,] dataArr, int row, string sheetNm, string itemNo)
        {
            //コメントの最大チェック
            if (dataArr[row, COMMENT_COL] != null)
            {
                if (dataArr[row, COMMENT_COL].ToString().Length > COMMENT_LEN)
                {
                    //コメントの最大エラー
                    logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00021_E, COMMENT, COMMENT_LEN, sheetNm, NO_STR + itemNo));
                    return false;
                }
            }

            //相手サブシステムＩＤの最大チェック
            if (dataArr[row, TELSUBSYSID_COL].ToString().Length > TELSUBSYSID_LEN)
            {
                //相手サブシステムＩＤの最大エラー
                logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00021_E, TEL_SUBSYS_ID, TELSUBSYSID_LEN, sheetNm, NO_STR + itemNo));
                return false;
            }
            if (!HankakuCheck(dataArr[row, TELSUBSYSID_COL].ToString()))
            {
                //相手サブシステムＩＤの半角エラー
                logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00005_E, sheetNm, NO_STR + itemNo + "、項目名：" + TEL_SUBSYS_ID));
                return false;
            }

            //要求応答区分の最大チェック
            if (dataArr[row, TELTYPE_COL].ToString().Length > TELTYPE_LEN)
            {
                //要求応答区分の最大エラー
                logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00021_E, REQUEST_CLS, TELTYPE_LEN, sheetNm, NO_STR + itemNo));
                return false;
            }
            if (!HankakuCheck(dataArr[row, TELTYPE_COL].ToString()))
            {
                //要求応答区分の半角エラー
                logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00005_E, sheetNm, NO_STR + itemNo + "、項目名：" + REQUEST_CLS));
                return false;
            }
            //要求応答区分のデータのチェック
            if (!dataArr[row, TELTYPE_COL].ToString().Equals("E") && !dataArr[row, TELTYPE_COL].ToString().Equals("R"))
            {
                //要求応答区分が「Ｅ」又は「Ｒ」ではない場合
                logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00006_E, sheetNm, NO_STR + itemNo));
                return false;
            }

            //ＩＦパターン番号の最大チェック
            if (dataArr[row, PATNO_COL].ToString().Length > PATNO_LEN)
            {
                //ＩＦパターン番号の最大エラー
                logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00021_E, PATTERN_NO, PATNO_LEN, sheetNm, NO_STR + itemNo));
                return false;
            }
            if (!HankakuCheck(dataArr[row, PATNO_COL].ToString()))
            {
                //ＩＦパターン番号の半角エラー
                logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00005_E, sheetNm, NO_STR + itemNo + "、項目名：" + PATTERN_NO));
                return false;
            }
            //ＩＦパターン番号の数字チェック
            if (!Utils.IsNum(dataArr[row, PATNO_COL].ToString()))
            {
                //ＩＦパターン番号の最大エラー
                logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00007_E, sheetNm, NO_STR + itemNo));
                return false;
            }

            //情報部グループＩＤの最大チェック
            if (dataArr[row, GROUPID_COL] != null)
            {
                if (dataArr[row, GROUPID_COL].ToString().Length > GROUPID_LEN)
                {
                    //情報部グループＩＤの最大エラー
                    logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00021_E, INFOGROUP_ID, GROUPID_LEN, sheetNm, NO_STR + itemNo));
                    return false;
                }
                if (!HankakuCheck(dataArr[row, GROUPID_COL].ToString()))
                {
                    //情報部グループＩＤの半角エラー
                    logger.Warn(version.User.USERID + SPACE + String.Format(Resources.DEN00005_E, sheetNm, NO_STR + itemNo + "、項目名：" + INFOGROUP_ID));
                    return false;
                }

            }

            return true;
        }

        private bool HankakuCheck(string phyID)
        {
            return Regex.IsMatch(phyID, "^[a-zA-Z0-9!-/*:-@¥[-`{-~]+$");
        }

        private bool YOBIFormatCheck(string phyID)
        {
            return Regex.IsMatch(phyID, "YOBI(.+)");
        }

        private bool PHYID_TURNFormatCheck(string phyID)
        {
            return Regex.IsMatch(phyID, "{(.+)}*(.+)");
        }

    }
}
