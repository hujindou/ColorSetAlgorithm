﻿using MarsTool.Models;
using MarsTool.Models.DB;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarsTool
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private VersionModel version;

        public MainForm(VersionModel vermodel) : this()
        {
            version = vermodel;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            RDataForm m = Application.OpenForms["RDataForm"] as RDataForm;
            if (m == null)
            {
                m = new RDataForm(version);
                m.Show();
            }
            else
                m.BringToFront();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            KohoForm m = Application.OpenForms["KohoForm"] as KohoForm;
            if (m == null)
            {
                m = new KohoForm(version);
                m.Show();
            }
            else
                m.BringToFront();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            FileLoadForm f = Application.OpenForms["FileLoadForm"] as FileLoadForm;
            if (f == null)
            {
                f = new FileLoadForm(version);
                f.Show();
            }
            else
                f.BringToFront();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SearchForm m = Application.OpenForms["SearchForm"] as SearchForm;
            if (m == null)
            {
                m = new SearchForm(version);
                m.Show();
            }
            else
                m.BringToFront();
        }

        private void Form5_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Owner.Dispose();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            MarsTool.PasswordChange pc = new MarsTool.PasswordChange(version);
            pc.ShowDialog(this);
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.luser.Text = version.User.USERNAME;
            this.lver.Text = version.Vername;
            this.label1.Select();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // 物理パターン管理機能画面の表示(20180508)

            TelForm m = Application.OpenForms["TelForm"] as TelForm;
            if (m == null)
            {
                m = new TelForm(version);
                m.Show();
            }
            else
                m.BringToFront();
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            base.OnClosing(e);
            logger.Info($"{version.User.USERID} ログアウト");
            version.context.Dispose();
        }

        /// <summary>
        /// ログアウト
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button7_Click(object sender, EventArgs e)
        {
            List<Form> tmplst = new List<Form>();
            foreach (var tmp in Application.OpenForms)
            {
                var cvt = tmp as Form;
                if (cvt != null && cvt.Name != "Login" && cvt.Name != "MainForm")
                {
                    tmplst.Add(cvt);
                }
            }
            foreach (var tmp in tmplst)
            {
                tmp.Dispose();
            }

            logger.Info($"{version.User.USERID} ログアウト");

            this.Owner.Show();
            this.Dispose();
        }
        private NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();
        private void MainForm_Activated(object sender, EventArgs e)
        {
            this.BringToFront();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // インタフェース管理機能画面の表示
            Interface f = Application.OpenForms["Interface"] as Interface;
            if (f == null)
            {
                f = new Interface(version);
                f.Show();
            }
            else
                f.BringToFront();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MappingParser f = Application.OpenForms["MappingParser"] as MappingParser;
            if(f == null)
            {
                f = new MappingParser(version);
                f.Show();
            }
            else
            {
                f.BringToFront();
            }
        }
    }
}
