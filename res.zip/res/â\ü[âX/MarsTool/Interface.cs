﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MarsTool.Common.Forms;
using System.IO;
using MarsTool.Common;
using MarsTool.Services;
using MarsTool.Exceptions;
using MarsTool.Properties;
using MarsTool.Models;
using System.Text.RegularExpressions;
using MarsTool.Models.DB;

namespace MarsTool
{
    public partial class Interface : Form
    {
        private NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        private int displayCnt = 0;  

        public Interface()
        {
            InitializeComponent();

            #region 編集画面の初期化
            this.noSave = true;
            //グループセルの設定
            GroupDataGridView.GroupCell itemCell = new GroupDataGridView.GroupCell
            {
                Text = "アイテム情報",
                Start = 0,
                Count = 10,
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center,
                Tag = "ItemInfo"
            };
            dgvEditItemEditor.GroupCells.Add(itemCell);
            GroupDataGridView.GroupCell copyCell = new GroupDataGridView.GroupCell
            {
                Text = "コピー句情報",
                Start = 10,
                Count = 2,
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center,
                Tag = "CopyInfo"
            };
            dgvEditItemEditor.GroupCells.Add(copyCell);
            GroupDataGridView.GroupCell requirementCell = new GroupDataGridView.GroupCell
            {
                Text = "設定条件",
                Start = 12,
                Count = 1,
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center,
                BackColor = SystemColors.GradientInactiveCaption,
                Tag = "Condition"
            };
            dgvEditItemEditor.GroupCells.Add(requirementCell);
            GroupDataGridView.GroupCell logicifCell = new GroupDataGridView.GroupCell
            {
                Text = "論理インタフェース",
                Start = 13,
                Count = 13,
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center,
                Tag = "LogicIf"
            };
            GroupDataGridView.GroupCell subsysCell = new GroupDataGridView.GroupCell
            {
                Text = "サブシステム",
                Start = 0,
                Count = 13,
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center,
                Tag = "Subsystem"
            };
            GroupDataGridView.GroupCell parserCell = new GroupDataGridView.GroupCell
            {
                Text = "Ｍパーサ物理情報",
                Start = 0,
                Count = 6,
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center,
                Tag = "MPaser"
            };
            GroupDataGridView.GroupCell LayoutCell = new GroupDataGridView.GroupCell
            {
                Text = "レイアウト定義",
                Start = 0,
                Count = 6,
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center,
                Tag = "Layout"
            };
            parserCell.ChildCells.Add(LayoutCell);
            GroupDataGridView.GroupCell logicCell = new GroupDataGridView.GroupCell
            {
                Text = "論理条件",
                Start = 6,
                Count = 7,
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center,
                BackColor = SystemColors.GradientActiveCaption,
                Tag = "LogicCondition"
            };
            GroupDataGridView.GroupCell varCell = new GroupDataGridView.GroupCell
            {
                Text = string.Empty,
                Start = 0,
                Count = 7,
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center
            };
            logicCell.ChildCells.Add(varCell);
            subsysCell.ChildCells.Add(parserCell);
            subsysCell.ChildCells.Add(logicCell);
            logicifCell.ChildCells.Add(subsysCell);
            dgvEditItemEditor.GroupCells.Add(logicifCell);
            
            //可変コラムの設定
            GroupDataGridView.VariableIndex requireIndex = new GroupDataGridView.VariableIndex  // 設定条件
            {
                Index = 12,
                Count = 1,
                Tag = Resources.IF_TAG_REQUIREMENT
            };
            GroupDataGridView.VariableIndex parserIndex = new GroupDataGridView.VariableIndex   // 論理インタフェース開始位置
            {
                Index = 13,
                Count = 0,
                Tag = Resources.IF_TAG_PARSER
            };
            GroupDataGridView.VariableIndex layoutIndex = new GroupDataGridView.VariableIndex   // 論理条件
            {
                Index = 19,
                Count = 7,
                Tag = Resources.IF_TAG_LOGICLAYOUT
            };
            dgvEditItemEditor.VariableIndexs.Add(requireIndex);
            dgvEditItemEditor.VariableIndexs.Add(parserIndex);
            dgvEditItemEditor.VariableIndexs.Add(layoutIndex);

            //属性辞書（データ属性：Ｍパーサ物理属性）の作成
            dicPhysicType = Common.IntefaceCommon.getDicPhysicType();

            //属性辞書（Ｍパーサ物理属性：Ｍパーサ論理属性）の作成
            dicPerserType = Common.IntefaceCommon.getDicParseType();

            //可変コラムの制御を行う
            variableColumnCtrlForRequirement = new VariableColumnCtrl(this.dgvEditItemEditor,
                                                                this.btnEditRequirementAdd,
                                                                this.btnEditRequirementDel,
                                                                this.btnEditRequirementRename,
                                                                this.lstEditRequirement,
                                                                this.txtEditRequirement,
                                                                string.Empty,
                                                                null,
                                                                Resources.IF_TAG_REQUIREMENT,
                                                                -1,
                                                                1);

            variableColumnCtrlForRequirement.AddItem += VariableColumnCtrlForRequirement_Action;
            variableColumnCtrlForRequirement.RenameItem += VariableColumnCtrlForRequirement_Action;
            variableColumnCtrlForRequirement.DeleteItem += VariableColumnCtrlForRequirement_Action;
            variableColumnCtrlForRequirement.BeforeChangeList += VariableColumnCtrl_BeforeChangeList;
            variableColumnCtrlForRequirement.ChangeList += VariableColumnCtrl_ChangeList;

            List<VariableColumnCtrl.InputInterface> iis = new List<VariableColumnCtrl.InputInterface>();
            VariableColumnCtrl.InputInterface ii = new VariableColumnCtrl.InputInterface
            {
                TextBox = this.txtEditLogicifCopyId,
                Index = 0,
                Level = 3
            };
            iis.Add(ii);
            variableColumnCtrlForLogic = new VariableColumnCtrl(this.dgvEditItemEditor,
                                                                this.btnEditLogicifAdd,
                                                                this.btnEditLogicifDel,
                                                                this.btnEditLogicifRename,
                                                                this.lstEditLogicif,
                                                                this.txtEditLogicifName,
                                                                "論理条件",
                                                                iis,
                                                                Resources.IF_TAG_LOGICLAYOUT,
                                                                2,
                                                                7);
            variableColumnCtrlForLogic.AddItem += VariableColumnCtrlForLogic_Action;
            variableColumnCtrlForLogic.RenameItem += VariableColumnCtrlForLogic_Action;
            variableColumnCtrlForLogic.DeleteItem += VariableColumnCtrlForLogic_Action;
            variableColumnCtrlForLogic.BeforeChangeList += VariableColumnCtrl_BeforeChangeList;
            variableColumnCtrlForLogic.ChangeList += VariableColumnCtrl_ChangeList;

            //念のため、再描画を行う
            dgvEditItemEditor.Refresh();
            //プレビュー画面の設定
            SheetPreview = new SheetShowPreview(this.cvsSheet, SheetShowPreview.PreviewType.ItemSheet);
            StructPreview = new SheetShowPreview(this.cvsPicture, SheetShowPreview.PreviewType.ItemStructImage);
            #endregion
        }

        private void VariableColumnCtrlForRequirement_Action(object sender, VariableColumnCtrl.VariableColumnCtrlEvent e)
        {
            ModeChange(MODE.Edit);
        }

        /// <summary>
        /// リストが変更された時の処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void VariableColumnCtrl_ChangeList(object sender, VariableColumnCtrl.VariableColumnCtrlEvent e)
        {
            if(sender == variableColumnCtrlForRequirement)
            {
                //論理設定条件が変更された時
            }
            else
            {
                //論理インタフェースが変更された時
                InterfaceEdit interfaceEdit = new InterfaceEdit(this.version, dgvEditItemEditor, string.Empty, this.EditSubsystem);
                List <T_CPYLOG > list = interfaceEdit.getCPYLOGfromDataGridView();
                int Index = dgvEditItemEditor.GetIndexVariableColumn(Resources.IF_TAG_LOGICLAYOUT);
                if(e.SourceIndex == -1) // 追加
                {
                    T_CPYLOG cpylog = new T_CPYLOG
                    {
                        CPYLGC_PHYSYSID = this.CPYPHY.CPYPHY_SUBSYSID,
                        CPYLGC_INFOID = this.CPYPHY.CPYPHY_INFOID,
                        CPYLGC_OUTPUTORDER = e.Index,
                        CPYLGC_SUBSYSID = this.EditSubsystem,
                        CPYLGC_COMMENT = string.Empty,
                        CPYLGC_USERID = string.Empty,
                        CPYLGC_OPNM = dgvEditItemEditor.GetGroupCellText(Index + (7 * e.Index), 2),
                        CPYLGC_LCPID = dgvEditItemEditor.GetGroupCellText(Index + (7 * e.Index), 3)
                    };
                    list.Insert(e.Index, cpylog);
                    interfaceEdit.setCPYLOGtoDataGridView(list);
                }
                else if(e.Index == -1)  // 削除
                {
                    list.RemoveAt(e.SourceIndex);
                    interfaceEdit.setCPYLOGtoDataGridView(list);
                }
                else                    // 更新、順序変更
                {
                    //並び替え
                    List<T_CPYLOG> newlist = new List<T_CPYLOG>();
                    for(int i = 0; i < lstEditLogicif.Items.Count; i ++)
                    {
                        T_CPYLOG cpylog = null;
                        for(int j = 0; j < list.Count; j ++)
                        {
                            if(lstEditLogicif.Items[i] as string == list[j].CPYLGC_OPNM)
                            {
                                cpylog = list[j];
                                cpylog.CPYLGC_LCPID = dgvEditItemEditor.GetGroupCellText(Index + (7 * i), 3);
                                break;
                            }
                        }
                        if(cpylog != null)
                        {
                            cpylog.CPYLGC_OUTPUTORDER = i;
                            newlist.Add(cpylog);
                        }
                        else
                        {
                            //名称が変更された場合（位置は同じ）
                            cpylog = list[i];
                            cpylog.CPYLGC_OPNM = dgvEditItemEditor.GetGroupCellText(Index + (7 * i), 2);
                            cpylog.CPYLGC_LCPID = dgvEditItemEditor.GetGroupCellText(Index + (7 * i), 3);
                            newlist.Add(cpylog);
                        }
                    }
                    interfaceEdit.setCPYLOGtoDataGridView(newlist);
                }
            }
            //履歴取得の抑止を解除
            this.noSave = false;
            //更新を有効にする
            ModeChange(MODE.Edit);
        }

        /// <summary>
        /// リストが変更される直前の処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void VariableColumnCtrl_BeforeChangeList(object sender, VariableColumnCtrl.VariableColumnCtrlEvent e)
        {
            //履歴の取得を抑止する
            this.noSave = true;
        }

        private void VariableColumnCtrlForLogic_Action(object sender, VariableColumnCtrl.VariableColumnCtrlEvent e)
        {
            if(e.Action == VariableColumnCtrl.ACTION.Add)
            {
                int Index = dgvEditItemEditor.GetIndexVariableColumn(Resources.IF_TAG_PARSER);                  // Ｍパーサ物理情報 の開始位置
                int logicIndex = dgvEditItemEditor.GetIndexVariableColumn(Resources.IF_TAG_LOGICLAYOUT);        // 論理インタフェース・論理条件 の開始位置
                foreach(DataGridViewRow row in dgvEditItemEditor.Rows)
                {
                    for (int i = logicIndex; i < dgvEditItemEditor.ColumnCount; i += 7)
                    {
                        string typ = (string)row.Cells[Index + 2].Value;
                        DataGridViewComboBoxCell cell = (DataGridViewComboBoxCell)row.Cells[i + 2];

                        if (dicPerserType.TryGetValue(typ, out List<string> list))
                        {
                            //既に設定されているＭパーサ論理属性が設定可能範囲外である場合は空文字にする
                            if (list.Contains((string)cell.Value) == false)
                            {
                                cell.Value = string.Empty;
                            }
                            cell.Items.Clear();
                            foreach (string t in list)
                            {
                                cell.Items.Add(t);
                            }
                        }
                    }
                }
            }
            ModeChange(MODE.Edit);
        }

        private VersionModel version;

        private bool searchEdit = false;
        private int tabPageIndex = 0;
        private List<InterfaceEdit.EditInfo> EditInfos = new List<InterfaceEdit.EditInfo>();
        private InterfaceEdit.RowInfo BeforeRowInfo = null;
        private InterfaceEdit.LastUpdateUser UpdateUser = null;
        private bool noSave = false;
        private List<T_CPYLOG> listCPYLOG = new List<T_CPYLOG>();

        public Interface(VersionModel v):this()
        {
            RdoCopyku.Checked = true;
            this.dgvPhyData.Tag = this.chkRDataAll;
            this.btnOutput.Enabled = false;
            this.txtCopyKuNm.Enabled = false;
            if (this.dgvPhyData.Tag is CheckBox)
            {
                this.CheckDgv = new CheckDataGridView(this.dgvPhyData, this.dgvPhyData.Tag as CheckBox);
                this.CheckDgv.ChangeStatus += ChangeStatus;
            }
            this.groupBox7.Enabled = false;
            version = v;
        }
        /// <summary>
        /// 検索画面より呼ばれた場合
        /// </summary>
        /// <param name="t_PHYITM"></param>
        /// <param name="v"></param>
        public Interface(T_PHYITM t_PHYITM,  VersionModel v) : this()
        {
            this.PHYITM = t_PHYITM;
            version = v;
            this.tabControl1.SelectedIndex = 1; // 編集タブをアクティブにする
            setEdit(t_PHYITM.PHYITM_SUBSYSID, t_PHYITM.PHYITM_INFOID, string.Empty);  //編集画面を更新
            this.tabPageIndex = 1;
            this.searchEdit = true;
            #region 検索画面より呼ばれた場合、出力画面の初期化
            this.dgvPhyData.Tag = this.chkRDataAll;
            this.btnOutput.Enabled = false;
            this.txtCopyKuNm.Enabled = false;
            if (this.dgvPhyData.Tag is CheckBox)
            {
                this.CheckDgv = new CheckDataGridView(this.dgvPhyData, this.dgvPhyData.Tag as CheckBox);
                this.CheckDgv.ChangeStatus += ChangeStatus;
            }
            this.groupBox7.Enabled = false;
            #endregion 検索画面より呼ばれた場合、出力画面の初期化
        }

        public Interface(T_PHYITM t_PHYITM, VersionModel v , string jnl) : this(t_PHYITM,v)
        {
            //ジャーナル編集画面から、情報部の詳細を参照する時、不要なタブを削除
            this.tabControl1.TabPages.Remove(this.tabPage1);
            this.tabControl1.TabPages.Remove(this.tabPage2);
            this.tabControl1.TabPages.Remove(this.tabPage3);
        }

        /// <summary>
        /// 画面が閉じられる時の処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Interface_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(this.mode == MODE.Edit)
            {
                //ＤＢ更新前
                if (MessageBox.Show(Resources.IF_MSG_CANCEL,
                                    Resources.QUESTION, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    e.Cancel = true;
                }
            }
            else if( this.mode == MODE.Write)
            {
                //ファイル出力前
                if (MessageBox.Show(Resources.IF_MSG_ASK_OUTPUT,
                                    Resources.INFORMATION, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    e.Cancel = true;
                }
            }
        }

        private enum MODE { View, Edit, Write };

        /// <summary>
        /// 属性辞書（データ属性：Ｍパーサ物理属性）
        /// </summary>
        Dictionary<string, List<string>> dicPhysicType = null;
        /// <summary>
        /// 属性辞書（Ｍパーサ物理属性：Ｍパーサ論理属性）
        /// </summary>
        Dictionary<string, List<string>> dicPerserType = null;
        /// <summary>
        /// 可変コラム制御（設定条件）
        /// </summary>
        private VariableColumnCtrl variableColumnCtrlForRequirement;
        /// <summary>
        /// 可変コラム制御（論理インタフェース）
        /// </summary>
        private VariableColumnCtrl variableColumnCtrlForLogic;
        /// <summary>
        /// アイテム説明書・プレビュー画面機能
        /// </summary>
        private SheetShowPreview SheetPreview;
        /// <summary>
        /// アイテム構成図・プレビュー画面機能
        /// </summary>
        private SheetShowPreview StructPreview;
        private T_PHYITM PHYITM;
        private T_CPYPHY CPYPHY;
        private T_CPYPHY OriginCPYPHY;
        private MODE mode = MODE.View;
        private string EditSubsystem = string.Empty;
        private string PHYPRS_LAYDEF = string.Empty;
        #region 編集画面・ＧＵＩ操作

        private void btnEditViewItemInfo_CheckedChanged(object sender, EventArgs e)
        {
            //[アイテム情報]ボタンのチェック状態に応じて、該当コラムの表示／非表示を切り替える
            dgvEditItemEditor.Columns[1].Visible = btnEditViewItemInfo.Checked;
            dgvEditItemEditor.Columns[6].Visible = btnEditViewItemInfo.Checked;
            dgvEditItemEditor.Columns[7].Visible = btnEditViewItemInfo.Checked;
            dgvEditItemEditor.Columns[8].Visible = btnEditViewItemInfo.Checked;
            dgvEditItemEditor.Columns[9].Visible = btnEditViewItemInfo.Checked;
            if (btnEditViewItemInfo.Checked)
            {
                dgvEditItemEditor.Columns[0].Frozen = false;
            }
            else
            {
                dgvEditItemEditor.Columns[9].Frozen = true;
            }
        }

        private void btnEditViewCopyInfo_CheckedChanged(object sender, EventArgs e)
        {
            //[コピー句情報]ボタンのチェック状態に応じて、該当コラムの表示／非表示を切り替える
            dgvEditItemEditor.Columns[10].Visible = btnEditViewCopyInfo.Checked;
            dgvEditItemEditor.Columns[11].Visible = btnEditViewCopyInfo.Checked;
        }

        private void btnEditViewRequirment_CheckedChanged(object sender, EventArgs e)
        {
            //[設定条件]の開始位置と個数を取得し、該当範囲のコラムの表示／非表示を切り替える
            int Index = dgvEditItemEditor.GetIndexVariableColumn(Resources.IF_TAG_REQUIREMENT);
            int Count = dgvEditItemEditor.GetCountVariableColumn(Resources.IF_TAG_REQUIREMENT);
            for(int i = Index; i < (Index + Count); i++)
            {
                dgvEditItemEditor.Columns[i].Visible = btnEditViewRequirment.Checked;
            }
            //[設定条件]の編集エリアの表示／非表示も切り替える
            grpEditRequirement.Visible = btnEditViewRequirment.Checked;
        }

        private void btnEditViewLogicif_CheckedChanged(object sender, EventArgs e)
        {
            //論理インタフェースの開始位置（Ｍパーサ物理情報）を取得する
            int Index = dgvEditItemEditor.GetIndexVariableColumn(Resources.IF_TAG_PARSER);
            //論理インタフェースの開始位置から終端まで、コラムの表示／非表示を切り替える
            for(int i = Index; i < dgvEditItemEditor.Columns.Count; i++)
            {
                dgvEditItemEditor.Columns[i].Visible = btnEditViewLogicif.Checked;
            }
            //[論理インタフェース]の編集エリアの表示／非表示も切り替える
            grpEditLogicif.Visible = btnEditViewLogicif.Checked;
        }

        /// <summary>
        /// セルの内容が変更された場合
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvEditItemEditor_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1) return;   //ヘッダ部は無視

            ModeChange(MODE.Edit);

            int Index = dgvEditItemEditor.GetIndexVariableColumn(Resources.IF_TAG_PARSER);                 // Ｍパーサ物理情報 の開始位置
            int logicIndex = dgvEditItemEditor.GetIndexVariableColumn(Resources.IF_TAG_LOGICLAYOUT);       // 論理インタフェース・論理条件 の開始位置
            int logicCount = dgvEditItemEditor.GetCountVariableColumn(Resources.IF_TAG_LOGICLAYOUT);       // 論理インタフェース・論理条件 のコラム数

            //データ属性が変更された場合、データ属性に応じてＭパーサ物理属性の設定可能な範囲を変更する
            if ( e.ColumnIndex == 3)
            {
                string typ = (string)dgvEditItemEditor.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;
                DataGridViewComboBoxCell cell = (DataGridViewComboBoxCell)dgvEditItemEditor.Rows[e.RowIndex].Cells[Index + 2];

                if (dicPhysicType.TryGetValue(typ, out List<string> list))
                {
                    //既に設定されているＭパーサ物理属性が設定可能範囲外である場合は空文字にする
                    if (list.Contains((string)cell.Value) == false)
                    {
                        cell.Value = string.Empty;
                        //Ｍパーサ論理属性もクリアし、設定可能範囲を初期化する
                        for(int i = logicIndex; i < dgvEditItemEditor.ColumnCount; i+=7)
                        {
                            DataGridViewComboBoxCell logicCell = (DataGridViewComboBoxCell)dgvEditItemEditor.Rows[e.RowIndex].Cells[i + 2];
                            logicCell.Value = string.Empty;
                            logicCell.Items.Clear();
                        }
                    }
                    cell.Items.Clear();
                    foreach (string t in list)
                    {
                        cell.Items.Add(t);
                    }
                }
            }
            //Ｍパーサ物理属性が変更された場合、Ｍパーサ論理属性の設定可能な範囲を変更する
            else if ( e.ColumnIndex == (Index + 2) ) 
            {
                for(int i = logicIndex; i < dgvEditItemEditor.ColumnCount; i+=7)
                {
                    string typ = (string)dgvEditItemEditor.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;
                    DataGridViewComboBoxCell cell = (DataGridViewComboBoxCell)dgvEditItemEditor.Rows[e.RowIndex].Cells[i + 2];

                    if(dicPerserType.TryGetValue(typ, out List<string> list))
                    {
                        //既に設定されているＭパーサ論理属性が設定可能範囲外である場合は空文字にする
                        if (list.Contains((string)cell.Value) == false )
                        {
                            cell.Value = string.Empty;
                        }
                        cell.Items.Clear();
                        foreach(string t in list)
                        {
                            cell.Items.Add(t);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// [更新]ボタン押下時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEditCommit_Click(object sender, EventArgs e)
        {
            dgvEditItemEditor.EndEdit();

            if (dgvEditItemEditor.Rows == null || dgvEditItemEditor.Rows.Count == 0) return;

            string msg = string.Empty;
            MessageBoxIcon errlevel = MessageBoxIcon.None;

            InterfaceEdit interfaceEdit = new InterfaceEdit(this.version, 
                                                            this.dgvEditItemEditor, 
                                                            this.CPYPHY.CPYPHY_SUBSYSID, 
                                                            this.CPYPHY.CPYPHY_INFOID,
                                                            this.EditSubsystem);

            //検定でエラーがあった場合は処理を中断する
            if (interfaceEdit.checkDataGridView() == false)
            {
                MessageBox.Show(Resources.IF_MSG_EDITERROR, Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                WaitDialog.Show(this);
                int LayoutIndex = dgvEditItemEditor.GetIndexVariableColumn(Resources.IF_TAG_LOGICLAYOUT);
                int LayoutCount = dgvEditItemEditor.GetCountVariableColumn(Resources.IF_TAG_LOGICLAYOUT);
                int ParseIndex = dgvEditItemEditor.GetIndexVariableColumn(Resources.IF_TAG_PARSER);

                // レイアウト定義が重複していないか検定する
                GroupDataGridView.GroupCell groupCell = dgvEditItemEditor.GetGroupCell(ParseIndex, 3);
                groupCell.BackColor = SystemColors.Control;
                if (this.version.context.T_PHYPRS.AsNoTracking().Where(r => r.PHYPRS_LAYDEF == groupCell.Text &&
                                                                           (r.PHYPRS_PHYSYSID != this.CPYPHY.CPYPHY_SUBSYSID ||
                                                                            r.PHYPRS_INFOID != this.CPYPHY.CPYPHY_INFOID ||
                                                                            r.PHYPRS_SUBSYSID != this.cmbEditTargetSubsys.Text)).Count() > 1)
                {
                    groupCell.BackColor = Color.Red;
                    msg = string.Format(Resources.IF_MSG_EDITEXISTS, string.Format("レイアウト定義：{0}", groupCell.Text));
                    errlevel = MessageBoxIcon.Warning;
                    this.logger.Warn(msg);
                    return;
                }

                // 物理ＩＤが重複していないか検定する
                dgvEditItemEditor.Rows[0].Cells[ParseIndex].Style.BackColor = SystemColors.Window;
                string PHYID = dgvEditItemEditor.Rows[0].Cells[ParseIndex].Value as string;
                if (!string.IsNullOrEmpty(PHYID))
                {
                    if (this.version.context.T_PHYPRS.AsNoTracking().Where(r =>
                                                                                r.PHYPRS_SUBSYSID == this.cmbEditTargetSubsys.Text &&
                                                                                r.PHYPRS_PHYID == PHYID &&
                                                                                r.PHYPRS_LAYDEF != PHYPRS_LAYDEF).Select(r
                                                                                                => r.PHYPRS_LAYDEF).Distinct().Count() > 0)
                    {
                        dgvEditItemEditor.Rows[0].Cells[ParseIndex].Style.BackColor = Color.Red;
                        msg = string.Format(string.Format(Resources.IF_MSG_EDITEXISTS, string.Format("物理ＩＤ：{0}", PHYID)));
                        errlevel = MessageBoxIcon.Warning;
                        this.logger.Warn(msg);
                        return;
                    }
                    if(string.IsNullOrEmpty(groupCell.Text))
                    {
                        groupCell.BackColor = Color.Red;
                        msg = string.Format(Resources.IF_LOG_NODATA, "レイアウト定義");
                        errlevel = MessageBoxIcon.Warning;
                        this.logger.Warn(msg);
                        return;
                    }
                }

                //開始レベル番号
                if (dgvEditItemEditor.Rows.Count > 0)
                {
                    List<T_CPYLOG> listCPYLOG = interfaceEdit.getCPYLOGfromDataGridView();
                    for (int i = 0; i < LayoutCount / 7; i++)
                    {
                        // 論理コピー句が重複していないか検定する
                        GroupDataGridView.GroupCell logicCell = dgvEditItemEditor.GetGroupCell(LayoutIndex + 1, 3);
                        logicCell.BackColor = SystemColors.Control;
                        T_CPYLOG cpylog = null;
                        if (listCPYLOG.Count > i)
                        {
                            cpylog = listCPYLOG[i];
                            for(int j = i + 1; j < LayoutCount / 7 - 1; j++)
                            {
                                if(cpylog != null && listCPYLOG[j] != null)
                                {
                                    if(cpylog.CPYLGC_LCPID == listCPYLOG[j].CPYLGC_LCPID)
                                    {
                                        logicCell.BackColor = Color.Red;
                                        msg = Resources.IF_MSG_EDITERROR +string.Format("（論理コピー句ＩＤの重複：{0}）", cpylog.CPYLGC_LCPID);
                                        errlevel = MessageBoxIcon.Warning;
                                        this.logger.Warn(msg);
                                        return;
                                    }
                                }
                            }
                        }

                        if (this.version.context.T_CPYLOG.AsNoTracking().Where(r => r.CPYLGC_LCPID == logicCell.Text &&
                                                                                  (r.CPYLGC_SUBSYSID != this.EditSubsystem ||
                                                                                   r.CPYLGC_PHYSYSID != this.CPYPHY.CPYPHY_SUBSYSID ||
                                                                                   r.CPYLGC_INFOID != this.CPYPHY.CPYPHY_INFOID)).Count() > 0)
                        {
                            logicCell.BackColor = Color.Red;
                            msg = string.Format(string.Format(Resources.IF_MSG_EDITEXISTS, string.Format("論理コピー句ＩＤ：{0}", logicCell.Text)));
                            errlevel = MessageBoxIcon.Warning;
                            this.logger.Warn(msg);
                            return;
                        }

                        string value = dgvEditItemEditor.Rows[0].Cells[LayoutIndex + 1].EditedFormattedValue as string;
                        if (int.TryParse(value, out int level))
                        {
                            if(cpylog == null)
                            {
                                logicCell.BackColor = Color.Red;
                                msg = string.Format(string.Format(Resources.IF_LOG_NODATA, "論理コピー句ＩＤ"));
                                errlevel = MessageBoxIcon.Warning;
                                this.logger.Warn(msg);
                                return;
                            }
                            cpylog.CPYLGC_LEVNO = level;
                            // 文字検定
                            if (logicCell.Text.Length > 8 || Utils.IsAlpahNum(logicCell.Text) == false)
                            {
                                logicCell.BackColor = Color.Red;
                                msg = Resources.IF_MSG_EDITERROR + string.Format("（論理コピー句ＩＤ内容不正：{0}）", cpylog.CPYLGC_LCPID);
                                errlevel = MessageBoxIcon.Error;
                                this.logger.Error(msg);
                                return;
                            }
                        }

                        // 論理条件
                        GroupDataGridView.GroupCell LNameCell = dgvEditItemEditor.GetGroupCell(LayoutIndex + 1, 2);
                        LNameCell.BackColor = SystemColors.GradientActiveCaption;
                        if (LNameCell.Text.Length > 10)
                        {
                            LNameCell.BackColor = Color.Red;
                            msg = Resources.IF_MSG_EDITERROR + string.Format("（論理条件内容不正：{0}）", LNameCell.Text);
                            errlevel = MessageBoxIcon.Error;
                            this.logger.Error(msg);
                            return;
                        }

                        LayoutIndex += 7;
                    }
                    interfaceEdit.setCPYLOGtoDataGridView(listCPYLOG);
                }

                //ＤＢの更新を行う
                //   基本的に以下のルールで行う
                //     ＯＫ）=> 続行
                //     ＮＧ）=> 中断
                //  （１）物理コピー句情報の更新ユーザＩＤと更新日時が読込時と一致しているか検定する
                //  （２）削除された行を物理アイテム情報と紐付くテーブル（論理設定条件情報、物理Ｍパーサ情報、論理アイテム情報）から削除する
                //  （３）追加／変更された行を物理アイテム情報と紐付くテーブル（論理設定条件情報、物理Ｍパーサ情報、論理アイテム情報）に反映する
                //  （４）物理コピー句情報の更新を行う。
                //　（５）論理コピー句情報の更新を行う。
                //  （６）コミットする
                try
                {
                    this.logger.Info(Resources.IF_LOG_UPDATE_START_I);

                    bool result = true;
                    InterfaceEdit.UpdateInfo updateInfo = interfaceEdit.getUpdateInfo();
                    if (updateInfo.CPYPHY)
                    {
                        InterfaceEdit.LastUpdateUser last = interfaceEdit.getPhysicLastUpdateUser();
                        if (last.User != this.UpdateUser.User || last.DateTime != this.UpdateUser.DateTime) //更新チェック
                        {
                            this.logger.Warn(string.Format(Resources.IF_LOG_UPDATE_NO_W, "物理コピー句情報", last.User, last.DateTime));
                            msg = string.Format(string.Format(Resources.IF_MSG_NOUPDATE, last.User, last.DateTime.ToString()));
                            errlevel = MessageBoxIcon.Error;
                            return;
                        }
                    }

                    if (updateInfo.PHYPRS)
                    {
                        for (int i = 0; i < dgvEditItemEditor.Rows.Count; i++)
                        {
                            if (dgvEditItemEditor.Rows[i].Tag != null)
                            {
                                InterfaceEdit.RowInfo rowinfo = dgvEditItemEditor.Rows[i].Tag as InterfaceEdit.RowInfo;
                                T_PHYPRS_EF phyprs = interfaceEdit.getPHYPRS(rowinfo.phyitm.PHYITM_SEQ);
                                if (phyprs != null && (phyprs.PHYPRS_USERID != rowinfo.phyprs.PHYPRS_USERID || phyprs.PHYPRS_UPDTIME != rowinfo.phyprs.PHYPRS_UPDTIME))
                                {
                                    this.logger.Warn(string.Format(Resources.IF_LOG_UPDATE_NO_W, "物理Ｍパーサ情報テーブル", phyprs.PHYPRS_USERID, phyprs.PHYPRS_UPDTIME));
                                    msg = string.Format(string.Format(Resources.IF_MSG_NOUPDATE, phyprs.PHYPRS_USERID, phyprs.PHYPRS_UPDTIME.ToString()));
                                    errlevel = MessageBoxIcon.Error;
                                    return;
                                }
                            }
                        }
                    }

                    for (int j = 0; j < listCPYLOG.Count; j++)
                    {
                        for (int i = 0; i < updateInfo.updateLCPID.Count; i++)
                        {
                            if (listCPYLOG[j].CPYLGC_LCPID == updateInfo.updateLCPID[i])
                            {
                                InterfaceEdit.LastUpdateUser last = interfaceEdit.getLogicLastUpdateUser(updateInfo.updateLCPID[i]);
                                if (last.User != listCPYLOG[j].CPYLGC_USERID || last.DateTime != listCPYLOG[j].CPYLGC_UPDTIME)
                                {
                                    this.logger.Warn(string.Format(Resources.IF_LOG_UPDATE_NO_W, "論理コピー句情報", last.User, last.DateTime));
                                    msg = string.Format(string.Format(Resources.IF_MSG_NOUPDATE, last.User, last.DateTime.ToString()));
                                    errlevel = MessageBoxIcon.Error;
                                    return;
                                }
                                break;
                            }
                        }
                        for (int i = 0; i < updateInfo.deleteLCPID.Count; i++)
                        {
                            if (listCPYLOG[j].CPYLGC_LCPID == updateInfo.deleteLCPID[i])
                            {
                                InterfaceEdit.LastUpdateUser last = interfaceEdit.getLogicLastUpdateUser(updateInfo.deleteLCPID[i]);
                                if (last.User != listCPYLOG[j].CPYLGC_USERID || last.DateTime != listCPYLOG[j].CPYLGC_UPDTIME)
                                {
                                    this.logger.Warn(string.Format(Resources.IF_LOG_UPDATE_NO_W, "論理コピー句情報", last.User, last.DateTime));
                                    msg = string.Format(string.Format(Resources.IF_MSG_NOUPDATE, last.User, last.DateTime.ToString()));
                                    errlevel = MessageBoxIcon.Error;
                                    return;
                                }
                                break;
                            }
                        }
                    }

                    using (var tran = this.Context.Database.BeginTransaction())
                    {
                        // 行削除
                        List<InterfaceEdit.RowInfo> listDelete = new List<InterfaceEdit.RowInfo>();
                        foreach (InterfaceEdit.EditInfo editItem in this.EditInfos)
                        {
                            if (editItem.EditType == InterfaceEdit.EditInfo.EditTypes.Delete)
                            {
                                listDelete.Add(editItem.RowInfo);
                            }
                        }

                        // 行削除
                        if (interfaceEdit.DeleteDB(this.CPYPHY, listDelete))
                        {
                            // 追加／更新
                            result = interfaceEdit.WriteRowDB();
                            if (result)
                            {
                                // 物理コピー句情報の更新
                                if (updateInfo.CPYPHY || this.CPYPHY.CPYPHY_COMMENT != OriginCPYPHY.CPYPHY_COMMENT
                                                      || this.CPYPHY.CPYPHY_LEVNO != OriginCPYPHY.CPYPHY_LEVNO)
                                {
                                    result = interfaceEdit.WritePhysicHeaderDB(this.CPYPHY);
                                }
                                if (result)
                                {
                                    // 論理コピー句情報の更新
                                    List<T_CPYLOG> list = interfaceEdit.getCPYLOGfromDataGridView();
                                    for (int i = 0; i < list.Count; i++)
                                    {
                                        foreach (string LCPID in updateInfo.updateLCPID)
                                        {
                                            if (list[i].CPYLGC_LCPID == LCPID)
                                            {
                                                result = interfaceEdit.WriteLogicHeaderDB(list[i]);
                                                break;
                                            }
                                        }
                                        if (result == false) break;
                                    }
                                    if (result)
                                    {
                                        // 論理コピー句情報の削除
                                        foreach (string LCPID in updateInfo.deleteLCPID)
                                        {
                                            result = interfaceEdit.deleteLogicHeaderDB(LCPID);
                                            if (result == false) break;
                                        }
                                    }
                                }
                                //全て成功した場合のみコミットする
                                if (result)
                                {
                                    tran.Commit();
                                    this.logger.Info(Resources.IF_LOG_UPDATE_COMMIT_I);
                                }
                            }
                        }
                        else
                        {
                            this.logger.Error(Resources.IF_LOG_UPDATE_ERROR_E);
                            //追加／更新に失敗した場合、エラーを表示し、処理を中断する（通常はここに来ないはず・・・）
                            msg = Resources.IF_LOG_DBWRITE_E;
                            errlevel = MessageBoxIcon.Error;
                            return;
                        }
                    }
                    if (result)
                    {
                        this.logger.Info(Resources.IF_LOG_UPDATE_END_I);
                        //完了メッセージ
                        msg = "ＤＢ更新に成功しました";
                        errlevel = MessageBoxIcon.Information;
                    }
                    else
                    {
                        this.logger.Error(Resources.IF_LOG_UPDATE_ERROR_E);
                        //更新に失敗した場合、エラーを表示し、処理を中断する（通常はここに来ないはず・・・）
                        msg = Resources.IF_LOG_DBWRITE_E;
                        errlevel = MessageBoxIcon.Error;
                        return;
                    }

                }
                catch (Exception ex)
                {
                    this.logger.Error(ex, Resources.IF_LOG_UPDATE_ERROR_E);
                    msg = Resources.IF_LOG_DBWRITE_E;
                    errlevel = MessageBoxIcon.Error;
                    return;
                }

                this.EditInfos.Clear();

                try
                {
                    //更新が完了したので、最新の更新日時を再取得する
                    this.UpdateUser = interfaceEdit.getPhysicLastUpdateUser();

                    //ＤＢから再取得し、編集画面に反映する。また、編集履歴を初期化する
                    setEdit(this.CPYPHY.CPYPHY_SUBSYSID, this.CPYPHY.CPYPHY_INFOID, string.Empty);
                }
                catch (Exception ex)
                {
                    //更新後のＤＢ読込に失敗
                    this.logger.Error(ex, string.Format("{0} {1}", version.User.USERID, Resources.IF_LOG_DBREAD_E));
                    msg = Resources.IF_LOG_DBREAD_E;
                    errlevel = MessageBoxIcon.Error;
                    return;
                }

                this.noSave = false;
                //出力を有効にする
                ModeChange(MODE.Write);

                //アイテム設計書、アイテム構成図の画面に反映する
                try
                {
                    SheetPreview.DataGridViewToCanvas(this.dgvEditItemEditor);
                    if (SheetPreview.MaxPage > 0)
                    {
                        SheetPreview.Page = 1;
                        this.cmbSheetPage.Items.Clear();
                        for (int p = 0; p < SheetPreview.MaxPage; p++)
                        {
                            this.cmbSheetPage.Items.Add(p + 1);
                        }
                        this.cmbSheetPage.SelectedIndex = 0;
                        SheetPreview.ShowPreview();
                    }
                }
                catch (Exception)
                {
                    //エラーは無視する
                }
                try
                {
                    StructPreview.DataGridViewToCanvas(this.dgvEditItemEditor);
                    if (StructPreview.MaxPage > 0)
                    {
                        StructPreview.Page = 1;
                        this.cmbPicturePage.Items.Clear();
                        for (int p = 0; p < StructPreview.MaxPage; p++)
                        {
                            this.cmbPicturePage.Items.Add(p + 1);
                        }
                        this.cmbPicturePage.SelectedIndex = 0;
                        StructPreview.ShowPreview();
                    }
                }
                catch (Exception)
                {
                    //エラーは無視する
                }
            }
            finally
            {
                WaitDialog.Close();
                if(errlevel == MessageBoxIcon.Information)
                {
                    MessageBox.Show(msg, Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if(errlevel == MessageBoxIcon.Warning)
                {
                    MessageBox.Show(msg, Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if(errlevel == MessageBoxIcon.Error)
                {
                    MessageBox.Show(msg, Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnEditPhysicifCopyComment_Click(object sender, EventArgs e)
        {
            //コメントの入力ダイアログを表示する
            InputDialog dialog = new InputDialog
            {
                Multiline = true
            };
            if (dialog.ShowDialog(this, "コピー句コメント編集", "コピー句コメントを編集してください", this.CPYPHY.CPYPHY_COMMENT) == DialogResult.OK)
            {
                if(this.CPYPHY.CPYPHY_COMMENT != dialog.Value)  // コピー句コメントが変更されて場合のみ
                {
                    this.CPYPHY.CPYPHY_COMMENT = dialog.Value;
                    ModeChange(MODE.Edit);
                }
            }
        }

        private void btnEditLogicifCopyComment_Click(object sender, EventArgs e)
        {
            if (lstEditLogicif.SelectedIndex == -1) return;
            int Index = lstEditLogicif.SelectedIndex;
            //コメントの入力ダイアログを表示する
            InputDialog dialog = new InputDialog
            {
                Multiline = true
            };
            InterfaceEdit interfaceEdit = new InterfaceEdit(this.version, dgvEditItemEditor, string.Empty, this.EditSubsystem);
            List<T_CPYLOG> cpylog = interfaceEdit.getCPYLOGfromDataGridView();
            if (dialog.ShowDialog(this, "コピー句コメント編集", "コピー句コメントを編集してください", cpylog[Index].CPYLGC_COMMENT) == DialogResult.OK)
            {
                if(cpylog[Index].CPYLGC_COMMENT != dialog.Value)
                {
                    cpylog[Index].CPYLGC_COMMENT = dialog.Value;
                    interfaceEdit.setCPYLOGtoDataGridView(cpylog);
                    ModeChange(MODE.Edit);
                }
            }
        }

        private void btnEditPhysicFileRef_Click(object sender, EventArgs e)
        {
            //OpenFileDialog から物理コピー句ファイルを選択させる
            string defaultDir = string.Empty;
            if(this.txtEditPhysicFile.Text != string.Empty)     // 設定済みの場合は、該当フォルダをデフォルトとする
            {
                defaultDir = Path.GetDirectoryName(this.txtEditPhysicFile.Text);
            }
            OpenFileDialog dialog = new OpenFileDialog
            {
                Filter = "Cobol Files|*.cbl|All Files|*",
                FilterIndex = 0,
                Multiselect = false,
                InitialDirectory = defaultDir
            };
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                this.txtEditPhysicFile.Text = dialog.FileName;
            }
        }

        private void txtEditPhysicFile_TextChanged(object sender, EventArgs e)
        {
            if (txtEditPhysicFile.Text.Length == 0)
            {
                btnEditPhysicFileIn.Enabled = false;
                return;
            }

            // 物理コピー句ファイル の テキストボックス の入力内容が変更された時、
            // 該当ファイルが存在する場合は[読込]ボタンを有効化する。存在しない場合は[読込]ボタンを無効化する
            try
            {
                btnEditPhysicFileIn.Enabled = File.Exists(Path.GetFullPath(txtEditPhysicFile.Text));
            }
            catch
            {
                //File.Exists で例外となった場合は、ボタンを無効化する（パスとして不適格な内容が入力された為）
                btnEditPhysicFileIn.Enabled = false;
            }
        }

        /// <summary>
        /// 対象サブシステムの変更
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbEditTargetSubsys_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbEditTargetSubsys.SelectedIndex >= 0)
            {
                if(this.EditSubsystem != cmbEditTargetSubsys.Text)
                {
                    btnEditTargetSubsys.Enabled = true;
                }
                else
                {
                    btnEditTargetSubsys.Enabled = false;
                }
            }
            else
            {
                btnEditTargetSubsys.Enabled = false;
            }
        }

        private void btnEditTargetSubsys_Click(object sender, EventArgs e)
        {
            if(this.mode == MODE.Edit)
            {
                if(MessageBox.Show(Resources.IF_MSG_CANCEL, Resources.QUESTION, 
                                                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    cmbEditTargetSubsys.Text = this.EditSubsystem;
                    return;
                }
            }

            this.EditSubsystem = cmbEditTargetSubsys.Text;
            this.logger.Info(string.Format(Resources.IF_LOG_CHANGE_SUBSYS_I, cmbEditTargetSubsys.Text));

            if (this.CPYPHY != null)
            {
                if(this.CPYPHY.CPYPHY_SUBSYSID == this.cmbEditTargetSubsys.Text)
                {
                    if(this.searchEdit)
                    {
                        this.grpEditPhysicif.Enabled = false;
                        this.grpEditRequirement.Enabled = false;
                        this.dgvEditItemEditor.ContextMenuStrip = null;
                    }
                    else
                    {
                        this.grpEditPhysicif.Enabled = true;
                        this.grpEditRequirement.Enabled = true;
                        this.dgvEditItemEditor.ContextMenuStrip = this.msEditMenu;
                    }
                    this.dgvEditItemEditor.ReadOnly = false;
                }
                else
                {
                    this.grpEditPhysicif.Enabled = false;
                    this.grpEditRequirement.Enabled = false;
                    this.dgvEditItemEditor.ContextMenuStrip = null;
                    this.dgvEditItemEditor.ReadOnly = false;
                }
                this.grpEditMPaser.Enabled = true;
                this.grpEditLogicif.Enabled = true;
                setEdit(this.CPYPHY.CPYPHY_SUBSYSID, this.CPYPHY.CPYPHY_INFOID, string.Empty);
            }
            else
            {
                this.grpEditPhysicFile.Enabled = true;
                this.grpEditPhysicif.Enabled = false;
                this.grpEditRequirement.Enabled = false;
                this.dgvEditItemEditor.ContextMenuStrip = null;
                this.dgvEditItemEditor.ReadOnly = false;
                setEdit(string.Empty, string.Empty, string.Empty);
            }

            btnEditTargetSubsys.Enabled = false;
            this.noSave = false;

            //論理インタフェースのサブシステムを選択したサブシステムに変更する
            foreach (GroupDataGridView.GroupCell groupcell in this.dgvEditItemEditor.GroupCells)
            {
                if(groupcell.Tag as string == "LogicIf")
                {
                    foreach(GroupDataGridView.GroupCell gcell in groupcell.ChildCells)
                    {
                        if(gcell.Tag as string == "Subsystem")
                        {
                            gcell.Text = this.EditSubsystem;
                            this.dgvEditItemEditor.Refresh();
                            return;
                        }
                    }
                }
            }
        }

        private void dgvEditItemEditor_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            if (this.dgvEditItemEditor.Rows[e.RowIndex].Tag != null)
            {
                this.BeforeRowInfo = (InterfaceEdit.RowInfo)this.dgvEditItemEditor.Rows[e.RowIndex].Tag;
            }
            else
            {
                this.BeforeRowInfo = null;
            }
        }

        private void dgvEditItemEditor_RowValidated(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            if(this.noSave == false)
            {
                InterfaceEdit.EditInfo editInfo = new InterfaceEdit.EditInfo(InterfaceEdit.EditInfo.EditTypes.Change, e.RowIndex);
                editInfo.BeforeRowInfo = this.BeforeRowInfo;
                if (this.dgvEditItemEditor.Rows[e.RowIndex].Tag != null)
                {
                    InterfaceEdit interfaceEdit = new InterfaceEdit(version, dgvEditItemEditor, txtEditPhysicSubsys.Text, txtEditPhysicInfoID.Text, this.EditSubsystem);
                    InterfaceEdit.RowInfo rowInfo = interfaceEdit.getRowInfoFormDataGridView(e.RowIndex);
                    if (this.BeforeRowInfo != rowInfo)
                    {
                        editInfo.AfterRowInfo = interfaceEdit.getRowInfoFormDataGridView(e.RowIndex);
                    }
                }
                else
                {
                    editInfo.AfterRowInfo = null;
                }
                if (editInfo.BeforeRowInfo != editInfo.AfterRowInfo)
                {
                    this.EditInfos.Add(editInfo);
                }
            }
        }

        /// <summary>
        /// セルクリック
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvEditItemEditor_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if(this.searchEdit || this.CPYPHY.CPYPHY_SUBSYSID != this.EditSubsystem)
            {
                return;
            }
            switch (e.ColumnIndex)
            {
                case 7:     // 候補値
                    this.dgvEditItemEditor.Rows[e.RowIndex].Cells[e.ColumnIndex].Tag = null;
                    T_PHYITM phyitm = new T_PHYITM();
                    phyitm.PHYITM_GROUP = this.dgvEditItemEditor.Rows[e.RowIndex].Cells[e.ColumnIndex].Value as string;
                    GroupForm groupForm = new GroupForm(phyitm, this.version);
                    groupForm.ShowDialog();
                    this.dgvEditItemEditor.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = groupForm.GroupNm;
                    if(groupForm.GroupNm != null && groupForm.GroupNm != string.Empty)
                    {
                        InterfaceEdit interfaceEdit = new InterfaceEdit(this.version, this.dgvEditItemEditor, this.CPYPHY.CPYPHY_SUBSYSID, this.CPYPHY.CPYPHY_INFOID, this.EditSubsystem);
                        List<T_KOHO> koho = interfaceEdit.getKOHO(groupForm.GroupNm);
                        this.dgvEditItemEditor.Rows[e.RowIndex].Cells[e.ColumnIndex].Tag = koho;
                    }

                    break;
                case 8:     // 図表
                    SelectPicture selectPicture = new SelectPicture();
                    if (this.dgvEditItemEditor.Rows[e.RowIndex].Cells[e.ColumnIndex].Tag != null)
                    {
                        selectPicture.FilePath = this.dgvEditItemEditor.Rows[e.RowIndex].Cells[e.ColumnIndex].Tag as string;
                    }
                    selectPicture.PictureName = this.dgvEditItemEditor.Rows[e.RowIndex].Cells[e.ColumnIndex].Value as string;
                    if (this.dgvEditItemEditor.Rows[e.RowIndex].Tag != null)
                    {
                        InterfaceEdit.RowInfo rowinfo = this.dgvEditItemEditor.Rows[e.RowIndex].Tag as InterfaceEdit.RowInfo;
                        selectPicture.ImageData = rowinfo.phyitm.PHYITM_IMAGE;
                    }
                    selectPicture.LimitFileSize = 61440;    // 画像は最大60KBとする
                    selectPicture.LimitNameSize = 60;       // 図表名は最大６０文字とする
                    if (selectPicture.ShowDialog() == DialogResult.OK)
                    {
                        if(selectPicture.Action == SelectPicture.DialogAction.Set)
                        {
                            this.dgvEditItemEditor.Rows[e.RowIndex].Cells[e.ColumnIndex].Tag = selectPicture.FilePath;
                            this.dgvEditItemEditor.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = selectPicture.PictureName;
                        }
                        else
                        {
                            this.dgvEditItemEditor.Rows[e.RowIndex].Cells[e.ColumnIndex].Tag = null;
                            this.dgvEditItemEditor.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = null;
                        }
                    }
                    break;
                default:
                    break;
            }
        }

        private void btnEditRequirementAdd_Click(object sender, EventArgs e)
        {
            ModeChange(MODE.Edit);
        }

        private void btnEditRequirementDel_Click(object sender, EventArgs e)
        {
            ModeChange(MODE.Edit);
        }

        private void btnEditRequirementRename_Click(object sender, EventArgs e)
        {
            ModeChange(MODE.Edit);
        }

        private void btnEditPhysicFileIn_Click(object sender, EventArgs e)
        {
            if(this.mode == MODE.Edit)
            {
                if (MessageBox.Show(Resources.IF_MSG_CANCEL, Resources.QUESTION,
                                                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
            }

            setEdit(string.Empty, string.Empty, txtEditPhysicFile.Text);
            this.noSave = false;
            if (this.CPYPHY == null)
            {
                //物理コピー句なし
                grpEditPhysicif.Enabled = false;
                grpEditRequirement.Enabled = false;
                grpEditMPaser.Enabled = false;
                grpEditLogicif.Enabled  = false;
                dgvEditItemEditor.ContextMenuStrip = null;
            }
            else
            {
                grpEditMPaser.Enabled = true;
                grpEditLogicif.Enabled = true;

                if (this.EditSubsystem == this.CPYPHY.CPYPHY_SUBSYSID)
                {
                    grpEditPhysicif.Enabled = true;
                    grpEditRequirement.Enabled = true;
                    dgvEditItemEditor.ContextMenuStrip = this.msEditMenu;
                }
                else
                {
                    grpEditPhysicif.Enabled = false;
                    grpEditRequirement.Enabled = false;
                    dgvEditItemEditor.ContextMenuStrip = null;
                }
            }
        }

        private void txtEditOutputPath_TextChanged(object sender, EventArgs e)
        {
            outputChange();
        }

        private void chkEditOutputCopy_CheckedChanged(object sender, EventArgs e)
        {
            outputChange();
        }

        private void chkEditOutputLayoutCsv_CheckedChanged(object sender, EventArgs e)
        {
            outputChange();
        }

        private void chkEditOutputLayoutText_CheckedChanged(object sender, EventArgs e)
        {
            outputChange();
        }

        private void outputChange()
        {
            if (Directory.Exists(txtEditOutputPath.Text))
            {
                if(chkEditOutputCopy.Checked || chkEditOutputLayoutCsv.Checked || chkEditOutputLayoutText.Checked)
                {
                    btnEditOutput.Enabled = true;
                }
                else
                {
                    btnEditOutput.Enabled = false;
                }
            }
            else
            {
                btnEditOutput.Enabled = false;
            }
        }

        private void btnEditOutputRef_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "保存先フォルダを選択してください";
            dialog.SelectedPath = this.txtEditOutputPath.Text;
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                txtEditOutputPath.Text = dialog.SelectedPath;
            }

        }

        private void btnEditOutput_Click(object sender, EventArgs e)
        {
            List<string> listErrorFile = new List<string>();
            List<string> listOutFile = new List<string>();
            string file;
            string dir;
            if (txtEditOutputPath.Text.Last() == '\\') 
            {
                dir = txtEditOutputPath.Text.Substring(0, txtEditOutputPath.Text.Length - 1).Trim();
            }
            else
            {
                dir = txtEditOutputPath.Text.Trim();
            }


            InterfaceEdit interfaceEdit = new InterfaceEdit(this.version,
                                                            this.dgvEditItemEditor,
                                                            this.CPYPHY.CPYPHY_SUBSYSID,
                                                            this.CPYPHY.CPYPHY_INFOID,
                                                            this.EditSubsystem);
            string msg =  string.Empty;
            MessageBoxIcon errLevel = MessageBoxIcon.None;
            try
            {
                WaitDialog.Show(this);
                if (interfaceEdit.checkDB() == false)
                {
                    msg = "ＤＢの内容が不正です";
                    errLevel = MessageBoxIcon.Error;
                    return;
                }
                //開始のログを出力
                this.logger.Info(string.Format(Resources.IF_LOG_OUTPUT_START_I, dir));

                if (chkEditOutputCopy.Checked)
                {
                    //物理コピー句のサブシステムと一致する場合は物理コピー句を出力対象とする
                    if (string.IsNullOrEmpty(this.CPYPHY.CPYPHY_BCPID) == false && this.CPYPHY.CPYPHY_SUBSYSID == this.EditSubsystem)
                    {
                        file = string.Format("{0}\\{1}.cbl", dir, CPYPHY.CPYPHY_BCPID);
                        try
                        {
                            using (StreamWriter sw =
                                        new StreamWriter(file,
                                                         false,
                                                         Encoding.GetEncoding(System.Configuration.ConfigurationManager.AppSettings["Encoding"])))
                            {
                                sw.Write(interfaceEdit.getPhysicCopyphraseFromDB());
                            }
                            listOutFile.Add(file);
                            this.logger.Info(LogUtils.GetMsgInfo(Resources.IF_LOG_PHYSIC_FILEOUT_I, Path.GetFileName(file)));
                        }
                        catch (Exception ex)
                        {
                            this.logger.Error(ex, string.Format(Resources.IF_LOG_PHYSIC_FILEOUT_E, Path.GetFileName(file)));
                            listErrorFile.Add(file);
                        }
                    }
                    //論理コピー句の出力
                    Dictionary<string, string> dictionarySource = interfaceEdit.getLogicCopyPharseFromDB();
                    foreach (string key in dictionarySource.Keys)
                    {
                        if (string.IsNullOrEmpty(key) == false)
                        {
                            file = string.Format("{0}\\{1}.cbl", dir, key);
                            try
                            {
                                using (StreamWriter sw = new StreamWriter(file,
                                                                          false,
                                                                          Encoding.GetEncoding(System.Configuration.ConfigurationManager.AppSettings["Encoding"])))
                                {
                                    sw.Write(dictionarySource[key]);
                                }
                                listOutFile.Add(file);
                                this.logger.Info(string.Format(Resources.IF_LOG_LOGIC_FILEOUT_I, Path.GetFileName(file)));
                            }
                            catch (Exception ex)
                            {
                                this.logger.Error(ex, string.Format(Resources.IF_LOG_LOGIC_FILEOUT_E, Path.GetFileName(file)));
                                listErrorFile.Add(file);
                            }
                        }
                    }
                }
                if (chkEditOutputLayoutCsv.Checked)
                {
                    string layout = interfaceEdit.getLayoutDef();
                    if (string.IsNullOrEmpty(layout) == false)
                    {
                        file = string.Format("{0}\\{1}.csv", dir, layout);
                        try
                        {
                            using (StreamWriter sw = new StreamWriter(file,
                                                                      false,
                                                                      Encoding.GetEncoding(System.Configuration.ConfigurationManager.AppSettings["Encoding"])))
                            {
                                sw.Write(interfaceEdit.getPhysicLayoutDef());
                            }
                            listOutFile.Add(file);
                            this.logger.Info(string.Format(Resources.IF_LOG_LAYOUT_FILEOUT_I, Path.GetFileName(file)));
                        }
                        catch (Exception ex)
                        {
                            this.logger.Error(ex, string.Format(Resources.IF_LOG_LAYOUT_FILEOUT_E, Path.GetFileName(file)));
                            listErrorFile.Add(file);
                        }
                    }
                }

                if (chkEditOutputLayoutText.Checked)
                {
                    string layout = interfaceEdit.getLayoutDef();
                    if (string.IsNullOrEmpty(layout) == false)
                    {
                        file = string.Format("{0}\\{1}.txt", dir, layout);
                        try
                        {
                            using (StreamWriter sw = new StreamWriter(file,
                                                                      false,
                                                                      Encoding.GetEncoding(System.Configuration.ConfigurationManager.AppSettings["Encoding"])))
                            {
                                sw.Write(interfaceEdit.getPhysicLayoutDef());
                            }
                            listOutFile.Add(file);
                            this.logger.Info(string.Format(Resources.IF_LOG_LAYOUT_FILEOUT_I, Path.GetFileName(file)));
                        }
                        catch (Exception ex)
                        {
                            this.logger.Error(ex, string.Format(Resources.IF_LOG_LAYOUT_FILEOUT_E, Path.GetFileName(file)));
                            listErrorFile.Add(file);
                        }
                    }
                }

                //出力完了のログ
                this.logger.Info(string.Format(Resources.IF_LOG_OUTPUT_END_I, listOutFile.Count, listErrorFile.Count));

                StringBuilder sb = new StringBuilder();
                int count = 0;
                if (listOutFile.Count > 0)
                {
                    sb.Append("出力が完了しました\r\n--------\r\n");
                    foreach (string s in listOutFile)
                    {
                        if (count > 5)
                        {
                            sb.Append(" :\r\n");
                            break;
                        }
                        sb.Append(s);
                        sb.Append("\r\n");
                        count++;
                    }
                    sb.Append(string.Format("--------\r\n>> 全 {0}本\r\n\r\n", listOutFile.Count));
                }

                count = 0;
                if (listErrorFile.Count > 0)
                {
                    sb.Append("出力に失敗しました\r\n--------\r\n");
                    foreach (string s in listErrorFile)
                    {
                        if (count > 5)
                        {
                            sb.Append(" :\r\n");
                            break;
                        }
                        sb.Append(s);
                        sb.Append("\r\n");
                        count++;
                    }
                    sb.Append(string.Format("--------\r\n>> 全 {0}本\r\n", listErrorFile.Count));
                }
                msg = sb.ToString();
            }
            finally
            {
                WaitDialog.Close();
                if (errLevel == MessageBoxIcon.Error)
                {
                    MessageBox.Show(msg, Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(msg, "出力結果", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }


        /// <summary>
        /// セルの編集直前
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvEditItemEditor_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (this.CPYPHY == null)
            {
                e.Cancel = true;
                return;
            }
            int Index = this.dgvEditItemEditor.GetIndexVariableColumn(Resources.IF_TAG_PARSER);
            int LogicIndex = this.dgvEditItemEditor.GetIndexVariableColumn(Resources.IF_TAG_LOGICLAYOUT);
            int LogicCount = this.dgvEditItemEditor.GetCountVariableColumn(Resources.IF_TAG_LOGICLAYOUT);
            int ParserIndex = this.dgvEditItemEditor.GetIndexVariableColumn(Resources.IF_TAG_PARSER);

            //物理コピー句のサブシステムと一致しない場合はキャンセルする
            if (e.ColumnIndex < Index & ((this.CPYPHY.CPYPHY_SUBSYSID != this.EditSubsystem) || (this.searchEdit)))
            {
                e.Cancel = true;
                return;
            }
            //物理Ｍパーサ情報はレイアウト定義が未設定の場合はキャンセル
            if (ParserIndex <= e.ColumnIndex && e.ColumnIndex < LogicIndex)
            {
                string id = this.dgvEditItemEditor.GetGroupCellText(ParserIndex, 3);
                if (string.IsNullOrEmpty(id))
                {
                    e.Cancel = true;
                    return;
                }
            }

            //論理情報は論理コピー句ＩＤが未設定の場合はキャンセル
            for (int i = 0; i < LogicCount; i += 7)
            {
                if (LogicIndex <= e.ColumnIndex && e.ColumnIndex < LogicIndex + 7)
                {
                    string id = this.dgvEditItemEditor.GetGroupCellText(LogicIndex, 3);
                    if (string.IsNullOrEmpty(id))
                    {
                        e.Cancel = true;
                        return;
                    }
                }
            }

            if (e.RowIndex == 0) return;

            //物理コピー句の開始レベル番号は最上位のみ編集可能
            if (e.ColumnIndex == 10 )
            {
                e.Cancel = true;
                return;
            }
            //物理ＩＤは最上位のみ編集可能
            if (e.ColumnIndex == Index )
            {
                e.Cancel = true;
                return;
            }
            //論理コピー句の開始レベル番号は最上位のみ編集可能
            for(int i = 0; i < LogicCount; i += 7)
            {
                if(e.ColumnIndex == (LogicIndex + i + 1))
                {
                    e.Cancel = true;
                    return;
                }
            }

        }

        /// <summary>
        /// セルの編集直後
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvEditItemEditor_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1) return;
            if (e.ColumnIndex == 2)
            {
                //アイテム名称の予備名称の自動補正
                string str = dgvEditItemEditor.Rows[e.RowIndex].Cells[e.ColumnIndex].Value as string;
                if (Utils.IsFiller(str))
                {
                    dgvEditItemEditor.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = "予備";
                }
            }
        }

        private void txtEditMPaserLayoutDef_TextChanged(object sender, EventArgs e)
        {
            if(txtEditMPaserLayoutDef.Text != string.Empty && txtEditMPaserLayoutDef.Text.Length <= 8)
            {
                if(Utils.IsAlpahNum(txtEditMPaserLayoutDef.Text))
                {
                    int Index = dgvEditItemEditor.GetIndexVariableColumn(Resources.IF_TAG_PARSER);
                    if (txtEditMPaserLayoutDef.Text == dgvEditItemEditor.GetGroupCellText(Index, 3))
                    {
                        btnEditMPaserSet.Enabled = false;
                    }
                    else
                    {
                        btnEditMPaserSet.Enabled = true;
                    }
                }
                else
                {
                    btnEditMPaserSet.Enabled = false;
                }
            }
            else
            {
                btnEditMPaserSet.Enabled = false;
            }
        }

        private void btnEditMPaserSet_Click(object sender, EventArgs e)
        {
            int Index = dgvEditItemEditor.GetIndexVariableColumn(Resources.IF_TAG_PARSER);
            dgvEditItemEditor.RenameGroup(Index, 3, txtEditMPaserLayoutDef.Text);
            dgvEditItemEditor.Refresh();
            btnEditMPaserSet.Enabled = false;
            ModeChange(MODE.Edit);
        }

        /// <summary>
        /// 論理削除ボタンが押下された時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEditPhysicifDel_Click(object sender, EventArgs e)
        {
            //確認メッセージを２回表示し、誤って削除するのを防ぐ
            if (MessageBox.Show(Resources.IF_MSG_INFODEL, Resources.QUESTION, 
                                                          MessageBoxButtons.YesNo, 
                                                          MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (MessageBox.Show(Resources.IF_MSG_INFOWARN, Resources.QUESTION,
                                                              MessageBoxButtons.YesNo,
                                                              MessageBoxIcon.Question) == DialogResult.Yes)
                {

                    InterfaceEdit interfaceEdit = new InterfaceEdit(this.version,
                                                                    this.dgvEditItemEditor,
                                                                    this.CPYPHY.CPYPHY_SUBSYSID,
                                                                    this.CPYPHY.CPYPHY_INFOID,
                                                                    this.EditSubsystem);

                    InterfaceEdit.UpdateInfo updateInfo = interfaceEdit.getUpdateInfo();
                    if (updateInfo.CPYPHY)
                    {
                        InterfaceEdit.LastUpdateUser last = interfaceEdit.getPhysicLastUpdateUser();
                        if (last.User != this.UpdateUser.User || last.DateTime != this.UpdateUser.DateTime) //更新チェック
                        {
                            this.logger.Warn(string.Format(Resources.IF_LOG_UPDATE_NO_W, "物理コピー句情報", last.User, last.DateTime));
                            MessageBox.Show(string.Format(Resources.IF_MSG_NOUPDATE,
                                                            last.User, last.DateTime.ToString()), Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                            return;
                        }
                    }

                    this.logger.Info(string.Format(Resources.IF_LOG_DELETE_START, this.CPYPHY.CPYPHY_INFOID, this.CPYPHY.CPYPHY_BCPNM, this.CPYPHY.CPYPHY_BCPID));
                    // 削除処理
                    using (var tran = this.Context.Database.BeginTransaction())
                    {
                        try
                        {
                            if (interfaceEdit.WritePhysicHeaderDB(this.CPYPHY, ConstantUtils.STATUS_DELELTE) == false)
                            {
                                this.logger.Error(string.Format(Resources.IF_LOG_DELETE_ERR,this.CPYPHY.CPYPHY_INFOID, this.CPYPHY.CPYPHY_BCPNM , this.CPYPHY.CPYPHY_BCPID));
                            }
                            else
                            {
                                tran.Commit();
                                this.logger.Info(string.Format(Resources.IF_LOG_DELETE_END, this.CPYPHY.CPYPHY_INFOID, this.CPYPHY.CPYPHY_BCPNM, this.CPYPHY.CPYPHY_BCPID));
                                MessageBox.Show(string.Format(Resources.IF_LOG_DELETE_END, this.CPYPHY.CPYPHY_INFOID, this.CPYPHY.CPYPHY_BCPNM, this.CPYPHY.CPYPHY_BCPID),
                                                Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                grpEditPhysicif.Enabled = false;
                                grpColumn.Enabled = false;
                                grpEditMPaser.Enabled = false;
                                dgvEditItemEditor.Rows.Clear();
                                dgvEditItemEditor.Enabled = false;
                            }

                        }
                        catch (Exception ex)
                        {
                            this.logger.Error(ex, string.Format(Resources.IF_LOG_DELETE_ERR, this.CPYPHY.CPYPHY_INFOID, this.CPYPHY.CPYPHY_BCPNM, this.CPYPHY.CPYPHY_BCPID));
                        }
                    }

                }

            }
        }

        #region PrivateMethod
        private bool setEdit(string subsysID, string infoID, string file)
        {
            this.noSave = true;
            //初期化
            txtEditPhysicSubsys.Text = string.Empty;        //サブシステムＩＤ
            txtEditPhysicInfoID.Text = string.Empty;        //情報部ＩＤ
            txtEditPhysicCopyID.Text = string.Empty;        //コピー句ＩＤ
            txtEditPhysicCopyName.Text = string.Empty;      //コピー句名称
            dgvEditItemEditor.Rows.Clear();
            dgvEditItemEditor.Tag = null;
            variableColumnCtrlForRequirement.Clear();
            variableColumnCtrlForLogic.Clear();
            this.listCPYLOG.Clear();
            this.CPYPHY = null;
            lstEditLogicif.SelectedIndex = -1;
            lstEditRequirement.SelectedIndex = -1;
            txtEditLogicifName.Text = string.Empty;
            txtEditLogicifCopyId.Text = string.Empty;
            txtEditRequirement.Text = string.Empty;
            txtEditMPaserLayoutDef.Text = string.Empty;

            //物理サブシステムが不明な場合は処理しない
            if ((subsysID == null || subsysID == string.Empty) && (file == null || file == string.Empty)) return false;

            InterfaceEdit interfaceEdit;
            T_CPYPHY cpyphy = null;
            if(file == string.Empty)
            {
                this.logger.Info(string.Format(Resources.IF_LOG_LOAD_START_I, string.Format("サブシステムＩＤ={0}, 情報部ＩＤ={1}", subsysID, infoID)));
                interfaceEdit = new InterfaceEdit(this.version,
                                                        dgvEditItemEditor,
                                                        subsysID,
                                                        infoID,
                                                        this.EditSubsystem);
                cpyphy = interfaceEdit.getPhysicCopyInfo();
                if(cpyphy == null || cpyphy.CPYPHY_STATUS == ConstantUtils.STATUS_DELELTE)
                {
                    this.logger.Info(string.Format(Resources.IF_LOG_LOAD_FAULT_I, "物理コピー句が登録されていません"));
                    MessageBox.Show(string.Format("物理コピー句が登録されていません"), Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
            }
            else
            {
                this.logger.Info(string.Format(Resources.IF_LOG_LOAD_START_I, string.Format("File={0}", file)));
                interfaceEdit = new InterfaceEdit(this.version,
                                                        dgvEditItemEditor,
                                                        file,
                                                        this.EditSubsystem);
                cpyphy = interfaceEdit.getPhysicCopyInfo();
                List<T_PHYITM> listPHYITM = interfaceEdit.getPhysicItemInfo();
                //コピー句ファイルより情報を取得し、ＤＢから取得した情報を比較する
                T_CPYPHY fileCPYPHY = interfaceEdit.getPhysicCopyInfoFromFile(file);
                List<T_PHYITM> listCopyfl = interfaceEdit.getPhysicItemInfoFromFile(file);
                bool checkResult = true;
                if(cpyphy == null || listPHYITM == null || cpyphy.CPYPHY_STATUS == ConstantUtils.STATUS_DELELTE)
                {
                    this.logger.Info(string.Format(Resources.IF_LOG_LOAD_FAULT_I, "物理コピー句が登録されていません"));
                    MessageBox.Show(string.Format("物理コピー句が登録されていません"), Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
                if(fileCPYPHY == null || listCopyfl == null)
                {
                    this.logger.Info(string.Format(Resources.IF_LOG_LOAD_FAULT_I, "物理コピー句ファイルではありません"));
                    MessageBox.Show(string.Format("物理コピー句ファイルではありません"), Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

                if (cpyphy.CPYPHY_LEVNO != fileCPYPHY.CPYPHY_LEVNO || cpyphy.CPYPHY_BCPID != fileCPYPHY.CPYPHY_BCPID)
                {
                    checkResult = false;
                }
                else
                {
                    int Max = listCopyfl.Count;
                    if (listPHYITM.Count > listCopyfl.Count) Max = listPHYITM.Count;
                    for(int i = 0; i < Max; i++)
                    {
                        if(i < listPHYITM.Count && i < listCopyfl.Count) 
                        {
                            //内容の比較
                            if(listPHYITM[i].PHYITM_LEVEL != listCopyfl[i].PHYITM_LEVEL)
                            {
                                checkResult = false;
                            }
                            if (listPHYITM[i].PHYITM_ITEMNM != listCopyfl[i].PHYITM_ITEMNM)
                            {
                                checkResult = false;
                            }
                            if (listPHYITM[i].PHYITM_CPYDTTYPE != listCopyfl[i].PHYITM_CPYDTTYPE)
                            {
                                if(string.IsNullOrEmpty(listPHYITM[i].PHYITM_CPYDTTYPE) == false && string.IsNullOrEmpty(listCopyfl[i].PHYITM_CPYDTTYPE) == false)
                                {
                                    if(listCopyfl[i].PHYITM_CPYDTTYPE != "ADDRESS" || listPHYITM[i].PHYITM_CPYDTTYPE.IndexOf("ADDRESS") != 0)
                                    {
                                        checkResult = false;
                                    }
                                }
                            }
                            if (listPHYITM[i].PHYITM_OCCURS != listCopyfl[i].PHYITM_OCCURS)
                            {
                                if (listPHYITM[i].PHYITM_OCCURS != null && listCopyfl[i].PHYITM_OCCURS != null)
                                {
                                    checkResult = false;
                                }
                            }
                        }
                        else if(i < listPHYITM.Count && i >= listCopyfl.Count)
                        {
                            checkResult = false;
                        }
                        else
                        {
                            checkResult = false;
                        }
                    }
                }
                if(checkResult == false)
                {
                    this.logger.Info(string.Format(Resources.IF_LOG_LOAD_FAULT_I, "物理コピー句ファイルの内容がＤＢの内容と異なります"));
                    MessageBox.Show(string.Format("物理コピー句ファイルの内容がＤＢの内容と異なります"), Resources.WARNING);
                    return false;
                }
            }

            grpColumn.Enabled = true;
            grpEditMPaser.Enabled = true;
            dgvEditItemEditor.Enabled = true;

            this.CPYPHY = cpyphy;
            this.OriginCPYPHY = new T_CPYPHY
            {
                CPYPHY_BCPID = cpyphy.CPYPHY_BCPID,
                CPYPHY_BCPNM = cpyphy.CPYPHY_BCPNM,
                CPYPHY_COMMENT = cpyphy.CPYPHY_COMMENT,
                CPYPHY_INFOID = cpyphy.CPYPHY_INFOID,
                CPYPHY_LEVNO = cpyphy.CPYPHY_LEVNO,
                CPYPHY_SIZE = cpyphy.CPYPHY_SIZE,
                CPYPHY_SUBSYSID = cpyphy.CPYPHY_SUBSYSID,
                CPYPHY_USERID = cpyphy.CPYPHY_USERID,
                CPYPHY_UPDTIME = cpyphy.CPYPHY_UPDTIME
            };

            txtEditPhysicSubsys.Text = this.CPYPHY.CPYPHY_SUBSYSID;     //サブシステムＩＤ
            txtEditPhysicInfoID.Text = this.CPYPHY.CPYPHY_INFOID;       //情報部ＩＤ
            txtEditPhysicCopyID.Text = this.CPYPHY.CPYPHY_BCPID;        //コピー句ＩＤ
            txtEditPhysicCopyName.Text = this.CPYPHY.CPYPHY_BCPNM;      //コピー句名称

            //ＤＢより該当情報を取得し、GroupDataGridView に反映する
            interfaceEdit.setDataGridViewFromDB();
            //論理設定条件を取得し、リストに追加する
            List<string> listCondition = ((InterfaceEdit.HeaderInfo)this.dgvEditItemEditor.Tag).conditionNames;
            foreach (string Name in listCondition)
            {
                this.lstEditRequirement.Items.Add(Name);
            }

            //Ｍパーサ定義名称を設定
            txtEditMPaserLayoutDef.Text = interfaceEdit.getLayoutDef();
            PHYPRS_LAYDEF = txtEditMPaserLayoutDef.Text;

            List<T_CPYLOG> listCpylog = ((InterfaceEdit.HeaderInfo)this.dgvEditItemEditor.Tag).cpylog;
            foreach (T_CPYLOG cpylog in listCpylog)
            {
                this.lstEditLogicif.Items.Add(cpylog.CPYLGC_OPNM);
                T_CPYLOG cpylogItem = new T_CPYLOG
                {
                    CPYLGC_INFOID  = cpylog.CPYLGC_INFOID,
                    CPYLGC_PHYSYSID = cpylog.CPYLGC_PHYSYSID,
                    CPYLGC_SUBSYSID = cpylog.CPYLGC_SUBSYSID,
                    CPYLGC_OUTPUTORDER = cpylog.CPYLGC_OUTPUTORDER,
                    CPYLGC_OPNM = cpylog.CPYLGC_OPNM,
                    CPYLGC_LCPID = cpylog.CPYLGC_LCPID,
                    CPYLGC_LEVNO = cpylog.CPYLGC_LEVNO,
                    CPYLGC_COMMENT = cpylog.CPYLGC_COMMENT,
                    CPYLGC_UPDTIME = cpylog.CPYLGC_UPDTIME,
                    CPYLGC_USERID = cpylog.CPYLGC_USERID
                };

                this.listCPYLOG.Add(cpylogItem);
            }
            //プレビュー画面に反映する
            SheetPreview.DataGridViewToCanvas(this.dgvEditItemEditor);
            if (SheetPreview.MaxPage > 0)
            {
                SheetPreview.Page = 1;
                this.cmbSheetPage.Items.Clear();
                for (int p = 0; p < SheetPreview.MaxPage; p++)
                {
                    this.cmbSheetPage.Items.Add(p + 1);
                }
                this.cmbSheetPage.SelectedIndex = 0;
                SheetPreview.ShowPreview();
            }
            StructPreview.DataGridViewToCanvas(this.dgvEditItemEditor);
            if (StructPreview.MaxPage > 0)
            {
                StructPreview.Page = 1;
                this.cmbPicturePage.Items.Clear();
                for (int p = 0; p < StructPreview.MaxPage; p++)
                {
                    this.cmbPicturePage.Items.Add(p + 1);
                }
                this.cmbPicturePage.SelectedIndex = 0;
                StructPreview.ShowPreview();
            }
            //
            ModeChange(MODE.View);
            //
            this.UpdateUser = interfaceEdit.getPhysicLastUpdateUser();
            this.logger.Info(Resources.IF_LOG_LOAD_END_I);
            return true;
        }

        private void ModeChange(MODE m)
        {
            this.mode = m;
            switch (m)
            {
                case MODE.View:
                    this.btnEditCommit.Enabled = false;//更新は無効
                    this.grpEditOutput.Enabled = true; //出力は有効
                    break;
                case MODE.Edit:
                    this.btnEditCommit.Enabled = true;  //更新は有効
                    this.grpEditOutput.Enabled = false; //出力は無効
                    break;
                case MODE.Write:
                    this.btnEditCommit.Enabled = false;//更新は無効
                    this.grpEditOutput.Enabled = true; //出力は有効
                    break;
                default:
                    break;
            }
        }
        #endregion
        #region 内部クラス
        /// <summary>
        /// 可変コラム操作クラス
        /// </summary>
        public class VariableColumnCtrl
        {
            public enum ACTION
            {
                Change,
                Add,
                Delete
            };

            /// <summary>
            /// 入力インタフェース管理
            /// </summary>
            public class InputInterface
            {
                /// <summary>
                /// 入力インタフェース
                /// </summary>
                public InputInterface()
                {
                    this.Level = 0;
                    this.Index = 0;
                    this.TextBox = null;
                    this.BlancCellValue = string.Empty;
                }
                /// <summary>
                /// 対象となるグループの階層
                /// </summary>
                public int Level { get; set; }
                /// <summary>
                /// 対象となるColumnIndexの相対位置
                /// </summary>
                public int Index { get; set; }
                /// <summary>
                /// テキストボックス
                /// </summary>
                public TextBox TextBox { get; set; }

                /// <summary>
                /// 空セルの値
                /// </summary>
                public string BlancCellValue { get; set; }
            }

            /// <summary>
            /// 追加ボタン
            /// </summary>
            public Button Add { get; set; }
            /// <summary>
            /// 削除ボタン
            /// </summary>
            public Button Del { get; set; }
            /// <summary>
            /// 変更ボタン
            /// </summary>
            public Button Rename { get; set; }
            /// <summary>
            /// 対象タグ名称
            /// </summary>
            public string Tag { get; set; }
            /// <summary>
            /// 項目の個数
            /// </summary>
            public int Count { get; }
            /// <summary>
            /// コンボボックス対象の相対位置
            /// </summary>
            public int Index { get; set; }
            /// <summary>
            /// コンボボックス対象のグループ階層
            /// </summary>
            public int Level { get; set; }
            /// <summary>
            /// 入力用コンボボックス
            /// </summary>
            public TextBox InputTextBox { get; set; }
            /// <summary>
            /// アイテム選択用リストボックス
            /// </summary>
            public ListBox SelectListBox { get; set; }
            /// <summary>
            /// 空セルの値
            /// </summary>
            public string BlankCellValue { get; set; }
            /// <summary>
            /// サブ情報入力用の入力インタフェースリスト
            /// </summary>
            public List<InputInterface> Input { get; set; }
            /// <summary>
            /// 対象となる DataGridViewEx
            /// </summary>
            public GroupDataGridView DataGridView { get; set; }

            public event VariableColumnCtrlEventHander RenameItem;
            public event VariableColumnCtrlEventHander AddItem;
            public event VariableColumnCtrlEventHander DeleteItem;
            public event VariableColumnCtrlEventHander BeforeChangeList;
            public event VariableColumnCtrlEventHander ChangeList;

            public delegate void VariableColumnCtrlEventHander(object sender, VariableColumnCtrlEvent e);

            public class VariableColumnCtrlEvent : EventArgs
            {
                public VariableColumnCtrlEvent(int index, ACTION action, List<string> values)
                {
                    this.Index = index;
                    this.Action = action;
                    this.Values = values;
                }
                public VariableColumnCtrlEvent(int index, int sourceIndex)
                {
                    this.Index = index;
                    this.SourceIndex = sourceIndex;
                    this.Action = ACTION.Change;
                }

                public int Index { get; }
                public int SourceIndex { get; }
                public ACTION Action { get; }
                public List<string> Values { get; }
            }

            protected virtual void OnRenameItem(VariableColumnCtrlEvent e)
            {
                RenameItem?.Invoke(this, e);
            }
            protected virtual void OnAddItem(VariableColumnCtrlEvent e)
            {
                AddItem?.Invoke(this, e);
            }
            protected virtual void OnDeleteItem(VariableColumnCtrlEvent e)
            {
                DeleteItem?.Invoke(this, e);
            }
            protected virtual void OnChangeList(VariableColumnCtrlEvent e)
            {
                ChangeList?.Invoke(this, e);
            }

            protected virtual void OnBeforeChangeList(VariableColumnCtrlEvent e)
            {
                BeforeChangeList?.Invoke(this, e);
            }

            private int SelectedIndex = -1;
            private int SourceIndex = -1;
            /// <summary>
            /// コンストラクタ
            /// </summary>
            /// <param name="dataGridViewEx"></param>
            /// <param name="addButton"></param>
            /// <param name="delButton"></param>
            /// <param name="renameButton"></param>
            /// <param name="textBox"></param>
            /// <param name="listBox"></param>
            /// <param name="BlancValue"></param>
            /// <param name="Input"></param>
            /// <param name="TargetTag"></param>
            /// <param name="Level"></param>
            /// <param name="Count"></param>
            public VariableColumnCtrl(GroupDataGridView dataGridViewEx, Button addButton, Button delButton, Button renameButton, ListBox listBox, TextBox textBox, string BlancValue, List<InputInterface> Input, string TargetTag, int Level, int Count)
            {
                this.DataGridView = dataGridViewEx;
                this.Add = addButton;
                this.Del = delButton;
                this.Rename = renameButton;
                this.Tag = TargetTag;
                this.InputTextBox = textBox;
                this.SelectListBox = listBox;
                this.Input = Input;
                this.Level = Level;
                this.Count = Count;
                this.BlankCellValue = BlancValue;

                this.Add.Click += new EventHandler(Add_Click);
                this.Del.Click += new EventHandler(Del_Click);
                this.Rename.Click += new EventHandler(Rename_Click);
                this.SelectListBox.SelectedIndexChanged += new EventHandler(SelectListBox_SelectedIndexChanged);
                this.SelectListBox.MouseDown += new MouseEventHandler(SelectListBox_MouseDown);
                this.SelectListBox.MouseUp += new MouseEventHandler(SelectListBox_MouseUp);
                this.InputTextBox.TextChanged += new EventHandler(updateButtonStatus);
                if(Input != null)
                {
                    foreach(InputInterface ii in Input)
                    {
                        if(ii.TextBox != null)
                        {
                            ii.TextBox.TextChanged += new EventHandler(updateButtonStatus);
                        }
                    }
                }

                //リストボックスの初期化
                this.SelectListBox.Items.Clear();
            }

            private void SelectListBox_MouseUp(object sender, MouseEventArgs e)
            {
                //移動したか検定
                if (SourceIndex == -1) return;
                int Index = SelectListBox.SelectedIndex;
                if (Index == SourceIndex) return;

                OnBeforeChangeList(new VariableColumnCtrlEvent(Index, SourceIndex));

                //リストボックス内の移動
                object tmp = SelectListBox.Items[SourceIndex];
                SelectListBox.Items.RemoveAt(SourceIndex);
                SelectListBox.Items.Insert(Index, tmp);

                int columnIndex = this.DataGridView.GetIndexVariableColumn(this.Tag)
                                    + SourceIndex * this.Count;
                int newIndex = this.DataGridView.GetIndexVariableColumn(this.Tag) 
                                    + Index * this.Count;

                //グループ名称の移動
                if(columnIndex > newIndex)
                {
                    List<string> tmpGroupName = new List<string>();
                    tmpGroupName.Add(this.DataGridView.GetGroupCellText(columnIndex, this.Level));
                    if(this.Input != null)
                    {
                        foreach (InputInterface ii in this.Input)
                        {
                            tmpGroupName.Add(this.DataGridView.GetGroupCellText(columnIndex, ii.Level));
                        }
                    }
                    for (int i = columnIndex; i > newIndex; i -= this.Count)
                    {
                        this.DataGridView.RenameGroup(i, this.Level, this.DataGridView.GetGroupCellText(i - this.Count, this.Level));
                        if(this.Input != null)
                        {
                            foreach (InputInterface ii in this.Input)
                            {
                                this.DataGridView.RenameGroup(i, ii.Level, this.DataGridView.GetGroupCellText(i - this.Count, ii.Level));
                            }
                        }
                    }
                    this.DataGridView.RenameGroup(newIndex, this.Level, tmpGroupName[0]);
                    if(this.Input != null)
                    {
                        for (int i = 0; i < this.Input.Count; i++)
                        {
                            this.DataGridView.RenameGroup(newIndex, this.Input[i].Level, tmpGroupName[i + 1]);
                        }
                    }
                }
                else
                {
                    List<string> tmpGroupName = new List<string>();
                    tmpGroupName.Add(this.DataGridView.GetGroupCellText(columnIndex, this.Level));
                    if(this.Input != null)
                    {
                        foreach (InputInterface ii in this.Input)
                        {
                            tmpGroupName.Add(this.DataGridView.GetGroupCellText(columnIndex, ii.Level));
                        }
                    }
                    for (int i = columnIndex; i < newIndex; i += this.Count)
                    {
                        this.DataGridView.RenameGroup(i, this.Level, this.DataGridView.GetGroupCellText(i + this.Count, this.Level));
                        if(this.Input != null)
                        {
                            foreach (InputInterface ii in this.Input)
                            {
                                this.DataGridView.RenameGroup(i, ii.Level, this.DataGridView.GetGroupCellText(i + this.Count, ii.Level));
                            }
                        }
                    }
                    this.DataGridView.RenameGroup(newIndex, this.Level, tmpGroupName[0]);
                    if(this.Input != null)
                    {
                        for (int i = 0; i < this.Input.Count; i++)
                        {
                            this.DataGridView.RenameGroup(newIndex, this.Input[i].Level, tmpGroupName[i + 1]);
                        }
                    }
                }


                //DataGridViewのコラム移動
                List<DataGridViewColumn> listColumn = new List<DataGridViewColumn>();
                Dictionary<int, List<DataGridViewCell>> dictionaryCells = new Dictionary<int, List<DataGridViewCell>>();
                for (int i = 0; i < this.Count; i++)
                {
                    listColumn.Add(this.DataGridView.Columns[columnIndex + i]);
                    List<DataGridViewCell> cells = new List<DataGridViewCell>();
                    foreach(DataGridViewRow row in this.DataGridView.Rows)
                    {
                        cells.Add(row.Cells[columnIndex + i]);
                    }
                    dictionaryCells.Add(i, cells);
                }
                for (int i = 0; i < this.Count; i++)
                {
                    this.DataGridView.Columns.RemoveAt(columnIndex);
                }

                for (int i = 0; i < this.Count; i++)
                {
                    listColumn[i].DisplayIndex = newIndex + i;
                    this.DataGridView.Columns.Insert(newIndex + i, listColumn[i]);
                    List<DataGridViewCell> cells = dictionaryCells[i];
                    int n = 0;
                    foreach(DataGridViewCell cell in cells)
                    {
                        DataGridViewRow row = this.DataGridView.Rows[n];
                        row.Cells[newIndex + i] = cell;
                        n++;
                    }
                }

                OnChangeList(new VariableColumnCtrlEvent(Index, SourceIndex));

                SelectListBox.SelectedIndex = Index;
            }

            private void SelectListBox_MouseDown(object sender, MouseEventArgs e)
            {
                if (SelectListBox.SelectedIndex == -1)
                {
                    SourceIndex = -1;
                    return;
                }
                SourceIndex = SelectListBox.SelectedIndex;
            }

            private void SelectListBox_SelectedIndexChanged(object sender, EventArgs e)
            {
                SelectedIndex = this.SelectListBox.SelectedIndex;
                if (SelectedIndex == -1) return;

                //ボタンの状態変更
                this.Add.Enabled = false;
                this.Del.Enabled = true;
                this.Rename.Enabled = false;

                if (this.Input != null)
                {
                    int Index = (SelectedIndex * this.Count) + this.DataGridView.GetIndexVariableColumn(this.Tag);
                    foreach (InputInterface ii in this.Input)
                    {
                        int TextIndex = Index + ii.Index;
                        if (ii.Level != 0)
                        {
                            ii.TextBox.Text = this.DataGridView.GetGroupCellText(TextIndex, ii.Level);
                        }
                        else
                        {
                            ii.TextBox.Text = this.DataGridView.Columns[TextIndex].HeaderText;
                        }
                    }
                }
                this.InputTextBox.Text = this.SelectListBox.Items[this.SelectListBox.SelectedIndex].ToString();
            }

            private void updateButtonStatus(object sender, EventArgs e)
            {
                this.Add.Enabled = false;
                this.Rename.Enabled = false;
                this.Del.Enabled = false;

                if (InputTextBox.Text.Trim() == string.Empty) return;
                
                if (this.SelectListBox.Items.Contains(InputTextBox.Text.Trim()))
                {
                    bool isBlank = false;
                    bool isChange = false;
                    if (Input != null)
                    {
                        foreach (InputInterface ii in Input)
                        {
                            if (ii.TextBox.Text.Trim() == string.Empty) isBlank = true;
                            if (GetText(this.SelectListBox.SelectedIndex, ii) != ii.TextBox.Text.Trim()) isChange = true;
                        }
                    }
                    if (isBlank == false)
                    {
                        if (isChange)
                        {
                            this.Rename.Enabled = true;
                        }
                        else
                        {
                            this.Del.Enabled = true;
                        }
                    }
                }
                else
                {
                    bool check = true;
                    if(Input != null)
                    {
                        foreach (InputInterface ii in Input)
                        {
                            if (ii.TextBox.Text.Trim() == string.Empty) check = false;
                        }
                    }
                    if (check)
                    {
                        this.Add.Enabled = true;
                        if (this.SelectListBox.SelectedIndex != -1)
                        {
                            this.Rename.Enabled = true;
                        }
                    }
                }
            }

            private string GetText(int listIndex)
            {
                int Index = (listIndex * this.Count) + this.DataGridView.GetIndexVariableColumn(this.Tag) + this.Index;
                if (this.Level != -1)
                {
                    return this.DataGridView.GetGroupCellText(Index, this.Level);
                }
                else
                {
                    return this.DataGridView.Columns[Index].HeaderText;
                }
            }
            private string GetText(int listIndex, InputInterface ii)
            {
                int Index = (listIndex * this.Count) + this.DataGridView.GetIndexVariableColumn(this.Tag) + ii.Index;
                if (ii.Level != -1)
                {
                    return this.DataGridView.GetGroupCellText(Index, ii.Level);
                }
                else
                {
                    return this.DataGridView.Columns[Index].HeaderText;
                }
            }

            private void SetText(int listIndex, string Text)
            {
                int Index = (listIndex * this.Count) + this.DataGridView.GetIndexVariableColumn(this.Tag) + this.Index;
                if (this.Level != -1)
                {
                    this.DataGridView.RenameGroup(Index, this.Level, Text);
                }
                else
                {
                    this.DataGridView.Columns[Index].HeaderText = Text;
                }
            }

            private void SetText(int listIndex, string Text, InputInterface ii)
            {
                int Index = (listIndex * this.Count) + this.DataGridView.GetIndexVariableColumn(this.Tag) + ii.Index;
                if (ii.Level != -1)
                {
                    this.DataGridView.RenameGroup(Index, ii.Level, Text);
                }
                else
                {
                    this.DataGridView.Columns[Index].HeaderText = Text;
                }
            }

            private bool IsEmpty(int listIndex)
            {
                string t = GetText(listIndex);
                if (t == BlankCellValue || t == string.Empty) return true;
                return false;
            }

            private bool IsEmpty(int listIndex, InputInterface ii)
            {
                string t = GetText(listIndex, ii);
                if (t == ii.BlancCellValue || t == string.Empty) return true;
                return false;
            }


            void Rename_Click(object sender, EventArgs e)
            {
                int renameIndex = this.SelectedIndex;
                if (this.SelectedIndex == -1)
                {
                    MessageBox.Show("更新する項目を選択してください", Resources.WARNING);
                    return;
                }
                string oldName = string.Empty;
                if (sender == this.Rename)
                {
                    oldName = GetText(this.SelectListBox.SelectedIndex);
                }
                if (this.Input != null)
                {
                    foreach (InputInterface ii in this.Input)
                    {
                        SetText(SelectedIndex, ii.TextBox.Text.Trim(), ii);
                        ii.TextBox.Text = string.Empty;
                    }
                }
                SetText(SelectedIndex, this.InputTextBox.Text.Trim());

                OnBeforeChangeList(new VariableColumnCtrlEvent(renameIndex, renameIndex));
                this.SelectListBox.Items.Insert(SelectedIndex, this.InputTextBox.Text.Trim());
                if (oldName != string.Empty)
                {
                    this.SelectListBox.Items.RemoveAt(SelectedIndex + 1);
                }
                this.InputTextBox.Text = string.Empty;
                if (sender == this.Rename)
                {
                    List<string> l = new List<string>();
                    l.Add((string)this.SelectListBox.Items[renameIndex]);
                    if(this.Input != null)
                    {
                        foreach (InputInterface ii in Input)
                        {
                            l.Add(GetText(renameIndex, ii));
                        }
                    }
                    OnRenameItem(new VariableColumnCtrlEvent(renameIndex, ACTION.Change, l));
                    OnChangeList(new VariableColumnCtrlEvent(renameIndex, renameIndex));
                }
                SelectedIndex = -1;
                this.DataGridView.Refresh();

                //ボタンの状態変更
                this.Add.Enabled = false;
                this.Del.Enabled = false;
                this.Rename.Enabled = false;
            }

            void Del_Click(object sender, EventArgs e)
            {
                if (this.SelectedIndex == -1)
                {
                    MessageBox.Show("削除する項目を選択してください", Resources.WARNING);
                    return;
                }
                List<string> l = new List<string>();
                l.Add((string)this.SelectListBox.Items[SelectedIndex]);
                if(this.Input != null)
                {
                    foreach (InputInterface ii in Input)
                    {
                        l.Add(GetText(SelectedIndex, ii));
                    }
                }
                int delIndex = this.SelectedIndex;
                Delete(this.SelectedIndex);
                this.InputTextBox.Text = string.Empty;
                if (this.Input != null)
                {
                    foreach (InputInterface ii in this.Input)
                    {
                        ii.TextBox.Text = string.Empty;
                    }
                }
                OnDeleteItem(new VariableColumnCtrlEvent(delIndex, ACTION.Delete, l));
                OnChangeList(new VariableColumnCtrlEvent(-1, delIndex));
                this.SelectedIndex = -1;
                this.DataGridView.Refresh();

                //ボタンの状態変更
                this.Add.Enabled = false;
                this.Del.Enabled = false;
                this.Rename.Enabled = false;
            }

            /// <summary>
            /// 削除
            /// </summary>
            /// <param name="SelectedIndex"></param>
            public void Delete(int SelectedIndex)
            {
                OnBeforeChangeList(new VariableColumnCtrlEvent(-1, SelectedIndex));

                int Index = (SelectedIndex * this.Count) + this.DataGridView.GetIndexVariableColumn(this.Tag);
                int Count = (this.DataGridView.GetCountVariableColumn(this.Tag) / this.Count);
                if (Count > 1)
                {
                    for (int i = 0; i < this.Count; i++)
                    {
                        this.DataGridView.RemoveVariableColumn(this.Tag, Index - this.DataGridView.GetIndexVariableColumn(this.Tag));
                    }
                    this.SelectListBox.Items.RemoveAt(SelectedIndex);
                }
                else
                {
                    if (this.Input != null)
                    {
                        foreach (InputInterface ii in this.Input)
                        {
                            SetText(SelectedIndex, string.Empty, ii);
                        }
                    }
                    SetText(SelectedIndex, this.BlankCellValue);
                    for (int i = Index; i < Index + this.Count; i++)
                    {
                        for (int Row = 0; Row < this.DataGridView.RowCount; Row++)
                        {
                            this.DataGridView.Rows[Row].Cells[i].Value = null;
                        }
                    }
                    this.SelectListBox.Items.RemoveAt(SelectedIndex);
                }
            }

            public void Clear()
            {
                int Count = this.SelectListBox.Items.Count;
                for (int i = (Count - 1); i >= 0; i--)
                {
                    Delete(i);
                }
                this.SelectedIndex = -1;
                this.DataGridView.Refresh();

                //ボタンの状態変更
                this.Add.Enabled = false;
                this.Del.Enabled = false;
                this.Rename.Enabled = false;
            }

            void Add_Click(object sender, EventArgs e)
            {
                if (this.SelectedIndex != -1 && this.InputTextBox.Text.Trim() == this.SelectListBox.Items[this.SelectedIndex].ToString())
                {
                    MessageBox.Show("既に追加されています。\n更新または削除してください。", Resources.WARNING);
                    return;
                }
                int Index = this.DataGridView.GetIndexVariableColumn(this.Tag);

                OnBeforeChangeList(new VariableColumnCtrlEvent(this.SelectListBox.Items.Count, -1));
                //先頭エントリに値が設定されているかチェックする
                if (IsEmpty(0) == false)
                {
                    int MaxLv;
                    int TopLv = -1;
                    if (this.Input == null)
                    {
                        MaxLv = this.DataGridView.GetGroupMaxLevel(Index);
                    }
                    else
                    {
                        MaxLv = 0;
                        foreach (InputInterface ii in this.Input)
                        {
                            if (MaxLv < (ii.Level - 1))
                            {
                                MaxLv = (ii.Level - 1);
                            }
                            if (TopLv > (ii.Level - 1) || TopLv == -1)
                            {
                                TopLv = ii.Level - 1;
                            }
                        }
                    }
                    //追加
                    GroupDataGridView.GroupCell groupCell = null;
                    if (this.Input != null)
                    {
                        int variableIndex = this.DataGridView.GetIndexVariableColumn(this.Tag);

                        GroupDataGridView.GroupCell gcell;
                        gcell = this.DataGridView.GetGroupCell(variableIndex, TopLv);
                        groupCell = new GroupDataGridView.GroupCell();
                        groupCell.Alignment = gcell.Alignment;
                        groupCell.BackColor = gcell.BackColor;
                        groupCell.ForeColor = gcell.ForeColor;
                        groupCell.LineAlignment = gcell.LineAlignment;
                        groupCell.Count = this.Count;

                        GroupDataGridView.GroupCell cell = groupCell;
                        for (int n = 1; n < MaxLv; n++)
                        {
                            GroupDataGridView.GroupCell ChildCell = new GroupDataGridView.GroupCell();
                            gcell = this.DataGridView.GetGroupCell(variableIndex, TopLv + n);
                            ChildCell.Alignment = gcell.Alignment;
                            ChildCell.BackColor = gcell.BackColor;
                            ChildCell.ForeColor = gcell.ForeColor;
                            ChildCell.LineAlignment = gcell.LineAlignment;
                            ChildCell.Count = this.Count;
                            cell.ChildCells.Add(ChildCell);
                        }
                    }

                    this.DataGridView.InsertVariableColumn(this.Tag,
                                                            MaxLv,
                                                            groupCell,
                                                            this.DataGridView.GetCountVariableColumn(this.Tag) - 1,
                                                            this.Count
                                                            );
                }
                //更新ボタンを呼び出す
                this.SelectedIndex = this.SelectListBox.Items.Count;
                this.Rename_Click(sender, e);
                List<string> l = new List<string>();
                l.Add((string)this.SelectListBox.Items[SelectListBox.Items.Count - 1]);
                if (Input != null)
                {
                    foreach (InputInterface ii in Input)
                    {
                        l.Add(GetText(SelectListBox.Items.Count - 1, ii));
                    }
                }
                OnAddItem(new VariableColumnCtrlEvent(SelectListBox.Items.Count - 1, ACTION.Add, l));
                OnChangeList(new VariableColumnCtrlEvent(SelectListBox.Items.Count - 1, -1));
            }
        }


        #endregion
        #endregion

        #region メニュー操作
        private void tsmInsert_Click(object sender, EventArgs e)
        {
            //選択行がない場合
            if(this.dgvEditItemEditor.SelectedRows.Count == 0)
            {
                if (sender == this.tsmInsertUp)
                {
                    InterfaceEdit.EditInfo editInfo = new InterfaceEdit.EditInfo(InterfaceEdit.EditInfo.EditTypes.Add, 0);
                    this.EditInfos.Add(editInfo);
                    this.dgvEditItemEditor.Rows.Insert(0, 1);
                }
                else
                {
                    InterfaceEdit.EditInfo editInfo = new InterfaceEdit.EditInfo(InterfaceEdit.EditInfo.EditTypes.Add, this.dgvEditItemEditor.RowCount);
                    this.EditInfos.Add(editInfo);
                    this.dgvEditItemEditor.Rows.Add();
                }
            }
            else
            {
                for(int i=0; i< this.dgvEditItemEditor.SelectedRows.Count; i++)
                {
                    if (sender == this.tsmInsertUp)
                    {
                        InterfaceEdit.EditInfo editInfo = new InterfaceEdit.EditInfo(InterfaceEdit.EditInfo.EditTypes.Add, this.dgvEditItemEditor.SelectedRows[i].Index);
                        this.EditInfos.Add(editInfo);
                        this.dgvEditItemEditor.Rows.Insert(this.dgvEditItemEditor.SelectedRows[i].Index, 1);
                    }
                    else
                    {
                        InterfaceEdit.EditInfo editInfo = new InterfaceEdit.EditInfo(InterfaceEdit.EditInfo.EditTypes.Add, this.dgvEditItemEditor.SelectedRows[i].Index + 1);
                        this.EditInfos.Add(editInfo);
                        this.dgvEditItemEditor.Rows.Insert(this.dgvEditItemEditor.SelectedRows[i].Index + 1, 1);
                    }
                }
            }
        }

        /// <summary>
        /// メニュー・削除を押下した場合
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tsmRemove_Click(object sender, EventArgs e)
        {
            //選択行が無い場合は何もしない
            if (this.dgvEditItemEditor.SelectedRows.Count == 0)
            {
                return;
            }
            //選択行を削除する
            int Count = this.dgvEditItemEditor.SelectedRows.Count;
            List<int> listSelectedRow = new List<int>();
            for(int i=0;i<Count;i++)
            {
                InterfaceEdit.EditInfo editInfo = new InterfaceEdit.EditInfo(InterfaceEdit.EditInfo.EditTypes.Delete, i);
                if (this.dgvEditItemEditor.SelectedRows[i].Tag != null) //Tagがある = 新規行ではない
                {
                    //編集情報に該当行の内容を設定
                    editInfo.RowInfo = (InterfaceEdit.RowInfo)this.dgvEditItemEditor.SelectedRows[i].Tag;
                    ModeChange(MODE.Edit);
                }
                this.EditInfos.Add(editInfo);
                listSelectedRow.Add(this.dgvEditItemEditor.SelectedRows[i].Index);
            }
            listSelectedRow.Sort();
            //実際の削除処理
            for (int i = 0; i < Count; i++)
            {
                this.dgvEditItemEditor.Rows.RemoveAt(listSelectedRow[Count - i -1]);
            }
        }
        #endregion
      
        #region　登録画面
        private void Excute_Click(object sender, EventArgs e)
        {
            String inputPath = txtInputPath.Text;
            String infoId = txtInfoId.Text;
            String subSysId = cmbSubSysID.SelectedValue == null ? null : cmbSubSysID.SelectedValue.ToString();
            String addressSize = cmbAddSize.SelectedItem == null ? null : cmbAddSize.SelectedItem.ToString();
            try
            {
                var checkedButton = inputTypeGBox.Controls.OfType<RadioButton>().FirstOrDefault(r => r.Checked);

                if (RdoCopyku.Checked)
                {
                    if (subSysId == String.Empty)
                    {
                        MessageBox.Show("サブシステムＩＤを入れてください。", "情報", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    if (infoId == String.Empty)
                    {
                        MessageBox.Show("情報部ＩＤを入れてください。", "情報", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    if (addressSize == null)
                    {
                        MessageBox.Show("ＡＤＤＲＥＳＳサイズを入れてください。", "情報", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    if (inputPath == String.Empty)
                    {
                        MessageBox.Show("入力ファイルを入れてください。", "情報", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    if (infoId.Count() > 20)
                    {
                        MessageBox.Show(Resources.CKR00010_E, "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    if (File.Exists(inputPath) == false)
                    {
                        MessageBox.Show("対象ファイル（ＣＯＢＯＬファイル）が存在しません。", "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    if (Path.GetExtension(inputPath) != ".cbl")
                    {
                        MessageBox.Show("入力したファイルはにＣＯＢＯＬファイルになっていません。", "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }                

                    PhysicalCopyKuReadProcess instance = new PhysicalCopyKuReadProcess(version);
                    Boolean result = instance.CopyKuFileReadAndRegisterProcess(inputPath, infoId, subSysId, addressSize, this.version.User.USERID);

                    if (result)
                    {
                        MessageBox.Show(string.Format(Resources.CKR00005_I, Path.GetFileName(inputPath)), "情報", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                    else
                    {
                        MessageBox.Show(string.Format(Resources.CKR00006_E, Path.GetFileName(inputPath)), "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }

                if (RdoItemInfoFile.Checked)
                {
                    if (subSysId == String.Empty)
                    {
                        MessageBox.Show("サブシステムＩＤを入れてください。", "情報", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    if (infoId == String.Empty)
                    {
                        MessageBox.Show("情報部ＩＤを入れてください。", "情報", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    if (inputPath == String.Empty)
                    {
                        MessageBox.Show("入力ファイルを入れてください。", "情報", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    if (infoId.Count() > 20)
                    {
                        MessageBox.Show(Resources.IDR00011_E, "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    if (File.Exists(inputPath) == false)
                    {
                        MessageBox.Show("入力ファイルが存在しません。", "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    string ext = (Path.GetExtension(inputPath));
                    if(!(ext == ".xls" || ext == ".xlsx"))
                    {
                        
                        MessageBox.Show("入力ファイルはＥＸＣＥＬファイルになっていません。", "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }                   
                    
                    ItemDescriptionReadProcess instance = new ItemDescriptionReadProcess(this.version);
                    Boolean result = instance.ItemDescriptionReadAndUpdateProcess(inputPath, subSysId, infoId,  this.version.User.USERID);
                    if (result)
                    {
                        MessageBox.Show(string.Format(Resources.IDR00007_I, infoId, "情報", MessageBoxButtons.OK, MessageBoxIcon.Information));
                        return;                     
                    }
                    else
                    {
                        MessageBox.Show(string.Format(Resources.IDR00006_E, infoId, "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error));
                        return;                       
                    }
                }

                if (RdoCopyKuToolRefSheet.Checked)
                {
                    if (inputPath == String.Empty)
                    {
                        MessageBox.Show("入力ファイルを入れてください。", "情報", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    if (File.Exists(inputPath) == false)
                    {
                        MessageBox.Show("入力ファイルが存在しません。", "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    if (Path.GetExtension(inputPath) != ".xlsm")
                    {
                        MessageBox.Show("入力ファイルはＥＸＣＥＬファイルになっていません。", "情報", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    if (addressSize == null)
                    {
                        MessageBox.Show("ＡＤＤＲＥＳＳサイズを入れてください。", "情報", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                    ToolRefSheetReadProcess instance = new ToolRefSheetReadProcess(version);
                    List<String> result = instance.ToolRefSheetReadAndRegisterProcess(inputPath, this.version.User.USERID, this.version.getModifiableSubsysList(), addressSize);
                    if (result.Count == 0)
                    {
                        MessageBox.Show("ツール専用シートの読み込み処理が完了しました。出力タブよりコピー句を出力して下さい。", "情報", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;

                    }
                    else
                    {
                        int i = 0;
                        StringBuilder builder = new StringBuilder();
                        foreach(String str in result)
                        {
                            i++;
                            builder.Append(str);
                            if(i != result.Count)
                            {
                                builder.Append("、");
                            }
                        }
                        MessageBox.Show(string.Format("入力ファイルのシート「{0}」の読み込み処理が異常終了しました。エラー内容はログファイルに確認してください。", builder.ToString()), 
                           "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
            }
            catch (CopyKuInfoReadProcessException ex)
            {
                MessageBox.Show(ex.Message, "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            if (RdoCopyku.Checked)
            {
                openFileDialog1.Filter = "Cobol Files (.cbl)|*.cbl|All Files (*.*)|*.*";
            }

            else if(RdoItemInfoFile.Checked)
            {
                openFileDialog1.Filter = "Excel Files|*.xls;*.xlsx|All Files (*.*)|*.*";
            }
            else if (RdoCopyKuToolRefSheet.Checked)
            {
                openFileDialog1.Filter = "Excel files |*.xlsm|All Files (*.*)|*.*";
            }

            // Set filter options and filter index.

            openFileDialog1.FilterIndex = 1;

            openFileDialog1.Multiselect = false;

            DialogResult result = openFileDialog1.ShowDialog();

            if (result == DialogResult.OK)
            {
                txtInputPath.Text = openFileDialog1.FileName;
            }
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            txtInputPath.Text = "";
            cmbSubSysID.SelectedIndex = -1;
            txtInfoId.Text = "";
            cmbAddSize.SelectedItem = null;
        }

        private void RdoCopyku_CheckedChanged(object sender, EventArgs e)
        {
            txtInfoId.Enabled = true;
            cmbSubSysID.Enabled = true;
            cmbAddSize.Enabled = true;
        }

        private void RdoItemInfoFile_CheckedChanged(object sender, EventArgs e)
        {
            txtInfoId.Enabled = true;
            cmbSubSysID.Enabled = true;
            cmbAddSize.SelectedItem = null;
            cmbAddSize.Enabled = false;
        }       

        private void RdoCopyKuToolRefSheet_CheckedChanged(object sender, EventArgs e)
        {
            cmbSubSysID.SelectedIndex = -1;
            cmbSubSysID.Enabled = false;
            txtInfoId.Enabled = false;           
            cmbAddSize.Enabled = true;           
        }

        private void Interface_Load(object sender, EventArgs e)
        {
            List<string> lst = new List<string>();
            lst.Add("");
            lst.AddRange(version.getModifiableSubsysList());
            this.cmbSubSysID.DataSource = lst;
            //編集画面のサブシステムＩＤを設定
            cmbEditTargetSubsys.Items.AddRange(version.getModifiableSubsysList().ToArray());
            //出力画面のサブシステムＩＤを設定
            List<string> phySysLst = new List<string>();
            phySysLst.Add("");
            phySysLst.AddRange(version.getAllSubsysList());
            this.combInitSubSysID.DataSource = phySysLst;
            //出力画面の論理サブシステムＩＤを設定
            List<string> logSysLst = new List<string>();
            logSysLst.Add("");
            logSysLst.AddRange(version.getAllSubsysList());
            this.combLogSubSysID.DataSource = logSysLst;
        }

        #endregion

        #region アイテム説明書
        private void cmbSheetPage_SelectedIndexChanged(object sender, EventArgs e)
        {
            //選択した頁のプレビューを表示する
            if(int.TryParse(this.cmbSheetPage.Text, out int iPage))
            {
                this.SheetPreview.Page = iPage;
                this.SheetPreview.ShowPreview();
            }
        }
        private void btnSheetPagepre_Click(object sender, EventArgs e)
        {
            if(this.cmbSheetPage.SelectedIndex > 0)
            {
                this.cmbSheetPage.SelectedIndex--;
            }
        }
        private void btnSheetPagenext_Click(object sender, EventArgs e)
        {
            if (this.cmbSheetPage.SelectedIndex < (this.cmbSheetPage.Items.Count - 1))
            {
                this.cmbSheetPage.SelectedIndex++;
            }
        }
        private void btnSheetSave_Click(object sender, EventArgs e)
        {
            //ファイル保存のダイアログで選択したファイルに出力する
            string Name;
            if (this.CPYPHY == null)
            {
                Name = "UnKnown";
            }
            else
            {
                Name = CPYPHY.CPYPHY_BCPNM;
            }
            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter = "Excel Files|*.xlsx|All Files|*",
                FilterIndex = 0,
                FileName = string.Format("アイテム説明書（{0}）.xlsx", Name),
                AddExtension = true
            };
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string msg = string.Empty;
                MessageBoxIcon errLevel = MessageBoxIcon.None;
                try
                {
                    WaitDialog.Show(this);
                    this.logger.Info(string.Format(Resources.IF_LOG_OUTPUT_START_I,
                                                   Path.GetDirectoryName(saveFileDialog.FileName)));
                    if (this.SheetPreview.SaveXlsxFile(saveFileDialog.FileName))
                    {
                        this.logger.Info(string.Format(Resources.IF_LOG_SHEET_FILEOUT_I,
                                                       Path.GetFileName(saveFileDialog.FileName)));
                        this.logger.Info(string.Format(Resources.IF_LOG_OUTPUT_END_I, 1, 0));
                        errLevel = MessageBoxIcon.Information;
                        msg = "保存が完了しました";
                    }
                    else
                    {
                        this.logger.Info(string.Format(Resources.IF_LOG_SHEET_FILEOUT_E,
                                                       Path.GetFileName(saveFileDialog.FileName)));
                        this.logger.Info(string.Format(Resources.IF_LOG_OUTPUT_END_I, 0, 1));
                        errLevel = MessageBoxIcon.Error;
                        msg = "保存に失敗しました";
                    }
                }
                finally
                {
                    WaitDialog.Close();
                    if(errLevel == MessageBoxIcon.Information)
                    {
                        MessageBox.Show(msg, Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else if(errLevel == MessageBoxIcon.Error)
                    {
                        MessageBox.Show(msg, Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
        #endregion

        #region アイテム構成図
        private void cmbPicturePage_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (int.TryParse(this.cmbPicturePage.Text, out int iPage))
            {
                this.StructPreview.Page = iPage;
                this.StructPreview.ShowPreview();
            }
        }
        private void btnPicturePagepre_Click(object sender, EventArgs e)
        {
            if (this.cmbPicturePage.SelectedIndex > 0)
            {
                this.cmbPicturePage.SelectedIndex--;
            }
        }
        private void btnPicturePagenext_Click(object sender, EventArgs e)
        {
            if (this.cmbPicturePage.SelectedIndex < (this.cmbPicturePage.Items.Count - 1))
            {
                this.cmbPicturePage.SelectedIndex++;
            }
        }
        private void btnPictureSave_Click(object sender, EventArgs e)
        {
            //ファイル保存のダイアログで選択したファイルに出力する
            string Name;
            if (this.CPYPHY == null)
            {
                Name = "UnKnown";
            }
            else
            {
                Name = this.CPYPHY.CPYPHY_BCPNM;
            }
            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter = "Excel Files|*.xlsx|All Files|*",
                FilterIndex = 0,
                FileName = string.Format("アイテム構成図（{0}）.xlsx", Name),
                AddExtension  = true
            };
            if(saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                this.logger.Info(string.Format(Resources.IF_LOG_OUTPUT_START_I,
                                               Path.GetDirectoryName(saveFileDialog.FileName)));

                string msg = string.Empty;
                MessageBoxIcon errLevel = MessageBoxIcon.None;
                try
                {
                    WaitDialog.Show(this);
                    if (this.StructPreview.SaveXlsxFile(saveFileDialog.FileName))
                    {
                        this.logger.Info(string.Format(Resources.IF_LOG_STRUCT_FILEOUT_I,
                                                       Path.GetFileName(saveFileDialog.FileName)));
                        this.logger.Info(string.Format(Resources.IF_LOG_OUTPUT_END_I, 1, 0));
                        msg = "保存が完了しました";
                        errLevel = MessageBoxIcon.Information;
                    }
                    else
                    {
                        this.logger.Info(string.Format(Resources.IF_LOG_STRUCT_FILEOUT_E,
                                                       Path.GetFileName(saveFileDialog.FileName)));
                        this.logger.Info(string.Format(Resources.IF_LOG_OUTPUT_END_I, 0, 1));
                        msg = "保存に失敗しました";
                        errLevel = MessageBoxIcon.Error;
                    }
                }
                finally
                {
                    WaitDialog.Close();
                    if (errLevel == MessageBoxIcon.Information)
                    {
                        MessageBox.Show(msg, Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else if (errLevel == MessageBoxIcon.Error)
                    {
                        MessageBox.Show(msg, Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
        #endregion

        #region Ｔａｂ
        private void tabControl1_Selecting(object sender, TabControlCancelEventArgs e)
        {
            switch (this.tabPageIndex)
            {
                case 1:         // 編集画面
                case 2:         // アイテム説明書
                case 3:         // アイテム構成図
                    if (e.TabPageIndex != 1 && e.TabPageIndex != 2 && e.TabPageIndex != 3) 
                    {
                        if (this.mode == MODE.Edit)             //編集しているが更新していない
                        {
                            if (MessageBox.Show(Resources.IF_MSG_CANCEL, Resources.QUESTION, MessageBoxButtons.YesNo) == DialogResult.No)
                            {
                                e.Cancel = true;
                            }
                        }
                        else if (this.mode == MODE.Write)      //更新したがファイル出力していない
                        {
                            if (MessageBox.Show(Resources.IF_MSG_ASK_OUTPUT, Resources.QUESTION, MessageBoxButtons.YesNo) == DialogResult.No)
                            {
                                e.Cancel = true;
                            }
                        }
                    }
                    break;
                default:
                    break;
            }

            if (e.Cancel == false)
            {
                this.tabPageIndex = e.TabPageIndex;
            }
        }

        #endregion

        private void groupBox5_Enter(object sender, EventArgs e)
        {

        }

        private void label20_Click(object sender, EventArgs e)
        {

        }

        #region 出力画面の処理

        #region 出力画面の検索ボタンの処理

        /// <summary>
        /// バージョンモデル
        /// </summary>
        protected mysqlcontext Context
        {
            get
            {
                return version.context;
            }
        }
        /// <summary>
        /// 検索最大件数
        /// </summary>
        protected const int MAX_COUNT = 50;

        /// <summary>
        /// データ一覧コントロール
        /// </summary>       
        private CheckDataGridView CheckDgv { get; set; }

        /// <summary>
        /// 検索
        /// </summary> 
        private void btnSearchOutput_Click_1(object sender, EventArgs e)
        {
            string msg = string.Empty;
            MessageBoxIcon ErrLevel = MessageBoxIcon.None;
            try
            {
                WaitDialog.Show(this);
                
                List<T_CPYPHY> cpyPhyInfoLists = this.CPYPHYSearchData();
                this.Clear();
                var count = cpyPhyInfoLists.Count();
                if (count == 0)
                {
                    msg = "検索データが存在しませんでした。";
                    ErrLevel = MessageBoxIcon.Information;
                    return;
                }

                if (this.dgvPhyData.Tag is CheckBox)
                {
                    (this.dgvPhyData.Tag as CheckBox).Enabled = true;
                }

                if (count > MAX_COUNT)
                {
                    cpyPhyInfoLists = cpyPhyInfoLists.Take(MAX_COUNT).ToList();
                    msg = $"{displayCnt}件を検索しましたが、{MAX_COUNT}件のみを表示します。";
                    displayCnt = 0;
                    ErrLevel = MessageBoxIcon.Information;
                }
                this.SetDgv(cpyPhyInfoLists);
            }
            catch (Exception exp)
            {
                this.logger.Error(exp, version.User.USERID + " " + "物理コピー句情報検索する時、エラーが発生しました");
                msg = "物理コピー句情報検索する時、エラーが発生しました";
                ErrLevel = MessageBoxIcon.Error;
                return;
            }
            finally
            {
                WaitDialog.Close();
                if(ErrLevel == MessageBoxIcon.Information)
                {
                    MessageBox.Show(msg, Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if (ErrLevel == MessageBoxIcon.Error)
                {
                    MessageBox.Show(msg, Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// 検索
        /// </summary>
        private List<T_CPYPHY> CPYPHYSearchData()
        {
                IQueryable<T_CPYPHY> phyData = null;
                // 画面からサブシステムＩＤの取得
                var index = this.combInitSubSysID.SelectedIndex;
                String subSysId = this.combInitSubSysID == null || index < 0 ? "" : this.combInitSubSysID.Items[index].ToString();
                // 画面から情報部ＩＤの取得
                String infoID = this.txtInitInfoId.Text;

                if (this.rdoRDataTbId.Checked)
                {
                    // コピー句ＩＤ
                    var copyKuID = this.txtCopyKuID.Text;
                    copyKuID = string.IsNullOrWhiteSpace(copyKuID) ? string.Empty : copyKuID;
                    phyData = this.Context.T_CPYPHY.AsNoTracking().Where(
                        r => r.CPYPHY_BCPID.Contains(copyKuID) && r.CPYPHY_INFOID.Contains(infoID) &&
                        (r.CPYPHY_SUBSYSID == subSysId || string.Empty.Equals(subSysId)) && (!r.CPYPHY_STATUS.Equals("1"))
                        ).Take(MAX_COUNT + 1);
                
                    if (phyData.Count() > MAX_COUNT)
                    {
                        displayCnt = this.Context.T_CPYPHY.AsNoTracking().Count(
                            r => r.CPYPHY_BCPID.Contains(copyKuID) && r.CPYPHY_INFOID.Contains(infoID) &&
                        (r.CPYPHY_SUBSYSID == subSysId || string.Empty.Equals(subSysId)) && (!r.CPYPHY_STATUS.Equals("1")));
                    }
                }
                else
                {
                    // コピー句名
                    var copyKuNm = this.txtCopyKuNm.Text;
                    copyKuNm = string.IsNullOrWhiteSpace(copyKuNm) ? string.Empty : copyKuNm;
                    phyData = this.Context.T_CPYPHY.AsNoTracking().Where(
                        r => r.CPYPHY_BCPNM.Contains(copyKuNm) && r.CPYPHY_INFOID.Contains(infoID) &&
                        (r.CPYPHY_SUBSYSID == subSysId || string.Empty.Equals(subSysId)) && (!r.CPYPHY_STATUS.Equals("1"))
                        ).Take(MAX_COUNT + 1);

                    if (phyData.Count() > MAX_COUNT)
                    {
                        displayCnt = this.Context.T_CPYPHY.AsNoTracking().Count(
                            r => r.CPYPHY_BCPNM.Contains(copyKuNm) && r.CPYPHY_INFOID.Contains(infoID) &&
                        (r.CPYPHY_SUBSYSID == subSysId || string.Empty.Equals(subSysId)) && (!r.CPYPHY_STATUS.Equals("1")));
                    }
                }
                return phyData.ToList();
        }

        /// <summary>
        /// 検索したデータが一覧に表示する
        /// </summary>
        /// <param name="queryDatas"></param>
        private void SetDgv(List<T_CPYPHY> queryDatas)
        {
            var fields = new List<string>();
            foreach (var record in queryDatas.ToList())
            {
                fields.Clear();
                // 選択列
                fields.Add("0");
                // 情報部ＩＤ
                fields.Add(record.CPYPHY_INFOID);
                // コピー句ＩＤ
                fields.Add(record.CPYPHY_BCPID);
                // コピー句名
                fields.Add(record.CPYPHY_BCPNM);

                var index = this.dgvPhyData.Rows.Add(fields.ToArray());
                var row = this.dgvPhyData.Rows[index].Tag = record;

            }
        }

        /// <summary>
        /// 画面クリア処理
        /// </summary>
        private void Clear()
        {
            this.dgvPhyData.Rows.Clear();
            if (this.dgvPhyData.Tag is CheckBox)
            {
                (this.dgvPhyData.Tag as CheckBox).Enabled = false;
                
            }
            (this.dgvPhyData.Tag as CheckBox).Checked = false;
            this.ChangeStatus(true);
        }

        /// <summary>
        /// 一覧に行のチェック状態変更
        /// </summary>
        /// <param name="nodata"></param>
        private void ChangeStatus(bool nodata)
        {
            if (!nodata)
            {
                this.groupBox7.Enabled = true;
            }
            else
            {
                this.groupBox7.Enabled = false;
            }
        }

        #endregion

        #region 出力画面の出力ボタン処理

        /// <summary>
        /// 出力
        /// </summary>
        /// <param name="queryDatas"></param>
        private void btnOutput_Click_1(object sender, EventArgs e)
        {
            List<string> listCompleteFiles = new List<string>();        // 出力が完了したファイルのリスト
            List<string> listErrFiles = new List<string>();             // 出力に失敗したファイルのリスト
            try
            {
                if (!Directory.Exists(this.txtOutputPath.Text))
                {
                    MessageBox.Show("出力パスに指定したファイルパスが不正です。正しいファイルパスを入力してください。",
                        Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                var result = MessageBox.Show("出力処理を行いますか?",
                             Resources.QUESTION, MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (result == DialogResult.Cancel) return;

                bool first = true;
                var rows = this.dgvPhyData.Rows.Cast<DataGridViewRow>().Where(r => "1".Equals(r.Cells[0].Value));

                this.logger.Info(version.User.USERID + " " + string.Format(Resources.IF_LOG_OUTPUT_START_I, Path.GetFullPath(this.txtOutputPath.Text)));
                WaitDialog.Show(this);
                foreach (DataGridViewRow row in rows)
                {
                    try
                    {
                        bool outFlg = false;
                        var cpyPhyData = row.Tag as T_CPYPHY;
                        if (cpyPhyData == null) continue;

                        // 設定条件表の出力
                        if (this.chkSettingCond.Checked)
                        {
                            try
                            {
                                SetCondTblCreation instance = new SetCondTblCreation(this.version);
                                outFlg = instance.CreateSettingConditionTable(cpyPhyData.CPYPHY_BCPID, cpyPhyData.CPYPHY_BCPNM, this.txtOutputPath.Text);
                                if (outFlg)
                                {
                                    listCompleteFiles.Add(Path.GetFileName("設定条件表"));
                                }
                                else
                                {
                                    listErrFiles.Add(Path.GetFileName("設定条件表"));
                                }
                            }
                            catch (SettingConditionException ex)
                            {
                                if (ex.GetMessage().Equals(LogUtils.GetMsgInfo(Resources.SCT00003_E, string.Empty)))
                                {
                                    MessageBox.Show(LogUtils.GetMsgInfo(Resources.SCT00003_E, string.Empty),
                                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    return;
                                }
                                //this.logger.Error(version.User.USERID + " " + ex.Message);
                                listErrFiles.Add(Path.GetFileName("設定条件表"));
                            }
                        }

                        outFlg = false;
                        // 物理/論理マッピングの出力
                        if (this.chkPhyLogMapping.Checked)
                        {
                            try
                            {
                                // 画面からサブシステムＩＤの取得
                                var index = this.combLogSubSysID.SelectedIndex;
                                String logSubSysId = this.combLogSubSysID == null || index < 0 ? "" : this.combLogSubSysID.Items[index].ToString();

                                PhyLogMapTblCreation instance = new PhyLogMapTblCreation(this.version);
                                outFlg = instance.CreateMappingTable(cpyPhyData.CPYPHY_BCPID, cpyPhyData.CPYPHY_BCPNM,
                                    logSubSysId, this.txtOutputPath.Text);
                                if (outFlg)
                                {
                                    listCompleteFiles.Add(Path.GetFileName("物理/論理マッピング表"));
                                }
                                else
                                {
                                    listErrFiles.Add(Path.GetFileName("物理/論理マッピング表"));
                                }
                            }
                            catch (PhysicalLogicalMappingException ex)
                            {
                                if (ex.GetMessage().Equals(LogUtils.GetMsgInfo(Resources.PLM00003_E, string.Empty)))
                                {
                                    MessageBox.Show(LogUtils.GetMsgInfo(Resources.PLM00003_E, string.Empty),
                                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    return;
                                }
                                //this.logger.Error(version.User.USERID + " " + ex.Message);
                                listErrFiles.Add(Path.GetFileName("物理/論理マッピング表"));
                            }
                        }

                        // 物理コピー句の出力
                        if (this.chkPhyCpyKu.Checked)
                        {
                            string file = Path.GetFullPath(string.Format("{0}\\{1}.cbl", txtOutputPath.Text.Trim(), cpyPhyData.CPYPHY_BCPID));
                            InterfaceEdit interfaceEdit = new InterfaceEdit(this.version,
                                                                            null,
                                                                            cpyPhyData.CPYPHY_SUBSYSID,
                                                                            cpyPhyData.CPYPHY_INFOID,
                                                                            null);
                            if (interfaceEdit.checkDB())
                            {
                                try
                                {
                                    using (StreamWriter sw = new StreamWriter(file, false, Encoding.GetEncoding(System.Configuration.ConfigurationManager.AppSettings["Encoding"])))
                                    {
                                        sw.Write(interfaceEdit.getPhysicCopyphraseFromDB());
                                    }
                                    listCompleteFiles.Add(Path.GetFileName(file));
                                    this.logger.Info(version.User.USERID + " " + string.Format(Resources.IF_LOG_PHYSIC_FILEOUT_I, Path.GetFileName(file)));
                                }
                                catch (Exception ex)
                                {
                                    this.logger.Error(ex, version.User.USERID + " " + string.Format(Resources.IF_LOG_PHYSIC_FILEOUT_E, Path.GetFileName(file)));
                                    listErrFiles.Add(Path.GetFileName(file));
                                }
                            }
                            else
                            {
                                this.logger.Error(version.User.USERID + " " + string.Format(Resources.IF_LOG_PHYSIC_FILEOUT_E, Path.GetFileName(file)));
                                listErrFiles.Add(Path.GetFileName(file));
                            }
                        }

                        // 論理コピー句の出力
                        if (this.chkLogCpyKu.Checked)
                        {
                            if (combLogSubSysID.Text != string.Empty)
                            {
                                InterfaceEdit interfaceEdit = new InterfaceEdit(this.version,
                                                                                null,
                                                                                cpyPhyData.CPYPHY_SUBSYSID,
                                                                                cpyPhyData.CPYPHY_INFOID,
                                                                                combLogSubSysID.Text);
                                if (interfaceEdit.checkDB())
                                {
                                    Dictionary<string, string> logicSource = interfaceEdit.getLogicCopyPharseFromDB();
                                    foreach (string key in logicSource.Keys)
                                    {
                                        string file = Path.GetFullPath(string.Format("{0}\\{1}.cbl", txtOutputPath.Text.Trim(), key));
                                        try
                                        {
                                            using (StreamWriter sw = new StreamWriter(file, false, Encoding.GetEncoding(System.Configuration.ConfigurationManager.AppSettings["Encoding"])))
                                            {
                                                sw.Write(logicSource[key]);
                                            }
                                            listCompleteFiles.Add(Path.GetFileName(file));
                                            this.logger.Info(version.User.USERID + " " + string.Format(Resources.IF_LOG_LOGIC_FILEOUT_I, Path.GetFileName(file)));
                                        }
                                        catch (Exception ex)
                                        {
                                            this.logger.Error(ex, version.User.USERID + " " + string.Format(Resources.IF_LOG_LOGIC_FILEOUT_E, Path.GetFileName(file)));
                                            listErrFiles.Add(Path.GetFileName(file));
                                        }
                                    }
                                }
                                else
                                {
                                    Dictionary<string, string> logicSource = interfaceEdit.getLogicCopyPharseFromDB();
                                    foreach (string key in logicSource.Keys)
                                    {
                                        string file = Path.GetFullPath(string.Format("{0}\\{1}.cbl", txtOutputPath.Text.Trim(), key));
                                        this.logger.Error(version.User.USERID + " " + string.Format(Resources.IF_LOG_LOGIC_FILEOUT_E, Path.GetFileName(file)));
                                        listErrFiles.Add(Path.GetFileName(file));
                                    }

                                }
                            }
                        }

                        // アイテム説明書
                        if (this.chkItem.Checked)
                        {
                            string file = Path.GetFullPath(string.Format("{0}\\{1}_アイテム説明書（{2}）.xlsx",
                                                                            txtOutputPath.Text.Trim(), 
                                                                            DateTime.Now.ToString(ConstantUtils.DATETIMEFORMAT),
                                                                            cpyPhyData.CPYPHY_BCPNM));
                            InterfaceEdit interfaceEdit = new InterfaceEdit(this.version,
                                                                            null,
                                                                            cpyPhyData.CPYPHY_SUBSYSID,
                                                                            cpyPhyData.CPYPHY_INFOID,
                                                                            null);
                            if (interfaceEdit.checkDB())
                            {
                                try
                                {
                                    List<InterfaceEdit.RowInfo> listRow = interfaceEdit.getRowInfosFromDB();
                                    SheetShowPreview itemSheet = new SheetShowPreview(cvsSheet, SheetShowPreview.PreviewType.ItemSheet);
                                    itemSheet.RowInfoToCanvas(listRow);
                                    if (itemSheet.SaveXlsxFile(file))
                                    {
                                        listCompleteFiles.Add(Path.GetFileName(file));
                                        this.logger.Info(version.User.USERID + " " + string.Format(Resources.IF_LOG_SHEET_FILEOUT_I, Path.GetFileName(file)));
                                    }
                                    else
                                    {
                                        listErrFiles.Add(Path.GetFileName(file));
                                        this.logger.Error(version.User.USERID + " " + string.Format(Resources.IF_LOG_SHEET_FILEOUT_E, Path.GetFileName(file)));
                                    }
                                }
                                catch (Exception ex)
                                {
                                    listErrFiles.Add(Path.GetFileName(file));
                                    this.logger.Error(ex, version.User.USERID + " " + string.Format(Resources.IF_LOG_SHEET_FILEOUT_E, Path.GetFileName(file)));
                                }
                            }
                            else
                            {
                                this.logger.Error(version.User.USERID + " " + string.Format(Resources.IF_LOG_SHEET_FILEOUT_E, Path.GetFileName(file)));
                                listErrFiles.Add(Path.GetFileName(file));
                            }
                        }

                        // アイテム構成図
                        if(this.chkItmMap.Checked)
                        {
                            string file = Path.GetFullPath(string.Format("{0}\\{1}_アイテム構成図（{2}）.xlsx",
                                                                            txtOutputPath.Text.Trim(),
                                                                            DateTime.Now.ToString(ConstantUtils.DATETIMEFORMAT),
                                                                            cpyPhyData.CPYPHY_BCPNM));
                            InterfaceEdit interfaceEdit = new InterfaceEdit(this.version,
                                                                            null,
                                                                            cpyPhyData.CPYPHY_SUBSYSID,
                                                                            cpyPhyData.CPYPHY_INFOID,
                                                                            null);
                            if (interfaceEdit.checkDB())
                            {
                                try
                                {
                                    List<InterfaceEdit.RowInfo> listRow = interfaceEdit.getRowInfosFromDB();
                                    SheetShowPreview itemSheet = new SheetShowPreview(cvsPicture, SheetShowPreview.PreviewType.ItemStructImage);
                                    itemSheet.RowInfoToCanvas(listRow);
                                    if (itemSheet.SaveXlsxFile(file))
                                    {
                                        listCompleteFiles.Add(Path.GetFileName(file));
                                        this.logger.Info(version.User.USERID + " " + string.Format(Resources.IF_LOG_STRUCT_FILEOUT_I, Path.GetFileName(file)));
                                    }
                                    else
                                    {
                                        listErrFiles.Add(Path.GetFileName(file));
                                        this.logger.Error(version.User.USERID + " " + string.Format(Resources.IF_LOG_STRUCT_FILEOUT_E, Path.GetFileName(file)));
                                    }
                                }
                                catch (Exception ex)
                                {
                                    listErrFiles.Add(Path.GetFileName(file));
                                    this.logger.Error(ex, version.User.USERID + " " + string.Format(Resources.IF_LOG_STRUCT_FILEOUT_E, Path.GetFileName(file)));
                                }
                            }
                            else
                            {
                                this.logger.Error(version.User.USERID + " " + string.Format(Resources.IF_LOG_STRUCT_FILEOUT_E, Path.GetFileName(file)));
                                listErrFiles.Add(Path.GetFileName(file));
                            }
                        }

                        // Ｍパーサ定義
                        if (this.chkMParser.Checked)
                        {
                            string file, ext;
                            if (rdbCSV.Checked)
                            {
                                ext = ".csv";
                            }
                            else
                            {
                                ext = ".txt";
                            }
                            InterfaceEdit interfaceEdit = new InterfaceEdit(this.version,
                                                                            null,
                                                                            cpyPhyData.CPYPHY_SUBSYSID,
                                                                            cpyPhyData.CPYPHY_INFOID,
                                                                            combLogSubSysID.Text);
                            StringBuilder sb = new StringBuilder();
                            if (first)
                            {
                                //物理ＩＦパターン定義
                                file = Path.GetFullPath(string.Format("{0}\\{1}{2}",
                                                                        txtOutputPath.Text.Trim(), "xxDTMPPT", ext));
                                try
                                {
                                    using (StreamWriter sw = new StreamWriter(file, false, Encoding.GetEncoding(System.Configuration.ConfigurationManager.AppSettings["Encoding"])))
                                    {

                                        List<T_DENSTRB> listDENSTRB = interfaceEdit.getDENSTRB();
                                        foreach (T_DENSTRB denstrb in listDENSTRB)
                                        {
                                            List<T_DENSTRBITM> listDENSTRBITM = interfaceEdit.getDENSRTBITM(denstrb.DENSTRB_TELSUBSYSID,
                                                                                                            denstrb.DENSTRB_TELTYPE,
                                                                                                            denstrb.DENSTRB_PATNO);
                                            sb.Clear();
                                            sb.Append(string.Format("{0:-2},{1},{2:-4}", denstrb.DENSTRB_TELSUBSYSID,
                                                                                          denstrb.DENSTRB_TELTYPE,
                                                                                          denstrb.DENSTRB_PATNO));
                                            if (denstrb.DENSTRB_GROUPID == null || denstrb.DENSTRB_GROUPID == string.Empty)
                                            {
                                                int count = 0;
                                                foreach (T_DENSTRBITM itm in listDENSTRBITM)
                                                {
                                                    // 繰り返す回数
                                                    int rep = 1;
                                                    if (itm.DENSTRBITM_TURN != null && itm.DENSTRBITM_TURN > 0)
                                                    {
                                                        rep = (int)itm.DENSTRBITM_TURN;
                                                    }

                                                    for (int i = 0; i < rep; i++)
                                                    {
                                                        string name;
                                                        sb.Append(",");
                                                        if (itm.DENSTRBITM_TYPE == "1")  // 物理ＩＤ
                                                        {
                                                            name = itm.DENSTRBITM_PHYID;
                                                        }
                                                        else                             // 予備
                                                        {
                                                            name = "YOBI";
                                                        }
                                                        if (itm.DENSTRBITM_YOBISIZE != null && itm.DENSTRBITM_YOBISIZE > 0)
                                                        {
                                                            name += string.Format("({0})", (int)itm.DENSTRBITM_YOBISIZE);
                                                        }
                                                        sb.Append(name);
                                                        count++;
                                                    }
                                                }
                                                sb.Append(";");
                                                for (int i = count; i < 31; i++)
                                                {
                                                    sb.Append(",");
                                                }
                                            }
                                            else
                                            {
                                                sb.Append(",");
                                                sb.Append(denstrb.DENSTRB_GROUPID);
                                                sb.Append(";,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,"); //３１個分は保障
                                            }
                                            sw.WriteLine(sb.ToString());
                                        }
                                    }
                                    listCompleteFiles.Add(Path.GetFileName(file));
                                    this.logger.Info(version.User.USERID + " " + string.Format(Resources.IF_LOG_PATTERN_FILEOUT_I, Path.GetFileName(file)));
                                }
                                catch (Exception ex)
                                {
                                    this.logger.Error(ex, version.User.USERID + " " + string.Format(Resources.IF_LOG_PATTERN_FILEOUT_E, Path.GetFileName(file)));
                                    listErrFiles.Add(Path.GetFileName(file));
                                }
                            }

                            if (interfaceEdit.checkDB())
                            {
                                //物理ＩＦレイアウト定義
                                if (combLogSubSysID.Text != string.Empty)
                                {
                                    string layout = interfaceEdit.getLayoutDef();
                                    if(string.IsNullOrEmpty(layout) == false)
                                    {
                                        file = Path.GetFullPath(string.Format("{0}\\{1}{2}",
                                                                            txtOutputPath.Text.Trim(), interfaceEdit.getLayoutDef(), ext));
                                        try
                                        {
                                            using (StreamWriter sw = new StreamWriter(file,
                                                                                        false,
                                                                                        Encoding.GetEncoding(System.Configuration.ConfigurationManager.AppSettings["Encoding"])))
                                            {
                                                sw.Write(interfaceEdit.getPhysicLayoutDef());
                                            }
                                            listCompleteFiles.Add(Path.GetFileName(file));
                                            this.logger.Info(version.User.USERID + " " + string.Format(Resources.IF_LOG_LAYOUT_FILEOUT_I, Path.GetFileName(file)));
                                        }
                                        catch (Exception ex)
                                        {
                                            this.logger.Error(ex, version.User.USERID + " " + string.Format(Resources.IF_LOG_LAYOUT_FILEOUT_E, Path.GetFileName(file)));
                                            listErrFiles.Add(Path.GetFileName(file));
                                        }
                                    }
                                }
                            }
                            else
                            {
                                file = Path.GetFullPath(string.Format("{0}\\{1}{2}",
                                                                    txtOutputPath.Text.Trim(), interfaceEdit.getLayoutDef(), ext));
                                this.logger.Error(version.User.USERID + " " + string.Format(Resources.IF_LOG_LAYOUT_FILEOUT_E, Path.GetFileName(file)));
                                listErrFiles.Add(Path.GetFileName(file));
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                        return;
                    }

                    first = false;
                }

                this.logger.Info(version.User.USERID + " " + string.Format(Resources.IF_LOG_OUTPUT_END_I, listCompleteFiles.Count, listErrFiles.Count));

            }
            finally
            {
                WaitDialog.Close();
            }
            if (listErrFiles.Count > 0)
            {
                MessageBox.Show("出力に失敗したファイルがあります。\r\nログファイルを確認してください。",
                                            Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                MessageBox.Show("出力処理が完了しました", Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        /// <summary>
        /// 出力バスの選択
        /// </summary>
        /// <returns></returns>
        private void button3_Click_1(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "出力バスを選択してください";
            dialog.SelectedPath = this.txtOutputPath.Text;
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                txtOutputPath.Text = dialog.SelectedPath;
            }
        }

        #endregion

        #region コピー句一括出力ボタンの処理
        private void button1_Click(object sender, EventArgs e)
        {
            
            //警告メッセージを出力する
            if(MessageBox.Show("全コピー句を出力します。\r\nその為、非常に時間が掛かります。\r\nよろしいですか？", 
                                        Resources.QUESTION, MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.Cancel)
            {
                return;
            }

            if (string.IsNullOrWhiteSpace(this.txtOutputPath.Text))
            {
                MessageBox.Show("出力バスを入力してください。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!Directory.Exists(this.txtOutputPath.Text))
            {
                MessageBox.Show("入力した出力バスが存在しません。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            List<string> listCompleteFiles = new List<string>();
            List<string> listErrFiles = new List<string>();

            this.logger.Info(Resources.IF_LOG_OUTPUT_START_I, Path.GetDirectoryName(this.txtOutputPath.Text));

            try
            {
                WaitDialog.Show(this);
                // 物理コピー句
                foreach (T_CPYPHY cpyphy in this.version.context.T_CPYPHY.AsNoTracking().ToArray())
                {
                    if (cpyphy.CPYPHY_STATUS == ConstantUtils.STATUS_DELELTE) continue;
                    string file = Path.GetFullPath(string.Format("{0}\\{1}.cbl", txtOutputPath.Text.Trim(), cpyphy.CPYPHY_BCPID));
                    try
                    {
                        InterfaceEdit interfaceEdit = new InterfaceEdit(this.version,
                                                                        null,
                                                                        cpyphy.CPYPHY_SUBSYSID,
                                                                        cpyphy.CPYPHY_INFOID,
                                                                        null);
                        using (StreamWriter sw = new StreamWriter(file, false, Encoding.GetEncoding(System.Configuration.ConfigurationManager.AppSettings["Encoding"])))
                        {
                            sw.Write(interfaceEdit.getPhysicCopyphraseFromDB());
                        }
                        listCompleteFiles.Add(Path.GetFileName(file));
                        this.logger.Info(Resources.IF_LOG_PHYSIC_FILEOUT_I, Path.GetFileName(file));
                    }
                    catch (Exception ex)
                    {
                        this.logger.Error(ex, Resources.IF_LOG_PHYSIC_FILEOUT_E, Path.GetFileName(file));
                        listErrFiles.Add(Path.GetFileName(file));
                    }
                }

                // 論理コピー句
                foreach (T_CPYLOG cpylog in this.version.context.T_CPYLOG.AsNoTracking().ToArray())
                {
                    InterfaceEdit interfaceEdit = new InterfaceEdit(this.version,
                                                                    null,
                                                                    cpylog.CPYLGC_PHYSYSID,
                                                                    cpylog.CPYLGC_INFOID,
                                                                    cpylog.CPYLGC_SUBSYSID);

                    T_CPYPHY cpyphy = interfaceEdit.getPhysicCopyInfo();
                    if (cpyphy == null || cpyphy.CPYPHY_STATUS == ConstantUtils.STATUS_DELELTE) continue;

                    Dictionary<string, string> logicSource = interfaceEdit.getLogicCopyPharseFromDB();
                    foreach (string key in logicSource.Keys)
                    {
                        string file = Path.GetFullPath(string.Format("{0}\\{1}.cbl", txtOutputPath.Text.Trim(), key));
                        try
                        {
                            using (StreamWriter sw = new StreamWriter(file, false, Encoding.GetEncoding(System.Configuration.ConfigurationManager.AppSettings["Encoding"])))
                            {
                                sw.Write(logicSource[key]);
                            }
                            listCompleteFiles.Add(Path.GetFileName(file));
                            this.logger.Info(Resources.IF_LOG_LOGIC_FILEOUT_I, Path.GetFileName(file));
                        }
                        catch (Exception ex)
                        {
                            this.logger.Error(ex, Resources.IF_LOG_LOGIC_FILEOUT_E, Path.GetFileName(file));
                            listErrFiles.Add(Path.GetFileName(file));
                        }
                    }
                }

            }
            finally
            {
                WaitDialog.Close();
            }
            this.logger.Info(Resources.IF_LOG_OUTPUT_END_I, listCompleteFiles.Count, listErrFiles.Count);
            if (listErrFiles.Count > 0)
            {
                MessageBox.Show("出力に失敗したファイルがあります。\r\nログファイルを確認してください。", 
                                            Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                MessageBox.Show("完了しました", Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        #endregion

        #region 出力ボタンの有効化・無効化チェック
        private void txtOutputPath_TextChanged(object sender, EventArgs e)
        {
            this.btnOutput.Enabled = !string.IsNullOrWhiteSpace(this.txtOutputPath.Text) &&
                (this.chkSettingCond.Checked || this.chkPhyLogMapping.Checked || this.chkPhyCpyKu.Checked || this.chkLogCpyKu.Checked
                || this.chkItem.Checked || this.chkItmMap.Checked || this.chkMParser.Checked);
        }

        private void chkPhyCpyKu_CheckedChanged_1(object sender, EventArgs e)
        {
            this.btnOutput.Enabled = !string.IsNullOrWhiteSpace(this.txtOutputPath.Text) &&
                (this.chkSettingCond.Checked || this.chkPhyLogMapping.Checked || this.chkPhyCpyKu.Checked || this.chkLogCpyKu.Checked
                || this.chkItem.Checked || this.chkItmMap.Checked || this.chkMParser.Checked);
        }

        private void chkLogCpyKu_CheckedChanged(object sender, EventArgs e)
        {
            this.btnOutput.Enabled = !string.IsNullOrWhiteSpace(this.txtOutputPath.Text) &&
                (this.chkSettingCond.Checked || this.chkPhyLogMapping.Checked || this.chkPhyCpyKu.Checked || this.chkLogCpyKu.Checked
                || this.chkItem.Checked || this.chkItmMap.Checked || this.chkMParser.Checked);
        }

        private void chkPhyLogMapping_CheckedChanged(object sender, EventArgs e)
        {
            this.btnOutput.Enabled = !string.IsNullOrWhiteSpace(this.txtOutputPath.Text) &&
                (this.chkSettingCond.Checked || this.chkPhyLogMapping.Checked || this.chkPhyCpyKu.Checked || this.chkLogCpyKu.Checked
                || this.chkItem.Checked || this.chkItmMap.Checked || this.chkMParser.Checked);
        }

        private void chkItem_CheckedChanged(object sender, EventArgs e)
        {
            this.btnOutput.Enabled = !string.IsNullOrWhiteSpace(this.txtOutputPath.Text) &&
                (this.chkSettingCond.Checked || this.chkPhyLogMapping.Checked || this.chkPhyCpyKu.Checked || this.chkLogCpyKu.Checked
                || this.chkItem.Checked || this.chkItmMap.Checked || this.chkMParser.Checked);
        }

        private void chkItmMap_CheckedChanged(object sender, EventArgs e)
        {
            this.btnOutput.Enabled = !string.IsNullOrWhiteSpace(this.txtOutputPath.Text) &&
                (this.chkSettingCond.Checked || this.chkPhyLogMapping.Checked || this.chkPhyCpyKu.Checked || this.chkLogCpyKu.Checked
                || this.chkItem.Checked || this.chkItmMap.Checked || this.chkMParser.Checked);
        }

        private void chkSettingCond_CheckedChanged(object sender, EventArgs e)
        {
            this.btnOutput.Enabled = !string.IsNullOrWhiteSpace(this.txtOutputPath.Text) &&
                (this.chkSettingCond.Checked || this.chkPhyLogMapping.Checked || this.chkPhyCpyKu.Checked || this.chkLogCpyKu.Checked
                || this.chkItem.Checked || this.chkItmMap.Checked || this.chkMParser.Checked);
        }

        private void chkMParser_CheckedChanged(object sender, EventArgs e)
        {
            this.btnOutput.Enabled = !string.IsNullOrWhiteSpace(this.txtOutputPath.Text) &&
                (this.chkSettingCond.Checked || this.chkPhyLogMapping.Checked || this.chkPhyCpyKu.Checked || this.chkLogCpyKu.Checked
                || this.chkItem.Checked || this.chkItmMap.Checked || this.chkMParser.Checked);
        }
        #endregion

        #region コピー句テキストボックスの有効化・無効化チェック
        private void rdoRDataTbId_CheckedChanged(object sender, EventArgs e)
        {
            this.txtCopyKuID.Enabled = this.rdoRDataTbId.Checked;
            this.txtCopyKuNm.Enabled = this.rdoCpyNm.Checked;
        }
        #endregion

        #endregion

    }
}