﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MarsTool.Models;
using MarsTool.Models.DB;

namespace MarsTool.LGC
{
    class Fct
    {
        public const string VersionPrefix = "version";
        public const string VersionDate = "date";
        public const string HostnamePrefix = "hostname";
        public const string PortPrefix = "port";
        public const string DatabasePrefix = "database";
        public const string DBUserPrefix = "user";
        public const string DBPassword = "password";


        public static Dictionary<string, List<string>> getPRI()
        {
            Dictionary<string, List<string>> res = new Dictionary<string, List<string>>();

            var ttmp = System.Configuration.ConfigurationManager.AppSettings["priviledgeConfigLocation"];

            byte[] bytearr = null;

            try
            {
                bytearr = System.IO.File.ReadAllBytes(ttmp);
            }
            catch
            {
                throw new Exception("権限管理ファイルは取得できません");
            }

            System.Text.RegularExpressions.Regex r1 = new System.Text.RegularExpressions.Regex(@"^\[.+\]$", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            System.Text.RegularExpressions.Regex r2 = new System.Text.RegularExpressions.Regex(@"^subsys\s*=[a-zA-Z0-9,]*$", System.Text.RegularExpressions.RegexOptions.IgnoreCase);

            bool isStart = false;

            using (var reader = new StreamReader(new MemoryStream(bytearr), Encoding.Default))
            {
                string tmpline;

                string groupname = null;

                while ((tmpline = reader.ReadLine()) != null)
                {
                    string trimstr = tmpline.Trim();

                    if (trimstr == "")
                        continue;

                    if (!trimstr.StartsWith("#") && !trimstr.StartsWith(";"))
                    {
                        var m1 = r1.Match(trimstr);
                        var m2 = r2.Match(trimstr);

                        if (m1.Success)
                        {
                            if (isStart)
                                throw new Exception("権限管理ファイルは中身不正");

                            groupname = trimstr.Substring(1, trimstr.Length - 2);

                            if (res.ContainsKey(groupname))
                                throw new Exception("権限管理ファイルは中身不正");
                            else
                                res.Add(groupname, new List<string>());

                            isStart = true;
                        }
                        else if (m2.Success)
                        {
                            if (!isStart)
                                throw new Exception("権限管理ファイルは中身不正");

                            if (!res.ContainsKey(groupname))
                                throw new Exception("権限管理ファイルは中身不正");

                            string idlst = trimstr.Substring(trimstr.IndexOf("=") + 1).Trim().ToUpper();
                            string[] arr = idlst.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                            if(arr != null && arr.Any(r => (r + "").Length > 4))
                            {
                                throw new Exception("権限管理ファイルへ定義するサブシステムＩＤは４桁以内にして下さい。");
                            }

                            if(arr != null && arr.Length > 0)
                            {
                                res[groupname].AddRange(arr.Where(r => (r + "").Length <= 4).Distinct());
                            }
                            
                            isStart = false;
                        }
                        else
                        {
                            throw new Exception("権限管理ファイルは中身不正");
                        }
                    }
                }
            }

            return res;
        }

        /// <summary>
        /// 世代の情報を取得する
        /// </summary>
        /// <returns></returns>
        public static List<VersionModel> getAllVersion()
        {
            List<VersionModel> res = new List<VersionModel>();

            System.Text.RegularExpressions.Regex r1 = new System.Text.RegularExpressions.Regex(@"^\[.+\]$", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            System.Text.RegularExpressions.Regex r2 = new System.Text.RegularExpressions.Regex(@"^hostname\s*=", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            System.Text.RegularExpressions.Regex r3 = new System.Text.RegularExpressions.Regex(@"^database\s*=", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            System.Text.RegularExpressions.Regex r4 = new System.Text.RegularExpressions.Regex(@"^user\s*=", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            System.Text.RegularExpressions.Regex r5 = new System.Text.RegularExpressions.Regex(@"^password\s*=", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            System.Text.RegularExpressions.Regex r6 = new System.Text.RegularExpressions.Regex(@"^port\s*=", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            System.Text.RegularExpressions.Regex r7 = new System.Text.RegularExpressions.Regex(@"^date\s*=", System.Text.RegularExpressions.RegexOptions.IgnoreCase);

            byte[] bytearr = null;

            var ttmp = System.Configuration.ConfigurationManager.AppSettings["versionConfigLocation"];

            try
            {
                bytearr = System.IO.File.ReadAllBytes(ttmp);
            }
            catch
            {
                System.Windows.Forms.MessageBox.Show("世代管理ファイルは取得できません",Properties.Resources.ATTENTION,System.Windows.Forms.MessageBoxButtons.OK,System.Windows.Forms.MessageBoxIcon.Error);
                return res;
            }


            using (var reader = new StreamReader(new MemoryStream(bytearr), Encoding.Default))
            {
                string tmpline;

                while ((tmpline = reader.ReadLine()) != null)
                {
                    string trimstr = tmpline.Trim();

                    if (trimstr == "")
                        continue;

                    if (!trimstr.StartsWith("#") && !trimstr.StartsWith(";"))
                    {
                        var m1 = r1.Match(trimstr);
                        var m2 = r2.Match(trimstr);
                        var m3 = r3.Match(trimstr);
                        var m4 = r4.Match(trimstr);
                        var m5 = r5.Match(trimstr);
                        var m6 = r6.Match(trimstr);
                        var m7 = r7.Match(trimstr);

                        if (m1.Success)
                        {
                            VersionModel tmp = getTMPModel(res, VersionPrefix);
                            if (String.IsNullOrEmpty(tmp.Vername))
                            {
                                tmp.Vername = trimstr.Substring(1, trimstr.Length - 2);
                            }
                            else
                            {
                                throw new Exception("世代コンフィグ不正");
                            }
                        }
                        else if (m2.Success)
                        {
                            VersionModel tmp = getTMPModel(res, HostnamePrefix);
                            if (String.IsNullOrEmpty(tmp.Hostname))
                            {
                                tmp.Hostname = trimstr.Substring(m2.Value.Length).Trim();
                            }
                            else
                            {
                                throw new Exception("世代コンフィグ不正");
                            }
                        }
                        else if (m3.Success)
                        {
                            VersionModel tmp = getTMPModel(res, DatabasePrefix);
                            if (String.IsNullOrEmpty(tmp.DBName))
                            {
                                tmp.DBName = trimstr.Substring(m3.Value.Length).Trim();
                            }
                            else
                            {
                                throw new Exception("世代コンフィグ不正");
                            }
                        }
                        else if (m4.Success)
                        {
                            VersionModel tmp = getTMPModel(res, DBUserPrefix);
                            if (String.IsNullOrEmpty(tmp.DBUser))
                            {
                                tmp.DBUser = trimstr.Substring(m4.Value.Length).Trim();
                            }
                            else
                            {
                                throw new Exception("世代コンフィグ不正");
                            }
                        }
                        else if (m5.Success)
                        {
                            VersionModel tmp = getTMPModel(res, DBPassword);
                            if (String.IsNullOrEmpty(tmp.DBPassword))
                            {
                                tmp.DBPassword = trimstr.Substring(m5.Value.Length).Trim();
                            }
                            else
                            {
                                throw new Exception("世代コンフィグ不正");
                            }
                        }
                        else if (m6.Success)
                        {
                            VersionModel tmp = getTMPModel(res, PortPrefix);
                            if (String.IsNullOrEmpty(tmp.Port))
                            {
                                tmp.Port = trimstr.Substring(m6.Value.Length).Trim();
                            }
                            else
                            {
                                throw new Exception("世代コンフィグ不正");
                            }
                        }
                        else if (m7.Success)
                        {
                            VersionModel tmp = getTMPModel(res, VersionDate);
                            if (String.IsNullOrEmpty(tmp.VersionDate))
                            {
                                tmp.VersionDate = trimstr.Substring(m7.Value.Length).Trim();

                                DateTime tmpdt = DateTime.ParseExact(tmp.VersionDate, "yyyyMMdd", null);

                                tmp.VersionDate = tmpdt.ToString("yyyyMMdd");
                            }
                            else
                            {
                                throw new Exception("世代コンフィグ不正");
                            }
                        }
                        else
                        {
                            throw new Exception("世代コンフィグ不正");
                        }
                    }
                }
            }
            return res;
        }

        private static VersionModel getTMPModel(List<VersionModel> res, string flag)
        {
            if (res.Count == 0)
            {
                res.Add(new VersionModel());
            }

            var tmp = res.Last();

            if (tmp.Vername != null && tmp.DBName != null && tmp.DBPassword != null &&
                tmp.DBUser != null && tmp.Hostname != null && tmp.Port != null)
            {
                if (flag == VersionPrefix)
                    res.Add(new VersionModel());
            }

            return res.Last();
        }
    }
}
