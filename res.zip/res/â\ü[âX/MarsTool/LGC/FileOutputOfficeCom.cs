﻿using MarsTool.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;

namespace MarsTool.LGC
{
    /// <summary>
    /// Epplus版のExcel出力機能は不安定で、バッグファイルを出力してしまうケースも発生するため
    /// Office Com版の出力機能を作成すること
    /// </summary>
    class FileOutputOfficeCom
    {
        private NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        /// <summary>
        /// 情報部の高さ - 1
        /// </summary>
        public const int BH = 3;
        /// <summary>
        /// 情報部の広さ - 1
        /// </summary>
        public const int BW = 6;

        /// <summary>
        /// サイズ、属性2 3 4 5の高さ - 1
        /// </summary>
        public const int BSH = 1;

        /// <summary>
        /// サイズ属性の高さ
        /// </summary>
        public const int SH = 2;
        /// <summary>
        /// 属性5 の高さ
        /// </summary>
        public const int P5H = 2;
        /// <summary>
        /// 属性3 4 の高さ
        /// </summary>
        public const int P34H = 2;
        /// <summary>
        /// 属性2の高さ
        /// </summary>
        public const int P2H = 2;
        /// <summary>
        /// 属性1の高さ
        /// </summary>
        public const int P1H = 2;
        /// <summary>
        /// 要求回答属性の高さ
        /// </summary>
        public const int RESREQH = 2;

        /// <summary>
        /// 操作種別の起点列
        /// </summary>
        public const int OPCS = 77;
        /// <summary>
        /// 操作種別の終点列
        /// </summary>
        public const int OPCE = 88;

        /// <summary>
        /// ANSの起点列
        /// </summary>
        public const int AS = 89;
        /// <summary>
        /// ANSの終点列
        /// </summary>
        public const int AE = 91;

        /// <summary>
        /// パターン番号の起点列
        /// </summary>
        public const int PS = 92;
        /// <summary>
        /// パターン番号の終点列
        /// </summary>
        public const int PE = 95;

        /// <summary>
        /// 記事の起点列
        /// </summary>
        public const int CS = 96;
        /// <summary>
        /// 記事の終点列
        /// </summary>
        public const int CE = 99;
        /// <summary>
        /// ページの最後行
        /// </summary>
        public const int PageLastRow = 58;

        struct LVL
        {
            /// <summary>
            /// 要求/回答情報描くフラッグ
            /// </summary>
            public bool REQRES;

            /// <summary>
            /// 
            /// </summary>
            public bool L1;

            /// <summary>
            /// 区間１、区間２、先乗列車描くフラッグ
            /// </summary>
            public bool L2;

            /// <summary>
            /// 予約/解約描くフラッグ
            /// </summary>
            public bool L3;
            /// <summary>
            /// 変更前/変更後描くフラッグ
            /// </summary>
            public bool L4;

            /// <summary>
            /// レピート描くフラッグ
            /// </summary>
            public bool L5;


            public int totalHeight;


        }

        /// <summary>
        /// 属性情報出力各フラッグ
        /// </summary>
        /// <param name="jp"></param>
        /// <param name="p2dic"></param>
        /// <returns></returns>
        private LVL calcLVL(ViewPattern jp, Dictionary<string, int> p2dic)
        {
            LVL res;
            res.REQRES = false;
            res.L1 = false;
            res.L2 = false;
            res.L3 = false;
            res.L4 = false;
            res.L5 = false;

            res.totalHeight = 0;

            p2dic.Clear();

            //欠番の時、出力するため
            if (jp.Enabled == 2)
            {
                res.totalHeight = 1;
            }

            if (jp == null || jp.JN_INFOBLOCKS == null || jp.JN_INFOBLOCKS.Count == 0)
                return res;

            for (int i = 0; i < jp.JN_INFOBLOCKS.Count; i++)
            {
                if (!String.IsNullOrWhiteSpace(jp.JN_INFOBLOCKS[i].JN_REQRESFLG))
                {
                    res.REQRES = true;
                }
                if (!String.IsNullOrWhiteSpace(jp.JN_INFOBLOCKS[i].JN_PROPERTY2))
                {
                    res.L2 = true;
                }
                if (!String.IsNullOrWhiteSpace(jp.JN_INFOBLOCKS[i].JN_PROPERTY3))
                {
                    res.L3 = true;
                }
                if (!String.IsNullOrWhiteSpace(jp.JN_INFOBLOCKS[i].JN_PROPERTY4))
                {
                    res.L4 = true;
                }
                if (!String.IsNullOrWhiteSpace(jp.JN_INFOBLOCKS[i].JN_PROPERTY5))
                {
                    res.L5 = true;
                }

                if (!String.IsNullOrWhiteSpace(jp.JN_INFOBLOCKS[i].JN_PROPERTY2))
                {
                    if (p2dic.ContainsKey(jp.JN_INFOBLOCKS[i].JN_PROPERTY2))
                    {
                    }
                    else
                    {
                        if (p2dic.Count == 0)
                            p2dic.Add(jp.JN_INFOBLOCKS[i].JN_PROPERTY2, 1);
                        else
                            p2dic.Add(jp.JN_INFOBLOCKS[i].JN_PROPERTY2, p2dic.Values.Max() + 1);
                    }
                }
            }

            for (int i = 0; i < jp.JN_INFOBLOCKS.Count; i++)
            {
                if (!String.IsNullOrWhiteSpace(jp.JN_INFOBLOCKS[i].INHERENTPROPERTY))
                {

                    if (p2dic.Count == 0)
                    {
                        p2dic.Add(jp.JN_INFOBLOCKS[i].INHERENTPROPERTY, 1);
                        jp.JN_INFOBLOCKS[i].JN_NAME = jp.JN_INFOBLOCKS[i].JN_NAME + " *1";
                    }
                    else
                    {
                        int tmpidx = p2dic.Values.Max() + 1;
                        p2dic.Add($"{i}|55172FD0-17AB-4AE6-BDDB-7A58F2342646|" + jp.JN_INFOBLOCKS[i].INHERENTPROPERTY, p2dic.Values.Max() + 1);
                        jp.JN_INFOBLOCKS[i].JN_NAME = jp.JN_INFOBLOCKS[i].JN_NAME + " *" + tmpidx;
                    }

                }
            }

            int h = BH + 1;
            h += SH;
            if (res.L3)
                h += P34H;
            if (res.L4)
                h += P34H;
            if (res.REQRES)
                h += RESREQH;
            if (res.L2)
                h += P2H;
            if (res.L5)
                h += P5H;
            h += 1;

            //記事の行数
            int t1 = 0;
            if (jp.JN_COMMNENT != null)
                t1 += jp.JN_COMMNENT.Split('\n').Length;
            t1 += p2dic.Count;

            //操作種別の行数
            int top = 0;
            if (jp.JN_OPTYPE != null)
                top += jp.JN_OPTYPE.Split('\n').Length;
            top += p2dic.Count;

            if (top > t1) t1 = top;

            int t2 = 0;

            if (jp.JN_INFOBLOCKS.Count <= 10)
            {
                t2 = h;
            }
            else if (jp.JN_INFOBLOCKS.Count <= 20)
            {
                t2 = h * 2;
            }
            else
            {
                //N行と同じ処理
                int totalcnt = jp.JN_INFOBLOCKS.Count;
                List<int> allrow = new List<int>();
                while (totalcnt > 0)
                {
                    if (allrow.Count == 0)
                    {
                        allrow.Add(10);
                        totalcnt -= 10;
                    }
                    else
                    {
                        int r = totalcnt - 8;
                        if (r > 2)
                        {
                            allrow.Add(8);
                            totalcnt = r;
                        }
                        else
                        {
                            allrow.Add(r);
                            totalcnt = 0;
                        }
                    }
                }

                t2 = allrow.Count * h;
            }

            res.totalHeight = t1 > t2 ? t1 : t2;

            return res;
        }

        private void SaveStreamToFile(string fileFullPath, System.IO.Stream stream)
        {
            if (stream.Length == 0) return;
            // Create a FileStream object to write a stream to a file
            using (System.IO.FileStream fileStream = System.IO.File.Create(fileFullPath, (int)stream.Length))
            {
                // Fill the bytes[] array with the stream data
                byte[] bytesInStream = new byte[stream.Length];
                stream.Read(bytesInStream, 0, (int)bytesInStream.Length);

                // Use FileStream object to write to the specified file
                fileStream.Write(bytesInStream, 0, bytesInStream.Length);
            }
        }

        private void SaveStreamToFile(string fileFullPath, byte[] data)
        {
            if (data == null || data.Length == 0) return;
            // Create a FileStream object to write a stream to a file
            using (System.IO.FileStream fileStream = System.IO.File.Create(fileFullPath, data.Length))
            {
                // Use FileStream object to write to the specified file
                fileStream.Write(data, 0, data.Length);
            }
        }

        private void printerror(System.Windows.Forms.RichTextBox tb, string ms)
        {
            int texbox = tb.TextLength;
            tb.AppendText(ms);
            tb.SelectionStart = texbox;
            tb.SelectionLength = ms.Length;
            tb.SelectionColor = System.Drawing.Color.Red;
            tb.ScrollToCaret();
        }


        public void readJNLData(string condition, List<ViewPattern> lst, VersionModel version, System.Windows.Forms.RichTextBox richTextBox2)
        {
            List<Models.DB.V_JNLPT> total = null;

            try
            {
                //出力する時、独自のDBを使う
                using (var context = new Models.DB.mysqlcontext(version.ConnectString))
                {
                    if (condition == Properties.Resources.JNL_LIST_ALL)
                    {
                        total = context.V_JNPT.AsNoTracking().Include("JNL_INFOBLOCKS").OrderBy(r => r.JNL_CUPID).ThenBy(r => r.JNL_TYPE).ThenBy(r => r.JNL_SUBORDER).ToList();
                    }
                    else
                    {
                        total = context.V_JNPT.AsNoTracking().Include("JNL_INFOBLOCKS").Where(r => r.JNL_CUPID == condition).OrderBy(r => r.JNL_TYPE).ThenBy(r => r.JNL_SUBORDER).ToList();
                    }
                }
            }
            catch (Exception exp)
            {
                logger.Error(exp, "ジャーナル出力DBエラー");
                lst.Add(new ViewPattern { JN_PATTERNID = "Error" });
                printerror(richTextBox2, "DBエラー\n\n");
                return;
            }

            //関数を二つに分けるため、未登録の情報部が存在する場合、下記の方法で実現します
            if (total.Any(r => r.JNL_INFOBLOCKS.Any(o => o.JNL_NAME == null)))
            {
                lst.Add(new ViewPattern { JN_PATTERNID = "Error" });
                printerror(richTextBox2, Properties.Resources.JNL_ERROR1);
                return;
            }

            foreach (var jp in total)
            {
                var jnPattern = new ViewPattern();
                jnPattern.JN_INFOBLOCKS = new List<ViewInfoBlock>();
                jnPattern.JN_ANS = jp.JNL_ANS;
                jnPattern.JN_COMMNENT = jp.JNL_COMMNENT;
                jnPattern.JN_CUPID = jp.JNL_CUPID;
                jnPattern.JN_OPTYPE = jp.JNL_OPTYPE;
                jnPattern.JN_PATTERNNO = jp.JNL_PATTERNNO;
                jnPattern.JN_TYPE = jp.JNL_TYPE;
                jnPattern.JN_SUBORDER = jp.JNL_SUBORDER;
                jnPattern.Enabled = jp.JNL_ENABLEFLG;
                foreach (var tmp in jp.JNL_INFOBLOCKS.OrderBy(r => r.JNL_ORDER))
                {
                    jnPattern.JN_INFOBLOCKS.Add(new ViewInfoBlock
                    {
                        JN_INTERFACEID = tmp.JNL_INFOID,
                        JN_PATTERNID = tmp.JNL_PATTERNID,
                        JN_PROPERTY2 = tmp.JNL_PROPERTY2,
                        JN_PROPERTY3 = tmp.JNL_PROPERTY3,
                        JN_PROPERTY4 = tmp.JNL_PROPERTY4,
                        JN_PROPERTY5 = tmp.JNL_PROPERTY5,
                        JN_REQRESFLG = tmp.JNL_REQRESFLG,
                        JN_SIZE = tmp.JNL_SIZE,
                        JN_ORDER = tmp.JNL_ORDER,
                        JN_NAME = tmp.JNL_NAME,
                        INHERENTPROPERTY = tmp.JNL_INHERENT,
                    });
                }
                lst.Add(jnPattern);
            }

            //var firstLost = lst.FirstOrDefault(r => r.JN_INFOBLOCKS.Count == 0);

            //if(firstLost == null)
            //{
            //    //do nothing
            //}
            //else
            //{
            //    if(lst[0] == firstLost)
            //    {
            //        var firstNotLost = lst.FirstOrDefault(r => r.JN_INFOBLOCKS.Count == 0);
            //    }

            //}

        }


        /// <summary>
        /// 出力処理
        /// </summary>
        /// <param name="alldata"></param>
        /// <param name="output"></param>
        /// <param name="info"></param>
        public void writeDataToExcel(List<ViewPattern> alldata, string output, System.Windows.Forms.RichTextBox info)
        {
            if (alldata == null || alldata.Count == 0)
            {
                info.AppendText("出力しようとするデータはないため、処理は中止しました\n\n");
                info.ScrollToCaret();
                return;
            }
            else if (alldata.Count == 1 && alldata[0].JN_PATTERNID == "Error")
            {
                //未登録の情報部が存在する時の処理
                return;
            }

            info.AppendText("ジャーナルパターン仕様書出力開始！完了するまで、画面操作しないでください\n");
            info.ScrollToCaret();

            string template = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "84D7E937-EBA8-4592-BFC3-25AA8F82C9C1.xlsx");
            output = System.IO.Path.Combine(output, "ジャーナルパターン仕様書-" + DateTime.Now.ToString("yyyyMMdd") + ".xlsx");

            bool remoteCopyFlag = false;

            //テンプレートファイルをコピーする
            var remoteFile = System.Configuration.ConfigurationManager.AppSettings["jnlOutputTemplateLocation"];
            if (!String.IsNullOrWhiteSpace(remoteFile))
            {
                try
                {
                    System.IO.File.Copy(remoteFile, template);
                    remoteCopyFlag = true;
                }
                catch
                {
                }
            }
            //失敗したら、リソースのテンプレートを使うこと
            if (remoteCopyFlag == false)
            {
                info.AppendText("デフォルトのテンプレートを使いました\n");
                info.ScrollToCaret();

                SaveStreamToFile(template, Properties.Resources.T);

            }

            List<float> rowHeight = new List<float>();

            info.AppendText($"出力しようとするジャーナルパターンの数は {alldata.Count} 件\n");
            info.ScrollToCaret();
            Excel.Application xlApp = null;

            try
            {
                xlApp = new Excel.Application();
            }
            catch (Exception exp)
            {
                logger.Error(exp,"ジャーナル出力Excel起動エラー");
                int texbox = info.TextLength;
                string ms = $"Excelは起動できません\n\n";
                info.AppendText(ms);
                info.SelectionStart = texbox;
                info.SelectionLength = ms.Length;
                info.SelectionColor = System.Drawing.Color.Red;
                info.ScrollToCaret();
                return;
            }

            //xlApp.Visible = true;
            xlApp.DisplayAlerts = false;
            Excel.Workbook workbook = xlApp.Workbooks.Open(template);
            Excel.Worksheet tplt = workbook.Sheets[1];
            tplt.Copy(Type.Missing, workbook.Sheets[workbook.Sheets.Count]);
            Excel.Worksheet s = workbook.Sheets[workbook.Sheets.Count];

            List<Tuple<string, string, int>> headlst = new List<Tuple<string, string, int>>();

            int pageIdx = 1;

            s.Name = "P" + pageIdx.ToString("D2");
            s.Range["A1", "A1"].Select();

            float x1 = (float)(s.Columns[1].Width);

            float x2 = 0;
            for (int tmpxi = 1; tmpxi <= 99; tmpxi++)
            {
                x2 += (float)(s.Columns[tmpxi].Width);
            }

            rowHeight.Add(0);
            for (int tmpxi = 1; tmpxi <= 58; tmpxi++)
            {
                rowHeight.Add((float)(s.Rows[tmpxi].Height));
            }

            //タイトル設定
            s.Cells[5, 3].Value = "";

            Dictionary<string, int> p2dic = new Dictionary<string, int>();

            int sr = 9;
            int sr2 = 9;

            int patterIndex = 0;

            for (int i = 0; i < alldata.Count; i++)
            {
                info.AppendText($"{i + 1}/{alldata.Count} --------------------------------\n");
                info.ScrollToCaret();

                //必要のレベル情報を出力する
                LVL level = calcLVL(alldata[i], p2dic);

                if (level.totalHeight + 2 > 51)
                {
                    int texbox = info.TextLength;
                    string ms = $"パターン番号「{alldata[i].JN_PATTERNNO.Replace(Environment.NewLine, " ")}」、CUP-ID「{alldata[i].JN_CUPID}」のジャーナルパターンは出力範囲を超えているので、スキップしました\n";
                    info.AppendText(ms);
                    info.SelectionStart = texbox;
                    info.SelectionLength = ms.Length;
                    info.SelectionColor = System.Drawing.Color.Red;
                    info.ScrollToCaret();

                    continue;

                    //workbook.Close(false);

                    //xlApp.Quit();

                    //if (xlApp != null)
                    //{
                    //    int excelProcessId = -1;
                    //    GetWindowThreadProcessId(new IntPtr(xlApp.Hwnd), ref excelProcessId);

                    //    System.Diagnostics.Process ExcelProc = System.Diagnostics.Process.GetProcessById(excelProcessId);
                    //    if (ExcelProc != null)
                    //    {
                    //        ExcelProc.Kill();
                    //    }
                    //}
                    //return;
                }
                else if (level.totalHeight + sr2 > PageLastRow)
                {
                    pageIdx++;
                    tplt.Copy(Type.Missing, workbook.Sheets[workbook.Sheets.Count]);
                    s = workbook.Sheets[workbook.Sheets.Count];
                    s.Name = "P" + pageIdx.ToString("D2");
                    s.Range["A1", "A1"].Select();
                    sr = 9;
                    sr2 = 9;
                    s.Cells[5, 3].Value = f(alldata[i].JN_CUPID, alldata[i].JN_TYPE);
                    var maxTuple2 = from tmptuple in headlst
                                    where tmptuple.Item2 == s.Cells[5, 3].Value
                                    select tmptuple.Item3;
                    headlst.Add(new Tuple<string, string, int>(s.Name, s.Cells[5, 3].Value, maxTuple2.Count() == 0 ? 1 : maxTuple2.Max() + 1));
                }

                if (f(alldata[i].JN_CUPID, alldata[i].JN_TYPE) != s.Cells[5, 3].Value)
                {
                    if ("".Equals(s.Cells[5, 3].Value))
                    {
                        s.Cells[5, 3].Value = f(alldata[i].JN_CUPID, alldata[i].JN_TYPE);
                        headlst.Add(new Tuple<string, string, int>(s.Name, s.Cells[5, 3].Value, 1));
                    }
                    else
                    {
                        pageIdx++;
                        tplt.Copy(Type.Missing, workbook.Sheets[workbook.Sheets.Count]);
                        s = workbook.Sheets[workbook.Sheets.Count];
                        s.Name = "P" + pageIdx.ToString("D2");
                        s.Range["A1", "A1"].Select();
                        sr = 9;
                        sr2 = 9;
                        s.Cells[5, 3].Value = f(alldata[i].JN_CUPID, alldata[i].JN_TYPE);
                        var maxTuple2 = from tmptuple in headlst
                                        where tmptuple.Item2 == s.Cells[5, 3].Value
                                        select tmptuple.Item3;
                        headlst.Add(new Tuple<string, string, int>(s.Name, s.Cells[5, 3].Value, maxTuple2.Count() == 0 ? 1 : maxTuple2.Max() + 1));
                    }
                }


                int location = 0;


                //N行と同じ処理
                int totalcnt = alldata[i].JN_INFOBLOCKS.Count;
                List<int> allrow = new List<int>();
                while (totalcnt > 0)
                {
                    if (allrow.Count == 0)
                    {
                        allrow.Add(10);
                        totalcnt -= 10;
                    }
                    else
                    {
                        int res = totalcnt - 8;
                        if (res > 2)
                        {
                            allrow.Add(8);
                            totalcnt = res;
                        }
                        else
                        {
                            allrow.Add(totalcnt);
                            totalcnt = 0;
                        }
                    }
                }

                //
                for (int lstid = 0; lstid < allrow.Count; lstid++)
                {
                    if (lstid == 0)
                    {
                        //first row
                        int sc = 4;
                        location = 10;

                        //一行にて出力できる場合
                        if (allrow.Count == 1)
                        {
                            location = alldata[i].JN_INFOBLOCKS.Count;
                        }
                        else if (allrow.Count == 2)
                        {
                            location = calcLocation(alldata, i);

                        }

                        //一行目の情報部
                        for (int j = 0; j < location; j++)
                        {
                            //情報部ボックス
                            drawJNBlock(s.Range[s.Cells[sr, sc], s.Cells[sr + BH, sc + BW]], alldata[i].JN_INFOBLOCKS[j].JN_NAME);
                            //サイズ情報
                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                            s.Range[s.Cells[sr + BH + 1, sc + BW], s.Cells[sr + BH + 1 + BSH, sc + BW]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                            drawSize(s.Range[s.Cells[sr + BH + 1, sc + 2], s.Cells[sr + BH + 1 + BSH, sc + BW - 2]], alldata[i].JN_INFOBLOCKS[j].JN_SIZE);
                            sc = sc + BW + 1;
                        }

                        if (alldata[i].JN_INFOBLOCKS.Count > location)
                        {
                            //右側の短線
                            s.Cells[sr, sc].Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle = Excel.XlLineStyle.xlContinuous;
                            s.Cells[sr + BH, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                            s.Cells[sr + BH + 1, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                        }

                        sr = sr + SH;

                        //予約、解約、変更前、変更後
                        //PROPERTY3、PROPERTY4
                        if (level.L3)
                        {
                            sc = 4;
                            for (int j = 0; j < location; j++)
                            {
                                if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3))
                                {
                                    if (j >= 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY3 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3)
                                    {
                                        //already set .
                                    }
                                    else
                                    {
                                        int endblock = 0;
                                        bool tmpflg = false;
                                        for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                        {
                                            if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY3)
                                            {
                                                if (k > location) tmpflg = true;
                                                endblock = k - j - 1;
                                                break;
                                            }
                                            if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                            {
                                                if (k >= location) tmpflg = true;
                                                endblock = k - j;
                                            }
                                        }
                                        if (endblock == 0) tmpflg = false;
                                        if (tmpflg)
                                        {
                                            endblock = location - j - 1;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            //s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1), sr + BH + 1 + BSH, sc + BW + endblock * (BW + 1)].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                s.Cells[sr + BH + 1 + BSH,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3);
                                        }
                                        else
                                        {
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1 + BSH, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                s.Cells[sr + BH + 1 + BSH,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3);
                                        }

                                    }

                                }
                                sc = sc + BW + 1;
                            }

                            //右側の短線
                            if (alldata[i].JN_INFOBLOCKS.Count > location && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY3)
                                && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY3))
                                s.Cells[sr + BH + 1, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                            sr = sr + P34H;
                        }
                        //PROPERTY3、PROPERTY4
                        if (level.L4)
                        {
                            sc = 4;
                            for (int j = 0; j < location; j++)
                            {
                                if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4))
                                {
                                    if (j >= 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY4 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4)
                                    {
                                        //already set .
                                    }
                                    else
                                    {
                                        int endblock = 0;
                                        bool tmpflg = false;
                                        for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                        {
                                            if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY4)
                                            {
                                                if (k > location) tmpflg = true;
                                                endblock = k - j - 1;
                                                break;
                                            }
                                            if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                            {
                                                if (k >= location) tmpflg = true;
                                                endblock = k - j;
                                            }
                                        }
                                        if (endblock == 0) tmpflg = false;
                                        if (tmpflg)
                                        {
                                            endblock = location - j - 1;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                s.Cells[sr + BH + 1 + BSH,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4);
                                        }
                                        else
                                        {
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                s.Cells[sr + BH + 1 + BSH,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4);
                                        }
                                    }
                                }
                                sc = sc + BW + 1;
                            }

                            //右側の短線
                            if (alldata[i].JN_INFOBLOCKS.Count > location && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY4)
                                && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY4))
                                s.Cells[sr + BH + 1, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                            sr = sr + P34H;
                        }

                        //要求回答設定
                        if (level.REQRES)
                        {
                            sc = 4;
                            for (int j = 0; j < location; j++)
                            {
                                if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG))
                                {
                                    if (j >= 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_REQRESFLG == alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG)
                                    {
                                        //already set .
                                    }
                                    else
                                    {
                                        int endblock = 0;
                                        bool tmpflg = false;
                                        for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                        {
                                            if (alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG != alldata[i].JN_INFOBLOCKS[k].JN_REQRESFLG)
                                            {
                                                if (k > location) tmpflg = true;
                                                endblock = k - j - 1;
                                                break;
                                            }
                                            if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                            {
                                                endblock = k - j;
                                                if (k > location) tmpflg = true;
                                            }
                                        }
                                        if (endblock == 0) tmpflg = false;
                                        if (tmpflg)
                                        {
                                            endblock = location - j - 1;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                s.Cells[sr + BH + 1 + BSH,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG);
                                        }
                                        else
                                        {
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                s.Cells[sr + BH + 1 + BSH,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG);
                                        }

                                    }
                                }
                                sc = sc + BW + 1;
                            }

                            //右側の短線
                            if (alldata[i].JN_INFOBLOCKS.Count > location && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_REQRESFLG)
                                && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_REQRESFLG))
                                s.Cells[sr + BH + 1, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                            sr = sr + RESREQH;
                        }

                        //PROPERTY2設定
                        if (level.L2)
                        {
                            sc = 4;
                            for (int j = 0; j < location; j++)
                            {
                                if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2))
                                {
                                    if (j >= 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY2 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2)
                                    {
                                        //already set .
                                    }
                                    else
                                    {
                                        int endblock = 0;
                                        bool tmpflg = false;
                                        for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                        {
                                            if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY2)
                                            {
                                                if (k > location) tmpflg = true;
                                                endblock = k - j - 1;
                                                break;
                                            }
                                            if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                            {
                                                if (k > location) tmpflg = true;
                                                endblock = k - j;
                                            }
                                        }
                                        if (endblock == 0) tmpflg = false;
                                        if (tmpflg)
                                        {
                                            endblock = location - j - 1;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                s.Cells[sr + BH + 1 + BSH,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], "＊ " + p2dic[alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2]);
                                        }
                                        else
                                        {
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                s.Cells[sr + BH + 1 + BSH,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], "＊ " + p2dic[alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2]);
                                        }

                                    }
                                }
                                sc = sc + BW + 1;
                            }

                            if (alldata[i].JN_INFOBLOCKS.Count > location && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY2)
                                && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY2))
                                s.Cells[sr + BH + 1, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                            sr = sr + P2H;
                        }

                        //property5
                        if (level.L5)
                        {
                            sc = 4;
                            for (int j = 0; j < location; j++)
                            {
                                if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5))
                                {
                                    if (j >= 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY5 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5)
                                    {
                                        //already set .
                                    }
                                    else
                                    {
                                        int endblock = 0;
                                        bool tmpflg = false;

                                        for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                        {
                                            if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY5)
                                            {
                                                if (k > location) tmpflg = true;
                                                endblock = k - j - 1;
                                                break;
                                            }
                                            if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                            {
                                                if (k > location) tmpflg = true;
                                                endblock = k - j;
                                            }
                                        }

                                        if (endblock == 0) tmpflg = false;
                                        if (tmpflg)
                                        {
                                            endblock = location - j - 1;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                s.Cells[sr + BH + 1 + BSH,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5);
                                        }
                                        else
                                        {
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                s.Cells[sr + BH + 1 + BSH,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5);
                                        }
                                    }

                                }
                                sc = sc + BW + 1;
                            }

                            if (alldata[i].JN_INFOBLOCKS.Count > location && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY5)
                                && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY5))
                                s.Cells[sr + BH + 1, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                            sr = sr + P5H;
                        }
                    }
                    else if (lstid == allrow.Count - 1)
                    {
                        //last row

                        int sc = 4 + 1;
                        location = 10 + (lstid - 1) * 8;

                        //二行にて出力できる場合
                        if (allrow.Count == 2)
                        {
                            //情報部は１０個以上の場合
                            location = calcLocation(alldata, i);

                        }

                        sc = sc + (BW + 1) * (10 - (alldata[i].JN_INFOBLOCKS.Count - location));
                        //情報部ボックスの高　＋　下の一行移動
                        sr = sr + BH + 1 + 1;



                        //左側の短線
                        s.Cells[sr, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle = Excel.XlLineStyle.xlContinuous;
                        s.Cells[sr + BH, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                        s.Cells[sr + BH + 1, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                        for (int j = location; j < alldata[i].JN_INFOBLOCKS.Count; j++)
                        {
                            //情報部ボックス
                            drawJNBlock(s.Range[s.Cells[sr, sc], s.Cells[sr + BH, sc + BW]], alldata[i].JN_INFOBLOCKS[j].JN_NAME);
                            //サイズ情報
                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                            s.Range[s.Cells[sr + BH + 1, sc + BW], s.Cells[sr + BH + 1 + BSH, sc + BW]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                            drawSize(s.Range[s.Cells[sr + BH + 1, sc + 2], s.Cells[sr + BH + 1 + BSH, sc + BW - 2]], alldata[i].JN_INFOBLOCKS[j].JN_SIZE);
                            sc = sc + BW + 1;
                        }
                        sr = sr + SH;

                        //予約、解約、変更前、変更後
                        //PROPERTY3、PROPERTY4
                        if (level.L3)
                        {
                            sc = 4 + 1;
                            sc = sc + (BW + 1) * (10 - (alldata[i].JN_INFOBLOCKS.Count - location));

                            //先頭の短線
                            if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY3)
                                && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY3))
                                s.Cells[sr + BH + 1, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                            for (int j = location; j < alldata[i].JN_INFOBLOCKS.Count; j++)
                            {
                                if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3))
                                {
                                    if (j >= location + 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY3 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3)
                                    {
                                        //already set .
                                    }
                                    else
                                    {
                                        int endblock = 0;
                                        for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                        {
                                            if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY3)
                                            {
                                                endblock = k - j - 1;
                                                break;
                                            }
                                            if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                            {
                                                endblock = k - j;
                                            }
                                        }
                                        if (alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY3 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3
                                            && j == location)
                                        {
                                            //前行の最後の元素と同じ場合
                                        }
                                        else
                                        {
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        }
                                        s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1 + BSH, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                            s.Cells[sr + BH + 1 + BSH,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3);
                                    }
                                }
                                sc = sc + BW + 1;
                            }
                            sr = sr + P34H;
                        }
                        //PROPERTY3、PROPERTY4
                        if (level.L4)
                        {
                            sc = 4 + 1;
                            sc = sc + (BW + 1) * (10 - (alldata[i].JN_INFOBLOCKS.Count - location));

                            //先頭の短線
                            if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY4)
                                && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY4))
                                s.Cells[sr + BH + 1, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                            for (int j = location; j < alldata[i].JN_INFOBLOCKS.Count; j++)
                            {
                                if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4))
                                {
                                    if (j >= location + 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY4 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4)
                                    {
                                        //already set .
                                    }
                                    else
                                    {
                                        int endblock = 0;
                                        for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                        {
                                            if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY4)
                                            {
                                                endblock = k - j - 1;
                                                break;
                                            }
                                            if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                            {
                                                endblock = k - j;
                                            }
                                        }

                                        if (alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY4 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4
                                            && j == location)
                                        {
                                            //前行の最後の元素と同じ場合
                                        }
                                        else
                                        {
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        }

                                        s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                            s.Cells[sr + BH + 1 + BSH,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4);
                                    }
                                }
                                sc = sc + BW + 1;
                            }

                            sr = sr + P34H;
                        }

                        //要求回答設定
                        if (level.REQRES)
                        {
                            sc = 4 + 1;
                            sc = sc + (BW + 1) * (10 - (alldata[i].JN_INFOBLOCKS.Count - location));

                            //先頭の短線
                            if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_REQRESFLG)
                                && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_REQRESFLG))
                                s.Cells[sr + BH + 1, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                            for (int j = location; j < alldata[i].JN_INFOBLOCKS.Count; j++)
                            {
                                if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG))
                                {
                                    if (j >= location + 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_REQRESFLG == alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG)
                                    {
                                        //already set .
                                    }
                                    else
                                    {
                                        int endblock = 0;
                                        for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                        {
                                            if (alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG != alldata[i].JN_INFOBLOCKS[k].JN_REQRESFLG)
                                            {
                                                endblock = k - j - 1;
                                                break;
                                            }
                                            if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                            {
                                                endblock = k - j;
                                            }
                                        }

                                        if (alldata[i].JN_INFOBLOCKS[j - 1].JN_REQRESFLG == alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG
                                            && j == location)
                                        {
                                            //前行の最後の元素と同じ場合
                                        }
                                        else
                                        {
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        }
                                        //s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                            s.Cells[sr + BH + 1 + BSH,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG);
                                    }
                                }
                                sc = sc + BW + 1;
                            }

                            sr = sr + RESREQH;
                        }

                        //PROPERTY2設定
                        if (level.L2)
                        {
                            sc = 4 + 1;
                            sc = sc + (BW + 1) * (10 - (alldata[i].JN_INFOBLOCKS.Count - location));

                            //先頭の短線
                            if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY2)
                                && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY2))
                                s.Cells[sr + BH + 1, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                            for (int j = location; j < alldata[i].JN_INFOBLOCKS.Count; j++)
                            {
                                if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2))
                                {
                                    if (j >= location + 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY2 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2)
                                    {
                                        //already set .
                                    }
                                    else
                                    {
                                        int endblock = 0;
                                        for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                        {
                                            if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY2)
                                            {
                                                endblock = k - j - 1;
                                                break;
                                            }
                                            if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                            {
                                                endblock = k - j;
                                            }
                                        }
                                        if (alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY2 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2
                                            && j == location)
                                        {
                                            //前行の最後の元素と同じ場合
                                        }
                                        else
                                        {
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        }
                                        s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                            s.Cells[sr + BH + 1 + BSH,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], "＊ " + p2dic[alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2]);
                                    }
                                }
                                sc = sc + BW + 1;
                            }

                            sr = sr + P2H;
                        }

                        //property5
                        //MAX(N)
                        if (level.L5)
                        {
                            sc = 4 + 1;
                            sc = sc + (BW + 1) * (10 - (alldata[i].JN_INFOBLOCKS.Count - location));

                            //先頭の短線
                            if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY5)
                                && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY5))
                                s.Cells[sr + BH + 1, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                            for (int j = location; j < alldata[i].JN_INFOBLOCKS.Count; j++)
                            {
                                if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5))
                                {
                                    if (j >= location + 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY5 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5)
                                    {
                                        //already set .
                                    }
                                    else
                                    {
                                        int endblock = 0;

                                        for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                        {
                                            if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY5)
                                            {
                                                endblock = k - j - 1;
                                                break;
                                            }
                                            if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                            {
                                                endblock = k - j;
                                            }
                                        }

                                        if (alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY5 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5
                                            && j == location)
                                        {
                                            //前行の最後の元素と同じ場合
                                        }
                                        else
                                        {
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        }
                                        s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                            s.Cells[sr + BH + 1 + BSH,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5);

                                    }

                                }
                                sc = sc + BW + 1;
                            }

                            sr = sr + P5H;
                        }
                    }
                    else
                    {

                        int sc = 11;
                        location = 10 + (lstid - 1) * 8;

                        //情報部ボックスの高　＋　下の一行移動
                        sr = sr + BH + 1 + 1;

                        //左側の短線
                        s.Cells[sr, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle = Excel.XlLineStyle.xlContinuous;
                        s.Cells[sr + BH, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                        s.Cells[sr + BH + 1, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                        for (int j = location; j < location + 8; j++)
                        {
                            //情報部ボックス
                            drawJNBlock(s.Range[s.Cells[sr, sc], s.Cells[sr + BH, sc + BW]], alldata[i].JN_INFOBLOCKS[j].JN_NAME);
                            //サイズ情報
                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                            s.Range[s.Cells[sr + BH + 1, sc + BW], s.Cells[sr + BH + 1 + BSH, sc + BW]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                            drawSize(s.Range[s.Cells[sr + BH + 1, sc + 2], s.Cells[sr + BH + 1 + BSH, sc + BW - 2]], alldata[i].JN_INFOBLOCKS[j].JN_SIZE);
                            sc = sc + BW + 1;
                        }
                        //右側の短線
                        s.Cells[sr, sc].Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle = Excel.XlLineStyle.xlContinuous;
                        s.Cells[sr + BH, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                        s.Cells[sr + BH + 1, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                        sr = sr + SH;

                        //予約、解約、変更前、変更後
                        //PROPERTY3、PROPERTY4
                        if (level.L3)
                        {
                            sc = 11;

                            //先頭の短線
                            if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY3)
                                && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY3))
                                s.Cells[sr + BH + 1, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                            for (int j = location; j < location + 8; j++)
                            {
                                if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3))
                                {
                                    if (j >= location + 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY3 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3)
                                    {
                                        //already set .
                                    }
                                    else
                                    {
                                        int endblock = 0;
                                        bool tmpflg = false;
                                        for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                        {
                                            if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY3)
                                            {
                                                if (k > location + 8) tmpflg = true;
                                                endblock = k - j - 1;
                                                break;
                                            }
                                            if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                            {
                                                if (k > location + 8) tmpflg = true;
                                                endblock = k - j;
                                            }
                                        }
                                        if (endblock == 0) tmpflg = false;
                                        if (tmpflg) endblock = location + 8 - j - 1;
                                        if (alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY3 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3
                                            && j == location)
                                        {
                                            //前行の最後の元素と同じ場合
                                        }
                                        else
                                        {
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        }
                                        if (tmpflg == false)
                                            s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1 + BSH, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                            s.Cells[sr + BH + 1 + BSH,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3);
                                    }

                                }
                                sc = sc + BW + 1;
                            }

                            //右側の短線
                            if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location + 8 - 1].JN_PROPERTY3)
                                && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location + 8].JN_PROPERTY3))
                                s.Cells[sr + BH + 1, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                            sr = sr + P34H;
                        }

                        if (level.L4)
                        {
                            sc = 11;

                            //先頭の短線
                            if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY4)
                                && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY4))
                                s.Cells[sr + BH + 1, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                            for (int j = location; j < location + 8; j++)
                            {
                                if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4))
                                {
                                    if (j >= location + 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY4 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4)
                                    {
                                        //already set .
                                    }
                                    else
                                    {
                                        int endblock = 0;
                                        bool tmpflg = false;
                                        for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                        {
                                            if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY4)
                                            {
                                                if (k > location + 8) tmpflg = true;
                                                endblock = k - j - 1;
                                                break;
                                            }
                                            if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                            {
                                                if (k > location + 8) tmpflg = true;
                                                endblock = k - j;
                                            }
                                        }
                                        if (endblock == 0) tmpflg = false;
                                        if (tmpflg) endblock = location + 8 - j - 1;
                                        if (alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY4 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4
                                            && j == location)
                                        {
                                            //前行の最後の元素と同じ場合
                                        }
                                        else
                                        {
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        }
                                        if (tmpflg == false)
                                            s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                            s.Cells[sr + BH + 1 + BSH,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4);
                                    }
                                }
                                sc = sc + BW + 1;
                            }

                            //右側の短線
                            if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location + 8 - 1].JN_PROPERTY4)
                                && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location + 8].JN_PROPERTY4))
                                s.Cells[sr + BH + 1, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                            sr = sr + P34H;
                        }

                        //要求回答設定
                        if (level.REQRES)
                        {
                            sc = 11;

                            //先頭の短線
                            if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_REQRESFLG)
                                && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_REQRESFLG))
                                s.Cells[sr + BH + 1, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                            for (int j = location; j < location + 8; j++)
                            {
                                if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG))
                                {
                                    if (j >= location + 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_REQRESFLG == alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG)
                                    {
                                        //already set .
                                    }
                                    else
                                    {
                                        int endblock = 0;
                                        bool tmpflg = false;
                                        for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                        {
                                            if (alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG != alldata[i].JN_INFOBLOCKS[k].JN_REQRESFLG)
                                            {
                                                if (k > location + 8) tmpflg = true;
                                                endblock = k - j - 1;
                                                break;
                                            }
                                            if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                            {
                                                if (k > location + 8) tmpflg = true;
                                                endblock = k - j;
                                            }
                                        }

                                        if (endblock == 0) tmpflg = false;

                                        if (tmpflg) endblock = location + 8 - j - 1;

                                        if (alldata[i].JN_INFOBLOCKS[j - 1].JN_REQRESFLG == alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG
                                            && j == location)
                                        {
                                            //前行の最後の元素と同じ場合
                                        }
                                        else
                                        {
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        }
                                        if (tmpflg == false)
                                            s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                            s.Cells[sr + BH + 1 + BSH,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG);
                                    }
                                }
                                sc = sc + BW + 1;
                            }

                            //右側の短線
                            if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location + 8 - 1].JN_REQRESFLG)
                                && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location + 8].JN_REQRESFLG))
                                s.Cells[sr + BH + 1, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                            sr = sr + RESREQH;
                        }

                        //PROPERTY2設定
                        if (level.L2)
                        {
                            sc = 11;

                            //先頭の短線
                            if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY2)
                                && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY2))
                                s.Cells[sr + BH + 1, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                            for (int j = location; j < location + 8; j++)
                            {
                                if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2))
                                {
                                    if (j >= location + 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY2 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2)
                                    {
                                        //already set .
                                    }
                                    else
                                    {
                                        int endblock = 0;
                                        bool tmpflg = false;
                                        for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                        {
                                            if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY2)
                                            {
                                                endblock = k - j - 1;
                                                if (k > location + 8) tmpflg = true;
                                                break;
                                            }
                                            if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                            {
                                                if (k > location + 8) tmpflg = true;
                                                endblock = k - j;
                                            }
                                        }
                                        if (endblock == 0) tmpflg = false;
                                        if (tmpflg) endblock = location + 8 - j - 1;
                                        if (alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY2 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2
                                            && j == location)
                                        {
                                            //前行の最後の元素と同じ場合
                                        }
                                        else
                                        {
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        }
                                        if (tmpflg == false)
                                            s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                            s.Cells[sr + BH + 1 + BSH,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], "＊ " + p2dic[alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2]);
                                    }
                                }
                                sc = sc + BW + 1;
                            }

                            if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location + 8 - 1].JN_PROPERTY2)
                                && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location + 8].JN_PROPERTY2))
                                s.Cells[sr + BH + 1, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                            sr = sr + P2H;
                        }

                        //property5
                        //MAX(N)
                        if (level.L5)
                        {
                            sc = 11;

                            //先頭の短線
                            if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY5)
                                && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY5))
                                s.Cells[sr + BH + 1, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                            for (int j = location; j < location + 8; j++)
                            {
                                if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5))
                                {
                                    if (j >= location + 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY5 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5)
                                    {
                                        //already set .
                                    }
                                    else
                                    {
                                        int endblock = 0;
                                        //do not delete this one
                                        bool tmpflg = false;

                                        for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                        {
                                            if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY5)
                                            {
                                                if (k > location + 8) tmpflg = true;
                                                endblock = k - j - 1;
                                                break;
                                            }
                                            if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                            {
                                                if (k > location + 8) tmpflg = true;
                                                endblock = k - j;
                                            }
                                        }

                                        if (endblock == 0) tmpflg = false;
                                        if (tmpflg) endblock = location + 8 - j - 1;
                                        if (alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY5 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5
                                            && j == location)
                                        {
                                            //前行の最後の元素と同じ場合
                                        }
                                        else
                                        {
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        }
                                        if (tmpflg == false)
                                            s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                            s.Cells[sr + BH + 1 + BSH,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5.Replace("*", ""));

                                    }

                                }
                                sc = sc + BW + 1;
                            }

                            if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location + 8 - 1].JN_PROPERTY5)
                                && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location + 8].JN_PROPERTY5))
                                s.Cells[sr + BH + 1, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                            sr = sr + P5H;
                        }

                    }
                }

                //欠番設定
                if (alldata[i].Enabled == 2)
                {
                    drawTextLA(s.Range[s.Cells[sr2 - 1, 3], s.Cells[sr2 + 1, 8]], "欠番");
                    patterIndex++;
                }
                else
                {
                    patterIndex++;
                    //操作種別設定
                    if (!String.IsNullOrWhiteSpace(alldata[i].JN_OPTYPE))
                    {
                        string[] arr = alldata[i].JN_OPTYPE.Split('\n');
                        for (int tmpi = 0; tmpi < arr.Length; tmpi++)
                        {
                            if (String.IsNullOrEmpty(arr[tmpi]) || !arr[tmpi].StartsWith(" "))
                            {
                                drawTextLA(s.Range[s.Cells[sr2 + tmpi, OPCS], s.Cells[sr2 + tmpi, OPCE]], arr[tmpi]);
                            }
                            else
                            {
                                drawTextRA(s.Range[s.Cells[sr2 + tmpi, OPCS], s.Cells[sr2 + tmpi, OPCE]], arr[tmpi]);
                            }
                        }
                    }

                    //ANS設定
                    if (!String.IsNullOrWhiteSpace(alldata[i].JN_ANS))
                    {
                        //string[] arr = alldata[i].JN_ANS.Split('\n');
                        //for (int tmpi = 0; tmpi < arr.Length; tmpi++)
                        //{

                        //    drawTextCA(s.Range[s.Cells[sr2 + tmpi, AS], s.Cells[sr2 + tmpi, AE]], arr[tmpi]);
                        //}

                        drawTextCA(s.Range[s.Cells[sr2, AS], s.Cells[sr2 + 1, AE]], alldata[i].JN_ANS);
                    }

                    //パターン番号設定
                    if (!String.IsNullOrWhiteSpace(alldata[i].JN_PATTERNNO))
                    {
                        //string[] arr = alldata[i].JN_PATTERNNO.Split('\n');
                        //for (int tmpi = 0; tmpi < arr.Length; tmpi++)
                        //{

                        //    drawTextCA(s.Range[s.Cells[sr2 + tmpi, PS], s.Cells[sr2 + tmpi, PE]], arr[tmpi]);
                        //}

                        drawTextCA(s.Range[s.Cells[sr2, PS], s.Cells[sr2 + 1, PE]], alldata[i].JN_PATTERNNO);
                    }

                    //記事設定
                    if (!String.IsNullOrWhiteSpace(alldata[i].JN_COMMNENT))
                    {
                        string[] arr = alldata[i].JN_COMMNENT.Split('\n');
                        for (int tmpi = 0; tmpi < arr.Length; tmpi++)
                        {
                            if (String.IsNullOrEmpty(arr[tmpi]) || !arr[tmpi].StartsWith(" "))
                            {
                                drawTextLA(s.Range[s.Cells[sr2 + tmpi, CS], s.Cells[sr2 + tmpi, CE]], arr[tmpi]);
                            }
                            else
                            {
                                drawTextRA(s.Range[s.Cells[sr2 + tmpi, CS], s.Cells[sr2 + tmpi, CE]], arr[tmpi]);
                            }
                        }
                    }


                    //PROPERTY2文字辞典設定
                    if (p2dic.Count > 0)
                    {
                        var lst = p2dic.OrderByDescending(r => r.Value);
                        int ri = 0;
                        foreach (var ttmp in lst)
                        {
                            ri++;
                            drawTextLA(s.Range[s.Cells[sr2 + level.totalHeight - ri, CS], s.Cells[sr2 + level.totalHeight - ri, CE]], "*" + ttmp.Value + ":" + cvt(ttmp.Key));
                        }
                    }

                    //Totalサイズ設定
                    drawTextRA2(s.Cells[sr2 + level.totalHeight - 1, OPCS - 2], calcSize(alldata[i].JN_INFOBLOCKS));


                }

                //番号つける
                drawTextCA2(s.Cells[sr2, 2], $"{alldata[i].JN_SUBORDER}");
                int lr = sr2 + level.totalHeight;

                //枠線
                //bottom line
                s.Range[s.Cells[lr, 2], s.Cells[lr, CE]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                //left line
                s.Range[s.Cells[sr2 - 1, 2], s.Cells[lr, 2]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                s.Range[s.Cells[sr2 - 1, 2], s.Cells[lr, 2]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                //right line
                s.Range[s.Cells[sr2 - 1, CE], s.Cells[lr, CE]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                //inside line
                s.Range[s.Cells[sr2 - 1, OPCS], s.Cells[lr, OPCS]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                s.Range[s.Cells[sr2 - 1, AS], s.Cells[lr, AS]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                s.Range[s.Cells[sr2 - 1, PS], s.Cells[lr, PS]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                s.Range[s.Cells[sr2 - 1, CS], s.Cells[lr, CS]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;

                //廃れる場合、×を与える
                if (alldata[i].Enabled == 0)
                {
                    float y1 = g(sr2 - 2, rowHeight);
                    float y2 = g(lr, rowHeight);
                    s.Shapes.AddLine(x1, y1, x2, y2).Line.ForeColor.RGB = System.Drawing.Color.Black.ToArgb();
                    s.Shapes.AddLine(x1, y2, x2, y1).Line.ForeColor.RGB = System.Drawing.Color.Black.ToArgb();
                }

                sr = lr + 2;
                sr2 = lr + 2;
            }

            //break;


            //rename title
            for (int i = 0; i < headlst.Count; i++)
            {
                int tmpcnt = headlst.Count(r => r.Item2 == headlst[i].Item2);
                if (tmpcnt > 1)
                {
                    workbook.Sheets[headlst[i].Item1].Cells[5, 3].Value = workbook.Sheets[headlst[i].Item1].Cells[5, 3].Value + $"（{headlst[i].Item3}／{tmpcnt}）";
                }

            }

            //不要シート削除
            workbook.Sheets["T"].Delete();

            if (patterIndex > 0)
            {
                try
                {
                    workbook.SaveAs(output, Excel.XlFileFormat.xlWorkbookDefault, Type.Missing, Type.Missing, false, false, Excel.XlSaveAsAccessMode.xlNoChange, Excel.XlSaveConflictResolution.xlLocalSessionChanges, Type.Missing, Type.Missing);
                }
                catch
                {
                    int texbox = info.TextLength;
                    string ms = $"出力対象ファイルは使用中なので、保存できません\n";
                    info.AppendText(ms);
                    info.SelectionStart = texbox;
                    info.SelectionLength = ms.Length;
                    info.SelectionColor = System.Drawing.Color.Red;
                    info.ScrollToCaret();
                }
            }

            workbook.Close(false);

            xlApp.Quit();

            if (patterIndex > 0)
            {
                info.AppendText($"ジャーナルパターン仕様書出力は完了しました\n");
                info.ScrollToCaret();
                info.AppendText($"パス：{output}\n\n");
                info.ScrollToCaret();
            }
            else
            {
                info.AppendText($"出力できるジャーナルパターンはありません\n\n");
                info.ScrollToCaret();
            }



            if (xlApp != null)
            {
                int excelProcessId = -1;
                GetWindowThreadProcessId(new IntPtr(xlApp.Hwnd), ref excelProcessId);

                System.Diagnostics.Process ExcelProc = System.Diagnostics.Process.GetProcessById(excelProcessId);
                if (ExcelProc != null)
                {
                    ExcelProc.Kill();
                }
            }

        }

        private string cvt(string key)
        {
            string uiq = "|55172FD0-17AB-4AE6-BDDB-7A58F2342646|";

            int tmploc = key.IndexOf(uiq);

            if (tmploc < 0) return key;

            string res = key.Substring(tmploc + uiq.Length);

            return res;
        }

        private int calcLocation(List<ViewPattern> alldata, int i)
        {
            int l = -100;

            var ansfirst = alldata[i].JN_INFOBLOCKS.FirstOrDefault(r => r.JN_PROPERTY3 == "回答");

            if (ansfirst != null)
                l = alldata[i].JN_INFOBLOCKS.IndexOf(ansfirst);

            int left = alldata[i].JN_INFOBLOCKS.Count - l;

            if (l <= 10 && left <= 10)
            {
            }
            else
            {
                //ansfirst = alldata[i].JN_INFOBLOCKS.FirstOrDefault(r => r.JN_PROPERTY4 == "後");

                //if (ansfirst != null)
                //    l = alldata[i].JN_INFOBLOCKS.IndexOf(ansfirst);

                //left = alldata[i].JN_INFOBLOCKS.Count - l;

                //if (l <= 10 && left <= 10)
                //{

                //}
                //else
                //{
                //    ansfirst = alldata[i].JN_INFOBLOCKS.FirstOrDefault(r => (r.JN_PROPERTY5 + "").Contains("MAX"));

                //    if (ansfirst != null)
                //        l = alldata[i].JN_INFOBLOCKS.IndexOf(ansfirst);

                //    left = alldata[i].JN_INFOBLOCKS.Count - l;

                //    if (l <= 10 && left <= 10)
                //    {
                //    }
                //    else
                //    {
                //        l = 10;
                //    }
                //}
                l = 10;
            }

            return l;
        }

        /// <summary>
        /// Total row height calc
        /// </summary>
        /// <param name="v"></param>
        /// <param name="rowHeight"></param>
        /// <returns></returns>
        private float g(int v, List<float> rowHeight)
        {
            float res = 0;
            for (int i = 1; i <= v; i++)
            {
                res += rowHeight[i];
            }
            return res;
        }

        private string f(object jN_CUPID, object jN_TYPE)
        {
            return $"{jN_CUPID}　{jN_TYPE}　　";
        }

        /// <summary>
        /// サイズの範囲を計算する
        /// </summary>
        /// <param name="jN_INFOBLOCKS"></param>
        /// <returns></returns>
        private string calcSize(List<ViewInfoBlock> jN_INFOBLOCKS)
        {
            int min = 0;
            int max = 0;
            foreach (var tmp in jN_INFOBLOCKS)
            {
                if (tmp.JN_SIZE != null)
                {
                    min += tmp.JN_SIZE.Value;

                    if (!String.IsNullOrWhiteSpace(tmp.JN_PROPERTY5))
                    {
                        string num = tmp.JN_PROPERTY5.Replace("*", "").Replace("(", "").Replace(")", "").ToUpper().Replace("MAX", "");
                        int n = 1;
                        if (int.TryParse(num, out n))
                        {
                            max += tmp.JN_SIZE.Value * n;
                        }
                        else
                        {
                            max += tmp.JN_SIZE.Value;
                        }
                    }
                    else
                    {
                        max += tmp.JN_SIZE.Value;
                    }
                }
            }
            if (max == min && max != 0)
                return max.ToString();
            else if (max != min)
                return $"{min} ～ {max}";
            else
                return "";
        }

        [System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true)]
        private static extern int GetWindowThreadProcessId(IntPtr hwnd, ref int lpdwProcessId);

        //文字設定、左揃え、結合
        private void drawTextLA(Excel.Range er, string content)
        {
            er.Merge();
            er.Value = content;
            er.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;
            er.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
        }

        //文字設定、左揃え、結合
        private void drawTextLTA(Excel.Range er, string content)
        {
            er.Merge();
            er.Value = content;
            er.VerticalAlignment = Excel.XlVAlign.xlVAlignTop;
            er.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
            er.WrapText = true;

        }

        //文字設定、右揃え、結合
        private void drawTextRA(Excel.Range er, string content)
        {
            er.Merge();
            er.Value = content;
            er.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;
            er.HorizontalAlignment = Excel.XlHAlign.xlHAlignRight;
        }

        //文字設定、右揃え、結合
        private void drawTextRA2(Excel.Range er, string content)
        {
            er.Value = content;
            er.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;
            er.HorizontalAlignment = Excel.XlHAlign.xlHAlignRight;
        }

        //文字設定、中央揃え、結合
        private void drawTextCA(Excel.Range er, string content)
        {
            er.Merge();
            er.Value = content;
            er.VerticalAlignment = Excel.XlVAlign.xlVAlignTop;
            er.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
        }

        //文字設定、中央揃え、結合
        private void drawTextCA2(Excel.Range er, string content)
        {
            er.Value = content;
            er.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;
            er.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
        }

        //情報部設定
        private void drawJNBlock(Excel.Range er, string content)
        {
            er.Merge();
            er.Value = content;
            er.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
            er.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;
            er.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
            er.WrapText = true;
        }

        //情報部のサイズ情報設定
        private void drawSize(Excel.Range er, int? content)
        {
            er.Merge();
            er.Value = content;
            er.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;
            er.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
            er.WrapText = true;
        }

        //PROPERTY3、4情報設定
        private void drawP3P4(Excel.Range er, string content)
        {
            er.Merge();
            er.Value = content;
            er.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;
            er.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
            er.Borders.LineStyle = Excel.XlLineStyle.xlLineStyleNone;
            er.WrapText = true;
        }
    }
}
