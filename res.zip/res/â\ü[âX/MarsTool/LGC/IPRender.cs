﻿using NLog;
using NLog.LayoutRenderers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsTool.LGC
{
    [LayoutRenderer("ip")]
    public class IPRender : LayoutRenderer
    {
        protected override void Append(StringBuilder builder, LogEventInfo logEvent)
        {
            if (lst == null)
            {
                lst = new List<string>();
                var host = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName());
                foreach (var xx in host.AddressList)
                {
                    if (xx.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                    {
                        string res = xx.ToString();
                        if (res.StartsWith("192.168"))
                        {
                            lst.Add(res);
                        }
                        else
                        {
                            lst.Insert(0, res);
                        }
                    }
                    else
                    {
                        lst.Insert(0, xx.ToString());
                    }
                }
                ip = lst.LastOrDefault();
            }

            builder.Append(ip);
        }

        List<string> lst = null;
        string ip = "";

    }
}
