﻿namespace MarsTool.Models
{
    using System;

    public partial class PhyDenbunItmInfo
    {
        public int order { get; set; }
        
        public string type { get; set; }
        
        public string phyID { get; set; }

        public string seq { get; set; }

        public int turn { get; set; }
        
        public int yobiSize { get; set; }
    }
}
