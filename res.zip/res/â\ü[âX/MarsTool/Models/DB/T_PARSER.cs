namespace MarsTool.Models.DB
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class T_PARSER
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(8)]
        public string PARSE_PHDEFID { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int PARSE_ORDER { get; set; }

        [Required]
        [StringLength(1)]
        public string PARSE_TYPE { get; set; }

        [StringLength(15)]
        public string PARSE_BCPID { get; set; }

        [StringLength(20)]
        public string PARSE_SEQ { get; set; }

        [StringLength(8)]
        public string PARSE_LCPID { get; set; }

        public int? PARSE_ENTRY { get; set; }

        public int? PARSE_SIZE { get; set; }

        public int? PARSE_TURN { get; set; }

        [StringLength(7)]
        public string PARSE_USERID { get; set; }

        public DateTime? PARSEL_UPDTIME { get; set; }
    }
}
