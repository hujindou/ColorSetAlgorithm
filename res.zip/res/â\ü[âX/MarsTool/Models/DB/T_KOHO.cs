namespace MarsTool.Models.DB
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class T_KOHO
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(60)]
        public string KOHO_GROUP { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(4)]
        public string KOHO_CODE { get; set; }

        [Required]
        [StringLength(100)]
        public string KOHO_CONTENT { get; set; }

        [Required]
        public int KOHO_ORDER { get; set; }

        [StringLength(7)]
        public string KOHO_USERID { get; set; }

        public DateTime? KOHO_UPDTIME { get; set; }
    }
}
