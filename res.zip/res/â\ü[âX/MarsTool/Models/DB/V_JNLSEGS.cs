namespace MarsTool.Models.DB
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class V_JNLSEGS
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public string JNL_PATTERNID { get; set; }

        /// <summary>
        /// ���ID
        /// </summary>
        public string JNL_INFOID { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int JNL_ORDER { get; set; }

        public string JNL_REQRESFLG { get; set; }

        [Column("JNL_FREEIPT")]
        public string JNL_PROPERTY2 { get; set; }

        [Column("JNL_RSVTRM")]
        public string JNL_PROPERTY3 { get; set; }

        [Column("JNL_BEFAFT")]
        public string JNL_PROPERTY4 { get; set; }

        [Column("JNL_MAX")]
        public string JNL_PROPERTY5 { get; set; }

        public string JNL_INHERENT { get; set; }


        [StringLength(60)]
        public string JNL_NAME { get; set; }

        public int? JNL_SIZE { get; set; }
    }
}
