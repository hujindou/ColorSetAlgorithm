﻿using MySql.Data.EntityFramework;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsTool.Models.DB
{
    [DbConfigurationType(typeof(MySqlEFConfiguration))]
    public class commondbcontext : DbContext
    {
        public commondbcontext()
            : base("name=mysqldb")
        {
            Database.SetInitializer<commondbcontext>(null);
        }

        /// <summary>
        /// ユーザーテーブル
        /// </summary>
        public virtual DbSet<T_USER> T_USERS { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
        }

        private string host = null;

        public string getHost()
        {
            if (host == null)
                host = this.Database.SqlQuery<string>("select HOST from information_schema.PROCESSLIST where ID = connection_id()").Single();
            return host;
        }
    }
}
