namespace MarsTool.Models.DB
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class T_PHYITM
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(4)]
        public string PHYITM_SUBSYSID { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(20)]
        public string PHYITM_INFOID { get; set; }

        [Key]
        [Column(Order = 2)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int PHYITM_ITEMNO { get; set; }

        [StringLength(600)]
        public string PHYITM_PATH { get; set; }

        [StringLength(18)]
        public string PHYITM_SEQ { get; set; }

        public int? PHYITM_LEVEL { get; set; }

        [StringLength(60)]
        public string PHYITM_ITEMID { get; set; }

        [StringLength(60)]
        public string PHYITM_ITEMNM { get; set; }

        [StringLength(6)]
        public string PHYITM_DTTYPE { get; set; }

        public int? PHYITM_DTLEN { get; set; }

        public int? PHYITM_OCCURS { get; set; }

        [StringLength(4096)]
        public string PHYITM_COMMENT { get; set; }

        [StringLength(200)]
        public string PHYITM_NOTE { get; set; }

        [StringLength(60)]
        public string PHYITM_CPYDTTYPE { get; set; }

        [StringLength(1)]
        public string PHYITM_ITEMFLG { get; set; }

        [StringLength(60)]
        public string PHYITM_GROUP { get; set; }

        [StringLength(60)]
        public string PHYITM_IMAGENM { get; set; }

        [Column(TypeName = "blob")]
        public byte[] PHYITM_IMAGE { get; set; }
    }
}
