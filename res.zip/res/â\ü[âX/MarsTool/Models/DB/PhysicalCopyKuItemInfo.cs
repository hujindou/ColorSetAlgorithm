﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsTool.Models.DB
{
    class PhysicalCopyKuItemInfo
    {

        //サブシステムID
        public string PHYITM_SubSysId { get; set; }

        //情報部ID
        public string PHYITM_InfoId { get; set; }

        //項目パス
        public string PHYITM_Path { get; set; }

        //項番
        public int PHYITM_ItemNo { get; set; }

        //シーケンス
        public string PHYITM_Seq { get; set; }

        //項目レベル        
        public int PHYITM_Level { get; set; }

        //アイテム記号名称
        [StringLength(60, ErrorMessage = "アイテム記号名称が60桁以上になっています。")]
        public string PHYITM_ItemId { get; set; }

        //アイテム名称
        [StringLength(60, ErrorMessage = "アイテム名称が60桁以上になっています。")]
        public string PHYITM_ItemName { get; set; }

        //アイテムのデータ形式
        [StringLength(6, ErrorMessage = "アイテムのデータ形式が6桁以上になっています。")]
        public String PHYITM_DTTYPE { get; set; }

        //アイテムのデータサイズ
        public int PHYITM_DTLEN { get; set; }

        //コピー句データ形式
        [StringLength(60, ErrorMessage = "コピー句データ形式が60桁以上になっています。")]
        public string PHYITM_CPYDTTYPE { get; set; }

        //アイテム内容
        [StringLength(4096, ErrorMessage = "アイテム内容が4096桁以上になっています。")]
        public string PHYITM_Comment { get; set; }

        //記事
        [StringLength(200, ErrorMessage = "記事が200桁以上になっています。")]
        public string PHYITM_Note { get; set; }

        //アイテムフラグ
        public string PHYITM_ItemFlg { get; set; }      

        //繰り返し数
        public int PHYITM_Occurs { get; set; }     

        [NotMapped]
        public int Tmp_DTLEN { get; set; }

        [NotMapped]
        public List<SettingConditionInfo> settingConditionInfos { get; set; }

        [NotMapped]
        public List<LogicalCopyKuItemInfo> logicalCopyKuItemInfos { get; set; }

        [NotMapped]
        public T_PHYPRS mParserItemInfo { get; set; }

        [NotMapped]
        public int LAST_LEN { get; set; }

        [NotMapped]
        public List<PhysicalCopyKuItemInfo> childList = new List<PhysicalCopyKuItemInfo>();
                
    }
}
