﻿namespace MarsTool.Models.DB
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class T_DENSTRBITM
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(4)]
        public string DENSTRBITM_SUBSYSID { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(4)]
        public string DENSTRBITM_TELSUBSYSID { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(1)]
        public string DENSTRBITM_TELTYPE { get; set; }

        [Key]
        [Column(Order = 3)]
        [StringLength(10)]
        public string DENSTRBITM_PATNO { get; set; }

        [Key]
        [Column(Order = 4)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int DENSTRBITM_ORDER { get; set; }

        [Required]
        [StringLength(2)]
        public string DENSTRBITM_TYPE { get; set; }

        [StringLength(15)]
        public string DENSTRBITM_PHYID { get; set; }

        [StringLength(20)]
        public string DENSTRBITM_SEQ { get; set; }
        [NotMapped]
        public bool SEQ_IS_USED { get; set; }

        public int? DENSTRBITM_TURN { get; set; }

        public int? DENSTRBITM_YOBISIZE { get; set; }

        [StringLength(7)]
        public string DENSTRBITM_USERID { get; set; }

        public DateTime? DENSTRBITM_UPDTIME { get; set; }

    }
}
