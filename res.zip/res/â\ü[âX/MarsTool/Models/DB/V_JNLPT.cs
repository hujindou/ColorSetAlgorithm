﻿namespace MarsTool.Models.DB
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class V_JNLPT
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public string JNL_PATTERNID { get; set; }

        public string JNL_PATTERNNO { get; set; }

        public string JNL_CUPID { get; set; }

        public string JNL_SUBORDER { get; set; }

        public string JNL_TYPE { get; set; }

        public string JNL_OPTYPE { get; set; }

        public string JNL_ANS { get; set; }

        public string JNL_COMMNENT { get; set; }

        public int JNL_ENABLEFLG { get; set; }

        public DateTime? JNL_UPDTIME { get; set; }

        public virtual ICollection<V_JNLSEGS> JNL_INFOBLOCKS { get; set; }
    }
}