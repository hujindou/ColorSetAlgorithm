﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsTool.Models.DB
{
    public class T_USER
    {
        [Column("USR_USERID")]
        [Key]
        public string USERID { get; set; }

        [Column("USR_PASSWORD")]
        public string PASSWORD { get; set; }

        [Column("USR_UPDDATE")]
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public DateTime UPDDATE { get; set; }

        [Column("USR_USERNAME")]
        public string USERNAME { get; set; }

        [Column("USR_COMPANY")]
        public string COMPANY { get; set; }

        [Column("USR_ROLE")]
        public string ROLE { get; set; }

        [Column("USR_GRP")]
        public string GRP { get; set; }


    }
}
