﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsTool.Models.DB
{
    class SettingConditionInfo
    {

        //サブシステムID
        public string COND_SUBSYSID { get; set; }

        //情報部ID
        public string COND_INFOID { get; set; }

        //設定条件名
        [StringLength(10, ErrorMessage = "設定条件名が10桁以上になっています。")]
        public string COND_OPNM { get; set; }

        //物理アイテムのシーケンス
        public string COND_SEQ { get; set; }

        //出力順序
        public int COND_OUTPUTORDER { get; set; }

        //設定条件情報
        [StringLength(40, ErrorMessage = "設定条件情報が40桁以上になっています。")]
        public string COND_SETCOND { get; set; }

        //物理アイテムの項番
        [NotMapped]
        public int PHYITM_ItemNo { get; set; }

        //物理アイテムのパス
        [NotMapped]
        public string PHYITM_Path { get; set; }

        public bool checkDatalengthData()
        {
            var validator = new ValidationContext(this, null, null);
            var valres = new List<ValidationResult>();
            bool isVal = Validator.TryValidateObject(this, validator, valres, true);

            return isVal;
        }
    }
}
