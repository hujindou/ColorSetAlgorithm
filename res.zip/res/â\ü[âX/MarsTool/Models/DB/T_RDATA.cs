namespace MarsTool.Models.DB
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class T_RDATA
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(4)]
        public string RDATA_SUBSYSID { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(10)]
        public string RDATA_TABLEID { get; set; }

        [Required]
        [StringLength(60)]
        public string RDATA_SYSNM { get; set; }

        [Required]
        [StringLength(60)]
        public string RDATA_TABLENM { get; set; }

        [Required]
        [StringLength(10)]
        public string RDATA_RDATAFNM { get; set; }

        [Required]
        [StringLength(1)]
        public string RDATA_RDATAFEXT { get; set; }

        [Required]
        [StringLength(60)]
        public string RDATA_FILEGRP { get; set; }

        public int RDATA_BLKLEN { get; set; }

        [Required]
        [StringLength(1)]
        public string RDATA_STUTYPE { get; set; }

        [Required]
        [StringLength(100)]
        public string RDATA_SUBSYSNM { get; set; }

        [StringLength(20)]
        public string RDATA_COPYID { get; set; }

        [StringLength(1)]
        public string RDATA_SORT { get; set; }

        [StringLength(1)]
        public string RDATA_EXPAND { get; set; }        

        [StringLength(10)]
        public string RDATA_KEYLOC { get; set; }

        [StringLength(10)]
        public string RDATA_KEYLEN { get; set; }

        [StringLength(60)]
        public string RDATA_KEY { get; set; }

        public int RDATA_MAXENTRY { get; set; }

        [StringLength(7)]
        public string RDATA_USERID { get; set; }

        public DateTime? RDATA_UPDTIME { get; set; }
    }
}
