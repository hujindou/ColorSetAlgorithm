namespace MarsTool.Models.DB
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class T_JNLSEGS
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [StringLength(18)]
        public string JNL_PATTERNID { get; set; }

        [Required]
        [StringLength(20)]
        public string JNL_INFOID { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int JNL_ORDER { get; set; }

        [StringLength(64)]
        public string JNL_REQRESFLG { get; set; }

        //[StringLength(64)]
        //public string JN_PROPERTY1 { get; set; }

        [StringLength(64)]
        [Column("JNL_FREEIPT")]
        public string JNL_PROPERTY2 { get; set; }

        [StringLength(64)]
        [Column("JNL_RSVTRM")]
        public string JNL_PROPERTY3 { get; set; }

        [StringLength(64)]
        [Column("JNL_BEFAFT")]
        public string JNL_PROPERTY4 { get; set; }

        [StringLength(64)]
        [Column("JNL_MAX")]
        public string JNL_PROPERTY5 { get; set; }

        public string JNL_INHERENT { get; set; }

        public static implicit operator T_JNLSEGS(Models.ViewInfoBlock v)
        {
            T_JNLSEGS res = new T_JNLSEGS();
            res.JNL_PATTERNID = v.JN_PATTERNID;
            res.JNL_PROPERTY2 = v.JN_PROPERTY2;
            res.JNL_PROPERTY3 = v.JN_PROPERTY3;
            res.JNL_PROPERTY4 = v.JN_PROPERTY4;
            res.JNL_PROPERTY5 = v.JN_PROPERTY5;
            res.JNL_REQRESFLG = v.JN_REQRESFLG;
            res.JNL_INFOID = v.JN_INTERFACEID;
            res.JNL_INHERENT = v.INHERENTPROPERTY;
            return res;
        }
    }
}
