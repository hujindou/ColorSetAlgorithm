﻿namespace MarsTool.Models.DB
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class T_CONDITION
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(4)]
        [Required]
        public string COND_SUBSYSID { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(20)]
        [Required]
        public string COND_INFOID { get; set; }

        [Key]
        [Column(Order = 3)]
        [StringLength(10)]
        [Required]
        public string COND_OPNM { get; set; }

        [Key]
        [Column(Order = 4)]
        [StringLength(18)]
        [Required]
        public string COND_SEQ { get; set; }

        [Required]
        public int COND_OUTPUTORDER { get; set; }

        [StringLength(40)]
        [Required]
        public string COND_SETCOND { get; set; }


    }
}
