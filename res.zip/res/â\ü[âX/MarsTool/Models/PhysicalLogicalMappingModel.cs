﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsTool.Models
{
    class PhysicalLogicalMappingModel
    {
        public string Cpyphy_subsysid { get; set; }

        public string Cpyphy_bcpid { get; set; }

        public string Cpyphy_bcpnm { get; set; }

        public string Logitm_subsysidl { get; set; }

        public List<PhysicalLogicalItmInfoModel> phyItmInfoList { get; set; }
    }
}
