﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsTool.Models
{
    class LogicalOperationModel
    {
        public string Cond_opnm { get; set; }

        public string Cond_setcond { get; set; }

        public int Cond_outputorder { get; set; }
    }
}
