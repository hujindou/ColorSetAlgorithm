﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsTool.Models
{
    public class ViewInfoBlock
    {
        [StringLength(18)]
        public string JN_PATTERNID { get; set; }

        /// <summary>
        /// 情報部ID、インタフェーステーブル参照
        /// </summary>
        [StringLength(20)]
        public string JN_INTERFACEID { get; set; }

        /// <summary>
        /// インタフェーステーブルに存在しない情報部
        /// システムにて定義する情報部の名前
        /// </summary>
        public string JN_NAME { get; set; }
        /// <summary>
        /// インタフェーステーブルに存在しない情報部
        /// システムにて定義する情報部のサイズ
        /// </summary>
        public int? JN_SIZE { get; set; }

        public int JN_ORDER { get; set; }

        /// <summary>
        /// レベル３属性、自由入力
        /// </summary>
        [StringLength(64)]
        public string JN_REQRESFLG { get; set; }

        /// <summary>
        /// レベル４属性、区間１とか、先乗列車情報とか
        /// </summary>
        [StringLength(64)]
        public string JN_PROPERTY2 { get; set; }

        /// <summary>
        /// レベル１属性、要求、回答とか
        /// </summary>
        [StringLength(64)]
        public string JN_PROPERTY3 { get; set; }

        /// <summary>
        /// レベル２属性、自由入力
        /// </summary>
        [StringLength(64)]
        public string JN_PROPERTY4 { get; set; }

        /// <summary>
        /// レベル５属性、MAX(N)とか
        /// </summary>
        [StringLength(64)]
        public string JN_PROPERTY5 { get; set; }


        /// <summary>
        /// 固有属性
        /// </summary>
        [StringLength(64)]
        public string INHERENTPROPERTY { get; set; }

        public bool checkData()
        {
            var validator = new ValidationContext(this, null, null);
            var valres = new List<ValidationResult>();
            bool isVal = Validator.TryValidateObject(this, validator, valres, true);

            return isVal;
        }

    }
}
