﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsTool.Models
{
    public class ViewPattern
    {
        [StringLength(18)]
        public string JN_PATTERNID { get; set; }

        /// <summary>
        /// パターン番号
        /// </summary>
        [StringLength(16)]
        [Required]
        public string JN_PATTERNNO { get; set; }

        [StringLength(16)]
        [Required]
        public string JN_CUPID { get; set; }

        /// <summary>
        /// 券種別
        /// </summary>
        [StringLength(256)]
        public string JN_TYPE { get; set; }

        /// <summary>
        /// 枝番
        /// </summary>
        [StringLength(6)]
        [Required]
        public string JN_SUBORDER { get; set; }

        /// <summary>
        /// ジャーナルパターンは廃止か、使用かのフラッグ
        /// ２は欠番
        /// １は使用
        /// ０は廃止
        /// </summary>
        public int Enabled { get; set; }

        /// <summary>
        /// 操作種別
        /// </summary>
        [StringLength(2048)]
        public string JN_OPTYPE { get; set; }

        [StringLength(16)]
        [Required]
        public string JN_ANS { get; set; }

        /// <summary>
        /// 記事
        /// </summary>
        [StringLength(2048)]
        public string JN_COMMNENT { get; set; }

        public DateTime? DT { get; set; }

        public string JNSEGKEY
        {
            get
            {
                if (JN_INFOBLOCKS == null || JN_INFOBLOCKS.Count == 0)
                    return null;

                System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create();
                byte[] barr = System.Text.Encoding.UTF8.GetBytes(String.Join("", JN_INFOBLOCKS.Select(r => r.JN_INTERFACEID)));

                byte[] h = md5.ComputeHash(barr);
                string res = "";
                for (int j = 0; j < h.Length; j++)
                {
                    res += h[j].ToString("X2");
                }

                return res;
            }
        }

        /// <summary>
        /// 編集者
        /// </summary>
        [StringLength(7)]
        public string USERID { get; set; }

        public List<ViewInfoBlock> JN_INFOBLOCKS { get; set; }

        public bool checkData()
        {
            //欠番の場合
            if (Enabled == 2)
            {
                if (String.IsNullOrWhiteSpace(JN_CUPID))
                    return false;
                else
                    return true;
            }

            if (JN_INFOBLOCKS == null || JN_INFOBLOCKS.Count < 1)
                return false;

            var validator = new ValidationContext(this, null, null);
            var valres = new List<ValidationResult>();
            bool isVal = Validator.TryValidateObject(this, validator, valres, true);

            if (isVal == false)
                return false;

            if (JN_INFOBLOCKS.Any(r => r.checkData() == false))
                return false;

            return true;
        }

    }
}
