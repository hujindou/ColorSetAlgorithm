﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsTool.Models
{
    class PhySettingConMappingModel
    {
        public string Cpyphy_subsysid { get; set; }

        public string Cpyphy_bcpid { get; set; }

        public string Cpyphy_bcpnm { get; set; }

        public List<PhysicalItmInfoModel> phyItmInfoList { get; set; }
    }
}
