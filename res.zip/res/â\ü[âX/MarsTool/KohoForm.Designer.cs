﻿namespace MarsTool
{
    partial class KohoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dgvKoho = new System.Windows.Forms.DataGridView();
            this.CODE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CONTENT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.chkAll = new System.Windows.Forms.CheckBox();
            this.dgvGroup = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.GROUP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtGroupNm = new System.Windows.Forms.TextBox();
            this.tabKoho = new System.Windows.Forms.TabControl();
            this.tpInsert = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.txtInputPath = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tpEdit = new System.Windows.Forms.TabPage();
            this.dgvMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.AddBeforeMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AddAfterMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DelMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKoho)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGroup)).BeginInit();
            this.tabKoho.SuspendLayout();
            this.tpInsert.SuspendLayout();
            this.tpEdit.SuspendLayout();
            this.dgvMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 398);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(587, 22);
            this.statusStrip1.TabIndex = 13;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dgvKoho);
            this.groupBox3.Controls.Add(this.btnUpdate);
            this.groupBox3.Location = new System.Drawing.Point(261, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(311, 362);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "コード候補値一覧";
            // 
            // dgvKoho
            // 
            this.dgvKoho.AllowUserToAddRows = false;
            this.dgvKoho.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKoho.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CODE,
            this.CONTENT});
            this.dgvKoho.Location = new System.Drawing.Point(6, 46);
            this.dgvKoho.MultiSelect = false;
            this.dgvKoho.Name = "dgvKoho";
            this.dgvKoho.RowHeadersWidth = 25;
            this.dgvKoho.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvKoho.RowTemplate.Height = 21;
            this.dgvKoho.Size = new System.Drawing.Size(299, 313);
            this.dgvKoho.TabIndex = 5;
            this.dgvKoho.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.DgvKoho_CellMouseClick);
            this.dgvKoho.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.DgvKoho_CellValidating);
            // 
            // CODE
            // 
            this.CODE.HeaderText = "コード";
            this.CODE.MaxInputLength = 10;
            this.CODE.Name = "CODE";
            this.CODE.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CODE.Width = 80;
            // 
            // CONTENT
            // 
            this.CONTENT.HeaderText = "内容";
            this.CONTENT.MaxInputLength = 100;
            this.CONTENT.Name = "CONTENT";
            this.CONTENT.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CONTENT.Width = 150;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Enabled = false;
            this.btnUpdate.Location = new System.Drawing.Point(251, 18);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(54, 23);
            this.btnUpdate.TabIndex = 6;
            this.btnUpdate.Text = "更新";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.BtnUpdate_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnDelete);
            this.groupBox1.Controls.Add(this.chkAll);
            this.groupBox1.Controls.Add(this.dgvGroup);
            this.groupBox1.Controls.Add(this.btnSearch);
            this.groupBox1.Controls.Add(this.txtGroupNm);
            this.groupBox1.Location = new System.Drawing.Point(7, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(248, 362);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "グループ名";
            // 
            // btnDelete
            // 
            this.btnDelete.Enabled = false;
            this.btnDelete.Location = new System.Drawing.Point(187, 336);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(54, 23);
            this.btnDelete.TabIndex = 7;
            this.btnDelete.Text = "削除";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
            // 
            // chkAll
            // 
            this.chkAll.AutoSize = true;
            this.chkAll.Enabled = false;
            this.chkAll.Location = new System.Drawing.Point(12, 50);
            this.chkAll.Name = "chkAll";
            this.chkAll.Size = new System.Drawing.Size(15, 14);
            this.chkAll.TabIndex = 3;
            this.chkAll.UseVisualStyleBackColor = true;
            // 
            // dgvGroup
            // 
            this.dgvGroup.AllowUserToAddRows = false;
            this.dgvGroup.AllowUserToResizeRows = false;
            this.dgvGroup.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGroup.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.GROUP});
            this.dgvGroup.Location = new System.Drawing.Point(7, 46);
            this.dgvGroup.MultiSelect = false;
            this.dgvGroup.Name = "dgvGroup";
            this.dgvGroup.ReadOnly = true;
            this.dgvGroup.RowHeadersVisible = false;
            this.dgvGroup.RowTemplate.Height = 21;
            this.dgvGroup.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvGroup.Size = new System.Drawing.Size(234, 287);
            this.dgvGroup.TabIndex = 4;
            this.dgvGroup.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvGroup_CellClick);
            // 
            // Column1
            // 
            this.Column1.FalseValue = "0";
            this.Column1.HeaderText = "";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column1.TrueValue = "1";
            this.Column1.Width = 20;
            // 
            // GROUP
            // 
            this.GROUP.HeaderText = "グループ名";
            this.GROUP.Name = "GROUP";
            this.GROUP.ReadOnly = true;
            this.GROUP.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.GROUP.Width = 200;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(187, 18);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(54, 23);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "検索";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
            // 
            // txtGroupNm
            // 
            this.txtGroupNm.Location = new System.Drawing.Point(7, 20);
            this.txtGroupNm.MaxLength = 120;
            this.txtGroupNm.Name = "txtGroupNm";
            this.txtGroupNm.Size = new System.Drawing.Size(174, 19);
            this.txtGroupNm.TabIndex = 1;
            // 
            // tabKoho
            // 
            this.tabKoho.Controls.Add(this.tpInsert);
            this.tabKoho.Controls.Add(this.tpEdit);
            this.tabKoho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabKoho.Location = new System.Drawing.Point(0, 0);
            this.tabKoho.Name = "tabKoho";
            this.tabKoho.SelectedIndex = 0;
            this.tabKoho.Size = new System.Drawing.Size(587, 398);
            this.tabKoho.TabIndex = 17;
            // 
            // tpInsert
            // 
            this.tpInsert.BackColor = System.Drawing.SystemColors.Control;
            this.tpInsert.Controls.Add(this.label1);
            this.tpInsert.Controls.Add(this.button7);
            this.tpInsert.Controls.Add(this.button5);
            this.tpInsert.Controls.Add(this.button6);
            this.tpInsert.Controls.Add(this.txtInputPath);
            this.tpInsert.Controls.Add(this.label5);
            this.tpInsert.Location = new System.Drawing.Point(4, 22);
            this.tpInsert.Name = "tpInsert";
            this.tpInsert.Padding = new System.Windows.Forms.Padding(3);
            this.tpInsert.Size = new System.Drawing.Size(579, 372);
            this.tpInsert.TabIndex = 0;
            this.tpInsert.Text = "登録";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(208, 12);
            this.label1.TabIndex = 23;
            this.label1.Text = "※ツール専用入力シート（候補値グループ）";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(504, 100);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(58, 23);
            this.button7.TabIndex = 22;
            this.button7.Text = "クリア";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(428, 100);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(58, 23);
            this.button5.TabIndex = 21;
            this.button5.Text = "登録";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(530, 51);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(32, 19);
            this.button6.TabIndex = 19;
            this.button6.Text = "…";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // txtInputPath
            // 
            this.txtInputPath.Location = new System.Drawing.Point(89, 51);
            this.txtInputPath.Name = "txtInputPath";
            this.txtInputPath.Size = new System.Drawing.Size(435, 19);
            this.txtInputPath.TabIndex = 18;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(20, 54);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 12);
            this.label5.TabIndex = 17;
            this.label5.Text = "入力ファイル";
            // 
            // tpEdit
            // 
            this.tpEdit.BackColor = System.Drawing.SystemColors.Control;
            this.tpEdit.Controls.Add(this.groupBox1);
            this.tpEdit.Controls.Add(this.groupBox3);
            this.tpEdit.Location = new System.Drawing.Point(4, 22);
            this.tpEdit.Name = "tpEdit";
            this.tpEdit.Padding = new System.Windows.Forms.Padding(3);
            this.tpEdit.Size = new System.Drawing.Size(579, 372);
            this.tpEdit.TabIndex = 1;
            this.tpEdit.Text = "編集";
            // 
            // dgvMenu
            // 
            this.dgvMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddBeforeMenuItem,
            this.AddAfterMenuItem,
            this.DelMenuItem});
            this.dgvMenu.Name = "dgvMenu";
            this.dgvMenu.Size = new System.Drawing.Size(125, 70);
            // 
            // AddBeforeMenuItem
            // 
            this.AddBeforeMenuItem.Name = "AddBeforeMenuItem";
            this.AddBeforeMenuItem.Size = new System.Drawing.Size(124, 22);
            this.AddBeforeMenuItem.Text = "上へ追加";
            this.AddBeforeMenuItem.Click += new System.EventHandler(this.AddMenuItem_Click);
            // 
            // AddAfterMenuItem
            // 
            this.AddAfterMenuItem.Name = "AddAfterMenuItem";
            this.AddAfterMenuItem.Size = new System.Drawing.Size(124, 22);
            this.AddAfterMenuItem.Text = "下へ追加";
            this.AddAfterMenuItem.Click += new System.EventHandler(this.AddMenuItem_Click);
            // 
            // DelMenuItem
            // 
            this.DelMenuItem.Name = "DelMenuItem";
            this.DelMenuItem.Size = new System.Drawing.Size(124, 22);
            this.DelMenuItem.Text = "削除";
            this.DelMenuItem.Click += new System.EventHandler(this.DelMenuItem_Click);
            // 
            // KohoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(587, 420);
            this.Controls.Add(this.tabKoho);
            this.Controls.Add(this.statusStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "KohoForm";
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "候補値管理機能";
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvKoho)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGroup)).EndInit();
            this.tabKoho.ResumeLayout(false);
            this.tpInsert.ResumeLayout(false);
            this.tpInsert.PerformLayout();
            this.tpEdit.ResumeLayout(false);
            this.dgvMenu.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView dgvKoho;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtGroupNm;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TabControl tabKoho;
        private System.Windows.Forms.TabPage tpInsert;
        private System.Windows.Forms.TabPage tpEdit;
        private System.Windows.Forms.DataGridView dgvGroup;
        private System.Windows.Forms.ContextMenuStrip dgvMenu;
        private System.Windows.Forms.ToolStripMenuItem AddBeforeMenuItem;
        private System.Windows.Forms.ToolStripMenuItem DelMenuItem;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtInputPath;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.ToolStripMenuItem AddAfterMenuItem;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.CheckBox chkAll;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn GROUP;
        private System.Windows.Forms.DataGridViewTextBoxColumn CODE;
        private System.Windows.Forms.DataGridViewTextBoxColumn CONTENT;
    }
}