﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarsTool
{
    public partial class ImportantFM : Form
    {
        private List<String> data = null;
        private string title = null;
        public ImportantFM(List<string> p)
        {
            InitializeComponent();
            data = p;
        }

        public ImportantFM(string v)
        {
            InitializeComponent();
            title = v;
        }

        private void OtherFM_Load(object sender, EventArgs e)
        {
            if(!String.IsNullOrEmpty(title))
            {
                if(title != "レベル５属性設定")
                {
                    this.Text = title;
                    this.label1.Text = title + "：";
                }
                else
                {
                    this.Text = "リピート設定";
                    this.label1.Text = "リピート設定：";
                }
            }
        }
    }
}
