﻿using MarsTool.Common;
using MarsTool.Common.Forms;
using MarsTool.Exceptions;
using MarsTool.Models;
using MarsTool.Models.DB;
using MarsTool.Properties;
using MarsTool.Services;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MarsTool
{
    /// <summary>
    /// 物理パターン管理機能クラス
    /// </summary>
    public partial class TelForm : MarsForm
    {
        #region 登録・パターン編集

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public TelForm(VersionModel version) : base(version)
        {
            InitializeComponent();

            this.tabCtrlTel.TabPages.Remove(this.tabEdit);           
        }

        /// <summary>
        /// 「参照」ボタン
        /// </summary>
        private void button6_Click(object sender, EventArgs e)
        {
            // 「OpenFileDialog」のオブジェクトを作成
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "Excelファイル|*.xlsx";
            openFileDialog1.Title = "電文構成パターン入力パスを入力してください！";

            // ファイルダイアログを表示して、ＯＫでクリックするとテキストボックスに表示される。 
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this.textBox17.Text = openFileDialog1.FileName;
            }
        }

        /// <summary>
        /// 「登録」ボタン
        /// </summary>
        private void button5_Click_1(object sender, EventArgs e)
        {
            String inputFilePath = this.textBox17.Text;

            //入力ファイルの必須チェック
            if (string.IsNullOrEmpty(inputFilePath))
            {
                MessageBox.Show(Resources.DEN00001_E,
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            //入力ファイルの存在チェック
            else if (!System.IO.File.Exists(inputFilePath))
            {
                MessageBox.Show(Resources.DEN00002_E,
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else
            {
                try
                {
                    DenbunRegisterSev.getInstance(this.Version).PhyDenbunInfoRegisterProcess(inputFilePath);
                }
                catch (DenbunRegException denbunExp)
                {
                    //ファイル読み込みエラー
                    MessageBox.Show(denbunExp.GetMessage(),
                        Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                catch (System.Exception sysExp)
                {
                    // 予想外エラー
                    this.Logger.Error(String.Format(Resources.DEN00025_E, sysExp));
                    MessageBox.Show(Resources.DEN00016_E,
                        Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                
                //終了処理
                MessageBox.Show(Resources.DEN00020_I,
                    Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        /// <summary>
        /// 「クリア」ボタン
        /// </summary>
        private void button7_Click_1(object sender, EventArgs e)
        {
            // 「クリア」ボタンを押すと、電文構成パターン入力パスがクリアされる。
            this.textBox17.Text = "";
        }

        #endregion

        #region パターン編集

        private void TelForm_Load(object sender, EventArgs e)
        {
            if (this.tabCtrlTel.TabPages.Cast<TabPage>().Any(tp => tp == this.tabPattern))
            {
                // サブシステムＩＤ設定
                this.SetSysIds();
            }
        }

        /// <summary>
        /// サブシステムＩＤ設定
        /// </summary>
        public void SetSysIds()
        {
            try
            {
                if (this.combTelSubSysID.Items.Count > 0) return;

                var subSysIds = this.Context.T_DENSTRB.AsNoTracking()
                    .Select(r => r.DENSTRB_SUBSYSID).Distinct().OrderBy(id => id).ToArray();
                if (subSysIds == null || subSysIds.Length == 0) return;

                foreach (var sysId in subSysIds)
                {
                    this.combTelSubSysID.Items.Add(sysId);
                }
            }
            catch
            {
                var msg = $"サブシステムＩＤの取得処理が失敗しました。";
                this.Logger.Error(msg);
                MessageBox.Show(msg, Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
        }

        /// <summary>
        /// 検索処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnTelSearch_Click(object sender, EventArgs e)
        {
            // サブシステムＩＤ
            var subSysId = this.combTelSubSysID.Text;
            if (string.IsNullOrWhiteSpace(subSysId))
            {
                MessageBox.Show("サブシステムＩＤを入力してください。", Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            this.SearchPattern(subSysId);
        }

        /// <summary>
        /// サブシステムＩＤにより、ＤＢから電文情報を検索する
        /// </summary>
        /// <param name="subSysId"></param>
        private void SearchPattern(string subSysId)
        {
            try
            {
                // 電文構成パターン物理情報テーブル
                var denstrbs = this.Context.T_DENSTRB.AsNoTracking()
                    .Where(r => r.DENSTRB_SUBSYSID == subSysId)
                    .OrderBy(r => r.DENSTRB_ORDER);

                var list = denstrbs.ToList();
                foreach (var denstrb in list)
                {
                    // 電文構成パターン物理アイテム情報テーブル
                    denstrb.itemInfos = this.Context.T_DENSTRBITM.AsNoTracking().Where(
                        r => r.DENSTRBITM_SUBSYSID == denstrb.DENSTRB_SUBSYSID &&
                        r.DENSTRBITM_TELSUBSYSID == denstrb.DENSTRB_TELSUBSYSID &&
                        r.DENSTRBITM_TELTYPE == denstrb.DENSTRB_TELTYPE &&
                        r.DENSTRBITM_PATNO == denstrb.DENSTRB_PATNO
                        ).OrderBy(r => r.DENSTRBITM_ORDER).Take(10).ToList();
                }

                this.dgvTel.Rows.Clear();
                this.dgvTel.Tag = subSysId;

                var count = list.Count();
                this.btnTelUpdate.Enabled = count != 0;
                if (count == 0)
                {
                    MessageBox.Show("検索データが存在しませんでした。",
                        Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                this.SetDgv(list);
            }
            catch (Exception ex)
            {
                this.Logger.Error(ex.Message);
                var msg = $"{MessageId.TSR00012_E}\n{ex.Message}";
                MessageBox.Show(msg, Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 検索したデータが一覧に表示する
        /// </summary>
        /// <param name="queryDatas"></param>
        private void SetDgv(List<T_DENSTRB> queryDatas)
        {
            var fields = new List<string>();
            var order = 1;
            foreach (var record in queryDatas.ToList())
            {
                fields.Clear();
                // 順序
                fields.Add($"{order}"); order++;
                // コメント
                fields.Add(record.DENSTRB_COMMENT);
                // サブシステムＩＤ
                fields.Add(record.DENSTRB_SUBSYSID);
                // 相手サブシステムＩＤ
                fields.Add(record.DENSTRB_TELSUBSYSID);
                // 要求応答区分
                var type = record.DENSTRB_TELTYPE;
                switch(type)
                {
                    case "E":
                    case "R":
                        break;

                    default:
                        type = string.Empty;
                        break;
                }
                fields.Add(type);
                // パターン番号
                fields.Add(record.DENSTRB_PATNO);
                // 情報部グループＩＤ
                fields.Add(record.DENSTRB_GROUPID);

                // 物理ID
                foreach (var itemInfo in record.itemInfos)
                {
                    // 項目種別
                    switch (itemInfo.DENSTRBITM_TYPE)
                    {
                        case CommonConstant.ID:
                            if (itemInfo.DENSTRBITM_TURN > 1)
                            {
                                fields.Add($"{{{itemInfo.DENSTRBITM_PHYID}}}*{itemInfo.DENSTRBITM_TURN}");
                            }
                            else
                            {
                                fields.Add(itemInfo.DENSTRBITM_PHYID);
                            }
                            break;

                        case CommonConstant.YB:
                            fields.Add($"YOBI({itemInfo.DENSTRBITM_YOBISIZE})");
                            break;

                        default:
                            break;
                    }
                }

                var index = this.dgvTel.Rows.Add(fields.ToArray());
                RowUtils.SetData<T_DENSTRB>(this.dgvTel.Rows[index], record);
            }
        }

        /// <summary>
        /// 右クリックして、メニューを表示する
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DgvTel_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex < 0) return;

            var curRow = this.dgvTel.Rows[e.RowIndex];
            if (e.ColumnIndex >= 0)
            {
                var columnName = this.dgvTel.Columns[e.ColumnIndex].Name;
                switch (columnName)
                {
                    // コメント
                    case "COMMENT":
                    // 相手サブシステムＩＤ
                    case "TELSUBSYSID":
                    // 要求応答区分
                    case "TELTYPE":
                    // パターン番号
                    case "PATNO":
                    // 情報部グループＩＤ
                    case "GROUPID":
                        curRow.Cells[e.ColumnIndex].ReadOnly = RowUtils.IsDelete(curRow);
                        break;

                    default:
                        break;
                }
            }

            if (e.Button == MouseButtons.Right)
            {
                if (!this.CheckModifyPrivilege(this.dgvTel.Tag as string)) return;

                this.DelMenu.Visible = !RowUtils.IsDelete(curRow);
                
                var cellRect = this.dgvTel.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, false);
                this.dgvTelMenu.Tag = curRow;
                this.dgvTelMenu.Show(this.dgvTel, new Point(cellRect.X + e.X, cellRect.Y + e.Y));
            }
        }

        /// <summary>
        /// 候補値上下移動する
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MoveMenu_Click(object sender, EventArgs e)
        {
            if (this.dgvTelMenu.Tag is DataGridViewRow)
            {
                var row = this.dgvTelMenu.Tag as DataGridViewRow;
                var index = row.Index;

                if (sender == this.MoveBeforeMenu)
                {
                    if (index == 0) return;
                    index--;
                }
                else
                {
                    if (index == this.dgvTel.Rows.Count - 1) return;
                    index++;
                }
                this.dgvTel.Rows.Remove(row);
                this.dgvTel.Rows.Insert(index, row);

                this.DgvTelOrder();
            }
        }

        /// <summary>
        /// 新しい行追加
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AddMenu_Click(object sender, EventArgs e)
        {
            if (this.dgvTelMenu.Tag is DataGridViewRow && this.dgvTel.Tag is string)
            {
                var fields = new List<string>();
                // 順序
                fields.Add(string.Empty);
                // コメント
                fields.Add(string.Empty);
                // サブシステムＩＤ
                fields.Add(this.dgvTel.Tag as string);
                // 相手サブシステムＩＤ
                fields.Add(string.Empty);
                // 要求応答区分
                fields.Add(string.Empty);
                // パターン番号
                fields.Add(string.Empty);
                // 情報部グループＩＤ
                fields.Add(string.Empty);

                var index = (this.dgvTelMenu.Tag as DataGridViewRow).Index;
                if (sender == this.AddAfterMenu)
                {
                    index++;
                }
                this.dgvTel.Rows.Insert(index, fields.ToArray());
                RowUtils.SetNew(this.dgvTel.Rows[index]);

                this.DgvTelOrder();
            }
        }

        /// <summary>
        /// 選択した行を削除する
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DelMenu_Click(object sender, EventArgs e)
        {
            if (this.dgvTelMenu.Tag is DataGridViewRow)
            {
                var row = this.dgvTelMenu.Tag as DataGridViewRow;

                if (this.IsUsed(RowUtils.GetData<T_DENSTRB>(row)))
                {
                    MessageBox.Show("該当する行の物理ＩＤが使用中です、削除できません。",
                        Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                RowUtils.SetDelete(row);

                this.DgvTelOrder();
            }
        }

        /// <summary>
        /// 順序揃え
        /// </summary>
        private void DgvTelOrder()
        {
            var order = 1;
            this.dgvTel.Rows.Cast<DataGridViewRow>()
                .Where(r => !RowUtils.IsDelete(r))
                .ToList().ForEach(r => r.Cells["NO"].Value = order++);
        }

        /// <summary>
        /// 一覧に入力データを検証する
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DgvTel_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            var value = e.FormattedValue.ToString();
            if (string.IsNullOrWhiteSpace(value)) return;

            switch (this.dgvTel.Columns[e.ColumnIndex].Name)
            {
                // 相手サブシステムＩＤ
                case "TELSUBSYSID":
                    {
                        if (!Utils.IsAlpahNum(value))
                        {
                            MessageBox.Show("相手サブシステムＩＤは英数字を入力してください。",
                                Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            e.Cancel = true;
                        }
                    }
                    break;

                // パターン番号
                case "PATNO":
                    if (!Utils.IsNum(value))
                    {
                        MessageBox.Show("パターン番号は数値を入力してください。",
                            Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        e.Cancel = true;
                    }
                    break;

                default:
                    break;
            }
        }

        private bool CheckModifyPrivilege(string subSysId)
        {
            // 当サブシステムへの編集権限を持つかの判断
            if (!this.Version.hasSubsysModifyPrivilege(subSysId))
            {
                MessageBox.Show("該当するサブシステムへの更新権限がありません。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        /// <summary>
        /// 電文構成編集画面に遷移
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DgvTel_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            var row = this.dgvTel.Rows[e.RowIndex];

            // 当サブシステムへの編集権限を持つかの判断
            if (!this.CheckModifyPrivilege(RowUtils.GetValue(row, "SUBSYSID"))) return;

            if (RowUtils.IsNew(row))
            {
                MessageBox.Show("新規行です、先に更新してください。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (RowUtils.IsDelete(row))
            {
                MessageBox.Show("該当する行が削除されました。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (this.IsDgvTelRowEdited(row))
            {
                MessageBox.Show("該当する行が編集されました、先に更新してください。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                var f = new TelForm(RowUtils.GetData<T_DENSTRB>(row), this.Version);
                f.ShowDialog();
            }
            catch (Exception ex)
            {
                this.Logger.Error(ex.Message);
                var msg = $"{MessageId.TSR00012_E}\n{ex.Message}";
                MessageBox.Show(msg, Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool ValidateDgvTel()
        {
            var rows = this.dgvTel.Rows.Cast<DataGridViewRow>().Where(r => !RowUtils.IsDelete(r));

            // 相手サブシステムＩＤ必須判定
            if (rows.Any(r => string.Empty.Equals(RowUtils.GetValue(r, "TELSUBSYSID"))))
            {
                MessageBox.Show("相手サブシステムＩＤは必須入力項目です。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            // 要求応答区分必須判定
            if (rows.Any(r => string.Empty.Equals(RowUtils.GetValue(r, "TELTYPE"))))
            {
                MessageBox.Show("要求応答区分は必須入力項目です。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            // パターン番号必須判定
            if (rows.Any(r => string.Empty.Equals(RowUtils.GetValue(r, "PATNO"))))
            {
                MessageBox.Show("パターン番号は必須入力項目です。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            var groupCnt = rows.GroupBy(r =>
            {
                var subSysId = RowUtils.GetValue(r, "SUBSYSID");
                var telSubSysId = RowUtils.GetValue(r, "TELSUBSYSID");
                var telType = RowUtils.GetValue(r, "TELTYPE");
                var patNo = RowUtils.GetValue(r, "PATNO");

                return $"{subSysId}-{telSubSysId}-{telType}-{patNo}";
            }).Count();
            if (groupCnt != rows.Count())
            {
                MessageBox.Show("編集した物理パターン情報は一意制約が違反です。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        /// <summary>
        /// パターン一覧の行編集判定
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        private bool IsDgvTelRowEdited(DataGridViewRow row)
        {
            var record = RowUtils.GetData<T_DENSTRB>(row);

            // 順序
            if (!string.Equals(record.DENSTRB_ORDER.ToString(), RowUtils.GetValue(row, "NO"))) return true;

            // コメント
            var comment = record.DENSTRB_COMMENT;
            if (comment == null)
            {
                comment = string.Empty;
            }
            if (!string.Equals(comment, RowUtils.GetValue(row, "COMMENT"))) return true;

            // 相手サブシステムＩＤ
            if (!string.Equals(record.DENSTRB_TELSUBSYSID, RowUtils.GetValue(row, "TELSUBSYSID"))) return true;

            // 要求応答区分
            if (!string.Equals(record.DENSTRB_TELTYPE, RowUtils.GetValue(row, "TELTYPE"))) return true;

            // パターン番号
            if (!string.Equals(record.DENSTRB_PATNO, RowUtils.GetValue(row, "PATNO"))) return true;

            // 情報部グループＩＤ
            var groupId = record.DENSTRB_GROUPID;
            if (groupId == null)
            {
                groupId = string.Empty;
            }
            if (!string.Equals(groupId, RowUtils.GetValue(row, "GROUPID"))) return true;

            return false;
        }

        /// <summary>
        /// パターン一覧編集判定
        /// </summary>
        /// <returns></returns>
        private bool IsDgvTelEdited()
        {
            var rows = this.dgvTel.Rows.Cast<DataGridViewRow>();
            // 削除
            if (rows.Any(r => RowUtils.IsDelete(r) && RowUtils.HasData(r))) return true;

            // 削除された行が対象外
            rows = rows.Where(r => !RowUtils.IsDelete(r));

            // 登録
            if (rows.Any(r => !RowUtils.HasData(r))) return true;

            // 更新
            var updateRows = rows.Where(r => RowUtils.HasData(r));
            if (updateRows.Any(r => this.IsDgvTelRowEdited(r))) return true;

            return false;
        }

        /// <summary>
        /// 更新処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnTelUpdate_Click(object sender, EventArgs e)
        {
            // 当サブシステムへの編集権限を持つかの判断
            if (!this.CheckModifyPrivilege(this.dgvTel.Tag as string)) return;

            var result = MessageBox.Show("更新処理を行いますか?",
                Resources.QUESTION, MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (result == DialogResult.Cancel) return;

            if (!this.ValidateDgvTel()) return;

            if (!this.IsDgvTelEdited())
            {
                MessageBox.Show("何も編集していないため、更新されませんでした。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (var tran = this.Context.Database.BeginTransaction())
                {
                    var rows = this.dgvTel.Rows.Cast<DataGridViewRow>();

                    // 更新処理
                    var updRows = rows.Where(r => !RowUtils.IsDelete(r) && RowUtils.HasData(r)).ToList();
                    updRows.ForEach(r => this.UpdateDenstrb(r));

                    // 削除処理
                    var delRows = rows.Where(r => RowUtils.IsDelete(r) && RowUtils.HasData(r)).ToList();
                    delRows.ForEach(r => this.DeleteDenstrb(r));

                    // 新規処理
                    var newRows = rows.Where(r => RowUtils.IsNew(r)).ToList();
                    newRows.ForEach(r => this.InsertDenstrb(r));

                    tran.Commit();
                }

                this.SearchPattern(this.dgvTel.Tag as string);
                MessageBox.Show("更新処理が正常終了しました。",
                    Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch(ExclusiveException ee)
            {
                this.Logger.Error(ee.Message);
                MessageBox.Show(ee.Message, Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                this.Logger.Error(ex.Message);
                var msg = $"{MessageId.TSR00012_E}\n{ex.Message}";
                MessageBox.Show(msg, Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool IsUsed(T_DENSTRB denstrb)
        {
            if (denstrb == null) return false;

            return this.Context.Database.SqlQuery<int>(
                "SELECT COUNT(DENSTRBITM_SUBSYSID) FROM T_DENSTRBITM" +
                $" WHERE DENSTRBITM_SUBSYSID     = '{denstrb.DENSTRB_SUBSYSID}'" +
                $"   AND DENSTRBITM_TELSUBSYSID  = '{denstrb.DENSTRB_TELSUBSYSID}'" +
                $"   AND DENSTRBITM_TELTYPE      = '{denstrb.DENSTRB_TELTYPE}'" +
                $"   AND DENSTRBITM_PATNO        = '{denstrb.DENSTRB_PATNO}'" +
                $"   AND EXISTS (SELECT 1 FROM T_PARSER WHERE PARSE_SEQ = DENSTRBITM_SEQ)").Single() > 0;
        }

        /// <summary>
        /// 電文構成パターン物理情報テーブルの更新処理
        /// </summary>
        /// <param name="row"></param>
        private void UpdateDenstrb(DataGridViewRow row)
        {
            // 編集された行が処理対象です
            if (!this.IsDgvTelRowEdited(row)) return;

            var rowDenstrb = RowUtils.GetData<T_DENSTRB>(row);

            // 更新日時
            var updateTime = DateTime.Now.ToString();

            // 電文構成パターン物理情報テーブル
            var rtn = this.Context.Database.ExecuteSqlCommand($"UPDATE T_DENSTRB " +
                $" SET DENSTRB_UPDTIME       = '{updateTime}'" +
                $" WHERE DENSTRB_SUBSYSID    = '{rowDenstrb.DENSTRB_SUBSYSID}'" +
                $"   AND DENSTRB_TELSUBSYSID = '{rowDenstrb.DENSTRB_TELSUBSYSID}'" +
                $"   AND DENSTRB_TELTYPE     = '{rowDenstrb.DENSTRB_TELTYPE}'" +
                $"   AND DENSTRB_PATNO       = '{rowDenstrb.DENSTRB_PATNO}'" +
                $"   AND DENSTRB_UPDTIME     = '{rowDenstrb.DENSTRB_UPDTIME}'");
            this.Context.SaveChanges();
            if (rtn == 0)
            {
                throw new ExclusiveException();
            }

            // 更新
            this.Context.Database.ExecuteSqlCommand($"UPDATE T_DENSTRB " +
                $" SET DENSTRB_TELSUBSYSID      = '{RowUtils.GetValue(row, "TELSUBSYSID")}'," + // 相手サブシステムＩＤ
                $"     DENSTRB_TELTYPE          = '{RowUtils.GetValue(row, "TELTYPE")}'," +     // 要求応答区分
                $"     DENSTRB_PATNO            = '{RowUtils.GetValue(row, "PATNO")}'," +       // パターン番号
                $"     DENSTRB_ORDER            = '{RowUtils.GetValue(row, "NO")}'," +          // 順序
                $"     DENSTRB_COMMENT          = '{RowUtils.GetValue(row, "COMMENT")}'," +     // コメント
                $"     DENSTRB_GROUPID          = '{RowUtils.GetValue(row, "GROUPID")}'," +     // 情報部グループＩＤ
                $"     DENSTRB_USERID           = '{this.Version.User.USERID}'," +
                $"     DENSTRB_UPDTIME          = '{updateTime}' " +
                $" WHERE DENSTRB_SUBSYSID       = '{rowDenstrb.DENSTRB_SUBSYSID}'" +
                $"   AND DENSTRB_TELSUBSYSID    = '{rowDenstrb.DENSTRB_TELSUBSYSID}'" +
                $"   AND DENSTRB_TELTYPE        = '{rowDenstrb.DENSTRB_TELTYPE}'" +
                $"   AND DENSTRB_PATNO          = '{rowDenstrb.DENSTRB_PATNO}'");

            this.Context.Database.ExecuteSqlCommand($"UPDATE T_DENSTRBITM " +
                $" SET DENSTRBITM_TELSUBSYSID   = '{RowUtils.GetValue(row, "TELSUBSYSID")}'," + // 相手サブシステムＩＤ
                $"     DENSTRBITM_TELTYPE       = '{RowUtils.GetValue(row, "TELTYPE")}'," +     // 要求応答区分
                $"     DENSTRBITM_PATNO         = '{RowUtils.GetValue(row, "PATNO")}'" +        // パターン番号
                $" WHERE DENSTRBITM_SUBSYSID    = '{rowDenstrb.DENSTRB_SUBSYSID}'" +
                $"   AND DENSTRBITM_TELSUBSYSID = '{rowDenstrb.DENSTRB_TELSUBSYSID}'" +
                $"   AND DENSTRBITM_TELTYPE     = '{rowDenstrb.DENSTRB_TELTYPE}'" +
                $"   AND DENSTRBITM_PATNO       = '{rowDenstrb.DENSTRB_PATNO}'");
        }

        /// <summary>
        /// 電文構成パターン物理情報テーブルの削除処理
        /// </summary>
        /// <param name="row"></param>
        private void DeleteDenstrb(DataGridViewRow row)
        {
            var rowDenstrb = RowUtils.GetData<T_DENSTRB>(row);

            // 削除 シーケンスが紐付がありません場合
            if (RowUtils.IsDelete(row) && !this.IsUsed(rowDenstrb))
            {
                this.Context.Database.ExecuteSqlCommand($"DELETE FROM T_DENSTRB " +
                    $" WHERE DENSTRB_SUBSYSID       = '{rowDenstrb.DENSTRB_SUBSYSID}'" +
                    $"   AND DENSTRB_TELSUBSYSID    = '{rowDenstrb.DENSTRB_TELSUBSYSID}'" +
                    $"   AND DENSTRB_TELTYPE        = '{rowDenstrb.DENSTRB_TELTYPE}'" +
                    $"   AND DENSTRB_PATNO          = '{rowDenstrb.DENSTRB_PATNO}'");

                this.Context.Database.ExecuteSqlCommand($"DELETE FROM T_DENSTRBITM " +
                    $" WHERE DENSTRBITM_SUBSYSID    = '{rowDenstrb.DENSTRB_SUBSYSID}'" +
                    $"   AND DENSTRBITM_TELSUBSYSID = '{rowDenstrb.DENSTRB_TELSUBSYSID}'" +
                    $"   AND DENSTRBITM_TELTYPE     = '{rowDenstrb.DENSTRB_TELTYPE}'" +
                    $"   AND DENSTRBITM_PATNO       = '{rowDenstrb.DENSTRB_PATNO}'");
            }
        }

        /// <summary>
        /// 電文構成パターン物理情報テーブルの登録処理
        /// </summary>
        /// <param name="row"></param>
        private void InsertDenstrb(DataGridViewRow row)
        {
            this.Context.Database.ExecuteSqlCommand("INSERT INTO T_DENSTRB " +
                        "           (DENSTRB_SUBSYSID," +        // サブシステムＩＤ
                        "            DENSTRB_TELSUBSYSID," +     // 相手サブシステムＩＤ
                        "            DENSTRB_TELTYPE," +         // 要求応答区分
                        "            DENSTRB_PATNO," +           // パターン番号
                        "            DENSTRB_ORDER," +           // 順序
                        "            DENSTRB_GROUPID," +         // 情報部グループＩＤ
                        "            DENSTRB_COMMENT," +         // コメント
                        "            DENSTRB_USERID," +          // 更新ユーザＩＤ
                        "            DENSTRB_UPDTIME)" +         // 更新日時
                        "     VALUES(" +
                        $"           '{RowUtils.GetValue(row, "SUBSYSID")}'," +
                        $"           '{RowUtils.GetValue(row, "TELSUBSYSID")}'," +
                        $"           '{RowUtils.GetValue(row, "TELTYPE")}'," +
                        $"           '{RowUtils.GetValue(row, "PATNO")}'," +
                        $"           '{RowUtils.GetValue(row, "NO")}'," +
                        $"           '{RowUtils.GetValue(row, "GROUPID")}'," +
                        $"           '{RowUtils.GetValue(row, "COMMENT")}'," +
                        $"           '{this.Version.User.USERID}'," +
                        $"           '{DateTime.Now.ToString()}'" +
                        "           )");
        }
        #endregion

        #region 編集
        private T_DENSTRB Denstrb { set; get; }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public TelForm(T_DENSTRB denstrb, VersionModel version) : base(version)
        {
            InitializeComponent();
            this.tabCtrlTel.TabPages.Remove(this.tabInsert);
            this.tabCtrlTel.TabPages.Remove(this.tabPattern);

            var column = this.dgvPhyId.Columns["TYPE"];
            if (column is DataGridViewComboBoxColumn)
            {
                var cbColumn = column as DataGridViewComboBoxColumn;
                cbColumn.Items.AddRange(new object[]
                {
                new KeyValuePair<string, string>(CommonConstant.PHYSICALID, CommonConstant.ID),
                new KeyValuePair<string, string>(CommonConstant.YOBI_NM, CommonConstant.YB)
                });
                cbColumn.DisplayMember = "Key";
                cbColumn.ValueMember = "Value";
            }

            this.Init(denstrb);
        }

        /// <summary>
        /// 画面初期化
        /// </summary>
        /// <param name="denstrb"></param>
        private void Init(T_DENSTRB denstrb)
        {
            // 電文構成パターン物理情報テーブル
            var queryData = this.Context.T_DENSTRB.AsNoTracking().Where(
                r =>
                r.DENSTRB_SUBSYSID == denstrb.DENSTRB_SUBSYSID &&
                r.DENSTRB_TELSUBSYSID == denstrb.DENSTRB_TELSUBSYSID &&
                r.DENSTRB_TELTYPE == denstrb.DENSTRB_TELTYPE &&
                r.DENSTRB_PATNO == denstrb.DENSTRB_PATNO
                );
            this.Denstrb = queryData.First();

            this.txtSubSysId.Text = this.Denstrb.DENSTRB_SUBSYSID;
            this.txtTelSubSysId.Text = this.Denstrb.DENSTRB_TELSUBSYSID;
            this.txtTelType.Text = this.Denstrb.DENSTRB_TELTYPE;
            this.txtPatternNo.Text = this.Denstrb.DENSTRB_PATNO;
            this.txtGroupId.Text = this.Denstrb.DENSTRB_GROUPID;
            this.rTxtComment.Text = this.Denstrb.DENSTRB_COMMENT;

            this.SetDgvPhyId(denstrb);
        }

        /// <summary>
        /// 検索したデータが一覧に表示する
        /// </summary>
        /// <param name="denstrb"></param>
        private void SetDgvPhyId(T_DENSTRB denstrb)
        {
            // 電文構成パターン物理アイテム情報テーブル
            this.Denstrb.itemInfos = this.Context.T_DENSTRBITM.AsNoTracking().Where(
                r => r.DENSTRBITM_SUBSYSID == denstrb.DENSTRB_SUBSYSID &&
                r.DENSTRBITM_TELSUBSYSID == denstrb.DENSTRB_TELSUBSYSID &&
                r.DENSTRBITM_TELTYPE == denstrb.DENSTRB_TELTYPE &&
                r.DENSTRBITM_PATNO == denstrb.DENSTRB_PATNO
                ).OrderBy(r => r.DENSTRBITM_ORDER).ToList();

            this.dgvPhyId.Rows.Clear();
            var fields = new List<string>();
            foreach (var item in this.Denstrb.itemInfos)
            {
                fields.Clear();
                // 項目種別
                switch (item.DENSTRBITM_TYPE)
                {
                    case CommonConstant.ID:
                    case CommonConstant.YB:
                        fields.Add(item.DENSTRBITM_TYPE);
                        break;

                    default:
                        fields.Add(string.Empty);
                        break;
                }
                // 物理ＩＤ
                fields.Add(item.DENSTRBITM_PHYID);
                // 繰返し回数
                fields.Add(item.DENSTRBITM_TURN.ToString());
                // 予備サイズ
                fields.Add(item.DENSTRBITM_YOBISIZE.ToString());

                // シーケンスが紐付中
                item.SEQ_IS_USED = this.Context.T_PARSER.AsNoTracking()
                    .Any(r => string.Equals(r.PARSE_SEQ, item.DENSTRBITM_SEQ));

                var index = this.dgvPhyId.Rows.Add(fields.ToArray());
                RowUtils.SetData<T_DENSTRBITM>(this.dgvPhyId.Rows[index], item);
            }
        }

        #region 物理ＩＤ一覧応じるデータグリッドイベント
        /// <summary>
        /// 一覧の行を右クリックして、メニューを表示する
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DgvPhyId_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex < 0) return;

            // 無効行が編集できない
            var curRow = this.dgvPhyId.Rows[e.RowIndex];
            if (e.ColumnIndex >= 0)
            {
                if (RowUtils.IsDelete(curRow))
                {
                    curRow.Cells[e.ColumnIndex].ReadOnly = true;
                }
                else
                {
                    var denstrbitm = RowUtils.GetData<T_DENSTRBITM>(curRow);
                    if (denstrbitm != null && denstrbitm.SEQ_IS_USED)
                    {
                        // 使用中行が編集できない
                        var columnName = this.dgvPhyId.Columns[e.ColumnIndex].Name;
                        switch (columnName)
                        {
                            // 項目種別
                            case "TYPE":
                            // 物理ＩＤ
                            case "PHYID":
                            // 予備サイズ
                            case "YOBISIZE":
                                curRow.Cells[columnName].ReadOnly = true;
                                break;

                            default:
                                break;
                        }
                    }
                    else
                    {
                        // 項目種別
                        var type = RowUtils.GetValue(curRow, "TYPE");
                        if (CommonConstant.ID.Equals(type))
                        {
                            curRow.Cells["PHYID"].ReadOnly = false;
                            curRow.Cells["TURN"].ReadOnly = false;
                            curRow.Cells["YOBISIZE"].ReadOnly = true;
                        }
                        else
                        {
                            curRow.Cells["PHYID"].ReadOnly = true;
                            curRow.Cells["TURN"].ReadOnly = true;
                            curRow.Cells["YOBISIZE"].ReadOnly = false;
                        }
                    }
                }
            }

            // メニュー表示
            if (e.Button == MouseButtons.Right)
            {
                this.DelMenuItem.Visible = !RowUtils.IsDelete(curRow);

                var cellRect = this.dgvPhyId.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, false);
                this.dgvMenu.Tag = this.dgvPhyId.Rows[e.RowIndex];
                this.dgvMenu.Show(this.dgvPhyId, new Point(cellRect.X + e.X, cellRect.Y + e.Y));
            }
        }

        /// <summary>
        /// 一覧を右クリックして、メニューを表示する
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DgvPhyId_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Right) return;

            // メニュー表示
            if (sender is DataGridView)
            {
                var dgv = sender as DataGridView;
                var dgvRect = dgv.DisplayRectangle;
                this.dgvTelAddMenu.Tag = dgv;
                this.dgvTelAddMenu.Show(dgv, new Point(dgvRect.X + e.X, dgvRect.Y + e.Y));
            }
        }

        private void DgvPhyId_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;

            var curRow = this.dgvPhyId.Rows[e.RowIndex];
            var denstrbitm = RowUtils.GetData<T_DENSTRBITM>(curRow);
            if (denstrbitm == null) return;
            if (denstrbitm.SEQ_IS_USED)
            {
                switch (this.dgvPhyId.Columns[e.ColumnIndex].Name)
                {
                    // 物理ＩＤ
                    case "PHYID":
                    // 予備サイズ
                    case "YOBISIZE":
                        MessageBox.Show("該当する行の物理ＩＤが使用中です、変更できません。",
                            Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        break;

                    default:
                        break;
                }
            }
        }

        /// <summary>
        /// 上へ追加 まはた 下へ追加メニュー処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AddMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dgvMenu.Tag is DataGridViewRow)
            {
                var index = (this.dgvMenu.Tag as DataGridViewRow).Index;
                if (sender == this.AddAfterMenuItem)
                {
                    index++;
                }
                this.AddNewItem(index);
            }
        }

        /// <summary>
        /// 追加メニュー処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AddMenu_Click_1(object sender, EventArgs e)
        {
            this.AddNewItem(this.dgvPhyId.Rows.Count);
        }
        #endregion

        /// <summary>
        /// 物理ＩＤ一覧に新しい行を追加する
        /// </summary>
        /// <param name="index"></param>
        private void AddNewItem(int index)
        {
            var fields = new List<string>();
            // 項目種別
            fields.Add(string.Empty);
            // 物理ＩＤ
            fields.Add(string.Empty);
            // 繰返し回数
            fields.Add(string.Empty);
            // 予備サイズ
            fields.Add(string.Empty);

            this.dgvPhyId.Rows.Insert(index, fields.ToArray());
            RowUtils.SetNew(this.dgvPhyId.Rows[index]);
        }

        /// <summary>
        /// 物理ＩＤ一覧から、物理ＩＤを削除すりょ
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DelMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dgvMenu.Tag is DataGridViewRow)
            {
                var row = this.dgvMenu.Tag as DataGridViewRow;
                var denstrbitm = RowUtils.GetData<T_DENSTRBITM>(row);

                if (denstrbitm != null && denstrbitm.SEQ_IS_USED)
                {
                    MessageBox.Show("該当する行の物理ＩＤが使用中です、削除できません。",
                        Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                RowUtils.SetDelete(row);
            }
        }

        /// <summary>
        /// 物理ＩＤ一覧で、入力中データを検証する
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DgvPhyId_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            var value = e.FormattedValue.ToString();
            if (string.IsNullOrWhiteSpace(value) || RowUtils.IsDelete(this.dgvPhyId.Rows[e.RowIndex])) return;

            var curRow = this.dgvPhyId.Rows.Cast<DataGridViewRow>().ToArray()[e.RowIndex];

            // 項目名
            var itemName = this.dgvPhyId.Columns[e.ColumnIndex].Name;

            // 項目種別
            if ("TYPE".Equals(itemName))
            {
                if (CommonConstant.PHYSICALID.Equals(value))
                {
                    var turn = curRow.Cells["TURN"].Value;
                    if (turn == null || string.Empty.Equals(turn) || "0".Equals(turn))
                    {
                        curRow.Cells["TURN"].Value = "1";
                    }
                    curRow.Cells["YOBISIZE"].Value = "0";
                }
                else
                {
                    curRow.Cells["PHYID"].Value = string.Empty;
                    curRow.Cells["TURN"].Value = "0";
                    if ("0".Equals(curRow.Cells["YOBISIZE"].Value))
                    {
                        curRow.Cells["YOBISIZE"].Value = string.Empty;
                    }
                }

                return;
            }

            // 項目種別が物理ＩＤの場合
            if (CommonConstant.ID.Equals(curRow.Cells["TYPE"].Value))
            {
                switch (itemName)
                {
                    // 物理ＩＤ
                    case "PHYID":
                        {
                            if (!Utils.IsAlpahNum(value))
                            {
                                MessageBox.Show("物理ＩＤは英数字を入力してください。",
                                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                e.Cancel = true;
                            }
                        }
                        break;

                    // 繰返し回数
                    case "TURN":
                        if (!Utils.IsNum(value) || int.Parse(value) == 0)
                        {
                            MessageBox.Show("繰返し回数は１以上の数値を入力してください。",
                                Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            e.Cancel = true;
                        }
                        break;

                    default:
                        break;
                }
            }
            // 項目種別が予備の場合
            else
            {
                switch (itemName)
                {
                    // 予備サイズ
                    case "YOBISIZE":
                        if (!Utils.IsNum(value) || int.Parse(value) == 0)
                        {
                            MessageBox.Show("予備サイズは１以上の数値を入力してください。",
                                Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            e.Cancel = true;
                        }
                        break;

                    default:
                        break;
                }
            }
        }

        /// <summary>
        /// 物理ＩＤ一覧のデータを検証する
        /// </summary>
        /// <returns></returns>
        private bool ValidateDgv()
        {
            if (this.dgvPhyId.Rows.Count <= 0) return true;

            var rows = this.dgvPhyId.Rows.Cast<DataGridViewRow>().Where(r => !RowUtils.IsDelete(r));
            // 項目種別必須判定
            if (rows.Any(r => string.Empty.Equals(RowUtils.GetValue(r, "TYPE"))))
            {
                MessageBox.Show("項目種別は必須入力項目です。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            // 物理ＩＤ行
            var phyIdRows = rows.Where(r => CommonConstant.ID.Equals(RowUtils.GetValue(r, "TYPE")));

            // 物理ＩＤ必須判定
            if (phyIdRows.Any(r => string.Empty.Equals(RowUtils.GetValue(r, "PHYID"))))
            {
                MessageBox.Show("項目種別が物理ＩＤの場合、物理ＩＤは必須入力項目です。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            // 予備行
            var ybRows = rows.Where(r => CommonConstant.YB.Equals(RowUtils.GetValue(r, "TYPE")));

            // 予備サイズ必須判定
            if (ybRows.Any(r => string.Empty.Equals(RowUtils.GetValue(r, "YOBISIZE"))))
            {
                MessageBox.Show("項目種別が予備の場合、予備サイズは必須入力項目です。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        /// <summary>
        /// 物理ＩＤ一覧の行編集判定
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        private bool IsDgvRowEdited(DataGridViewRow row)
        {
            var item = RowUtils.GetData<T_DENSTRBITM>(row);

            // 項目種別
            var type = RowUtils.GetValue(row, "TYPE");
            if (!string.Equals(item.DENSTRBITM_TYPE.ToString(), type)) return true;

            // 物理ＩＤ
            var phyId = RowUtils.GetValue(row, "PHYID");
            if (!string.Equals(item.DENSTRBITM_PHYID.ToString(), phyId)) return true;

            // 繰返し回数
            var turn = RowUtils.GetValue(row, "TURN");
            if (!string.Equals(item.DENSTRBITM_TURN.ToString(), turn)) return true;

            // 予備サイズ
            var yobiSize = RowUtils.GetValue(row, "YOBISIZE");
            if (!string.Equals(item.DENSTRBITM_YOBISIZE.ToString(), yobiSize)) return true;

            return false;
        }

        /// <summary>
        /// 物理ＩＤ一覧編集判定
        /// </summary>
        /// <returns></returns>
        private bool IsDgvEdited()
        {
            var rows = this.dgvPhyId.Rows.Cast<DataGridViewRow>();
            // 削除
            if (rows.Any(r => RowUtils.IsDelete(r) && RowUtils.HasData(r))) return true;

            // 削除された行が対象外
            rows = rows.Where(r => !RowUtils.IsDelete(r));

            // 登録
            if (rows.Any(r => !RowUtils.HasData(r))) return true;

            // 更新
            var updateRows = rows.Where(r => RowUtils.HasData(r));
            foreach (var row in updateRows)
            {
                if (this.IsDgvRowEdited(row)) return true;
            }

            return false;
        }

        /// <summary>
        /// 更新処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("更新処理を行いますか?",
                Resources.QUESTION, MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (result == DialogResult.Cancel) return;

            if (!this.ValidateDgv()) return;

            var isEdited = false;

            // 情報部グループＩＤ編集判定
            var groupId = this.Denstrb.DENSTRB_GROUPID;
            if (groupId == null) groupId = string.Empty;
            if (!this.txtGroupId.Text.Equals(groupId))
            {
                isEdited = true;
            }
            // コメント編集判定
            var comment = this.Denstrb.DENSTRB_COMMENT;
            if (comment == null) comment = string.Empty;
            if (!isEdited && !this.rTxtComment.Text.Equals(comment))
            {
                isEdited = true;
            }

            var isDgvEdited = this.IsDgvEdited();
            if (!isEdited && !isDgvEdited)
            {
                MessageBox.Show("何も編集していないため、更新されませんでした。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                // 更新日時
                var updateTime = DateTime.Now.ToString();
                // 電文構成パターン物理情報テーブル
                var rtn = this.Context.Database.ExecuteSqlCommand($"UPDATE T_DENSTRB " +
                $" SET DENSTRB_UPDTIME       = '{updateTime}'" +
                $" WHERE DENSTRB_SUBSYSID    = '{this.Denstrb.DENSTRB_SUBSYSID}'" +
                $"   AND DENSTRB_TELSUBSYSID = '{this.Denstrb.DENSTRB_TELSUBSYSID}'" +
                $"   AND DENSTRB_TELTYPE     = '{this.Denstrb.DENSTRB_TELTYPE}'" +
                $"   AND DENSTRB_PATNO       = '{this.Denstrb.DENSTRB_PATNO}'" +
                $"   AND DENSTRB_UPDTIME     = '{this.Denstrb.DENSTRB_UPDTIME}'");
                this.Context.SaveChanges();
                if (rtn == 0)
                {
                    throw new ExclusiveException();
                }

                using (var tran = this.Context.Database.BeginTransaction())
                {
                    // 削除
                    this.Context.Database.ExecuteSqlCommand($"DELETE FROM T_DENSTRBITM " +
                        $" WHERE DENSTRBITM_SUBSYSID    = '{this.Denstrb.DENSTRB_SUBSYSID}'" +
                        $"   AND DENSTRBITM_TELSUBSYSID = '{this.Denstrb.DENSTRB_TELSUBSYSID}'" +
                        $"   AND DENSTRBITM_TELTYPE     = '{this.Denstrb.DENSTRB_TELTYPE}'" +
                        $"   AND DENSTRBITM_PATNO       = '{this.Denstrb.DENSTRB_PATNO}'");

                    // 削除された行が対象外
                    var rows = this.dgvPhyId.Rows.Cast<DataGridViewRow>().Where(r => !RowUtils.IsDelete(r));

                    // 順序
                    var order = 1;

                    // 登録
                    foreach (var row in rows)
                    {
                        // 項目種別
                        var type = RowUtils.GetValue(row, "TYPE");
                        // 物理ＩＤ
                        var phyId = RowUtils.GetValue(row, "PHYID");
                        // シーケンス
                        var seq = string.Empty;
                        var item = RowUtils.GetData<T_DENSTRBITM>(row);
                        if (item != null)
                        {
                            seq = item.DENSTRBITM_SEQ;
                        }
                        else
                        {
                            seq = this.Version.genSequenceID("T_DENSTRBITM");
                        }

                        // 繰返し回数
                        var turn = RowUtils.GetValue(row, "TURN");
                        // 予備サイズ
                        var yobiSize = RowUtils.GetValue(row, "YOBISIZE");

                        this.Context.Database.ExecuteSqlCommand(
                            "INSERT INTO T_DENSTRBITM " +
                            "           (DENSTRBITM_SUBSYSID," +
                            "            DENSTRBITM_TELSUBSYSID," +
                            "            DENSTRBITM_TELTYPE," +
                            "            DENSTRBITM_PATNO," +
                            "            DENSTRBITM_ORDER," +
                            "            DENSTRBITM_TYPE," +
                            "            DENSTRBITM_PHYID," +
                            "            DENSTRBITM_SEQ," +
                            "            DENSTRBITM_TURN," +
                            "            DENSTRBITM_YOBISIZE," +
                            "            DENSTRBITM_USERID," +
                            "            DENSTRBITM_UPDTIME)" +
                            "     VALUES(" +
                            $"           '{this.Denstrb.DENSTRB_SUBSYSID}'," +
                            $"           '{this.Denstrb.DENSTRB_TELSUBSYSID}'," +
                            $"           '{this.Denstrb.DENSTRB_TELTYPE}'," +
                            $"           '{this.Denstrb.DENSTRB_PATNO}'," +
                            $"           '{order++}'," +
                            $"           '{type}'," +
                            $"           '{phyId}'," +
                            $"           '{seq}'," +
                            $"           '{turn}'," +
                            $"           '{yobiSize}'," +
                            $"           '{this.Version.User.USERID}'," +
                            $"           '{updateTime}'" +
                            "           )");
                    }

                    this.Context.Database.ExecuteSqlCommand($"UPDATE T_DENSTRB " +
                        $" SET DENSTRB_GROUPID        = '{this.txtGroupId.Text}'," +
                        $"     DENSTRB_COMMENT        = '{this.rTxtComment.Text}'," +
                        $"     DENSTRB_USERID         = '{this.Version.User.USERID}'," +
                        $"     DENSTRB_UPDTIME        = '{updateTime}' " +
                        $" WHERE DENSTRB_SUBSYSID     = '{this.Denstrb.DENSTRB_SUBSYSID}'" +
                        $"   AND DENSTRB_TELSUBSYSID  = '{this.Denstrb.DENSTRB_TELSUBSYSID}'" +
                        $"   AND DENSTRB_TELTYPE      = '{this.Denstrb.DENSTRB_TELTYPE}'" +
                        $"   AND DENSTRB_PATNO        = '{this.Denstrb.DENSTRB_PATNO}'");

                    tran.Commit();
                }
                this.Init(this.Denstrb);
                MessageBox.Show("更新処理が正常終了しました。",
                    Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (ExclusiveException ee)
            {
                this.Logger.Error(ee.Message);
                MessageBox.Show(ee.Message, Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                this.Logger.Error(ex.Message);
                var msg = $"{MessageId.TSR00012_E}\n{ex.Message}";
                MessageBox.Show(msg, Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion
    }
}