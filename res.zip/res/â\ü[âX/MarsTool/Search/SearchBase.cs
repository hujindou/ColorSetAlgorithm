﻿using MarsTool.Common.Forms;
using MarsTool.Models;
using MarsTool.Models.DB;
using MarsTool.Properties;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace MarsTool.Search
{
    /// <summary>
    /// 検索タグベースクラス
    /// </summary>
    /// <typeparam name="T"></typeparam>
    abstract class SearchBase<T> : ISubSysId
    {
        protected Logger Logger = NLog.LogManager.GetCurrentClassLogger();

        /// <summary>
        /// 検索最大件数
        /// </summary>
        protected const int MAX_COUNT = 50;

        /// <summary>
        /// サブシステムＩＤコントロール
        /// </summary>
        protected ComboBox SubSysIdsCtl { get; private set; }
        protected string SubSysId
        {
            get
            {
                var index = this.SubSysIdsCtl.SelectedIndex;
                if (this.SubSysIdsCtl == null || index < 0) return string.Empty;
                return this.SubSysIdsCtl.Items[index].ToString();
            }
        }

        /// <summary>
        /// データ一覧コントロール
        /// </summary>
        protected DataGridView Dgv { get; private set; }

        private CheckDataGridView CheckDgv { get; set; }

        /// <summary>
        /// バージョンモデル
        /// </summary>
        public VersionModel Version { get; private set; }

        /// <summary>
        /// バージョンモデル
        /// </summary>
        protected mysqlcontext Context
        {
            get
            {
                return Version.context;
            }
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public SearchBase(ComboBox subSysIdsCtl, DataGridView dgv, VersionModel version)
        {
            this.SubSysIdsCtl = subSysIdsCtl;

            this.Dgv = dgv;
            this.Dgv.CellDoubleClick += CellDoubleClick;
            if (this.Dgv.Tag is CheckBox)
            {
                this.CheckDgv = new CheckDataGridView(this.Dgv, this.Dgv.Tag as CheckBox);
                this.CheckDgv.ChangeStatus += ChangeStatus;
            }

            this.Version = version;
        }

        protected virtual void ChangeStatus(bool nodata) { }

        protected virtual void CellDoubleClick(object sender, DataGridViewCellEventArgs e) { }

        /// <summary>
        /// サブシステムＩＤ設定
        /// </summary>
        public bool SetSysIds()
        {
            try
            {
                if (this.SubSysIdsCtl == null || this.SubSysIdsCtl.Items.Count > 0) return true;
                var subSysIds = this.SearchSysIds();
                if (subSysIds == null || subSysIds.Length == 0) return true;

                this.SubSysIdsCtl.Items.Add(string.Empty);
                foreach (var sysId in subSysIds)
                {
                    this.SubSysIdsCtl.Items.Add(sysId);
                }

                return true;
            }
            catch (Exception ex)
            {
                this.Logger.Error(ex.Message);
                MessageBox.Show($"サブシステムＩＤの取得処理が失敗しました。",
                    Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);

                return false;
            }
        }

        protected virtual string[] SearchSysIds() { return null; }

        /// <summary>
        /// 検索
        /// </summary>
        /// <param name="dgv"></param>
        public void Search()
        {
            this.Search(true);
        }

        public void Search(bool showMsg)
        {
            try
            {
                if (!this.Validate()) return;

                this.Clear();
                var count = 0;
                var queryDatas = this.SearchData(out count);
                if (count == 0)
                {
                    if (showMsg)
                    {
                        MessageBox.Show("検索データが存在しませんでした。",
                            Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    return;
                }

                if (this.Dgv.Tag is CheckBox)
                {
                    (this.Dgv.Tag as CheckBox).Enabled = true;
                }

                // 検索されたデータが一覧に表示する
                this.SetDgv(queryDatas);

                if (showMsg && count > MAX_COUNT)
                {
                    var msg = $"{count}件を検索しましたが、{MAX_COUNT}件のみを表示します。";
                    MessageBox.Show(msg, Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                this.Logger.Error(ex.Message);
                var msg = $"{MessageId.TSR00012_E}\n{ex.Message}";
                MessageBox.Show(msg, Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        protected virtual bool Validate()
        {
            return true;
        }

        protected abstract List<T> SearchData(out int count);

        /// <summary>
        /// 画面クリア処理
        /// </summary>
        protected virtual void Clear()
        {
            this.Dgv.Rows.Clear();
            if (this.Dgv.Tag is CheckBox)
            {
                var chkbox = this.Dgv.Tag as CheckBox;

                chkbox.Checked = false;
                chkbox.Enabled = false;
            }
            this.ChangeStatus(true);
        }

        /// <summary>
        /// 検索されたデータが一覧に表示する
        /// </summary>
        /// <param name="queryDatas"></param>
        protected virtual void SetDgv(List<T> queryDatas) { }
    }
}
