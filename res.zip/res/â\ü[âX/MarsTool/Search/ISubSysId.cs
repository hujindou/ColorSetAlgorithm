﻿namespace MarsTool.Search
{
    /// <summary>
    /// サブシステムＩＤ検索インタフェース
    /// </summary>
    public interface ISubSysId
    {
        /// <summary>
        /// サブシステムＩＤ検索
        /// </summary>
        bool SetSysIds();
    }
}
