﻿namespace MarsTool
{
    partial class RDataForm
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.openFileDlg = new System.Windows.Forms.OpenFileDialog();
            this.folderBrowserDlg = new System.Windows.Forms.FolderBrowserDialog();
            this.backgroundWorker = new System.ComponentModel.BackgroundWorker();
            this.addDelMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.AddBeforeMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AddAfterMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AddMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DelMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.UnDelMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabRData = new System.Windows.Forms.TabControl();
            this.tpInsert = new System.Windows.Forms.TabPage();
            this.tabInsert = new System.Windows.Forms.TabControl();
            this.tpFileInsert = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnLoadRData = new System.Windows.Forms.Button();
            this.btnFileInsert = new System.Windows.Forms.Button();
            this.btnSelectFolder = new System.Windows.Forms.Button();
            this.txtRDataFolder = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.chkAllInsert = new System.Windows.Forms.CheckBox();
            this.dgvRDataFile = new System.Windows.Forms.DataGridView();
            this.Selected = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Filename = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Extension = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.InsertStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tpNewInsert = new System.Windows.Forms.TabPage();
            this.btnNewInsert = new System.Windows.Forms.Button();
            this.rdtNewInsert = new MarsTool.RData.RDataEditor();
            this.tpEdit = new System.Windows.Forms.TabPage();
            this.grpComp = new System.Windows.Forms.GroupBox();
            this.btnDbFileComp = new System.Windows.Forms.Button();
            this.btnSelectRData = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtRDataFile = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.rdtUpdate = new MarsTool.RData.RDataEditor();
            this.ucEditOutput = new MarsTool.RData.RDataOutput();
            this.tpOutput = new System.Windows.Forms.TabPage();
            this.ucOutput = new MarsTool.RData.RDataOutput();
            this.chkRDataAll = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rdoRDataTbNm = new System.Windows.Forms.RadioButton();
            this.rdoRDataTbId = new System.Windows.Forms.RadioButton();
            this.txtRDataTbNm = new System.Windows.Forms.TextBox();
            this.combSubSysID = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.btnSelecct = new System.Windows.Forms.Button();
            this.txtRDataTbId = new System.Windows.Forms.TextBox();
            this.dgvRDataOutput = new System.Windows.Forms.DataGridView();
            this.Column3 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.progressBarNewInsert = new System.Windows.Forms.ToolStripProgressBar();
            this.progressBarFileInsert = new System.Windows.Forms.ToolStripProgressBar();
            this.progressBarEdit = new System.Windows.Forms.ToolStripProgressBar();
            this.progressBarOutput = new System.Windows.Forms.ToolStripProgressBar();
            this.addDelMenu.SuspendLayout();
            this.tabRData.SuspendLayout();
            this.tpInsert.SuspendLayout();
            this.tabInsert.SuspendLayout();
            this.tpFileInsert.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRDataFile)).BeginInit();
            this.tpNewInsert.SuspendLayout();
            this.tpEdit.SuspendLayout();
            this.grpComp.SuspendLayout();
            this.tpOutput.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRDataOutput)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // openFileDlg
            // 
            this.openFileDlg.Filter = "(*.csv)|*.csv|(*.txt)|*.txt|(*.*)|*.*";
            // 
            // backgroundWorker
            // 
            this.backgroundWorker.WorkerReportsProgress = true;
            this.backgroundWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BackgroundWorker_DoWork);
            this.backgroundWorker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.BackgroundWorker_ProgressChanged);
            this.backgroundWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.BackgroundWorker_RunWorkerCompleted);
            // 
            // addDelMenu
            // 
            this.addDelMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddBeforeMenuItem,
            this.AddAfterMenuItem,
            this.AddMenuItem,
            this.DelMenuItem,
            this.UnDelMenuItem});
            this.addDelMenu.Name = "MenuItem";
            this.addDelMenu.Size = new System.Drawing.Size(125, 114);
            // 
            // AddBeforeMenuItem
            // 
            this.AddBeforeMenuItem.Name = "AddBeforeMenuItem";
            this.AddBeforeMenuItem.Size = new System.Drawing.Size(124, 22);
            this.AddBeforeMenuItem.Tag = "AddBefore";
            this.AddBeforeMenuItem.Text = "上へ追加";
            // 
            // AddAfterMenuItem
            // 
            this.AddAfterMenuItem.Name = "AddAfterMenuItem";
            this.AddAfterMenuItem.Size = new System.Drawing.Size(124, 22);
            this.AddAfterMenuItem.Tag = "AddAfter";
            this.AddAfterMenuItem.Text = "下へ追加";
            // 
            // AddMenuItem
            // 
            this.AddMenuItem.Name = "AddMenuItem";
            this.AddMenuItem.Size = new System.Drawing.Size(124, 22);
            this.AddMenuItem.Tag = "Add";
            this.AddMenuItem.Text = "追加";
            // 
            // DelMenuItem
            // 
            this.DelMenuItem.Name = "DelMenuItem";
            this.DelMenuItem.Size = new System.Drawing.Size(124, 22);
            this.DelMenuItem.Tag = "Delete";
            this.DelMenuItem.Text = "削除";
            // 
            // UnDelMenuItem
            // 
            this.UnDelMenuItem.Name = "UnDelMenuItem";
            this.UnDelMenuItem.Size = new System.Drawing.Size(124, 22);
            this.UnDelMenuItem.Tag = "UnDelete";
            this.UnDelMenuItem.Text = "回復";
            // 
            // tabRData
            // 
            this.tabRData.Controls.Add(this.tpInsert);
            this.tabRData.Controls.Add(this.tpEdit);
            this.tabRData.Controls.Add(this.tpOutput);
            this.tabRData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabRData.Location = new System.Drawing.Point(0, 0);
            this.tabRData.Name = "tabRData";
            this.tabRData.SelectedIndex = 0;
            this.tabRData.Size = new System.Drawing.Size(1098, 660);
            this.tabRData.TabIndex = 9;
            this.tabRData.SelectedIndexChanged += new System.EventHandler(this.TabRData_SelectedIndexChanged);
            // 
            // tpInsert
            // 
            this.tpInsert.BackColor = System.Drawing.SystemColors.Control;
            this.tpInsert.Controls.Add(this.tabInsert);
            this.tpInsert.Location = new System.Drawing.Point(4, 22);
            this.tpInsert.Name = "tpInsert";
            this.tpInsert.Padding = new System.Windows.Forms.Padding(3);
            this.tpInsert.Size = new System.Drawing.Size(1090, 634);
            this.tpInsert.TabIndex = 0;
            this.tpInsert.Text = "登録";
            // 
            // tabInsert
            // 
            this.tabInsert.Controls.Add(this.tpFileInsert);
            this.tabInsert.Controls.Add(this.tpNewInsert);
            this.tabInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabInsert.Location = new System.Drawing.Point(3, 3);
            this.tabInsert.Name = "tabInsert";
            this.tabInsert.SelectedIndex = 0;
            this.tabInsert.Size = new System.Drawing.Size(1084, 628);
            this.tabInsert.TabIndex = 13;
            this.tabInsert.SelectedIndexChanged += new System.EventHandler(this.TabInsert_SelectedIndexChanged);
            // 
            // tpFileInsert
            // 
            this.tpFileInsert.BackColor = System.Drawing.SystemColors.Control;
            this.tpFileInsert.Controls.Add(this.groupBox4);
            this.tpFileInsert.Controls.Add(this.chkAllInsert);
            this.tpFileInsert.Controls.Add(this.dgvRDataFile);
            this.tpFileInsert.Location = new System.Drawing.Point(4, 22);
            this.tpFileInsert.Name = "tpFileInsert";
            this.tpFileInsert.Padding = new System.Windows.Forms.Padding(3);
            this.tpFileInsert.Size = new System.Drawing.Size(1076, 602);
            this.tpFileInsert.TabIndex = 1;
            this.tpFileInsert.Text = "ファイルから登録";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox4.Controls.Add(this.btnLoadRData);
            this.groupBox4.Controls.Add(this.btnFileInsert);
            this.groupBox4.Controls.Add(this.btnSelectFolder);
            this.groupBox4.Controls.Add(this.txtRDataFolder);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Location = new System.Drawing.Point(5, 1);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1067, 39);
            this.groupBox4.TabIndex = 9;
            this.groupBox4.TabStop = false;
            // 
            // btnLoadRData
            // 
            this.btnLoadRData.Location = new System.Drawing.Point(874, 11);
            this.btnLoadRData.Name = "btnLoadRData";
            this.btnLoadRData.Size = new System.Drawing.Size(54, 23);
            this.btnLoadRData.TabIndex = 3;
            this.btnLoadRData.Text = "ロード";
            this.btnLoadRData.UseVisualStyleBackColor = true;
            this.btnLoadRData.Click += new System.EventHandler(this.BtnLoadRData_Click);
            // 
            // btnFileInsert
            // 
            this.btnFileInsert.Enabled = false;
            this.btnFileInsert.Location = new System.Drawing.Point(1006, 11);
            this.btnFileInsert.Name = "btnFileInsert";
            this.btnFileInsert.Size = new System.Drawing.Size(54, 23);
            this.btnFileInsert.TabIndex = 4;
            this.btnFileInsert.Text = "登録";
            this.btnFileInsert.UseVisualStyleBackColor = true;
            this.btnFileInsert.Click += new System.EventHandler(this.BtnFileInsert_Click);
            // 
            // btnSelectFolder
            // 
            this.btnSelectFolder.Location = new System.Drawing.Point(842, 11);
            this.btnSelectFolder.Name = "btnSelectFolder";
            this.btnSelectFolder.Size = new System.Drawing.Size(26, 23);
            this.btnSelectFolder.TabIndex = 2;
            this.btnSelectFolder.Text = "…";
            this.btnSelectFolder.UseVisualStyleBackColor = true;
            this.btnSelectFolder.Click += new System.EventHandler(this.BtnSelectFolder_Click);
            // 
            // txtRDataFolder
            // 
            this.txtRDataFolder.Location = new System.Drawing.Point(92, 13);
            this.txtRDataFolder.Name = "txtRDataFolder";
            this.txtRDataFolder.Size = new System.Drawing.Size(744, 19);
            this.txtRDataFolder.TabIndex = 1;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(6, 16);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(89, 12);
            this.label17.TabIndex = 8;
            this.label17.Text = "ＲＤＡＴＡフォルダ：";
            // 
            // chkAllInsert
            // 
            this.chkAllInsert.AutoSize = true;
            this.chkAllInsert.Enabled = false;
            this.chkAllInsert.Location = new System.Drawing.Point(11, 51);
            this.chkAllInsert.Name = "chkAllInsert";
            this.chkAllInsert.Size = new System.Drawing.Size(15, 14);
            this.chkAllInsert.TabIndex = 11;
            this.chkAllInsert.UseVisualStyleBackColor = true;
            // 
            // dgvRDataFile
            // 
            this.dgvRDataFile.AllowUserToAddRows = false;
            this.dgvRDataFile.AllowUserToDeleteRows = false;
            this.dgvRDataFile.AllowUserToResizeRows = false;
            this.dgvRDataFile.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRDataFile.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Selected,
            this.Filename,
            this.Extension,
            this.InsertStatus});
            this.dgvRDataFile.Location = new System.Drawing.Point(5, 47);
            this.dgvRDataFile.Name = "dgvRDataFile";
            this.dgvRDataFile.ReadOnly = true;
            this.dgvRDataFile.RowHeadersVisible = false;
            this.dgvRDataFile.RowTemplate.Height = 21;
            this.dgvRDataFile.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvRDataFile.Size = new System.Drawing.Size(1067, 549);
            this.dgvRDataFile.TabIndex = 5;
            // 
            // Selected
            // 
            this.Selected.DataPropertyName = "Selected";
            this.Selected.FalseValue = "0";
            this.Selected.Frozen = true;
            this.Selected.HeaderText = "";
            this.Selected.Name = "Selected";
            this.Selected.ReadOnly = true;
            this.Selected.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Selected.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Selected.TrueValue = "1";
            this.Selected.Width = 20;
            // 
            // Filename
            // 
            this.Filename.HeaderText = "RDATAファイル名";
            this.Filename.Name = "Filename";
            this.Filename.ReadOnly = true;
            this.Filename.Width = 160;
            // 
            // Extension
            // 
            this.Extension.HeaderText = "拡張子";
            this.Extension.Name = "Extension";
            this.Extension.ReadOnly = true;
            // 
            // InsertStatus
            // 
            this.InsertStatus.HeaderText = "登録ステータス";
            this.InsertStatus.Name = "InsertStatus";
            this.InsertStatus.ReadOnly = true;
            this.InsertStatus.Width = 800;
            // 
            // tpNewInsert
            // 
            this.tpNewInsert.BackColor = System.Drawing.SystemColors.Control;
            this.tpNewInsert.Controls.Add(this.btnNewInsert);
            this.tpNewInsert.Controls.Add(this.rdtNewInsert);
            this.tpNewInsert.Location = new System.Drawing.Point(4, 22);
            this.tpNewInsert.Name = "tpNewInsert";
            this.tpNewInsert.Padding = new System.Windows.Forms.Padding(3);
            this.tpNewInsert.Size = new System.Drawing.Size(1076, 602);
            this.tpNewInsert.TabIndex = 0;
            this.tpNewInsert.Text = "新規作成";
            // 
            // btnNewInsert
            // 
            this.btnNewInsert.Location = new System.Drawing.Point(1014, 123);
            this.btnNewInsert.Name = "btnNewInsert";
            this.btnNewInsert.Size = new System.Drawing.Size(54, 23);
            this.btnNewInsert.TabIndex = 11;
            this.btnNewInsert.Text = "登録";
            this.btnNewInsert.UseVisualStyleBackColor = true;
            this.btnNewInsert.Click += new System.EventHandler(this.BtnNewInsert_Click);
            // 
            // rdtNewInsert
            // 
            this.rdtNewInsert.DgvAddDelMenu = null;
            this.rdtNewInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rdtNewInsert.EditMode = false;
            this.rdtNewInsert.IsMBTable = false;
            this.rdtNewInsert.Location = new System.Drawing.Point(3, 3);
            this.rdtNewInsert.Name = "rdtNewInsert";
            this.rdtNewInsert.Size = new System.Drawing.Size(1070, 596);
            this.rdtNewInsert.TabIndex = 35;
            // 
            // tpEdit
            // 
            this.tpEdit.BackColor = System.Drawing.SystemColors.Control;
            this.tpEdit.Controls.Add(this.grpComp);
            this.tpEdit.Controls.Add(this.btnUpdate);
            this.tpEdit.Controls.Add(this.rdtUpdate);
            this.tpEdit.Controls.Add(this.ucEditOutput);
            this.tpEdit.Location = new System.Drawing.Point(4, 22);
            this.tpEdit.Name = "tpEdit";
            this.tpEdit.Padding = new System.Windows.Forms.Padding(3);
            this.tpEdit.Size = new System.Drawing.Size(1090, 634);
            this.tpEdit.TabIndex = 1;
            this.tpEdit.Text = "編集";
            // 
            // grpComp
            // 
            this.grpComp.Controls.Add(this.btnDbFileComp);
            this.grpComp.Controls.Add(this.btnSelectRData);
            this.grpComp.Controls.Add(this.label1);
            this.grpComp.Controls.Add(this.txtRDataFile);
            this.grpComp.Location = new System.Drawing.Point(6, 1);
            this.grpComp.Name = "grpComp";
            this.grpComp.Size = new System.Drawing.Size(1078, 39);
            this.grpComp.TabIndex = 31;
            this.grpComp.TabStop = false;
            // 
            // btnDbFileComp
            // 
            this.btnDbFileComp.Location = new System.Drawing.Point(1018, 11);
            this.btnDbFileComp.Name = "btnDbFileComp";
            this.btnDbFileComp.Size = new System.Drawing.Size(54, 23);
            this.btnDbFileComp.TabIndex = 3;
            this.btnDbFileComp.Text = "読込";
            this.btnDbFileComp.UseVisualStyleBackColor = true;
            this.btnDbFileComp.Click += new System.EventHandler(this.BtnDbFileComp_Click);
            // 
            // btnSelectRData
            // 
            this.btnSelectRData.Location = new System.Drawing.Point(910, 11);
            this.btnSelectRData.Name = "btnSelectRData";
            this.btnSelectRData.Size = new System.Drawing.Size(26, 23);
            this.btnSelectRData.TabIndex = 2;
            this.btnSelectRData.Text = "…";
            this.btnSelectRData.UseVisualStyleBackColor = true;
            this.btnSelectRData.Click += new System.EventHandler(this.BtnSelectRData_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 12);
            this.label1.TabIndex = 8;
            this.label1.Text = "RDATAファイル：";
            // 
            // txtRDataFile
            // 
            this.txtRDataFile.Location = new System.Drawing.Point(92, 13);
            this.txtRDataFile.Name = "txtRDataFile";
            this.txtRDataFile.Size = new System.Drawing.Size(812, 19);
            this.txtRDataFile.TabIndex = 1;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Enabled = false;
            this.btnUpdate.Location = new System.Drawing.Point(1024, 166);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(54, 23);
            this.btnUpdate.TabIndex = 5;
            this.btnUpdate.Text = "更新";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.BtnUpdate_Click);
            // 
            // rdtUpdate
            // 
            this.rdtUpdate.DgvAddDelMenu = null;
            this.rdtUpdate.EditMode = false;
            this.rdtUpdate.Enabled = false;
            this.rdtUpdate.IsMBTable = false;
            this.rdtUpdate.Location = new System.Drawing.Point(6, 46);
            this.rdtUpdate.Name = "rdtUpdate";
            this.rdtUpdate.Size = new System.Drawing.Size(1078, 548);
            this.rdtUpdate.TabIndex = 4;
            // 
            // ucEditOutput
            // 
            this.ucEditOutput.Enabled = false;
            this.ucEditOutput.FolderDialog = this.folderBrowserDlg;
            this.ucEditOutput.Location = new System.Drawing.Point(6, 591);
            this.ucEditOutput.Name = "ucEditOutput";
            this.ucEditOutput.Size = new System.Drawing.Size(1078, 38);
            this.ucEditOutput.TabIndex = 6;
            // 
            // tpOutput
            // 
            this.tpOutput.BackColor = System.Drawing.SystemColors.Control;
            this.tpOutput.Controls.Add(this.ucOutput);
            this.tpOutput.Controls.Add(this.chkRDataAll);
            this.tpOutput.Controls.Add(this.groupBox2);
            this.tpOutput.Controls.Add(this.dgvRDataOutput);
            this.tpOutput.Location = new System.Drawing.Point(4, 22);
            this.tpOutput.Name = "tpOutput";
            this.tpOutput.Padding = new System.Windows.Forms.Padding(3);
            this.tpOutput.Size = new System.Drawing.Size(1090, 634);
            this.tpOutput.TabIndex = 2;
            this.tpOutput.Text = "出力";
            // 
            // ucOutput
            // 
            this.ucOutput.Enabled = false;
            this.ucOutput.FolderDialog = this.folderBrowserDlg;
            this.ucOutput.Location = new System.Drawing.Point(6, 591);
            this.ucOutput.Name = "ucOutput";
            this.ucOutput.Size = new System.Drawing.Size(1078, 38);
            this.ucOutput.TabIndex = 11;
            // 
            // chkRDataAll
            // 
            this.chkRDataAll.AutoSize = true;
            this.chkRDataAll.Enabled = false;
            this.chkRDataAll.Location = new System.Drawing.Point(11, 52);
            this.chkRDataAll.Name = "chkRDataAll";
            this.chkRDataAll.Size = new System.Drawing.Size(15, 14);
            this.chkRDataAll.TabIndex = 6;
            this.chkRDataAll.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rdoRDataTbNm);
            this.groupBox2.Controls.Add(this.rdoRDataTbId);
            this.groupBox2.Controls.Add(this.txtRDataTbNm);
            this.groupBox2.Controls.Add(this.combSubSysID);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.btnSelecct);
            this.groupBox2.Controls.Add(this.txtRDataTbId);
            this.groupBox2.Location = new System.Drawing.Point(6, 1);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1078, 39);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            // 
            // rdoRDataTbNm
            // 
            this.rdoRDataTbNm.AutoSize = true;
            this.rdoRDataTbNm.Location = new System.Drawing.Point(357, 15);
            this.rdoRDataTbNm.Margin = new System.Windows.Forms.Padding(0);
            this.rdoRDataTbNm.Name = "rdoRDataTbNm";
            this.rdoRDataTbNm.Size = new System.Drawing.Size(79, 16);
            this.rdoRDataTbNm.TabIndex = 3;
            this.rdoRDataTbNm.Text = "テーブル名：";
            this.rdoRDataTbNm.UseVisualStyleBackColor = true;
            // 
            // rdoRDataTbId
            // 
            this.rdoRDataTbId.AutoSize = true;
            this.rdoRDataTbId.Checked = true;
            this.rdoRDataTbId.Location = new System.Drawing.Point(174, 15);
            this.rdoRDataTbId.Margin = new System.Windows.Forms.Padding(0);
            this.rdoRDataTbId.Name = "rdoRDataTbId";
            this.rdoRDataTbId.Size = new System.Drawing.Size(79, 16);
            this.rdoRDataTbId.TabIndex = 2;
            this.rdoRDataTbId.TabStop = true;
            this.rdoRDataTbId.Text = "テーブルＩＤ：";
            this.rdoRDataTbId.UseVisualStyleBackColor = true;
            this.rdoRDataTbId.CheckedChanged += new System.EventHandler(this.RdoRData_CheckedChanged);
            // 
            // txtRDataTbNm
            // 
            this.txtRDataTbNm.Enabled = false;
            this.txtRDataTbNm.Location = new System.Drawing.Point(439, 14);
            this.txtRDataTbNm.Name = "txtRDataTbNm";
            this.txtRDataTbNm.Size = new System.Drawing.Size(120, 19);
            this.txtRDataTbNm.TabIndex = 4;
            // 
            // combSubSysID
            // 
            this.combSubSysID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combSubSysID.FormattingEnabled = true;
            this.combSubSysID.Location = new System.Drawing.Point(87, 13);
            this.combSubSysID.Name = "combSubSysID";
            this.combSubSysID.Size = new System.Drawing.Size(65, 20);
            this.combSubSysID.TabIndex = 1;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(6, 17);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(79, 12);
            this.label19.TabIndex = 17;
            this.label19.Text = "サブシステムID：";
            // 
            // btnSelecct
            // 
            this.btnSelecct.Location = new System.Drawing.Point(1017, 11);
            this.btnSelecct.Name = "btnSelecct";
            this.btnSelecct.Size = new System.Drawing.Size(54, 23);
            this.btnSelecct.TabIndex = 5;
            this.btnSelecct.Text = "検索";
            this.btnSelecct.UseVisualStyleBackColor = true;
            this.btnSelecct.Click += new System.EventHandler(this.BtnSelecct_Click);
            // 
            // txtRDataTbId
            // 
            this.txtRDataTbId.Location = new System.Drawing.Point(254, 14);
            this.txtRDataTbId.Name = "txtRDataTbId";
            this.txtRDataTbId.Size = new System.Drawing.Size(85, 19);
            this.txtRDataTbId.TabIndex = 0;
            // 
            // dgvRDataOutput
            // 
            this.dgvRDataOutput.AllowUserToAddRows = false;
            this.dgvRDataOutput.AllowUserToDeleteRows = false;
            this.dgvRDataOutput.AllowUserToResizeRows = false;
            this.dgvRDataOutput.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRDataOutput.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column3,
            this.Column10,
            this.dataGridViewTextBoxColumn27,
            this.dataGridViewTextBoxColumn26,
            this.dataGridViewTextBoxColumn28,
            this.dataGridViewTextBoxColumn25,
            this.Column5,
            this.Status});
            this.dgvRDataOutput.Location = new System.Drawing.Point(6, 48);
            this.dgvRDataOutput.Name = "dgvRDataOutput";
            this.dgvRDataOutput.ReadOnly = true;
            this.dgvRDataOutput.RowHeadersVisible = false;
            this.dgvRDataOutput.RowTemplate.Height = 21;
            this.dgvRDataOutput.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvRDataOutput.Size = new System.Drawing.Size(1078, 542);
            this.dgvRDataOutput.TabIndex = 7;
            // 
            // Column3
            // 
            this.Column3.FalseValue = "0";
            this.Column3.HeaderText = "";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.TrueValue = "1";
            this.Column3.Width = 20;
            // 
            // Column10
            // 
            this.Column10.HeaderText = "サブシステムID";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.HeaderText = "テーブルＩＤ";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            this.dataGridViewTextBoxColumn27.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.HeaderText = "テーブル名";
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            this.dataGridViewTextBoxColumn26.ReadOnly = true;
            this.dataGridViewTextBoxColumn26.Width = 200;
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.HeaderText = "コピー句ＩＤ";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            this.dataGridViewTextBoxColumn28.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.HeaderText = "RDATAファイル名";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            this.dataGridViewTextBoxColumn25.ReadOnly = true;
            this.dataGridViewTextBoxColumn25.Width = 150;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "拡張子";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 70;
            // 
            // Status
            // 
            this.Status.HeaderText = "出力ステータス";
            this.Status.Name = "Status";
            this.Status.ReadOnly = true;
            this.Status.Width = 400;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.progressBarNewInsert,
            this.progressBarFileInsert,
            this.progressBarEdit,
            this.progressBarOutput});
            this.statusStrip1.Location = new System.Drawing.Point(0, 660);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1098, 22);
            this.statusStrip1.TabIndex = 6;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // progressBarNewInsert
            // 
            this.progressBarNewInsert.Name = "progressBarNewInsert";
            this.progressBarNewInsert.Size = new System.Drawing.Size(200, 16);
            this.progressBarNewInsert.Visible = false;
            // 
            // progressBarFileInsert
            // 
            this.progressBarFileInsert.Name = "progressBarFileInsert";
            this.progressBarFileInsert.Size = new System.Drawing.Size(200, 16);
            this.progressBarFileInsert.Visible = false;
            // 
            // progressBarEdit
            // 
            this.progressBarEdit.Name = "progressBarEdit";
            this.progressBarEdit.Size = new System.Drawing.Size(200, 16);
            this.progressBarEdit.Visible = false;
            // 
            // progressBarOutput
            // 
            this.progressBarOutput.Name = "progressBarOutput";
            this.progressBarOutput.Size = new System.Drawing.Size(200, 16);
            this.progressBarOutput.Visible = false;
            // 
            // RDataForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1098, 682);
            this.Controls.Add(this.tabRData);
            this.Controls.Add(this.statusStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "RDataForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ＲＤＡＴＡ管理機能";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.RDataForm_FormClosing);
            this.addDelMenu.ResumeLayout(false);
            this.tabRData.ResumeLayout(false);
            this.tpInsert.ResumeLayout(false);
            this.tabInsert.ResumeLayout(false);
            this.tpFileInsert.ResumeLayout(false);
            this.tpFileInsert.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRDataFile)).EndInit();
            this.tpNewInsert.ResumeLayout(false);
            this.tpEdit.ResumeLayout(false);
            this.grpComp.ResumeLayout(false);
            this.grpComp.PerformLayout();
            this.tpOutput.ResumeLayout(false);
            this.tpOutput.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRDataOutput)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.TabControl tabRData;
        private System.Windows.Forms.TabPage tpInsert;
        private System.Windows.Forms.TabPage tpEdit;
        private System.Windows.Forms.TabPage tpOutput;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnFileInsert;
        private System.Windows.Forms.Button btnSelectFolder;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtRDataFolder;
        private System.Windows.Forms.DataGridView dgvRDataFile;
        private System.Windows.Forms.CheckBox chkAllInsert;
        private System.Windows.Forms.CheckBox chkRDataAll;
        private System.Windows.Forms.Button btnLoadRData;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtRDataTbNm;
        private System.Windows.Forms.ComboBox combSubSysID;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btnSelecct;
        private System.Windows.Forms.TextBox txtRDataTbId;
        private System.Windows.Forms.DataGridView dgvRDataOutput;
        private System.Windows.Forms.GroupBox grpComp;
        private System.Windows.Forms.Button btnDbFileComp;
        private System.Windows.Forms.Button btnSelectRData;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtRDataFile;
        private System.Windows.Forms.OpenFileDialog openFileDlg;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDlg;
        private System.Windows.Forms.TabControl tabInsert;
        private System.Windows.Forms.TabPage tpNewInsert;
        private System.Windows.Forms.TabPage tpFileInsert;
        private System.Windows.Forms.Button btnNewInsert;
        private System.ComponentModel.BackgroundWorker backgroundWorker;
        private System.Windows.Forms.RadioButton rdoRDataTbId;
        private System.Windows.Forms.RadioButton rdoRDataTbNm;
        private System.Windows.Forms.ContextMenuStrip addDelMenu;
        private System.Windows.Forms.ToolStripMenuItem AddBeforeMenuItem;
        private System.Windows.Forms.ToolStripMenuItem DelMenuItem;
        private System.Windows.Forms.ToolStripMenuItem AddAfterMenuItem;
        private RData.RDataEditor rdtNewInsert;
        private RData.RDataEditor rdtUpdate;
        private RData.RDataOutput ucOutput;
        private RData.RDataOutput ucEditOutput;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Selected;
        private System.Windows.Forms.DataGridViewTextBoxColumn Filename;
        private System.Windows.Forms.DataGridViewTextBoxColumn Extension;
        private System.Windows.Forms.DataGridViewTextBoxColumn InsertStatus;
        private System.Windows.Forms.ToolStripMenuItem UnDelMenuItem;
        private System.Windows.Forms.ToolStripMenuItem AddMenuItem;
        private System.Windows.Forms.ToolStripProgressBar progressBarNewInsert;
        private System.Windows.Forms.ToolStripProgressBar progressBarFileInsert;
        private System.Windows.Forms.ToolStripProgressBar progressBarEdit;
        private System.Windows.Forms.ToolStripProgressBar progressBarOutput;
    }
}

