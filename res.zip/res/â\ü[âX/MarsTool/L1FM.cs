﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarsTool
{
    public partial class L1FM : Form
    {
        public string ResultString { get; set; }

        public L1FM()
        {
            InitializeComponent();
        }

        private void OtherFM_Load(object sender, EventArgs e)
        {
        }

        private void request_CheckedChanged(object sender, EventArgs e)
        {
            ResultString = "要求";
        }

        private void response_CheckedChanged(object sender, EventArgs e)
        {
            ResultString = "回答";
        }

        private void cancel_CheckedChanged(object sender, EventArgs e)
        {
            ResultString = "";
        }
    }
}
