﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarsTool.Common.Forms
{
    /// <summary>
    /// 入力ダイアログ
    /// </summary>
    public partial class InputDialog : Form
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public InputDialog()
        {
            InitializeComponent();
            this.Multiline = false;
        }

        /// <summary>
        /// チェック関数
        /// </summary>
        /// <param name="text">チェックする文字列</param>
        /// <returns></returns>
        public delegate bool check(string text);

        /// <summary>
        /// 検定関数
        /// </summary>
        public check Check { get; set; }

        /// <summary>
        /// エラーメッセージ
        /// </summary>
        public string ErrorMessage { get; set; }

        /// <summary>
        /// 入力テキストボックスを複数行入力可能とするか
        /// </summary>
        public bool Multiline
        {
            get
            {
                return txtInbox.Multiline;
            }
            set
            {
                txtInbox.Multiline = value;
                if (value)
                {
                    this.AcceptButton = null;
                }
                else
                {
                    this.AcceptButton = btnOK;
                }
            }
        }

        public string Value
        {
            get
            {
                return txtInbox.Text;
            }
        }

        /// <summary>
        /// 入力ダイアログを表示する
        /// </summary>
        /// <param name="win">呼出元ウィンドウ</param>
        /// <param name="title">ダイアログのタイトル</param>
        /// <param name="message">ダイアログに表示する説明</param>
        /// <param name="defaultString">初期値</param>
        /// <returns></returns>
        public DialogResult ShowDialog(IWin32Window win, string title, string message, string defaultString)
        {
            this.Text = title;
            lblMessage.Text = message;
            if (this.Check != null) this.btnOK.Enabled = false;

            if (defaultString == null)
            {
                txtInbox.Text = string.Empty;
            }
            else
            {
                if(this.Multiline)
                {
                    StringBuilder sb = new StringBuilder();
                    string[] buf = defaultString.Split('\n');
                    for(int i = 0; i < buf.Length; i++)
                    {
                        if(i != buf.Length - 1)
                        {
                            if (buf[i].Length > 0 && buf[i].Last() == '\r')
                            {
                                sb.Append(string.Format("{0}\n", buf[i]));
                            }
                            else
                            {
                                sb.Append(string.Format("{0}\r\n", buf[i]));
                            }
                        }
                        else
                        {
                            sb.Append(string.Format("{0}", buf[i]));
                        }
                    }
                    txtInbox.Text = sb.ToString();
                }
                else
                {
                    txtInbox.Text = defaultString;
                }
            }
            return base.ShowDialog(win);
        }

        private bool ErrorCheck()
        {
            if (this.Check == null) return true;
            return this.Check(txtInbox.Text);
        }

        private void txtInbox_TextChanged(object sender, EventArgs e)
        {
            this.errorProvider.SetError(this.txtInbox, string.Empty);
            if (this.ErrorCheck() == false)
            {
                this.btnOK.Enabled = false;
                this.errorProvider.SetIconAlignment(this.txtInbox, ErrorIconAlignment.MiddleLeft);
                this.errorProvider.SetError(this.txtInbox, this.ErrorMessage);
            }
            else
            {
                this.btnOK.Enabled = true;
            }
        }
    }
}
