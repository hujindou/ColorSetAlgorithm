﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Drawing.Drawing2D;

namespace MarsTool.Common.Forms
{
    public partial class Canvas : UserControl
    {
        private int X { get; set; }
        private int Y { get; set; }
        /// <summary>
        /// 排他制御用
        /// </summary>
        public object Lock { get; }

        /// <summary>
        /// 描画スタイル
        /// </summary>
        public enum Style
        {
            /// <summary>
            /// 文字列
            /// </summary>
            Text = 0,
            /// <summary>
            /// 直線
            /// </summary>
            Line,
            /// <summary>
            /// 四角形
            /// </summary>
            Box,
            /// <summary>
            /// 矢印
            /// </summary>
            Arrow,
            /// <summary>
            /// イメージ画像
            /// </summary>
            Image,
            /// <summary>
            /// グループ
            /// </summary>
            Group
        };

        /// <summary>
        /// 描画アイテムクリックイベントの引数
        /// </summary>
        /// <remaks>
        /// 描画アイテムをクリックしたときに発生するItemClickイベントの引数
        /// </remaks>
        public class ItemClickEventArgs : EventArgs
        {
            /// <summary>
            /// コンストラクタ
            /// </summary>
            /// <param name="Item">クリックされた描画アイテム</param>
            public ItemClickEventArgs(CanvasItem Item)
            {
                this.Item = Item;
            }
            /// <summary>
            /// クリックされた描画アイテム
            /// </summary>
            public CanvasItem Item { get; set; }
        }

        /// <summary>
        /// マウスイベントの引数
        /// </summary>
        /// <remaks>
        /// </remaks>
        public class ItemMouseEventArgs : EventArgs
        {
            /// <summary>
            /// コンストラクタ
            /// </summary>
            /// <param name="Button"></param>
            /// <param name="Clicks"></param>
            /// <param name="X"></param>
            /// <param name="Y"></param>
            /// <param name="Delta"></param>
            /// <param name="Item"></param>
            public ItemMouseEventArgs(MouseButtons Button, int Clicks, int X, int Y, int Delta, CanvasItem Item)
            {
                this.Button = Button;
                this.Clicks = Clicks;
                this.X = X;
                this.Y = Y;
                this.Delta = Delta;
                this.Item = Item;
            }

            /// <summary>
            /// 描画アイテム
            /// </summary>
            public CanvasItem Item { get; set; }

            /// <summary>
            /// マウスのＸ座標
            /// </summary>
            public int X { get; }
            /// <summary>
            /// マウスのＹ座標
            /// </summary>
            public int Y { get; }

            /// <summary>
            /// マウスのボタン
            /// </summary>
            public MouseButtons Button { get; }

            /// <summary>
            /// クリック回数
            /// </summary>
            public int Clicks { get; }

            /// <summary>
            /// スクロール量
            /// </summary>
            public int Delta { get; }

        }

        /// <summary>
        /// マウスイベントの引数
        /// </summary>
        /// <remaks>
        /// </remaks>
        public class ItemsMouseEventArgs : EventArgs
        {
            /// <summary>
            /// コンストラクタ
            /// </summary>
            /// <param name="Button"></param>
            /// <param name="Clicks"></param>
            /// <param name="X"></param>
            /// <param name="Y"></param>
            /// <param name="Delta"></param>
            /// <param name="Items"></param>
            public ItemsMouseEventArgs(MouseButtons Button, int Clicks, int X, int Y, int Delta, List<CanvasItem> Items)
            {
                this.Button = Button;
                this.Clicks = Clicks;
                this.X = X;
                this.Y = Y;
                this.Delta = Delta;
                this.Items = Items;
            }

            /// <summary>
            /// 描画アイテム
            /// </summary>
            public List<CanvasItem> Items { get; set; }

            /// <summary>
            /// マウスのＸ座標
            /// </summary>
            public int X { get; }
            /// <summary>
            /// マウスのＹ座標
            /// </summary>
            public int Y { get; }

            /// <summary>
            /// マウスのボタン
            /// </summary>
            public MouseButtons Button { get; }

            /// <summary>
            /// クリック回数
            /// </summary>
            public int Clicks { get; }
            /// <summary>
            /// スクロール量
            /// </summary>
            public int Delta { get; }

        }

        /// <summary>
        /// ItemClickイベントのイベントハンドラ
        /// </summary>
        /// <param name="sender">イベントを発生させたオブジェクト</param>
        /// <param name="e">引数</param>
        public delegate void ClickItemEventHandler(object sender, ItemClickEventArgs e);

        /// <summary>
        /// ItemMouseDownイベントのイベントハンドラ
        /// </summary>
        /// <param name="sender">イベントを発生させたオブジェクト</param>
        /// <param name="e">引数</param>
        public delegate void MouseDownItemEventHandler(object sender, ItemMouseEventArgs e);

        /// <summary>
        /// ItemMouseMoveイベントのイベントハンドラ
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public delegate void MouseMoveItemEventHandler(object sender, ItemMouseEventArgs e);

        /// <summary>
        /// ItemMouseUpイベントのイベントハンドラ
        /// </summary>
        /// <param name="sender">イベントを発生させたオブジェクト</param>
        /// <param name="e">引数</param>
        public delegate void MouseUpItemEventHandler(object sender, ItemMouseEventArgs e);

        /// <summary>
        /// ItemsMouseDownイベントのイベントハンドラ
        /// </summary>
        /// <param name="sender">イベントを発生させたオブジェクト</param>
        /// <param name="e">引数</param>
        public delegate void MouseDownItemsEventHandler(object sender, ItemsMouseEventArgs e);

        /// <summary>
        /// ItemsMouseMoveイベントのイベントハンドラ
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public delegate void MouseMoveItemsEventHandler(object sender, ItemsMouseEventArgs e);

        /// <summary>
        /// ItemsMouseUpイベントのイベントハンドラ
        /// </summary>
        /// <param name="sender">イベントを発生させたオブジェクト</param>
        /// <param name="e">引数</param>
        public delegate void MouseUpItemsEventHandler(object sender, ItemsMouseEventArgs e);

        /// <summary>
        /// 描画アイテム
        /// </summary>
        /// <remarks>
        /// 描画内容を決定する描画アイテム
        /// </remarks>
        [Serializable()]
        public class CanvasItem : ICloneable
        {
            /// <summary>
            /// コンストラクタ
            /// </summary>
            public CanvasItem()
            {
                this.Font = Canvas.DefaultFont;
                this.Color = SystemColors.Control;
                this.FontColor = SystemColors.WindowText;
                this.AlphaBlend = 255;
                this.Event = false;
                this.Margin = new Padding(4);
                this.StartCap = LineCap.Flat;
                this.EndCap = LineCap.Flat;
                this.ArrowCapSize = 8;
                this.LineWeight = 1;
                this.LineAlignment = StringAlignment.Center;
                this.Alignment = StringAlignment.Center;
                this.Vertical = false;
                this.Multiline = false;
                this.Fill = true;
                this.dashStyle = DashStyle.Solid;
                this.image = null;
                this.Tag = null;
                this.GroupItems = new ObservableCollection<CanvasItem>();
                this.Selected = false;
                this.SelectedColor = SystemColors.Highlight;
                this.Trimming = StringTrimming.Character;
                this.DoubleLine = false;
            }

            /// <summary>
            /// コンストラクタ
            /// </summary>
            /// <remarks>
            /// 引数に指定した描画アイテムのクローンを作成する
            /// </remarks>
            /// <param name="Item">コピー元の描画アイテム</param>
            public CanvasItem(CanvasItem Item)
            {
                this.id = Item.id;
                this.style = Item.style;
                this.Text = Item.Text;
                this.Recangle = Item.Recangle;
                this.Color = Item.Color;
                this.FontColor = Item.FontColor;
                this.Font = Item.Font;
                this.AlphaBlend = Item.AlphaBlend;
                this.Event = Item.Event;
                this.Margin = Item.Margin;
                this.StartCap = Item.StartCap;
                this.EndCap = Item.EndCap;
                this.StartArrowCap = Item.StartArrowCap;
                this.EndArrowCap = Item.EndArrowCap;
                this.ArrowCapSize = Item.ArrowCapSize;
                this.LineWeight = Item.LineWeight;
                this.LineAlignment = Item.LineAlignment;
                this.Alignment = Item.Alignment;
                this.Vertical = Item.Vertical;
                this.Multiline = Item.Multiline;
                this.Fill = Item.Fill;
                this.dashStyle = Item.dashStyle;
                if (Item.image != null)
                {
                    this.image = (Image)Item.image.Clone();
                }
                this.Tag = null;
                this.GroupItems = new ObservableCollection<CanvasItem>();
                foreach (CanvasItem item in Item.GroupItems)
                {
                    this.GroupItems.Add((CanvasItem)item.Clone());
                }
                this.Selected = Item.Selected;
                this.SelectedColor = Item.SelectedColor;
                this.Trimming = Item.Trimming;
                this.DoubleLine = Item.DoubleLine;
            }

            /// <summary>
            /// コピーの作成
            /// </summary>
            /// <remarks>
            /// 自身のコピーを作成する
            /// </remarks>
            /// <returns>作成したコピー</returns>
            public object Clone()
            {
                return new CanvasItem(this);
            }

            /// <summary>識別ＩＤ</summary>
            /// <remarks>
            /// 描画アイテムを一意に示す任意の文字列を取得／設定する
            /// </remarks>
            public string id { get; set; }
            /// <summary>描画スタイル</summary>
            /// <remarks>
            /// 描画スタイルは以下の通り
            /// ・Text  （文字列）
            /// ・Line  （直線）
            /// ・Box   （四角形）
            /// ・Arrow （矢印）
            /// ・Image （イメージ画像）
            /// </remarks>
            public Canvas.Style style { get; set; }
            /// <summary>文字列</summary>
            /// <remarks>
            /// styleプロパティがStyle.Textの場合のみ文字列の背景を塗りつぶします
            /// </remarks>
            public string Text { get; set; }
            /// <summary>描画範囲</summary>
            public Rectangle Recangle { get; set; }
            /// <summary>描画色</summary>
            /// <remarks>styleプロパティがStyle.Textの場合は背景色となります。文字色はFontColorプロパティを使用します</remarks>
            public Color Color { get; set; }
            /// <summary>文字色</summary>
            public Color FontColor { get; set; }
            /// <summary>フォント</summary>
            public Font Font { get; set; }
            /// <summary>透明度</summary>
            /// <remarks>
            /// 0～255の範囲で設定し、数値が大きいほど不透明度が高まります。
            /// 文字列の描画には適用されません。
            /// </remarks>
            public int AlphaBlend { get; set; }
            /// <summary>イベント発行フラグ</summary>
            /// <remarks>該当アイテムでイベントを発生させる場合はtrueを指定します</remarks>
            public bool Event { get; set; }
            /// <summary>余白</summary>
            public Padding Margin { get; set; }
            /// <summary>直線の開始キャップ</summary>
            /// <remarks>
            /// StyleプロパティがStyle.Lineの時の開始キャップを取得／設定します
            /// </remarks>
            public LineCap StartCap { get; set; }
            /// <summary>直線の終端キャップ</summary>
            /// <remarks>
            /// StyleプロパティがStyle.Lineの時の終端キャップを取得／設定します
            /// </remarks>
            public LineCap EndCap { get; set; }
            /// <summary>矢印の開始キャップ有無</summary>
            /// <remarks>
            /// StyleプロパティがStyle.Arrowの時、開始位置に矢印を表示するかを取得／設定します
            /// trueの場合は表示します
            /// </remarks>
            public bool StartArrowCap { get; set; }
            /// <summary>矢印の終端キャップ有無</summary>
            /// <remarks>
            /// StyleプロパティがStyle.Arrowの時、終端位置に矢印を表示するかを取得／設定します
            /// trueの場合は表示します
            /// </remarks>
            public bool EndArrowCap { get; set; }
            /// <summary>矢印のキャップサイズ</summary>
            /// <remarks>
            /// StyleプロパティがStyle.Arrowの時、表示する矢印の大きさを取得／設定します
            /// </remarks>
            public int ArrowCapSize { get; set; }
            /// <summary>線の太さ</summary>
            public int LineWeight { get; set; }
            /// <summary>描画位置・縦</summary>
            /// <remarks>
            /// 文字列の描画位置を取得／設定します。
            /// </remarks>
            public StringAlignment LineAlignment { get; set; }
            /// <summary>描画位置・横</summary>
            /// <remarks>
            /// 文字列の描画位置を取得／設定します。
            /// </remarks>
            public StringAlignment Alignment { get; set; }
            /// <summary>縦書き</summary>
            /// <remarks>
            /// 文字列を縦書きにする場合、trueを指定します
            /// </remarks>
            public bool Vertical { get; set; }
            /// <summary>複数行</summary>
            /// <remarks>
            /// 指定範囲内で文字列を複数行描画する場合trueを指定します
            /// </remarks>
            public bool Multiline { get; set; }
            /// <summary>塗りつぶし</summary>
            /// <remarks>
            /// StyleプロパティがStyle.Boxにおいて、内部を塗りつぶす場合はtrueを指定します
            /// </remarks>
            public bool Fill { get; set; }
            /// <summary>線種</summary>
            /// <remarks>
            /// StyleプロパティがStyle.Line,Style.Arrowにおいて、線の種類を指定します
            /// </remarks>
            public DashStyle dashStyle { get; set; }
            /// <summary>画像イメージ</summary>
            public Image image { get; set; }
            /// <summary>
            /// タグ情報
            /// </summary>
            public object Tag { get; set; }
            /// <summary>
            /// グループ化したアイテム
            /// </summary>
            public ObservableCollection<CanvasItem> GroupItems { get; set; }
            /// <summary>
            /// 文字列のトリミング方法
            /// </summary>
            public StringTrimming Trimming { get; set; }
            /// <summary>
            /// ２重線
            /// </summary>
            public bool DoubleLine { get; set; }
            /// <summary>
            /// 選択時の描画色
            /// </summary>
            public Color SelectedColor { get; set; }
            /// <summary>
            /// 拡大縮小
            /// </summary>
            public Boolean Zoom { get; set; }

            private bool _Selected;
            /// <summary>
            /// 選択状態
            /// </summary>
            public bool Selected
            {
                get
                {
                    return this._Selected;
                }
                set
                {
                    this._Selected = value;
                    foreach (CanvasItem item in this.GroupItems)
                    {
                        setSelected(item, value);
                    }
                }
            }

            private void setSelected(CanvasItem Item, bool Value)
            {
                Item.Selected = Value;
                foreach (CanvasItem item in Item.GroupItems)
                {
                    setSelected(item, Value);
                }
            }

            /// <summary>
            /// 移動
            /// </summary>
            /// <param name="X">新しいＸ座標</param>
            /// <param name="Y">新しいＹ座標</param>
            public void MoveTo(int X, int Y)
            {
                Rectangle rect = this.Recangle;
                rect.X = X;
                rect.Y = Y;
                this.Recangle = rect;
            }
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public Canvas()
        {
            InitializeComponent();
            this.Lock = new object();
            //this.CanvasItems = new ObservableCollection<CanvasItem>();
        }

        void CanvasItems_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            this.Refresh();
        }

        /// <summary>
        /// 描画アイテムコレクション
        /// </summary>
        /// <remarks>
        /// 描画する描画アイテムを格納するコレクション。
        /// 追加されている描画アイテムは全て描画対象となります。
        /// </remarks>
        public ObservableCollection<CanvasItem> CanvasItems { get; set; }

        /// <summary>
        /// 描画アイテムクリックイベント
        /// </summary>
        public event ClickItemEventHandler ClickItem;

        /// <summary>
        /// 描画アイテムのマウスボタン押下イベント
        /// </summary>
        public event MouseDownItemEventHandler MouseDownItem;

        /// <summary>
        /// 描画アイテムのマウス移動イベント
        /// </summary>
        public event MouseMoveItemEventHandler MouseMoveItem;

        /// <summary>
        /// 描画アイテムのマウスボタンアップイベント
        /// </summary>
        public event MouseUpItemEventHandler MouseUpItem;

        /// <summary>
        /// 描画アイテムのマウスボタン押下イベント
        /// </summary>
        public event MouseDownItemsEventHandler MouseDownItems;

        /// <summary>
        /// 描画アイテムのマウス移動イベント
        /// </summary>
        public event MouseMoveItemsEventHandler MouseMoveItems;

        /// <summary>
        /// 描画アイテムのマウスボタンアップイベント
        /// </summary>
        public event MouseUpItemsEventHandler MouseUpItems;

        /// <summary>
        /// 描画イベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Canvas_Paint(object sender, PaintEventArgs e)
        {
            lock (this.Lock)
            {
                this.CreateImage(e.Graphics, 0, 0, false, this.CanvasItems);
            }
        }

        /// <summary>
        /// 描画処理
        /// </summary>
        /// <param name="g">描画先のGraphicsオブジェクト</param>
        /// <param name="offsetX"></param>
        /// <param name="offsetY"></param>
        /// <param name="GroupSelected"></param>
        /// <param name="CanvasItems">描画するCanvasItems</param>
        private void CreateImage(Graphics g, int offsetX, int offsetY, bool GroupSelected, ObservableCollection<CanvasItem> CanvasItems)
        {
            if(CanvasItems != null)
            {
                g.SmoothingMode = SmoothingMode.HighQuality;
                //全ての描画アイテムを描画対象とする
                foreach (CanvasItem Item in CanvasItems)
                {
                    Color color = new Color();
                    if (Item.Selected || GroupSelected)
                    {
                        color = Item.SelectedColor;
                    }
                    else
                    {
                        color = Item.Color;
                    }
                    Rectangle rectangle = new Rectangle(Item.Recangle.X + offsetX, Item.Recangle.Y + offsetY, Item.Recangle.Width, Item.Recangle.Height);
                    if (Item.style == Style.Box)
                    {
                        if (Item.Fill)
                        {
                            using (Brush b = new SolidBrush(Color.FromArgb(Item.AlphaBlend, color)))
                            {
                                g.FillRectangle(b, rectangle);
                            }
                        }
                        else
                        {
                            using (Pen p = new Pen(Color.FromArgb(Item.AlphaBlend, color), Item.LineWeight))
                            {
                                if (Item.DoubleLine)
                                {
                                    p.CompoundArray = new[] { 0.0f, 0.35f, 0.65f, 1.0f };
                                }
                                g.DrawRectangle(p, rectangle);
                            }
                        }
                    }
                    if (Item.style == Style.Line)
                    {
                        using (Pen p = new Pen(Color.FromArgb(Item.AlphaBlend, color), Item.LineWeight))
                        {
                            p.StartCap = Item.StartCap;
                            p.EndCap = Item.EndCap;
                            p.DashStyle = Item.dashStyle;
                            if (Item.DoubleLine)
                            {
                                p.CompoundArray = new[] { 0.0f, 0.35f, 0.65f, 1.0f };
                            }
                            g.DrawLine(p, rectangle.X, rectangle.Y, rectangle.X + rectangle.Width, rectangle.Y + rectangle.Height);
                        }
                    }
                    if (Item.style == Style.Arrow)
                    {
                        using (Pen p = new Pen(Color.FromArgb(Item.AlphaBlend, color), Item.LineWeight))
                        {
                            AdjustableArrowCap ArrowCap = new AdjustableArrowCap(Item.ArrowCapSize, Item.ArrowCapSize, false);
                            if (Item.StartArrowCap)
                            {
                                p.CustomStartCap = ArrowCap;
                            }
                            if (Item.EndArrowCap)
                            {
                                p.CustomEndCap = ArrowCap;
                            }
                            p.DashStyle = Item.dashStyle;
                            if (Item.DoubleLine)
                            {
                                p.CompoundArray = new[] { 0.0f, 0.35f, 0.65f, 1.0f };
                            }
                            g.DrawLine(p, rectangle.X, rectangle.Y, rectangle.X + rectangle.Width, rectangle.Y + rectangle.Height);
                        }
                    }
                    if (Item.style == Style.Image)
                    {
                        if(Item.Zoom == false)
                        {
                            g.DrawImageUnscaledAndClipped(Item.image, rectangle);
                        }
                        else
                        {
                            g.DrawImage(Item.image, rectangle);
                        }
                    }
                    if (Item.style == Style.Group)
                    {
                        this.CreateImage(g, rectangle.X, rectangle.Y, Item.Selected | GroupSelected, Item.GroupItems);
                    }
                    //文字列は全ての描画アイテムで描画するので、Item.Style が Style.Text と それ以外で処理を分けて、それぞれ描画処理を行う
                    if (Item.style == Style.Text)
                    {
                        StringFormat sf = new StringFormat(StringFormat.GenericTypographic);
                        sf.Trimming = Item.Trimming;
                        sf.FormatFlags = StringFormatFlags.NoClip;
                        if (Item.Vertical)
                        {
                            sf.FormatFlags |= StringFormatFlags.DirectionVertical;
                        }
                        if (!Item.Multiline)
                        {
                            sf.FormatFlags |= StringFormatFlags.NoWrap;
                        }
                        //文字列の背景
                        if (Item.Text != string.Empty)
                        {
                            //文字列の描画エリアを取得し、その部分のみ背景を塗りつぶす
                            RectangleF rec = GetTextEria(Item, offsetX, offsetY);
                            using (Brush b = new SolidBrush(Color.FromArgb(Item.AlphaBlend, color)))
                            {
                                g.FillRectangle(b, rec);
                            }
                            //文字の描画
                            using (Brush b = new SolidBrush(Item.FontColor))
                            {
                                g.DrawString(Item.Text, Item.Font, b, rec, sf);
                            }
                        }

                    }
                    else
                    {
                        if (Item.Text != null)
                        {
                            StringFormat sf = new StringFormat();
                            sf.LineAlignment = Item.LineAlignment;
                            sf.Alignment = Item.Alignment;
                            sf.Trimming = Item.Trimming;
                            if (Item.Vertical)
                            {
                                sf.FormatFlags |= StringFormatFlags.DirectionVertical;
                            }
                            if (!Item.Multiline)
                            {
                                sf.FormatFlags |= StringFormatFlags.NoWrap;
                            }
                            using (Brush b = new SolidBrush(Item.FontColor))
                            {
                                g.DrawString(Item.Text, Item.Font, b, rectangle, sf);
                            }

                        }
                    }
                }
            }
        }

        /// <summary>
        /// 文字列の描画領域の算出
        /// </summary>
        /// <param name="Item"></param>
        /// <param name="offsetX"></param>
        /// <param name="offsetY"></param>
        /// <returns></returns>
        private RectangleF GetTextEria(CanvasItem Item, int offsetX, int offsetY)
        {
            StringFormat sf = new StringFormat(StringFormat.GenericTypographic);
            sf.LineAlignment = Item.LineAlignment;
            sf.Alignment = Item.Alignment;
            sf.Trimming = Item.Trimming;
            sf.FormatFlags = StringFormatFlags.NoClip;
            if (Item.Vertical)
            {
                sf.FormatFlags |= StringFormatFlags.DirectionVertical;
            }
            if (!Item.Multiline)
            {
                sf.FormatFlags |= StringFormatFlags.NoWrap;
            }


            using (Graphics g = this.CreateGraphics())
            {
                //テキストの描画エリアを取得する
                SizeF pSize = new Size(Item.Recangle.Width - Item.Margin.Left - Item.Margin.Right, Item.Recangle.Height - Item.Margin.Top - Item.Margin.Bottom);
                SizeF TextSize = g.MeasureString(Item.Text, Item.Font, pSize, sf);

                if (Item.Text != string.Empty)
                {
                    float bx = 0;
                    float by = 0;
                    float bw = 100;
                    float bh = 32;

                    StringAlignment Alignment;
                    if (!Item.Vertical)
                    {
                        Alignment = Item.Alignment;
                    }
                    else
                    {
                        Alignment = Item.LineAlignment;
                    }

                    switch (Alignment)
                    {
                        case StringAlignment.Near:
                            bx = (Item.Recangle.X + offsetX) + Item.Margin.Left;
                            break;
                        case StringAlignment.Center:
                            bx = (Item.Recangle.X + offsetX) + (Item.Recangle.Width / 2) - (TextSize.Width / 2) + Item.Margin.Left - Item.Margin.Right;
                            break;
                        case StringAlignment.Far:
                            bx = (Item.Recangle.X + offsetX) + Item.Recangle.Width - TextSize.Width - Item.Margin.Right;
                            break;
                    }
                    bw = TextSize.Width;

                    if (!Item.Vertical)
                    {
                        Alignment = Item.LineAlignment;
                    }
                    else
                    {
                        Alignment = Item.Alignment;
                    }
                    switch (Alignment)
                    {
                        case StringAlignment.Near:
                            by = (Item.Recangle.Y + offsetY) + Item.Margin.Top;
                            break;
                        case StringAlignment.Center:
                            by = (Item.Recangle.Y + offsetY) + (Item.Recangle.Height / 2) - (TextSize.Height / 2) + Item.Margin.Top - Item.Margin.Bottom;
                            break;
                        case StringAlignment.Far:
                            by = ((Item.Recangle.Y + offsetY) + Item.Recangle.Height) - TextSize.Height - Item.Margin.Bottom;
                            break;
                    }
                    bh = TextSize.Height;

                    return new RectangleF(bx, by, bw, bh);
                }
                else
                {
                    return Item.Recangle;
                }
            }
        }

        /// <summary>
        /// クリックイベント呼出
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnClickItem(ItemClickEventArgs e)
        {
            ClickItem?.Invoke(this, e);
        }

        /// <summary>
        /// マウスボタン押下イベント呼出
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnMouseDownItem(ItemMouseEventArgs e)
        {
            MouseDownItem?.Invoke(this, e);
        }

        /// <summary>
        /// マウス移動イベント呼出
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnMouseMoveItem(ItemMouseEventArgs e)
        {
            MouseMoveItem?.Invoke(this, e);
        }

        /// <summary>
        /// マウスボタンアップイベント呼出
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnMouseUpItem(ItemMouseEventArgs e)
        {
            MouseUpItem?.Invoke(this, e);
        }

        /// <summary>
        /// マウスボタン押下イベント呼出
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnMouseDownItems(ItemsMouseEventArgs e)
        {
            MouseDownItems?.Invoke(this, e);
        }

        /// <summary>
        /// マウス移動イベント呼出
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnMouseMoveItems(ItemsMouseEventArgs e)
        {
            MouseMoveItems?.Invoke(this, e);
        }

        /// <summary>
        /// マウスボタンアップイベント呼出
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnMouseUpItems(ItemsMouseEventArgs e)
        {
            MouseUpItems?.Invoke(this, e);
        }

        private void Canvas_Click(object sender, EventArgs e)
        {
            foreach (CanvasItem Item in this.CanvasItems)
            {
                //クリック位置をチェックし、対象の場合はクリックイベントを呼び出す
                if (CheckPointer(Item))
                {
                    this.OnClickItem(new ItemClickEventArgs(Item));
                }
            }
        }

        /// <summary>
        /// クリック位置のチェック
        /// </summary>
        /// <param name="Item"></param>
        /// <returns></returns>
        private bool CheckPointer(CanvasItem Item)
        {
            if (Item.Event)
            {
                if (Item.style != Style.Text)
                {
                    if ((Item.Recangle.X <= this.X) && ((Item.Recangle.X + Item.Recangle.Width) >= this.X))
                    {
                        if ((Item.Recangle.Y <= this.Y) && ((Item.Recangle.Y + Item.Recangle.Height) >= this.Y))
                        {
                            return true;
                        }
                    }
                }
                else
                {
                    //文字列の場合は、描画している文字列の部分のみをクリックイベントの対象とする
                    RectangleF rec = this.GetTextEria(Item, 0, 0);
                    if ((rec.X <= this.X) && ((rec.X + rec.Width) >= this.X))
                    {
                        if ((rec.Y <= this.Y) && ((rec.Y + rec.Height) >= this.Y))
                        {
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        private void Canvas_MouseMove(object sender, MouseEventArgs e)
        {
            List<CanvasItem> Items = new List<CanvasItem>();
            //マウスカーソルの位置を保存する
            this.X = e.X;
            this.Y = e.Y;
            foreach (CanvasItem Item in this.CanvasItems)
            {
                //クリック位置をチェックし、対象の場合はマウスボタン押下イベントを呼び出す
                if (CheckPointer(Item))
                {
                    this.OnMouseMoveItem(new ItemMouseEventArgs(e.Button, e.Clicks, e.X, e.Y, e.Delta, Item));
                    Items.Add(Item);
                }
            }
            if (Items.Count > 0)
            {
                this.OnMouseMoveItems(new ItemsMouseEventArgs(e.Button, e.Clicks, e.X, e.Y, e.Delta, Items));
            }
        }

        /// <summary>
        /// フォントサイズ取得
        /// </summary>
        /// <remarks>
        /// 指定したフォントサイズからスケーリング前のフォントサイズを算出する。
        /// </remarks>
        /// <param name="Size">フォントサイズ</param>
        /// <returns>スケーリング前のフォントサイズ</returns>
        public float GetEmSize(float Size)
        {
            using (Graphics g = this.CreateGraphics())
            {
                // DPIからスケーリングの比率を取得
                float scale = g.DpiX / 96f;
                return Size / scale;

            }
        }

        /// <summary>
        /// 画像保存
        /// </summary>
        /// <param name="File">保存先</param>
        /// <param name="Format">出力形式</param>
        public void Save(string File, System.Drawing.Imaging.ImageFormat Format)
        {
            using (Bitmap saveImg = (Bitmap)this.BackgroundImage.Clone())
            {
                using (Graphics g = Graphics.FromImage(saveImg))
                {
                    this.CreateImage(g, 0, 0, false, this.CanvasItems);
                    saveImg.Save(File, Format);
                }
            }

        }

        private void Canvas_MouseDown(object sender, MouseEventArgs e)
        {
            List<CanvasItem> Items = new List<CanvasItem>();
            foreach (CanvasItem Item in this.CanvasItems)
            {
                //クリック位置をチェックし、対象の場合はマウスボタン押下イベントを呼び出す
                if (CheckPointer(Item))
                {
                    this.OnMouseDownItem(new ItemMouseEventArgs(e.Button, e.Clicks, e.X, e.Y, e.Delta, Item));
                    Items.Add(Item);
                }
            }
            if (Items.Count > 0)
            {
                this.OnMouseDownItems(new ItemsMouseEventArgs(e.Button, e.Clicks, e.X, e.Y, e.Delta, Items));
            }
        }

        private void Canvas_MouseUp(object sender, MouseEventArgs e)
        {
            List<CanvasItem> Items = new List<CanvasItem>();
            foreach (CanvasItem Item in this.CanvasItems)
            {
                //クリック位置をチェックし、対象の場合はマウスボタン押下イベントを呼び出す
                if (CheckPointer(Item))
                {
                    this.OnMouseUpItem(new ItemMouseEventArgs(e.Button, e.Clicks, e.X, e.Y, e.Delta, Item));
                    Items.Add(Item);
                }
            }
            if (Items.Count > 0)
            {
                this.OnMouseUpItems(new ItemsMouseEventArgs(e.Button, e.Clicks, e.X, e.Y, e.Delta, Items));
            }
        }

        private void Canvas_Load(object sender, EventArgs e)
        {
            this.CanvasItems.CollectionChanged += CanvasItems_CollectionChanged;
        }
    }
}
