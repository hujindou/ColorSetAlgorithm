﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MarsTool.Common.Forms
{
    public partial class WaitDialog : Form
    {
        //外からインスタンスを生成できないようにコンストラクタはprivate
        static WaitDialog mInstance = null;
        static Point mPoint = new Point();
        static Form form = null;
        private WaitDialog()
        {
            InitializeComponent();
        }


        public static  void Show(Form window)
        {
            form = window;
            Show(new Point(window.Left + window.Width / 2, window.Top + window.Height / 2));
        }

        public static void Show(Point point)
        {
            mPoint = point;
            // BeginInvokeで実処理を別スレッド実行
            Action showProc = new Action(ShowProcess);
            IAsyncResult async = showProc.BeginInvoke(null, null);

            // そのままメインスレッドは処理が流れるため、別スレッドでインスタンスが生成されるまで待つ
            while (true)
            {
                if (mInstance != null)
                {
                    break;
                }
            }
            return;
        }

        private static void ShowProcess()
        {
            mInstance = new WaitDialog
            {
                Location = new Point(mPoint.X, mPoint.Y),
                TopLevel = true,
                TopMost = true
            };

            // Showだと処理が流れてスレッドが終了してしまうので、ShowDialogで表示して
            // 別スレッド側は処理を待つ
            mInstance.ShowDialog();
        }

        // クローズ処理
        public static new void Close()
        {
            if (mInstance == null || mInstance.IsDisposed == true) return;


            if (mInstance.InvokeRequired == true)
            {
                mInstance.Invoke(new Action(Close));
                Application.DoEvents();
                if (form != null) form.Activate();
            }
            else
            {
                ((Form)mInstance).Close();
            }
        }
    }
}
