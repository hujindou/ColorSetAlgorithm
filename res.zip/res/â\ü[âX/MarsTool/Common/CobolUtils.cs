﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace MarsTool.Common
{
    class CobolUtils
    {
        /// <summary>
        /// コピー句項目構造体
        /// </summary>
        public class CopyItem
        {
            /// <summary>
            /// 内部レベル
            /// </summary>
            public int Level { get; set; }
            /// <summary>
            /// 項目名称
            /// </summary>
            public string Name { get; set; }
            /// <summary>
            /// 属性・サイズ
            /// </summary>
            public string Type { get; set; }
            /// <summary>
            /// アドレス項目
            /// </summary>
            public bool IsAddress { get; set; }
            /// <summary>
            /// コメント・前
            /// </summary>
            public List<string> PrefixComments { get; set; }
            /// <summary>
            /// コメント・後
            /// </summary>
            public List<string> SuffixComments { get; set; }
            /// <summary>
            /// 繰り返し回数
            /// </summary>
            public int Occurs { get; set; }
            /// <summary>
            /// 置き換え
            /// </summary>
            public string Redefines { get; set; }
            /// <summary>
            /// コピー句・PREFIXING
            /// </summary>
            public string PREFIXING { get; set; }
            /// <summary>
            /// コピー句・SUFFIXING
            /// </summary>
            public string SUFFIXING { get; set; }
            /// <summary>
            /// コピー句ＩＤ（COPY IN COPY）
            /// </summary>
            public string ID { get; set; }
            /// <summary>
            /// 親項目
            /// </summary>
            public CopyItem ParentItem { get; set; }
            /// <summary>
            /// 子項目
            /// </summary>
            public List<CopyItem> ChileItem { get; set; }
            /// <summary>
            /// コメントのみか
            /// </summary>
            public bool IsComment { get; set; }
            /// <summary>
            /// オブジェクト（任意項目）
            /// </summary>
            public Object Object { get; set; }
            /// <summary>
            /// Index
            /// </summary>
            public int Index { get; set; }
            /// <summary>
            /// イニシャライズ
            /// </summary>
            public CopyItem()
            {
                ChileItem = new List<CopyItem>();
                PrefixComments = new List<string>();
                SuffixComments = new List<string>();
                this.Object = null;
            }
        }

        /// <summary>
        /// コピー句クラス
        /// </summary>
        public class CopyPhrase
        {
            #region 固定値
            private const int OutPosition = 10;

            #endregion

            /// <summary>
            /// Dispose済みフラグ
            /// </summary>
            private bool disposed = false;

            /// <summary>
            /// 現在の項目
            /// </summary>
            private CopyItem currentItem = null;

            private CopyItem CheckItem = null;

            public enum CheckReturn
            {
                OK = 0,
                NoItem,
                NoChild,
                TypeErr,
                Error
            };

            /// <summary>
            /// コンストラクタ
            /// </summary>
            public CopyPhrase()
            {
                Comment = new List<string>();
                this.Index = 0;
            }

            /// <summary>
            /// ファイナライザ
            /// </summary>
            ~CopyPhrase()
            {
                Dispose(false);
            }

            /// <summary>
            /// Dispose
            /// </summary>
            /// <param name="disposing"></param>
            protected virtual void Dispose(bool disposing)
            {
                if (!disposed)
                {
                    disposed = true;

                    if (disposing)
                    {
                        // managed リソースの解放
                    }

                    // unmanaged リソースの解放
                }
            }

            /// <summary>
            /// コピー句
            /// </summary>
            public CopyItem copyItem { get; set; }

            /// <summary>
            /// コピー句コメント
            /// </summary>
            public List<string> Comment { get; set; }

            public CopyItem CheckErrorItem
            {
                get { return CheckItem; }
            }

            private int Index { get; set; }

            /// <summary>
            /// コピー句.項目の追加
            /// </summary>
            /// <param name="Level">追加するレベル</param>
            /// <param name="Name">項目名称</param>
            /// <param name="Type">属性／サイズ</param>
            /// <param name="Occurs">繰り返し回数</param>
            /// <param name="Comments">行コメント</param>
            /// <returns>追加した項目</returns>
            public CopyItem Add(int Level, string Name, string Type, int Occurs, List<string> PrefixComments, List<string> SuffixComments)
            {
                return this.Add(Level, Name, Type, Occurs, null, PrefixComments, SuffixComments, null);
            }

            public CopyItem Add(int Level, string Name, string Type, int Occurs, List<string> PrefixComments, List<string> SuffixComments, Object obj)
            {
                return this.Add(Level, Name, Type, Occurs, null, PrefixComments, SuffixComments, null);
            }

            public CopyItem Add(int Level, string Name, string Type, int Occurs, string Redfines, List<string> PrefixComments, List<string> SuffixComments, Object obj)
            {
                if (Type == null) Type = string.Empty;
                if (Name == null) Name = string.Empty;

                if (Level == 1)
                {
                    //最上位項目
                    this.copyItem = new CopyItem();
                    copyItem.Name = Name;
                    copyItem.Object = obj;
                    if (Type.Length >= 7 && Type.Substring(0, 7) == "ADDRESS")
                    {
                        copyItem.Type = string.Empty;
                        copyItem.IsAddress = true;
                    }
                    else
                    {
                        copyItem.Type = Type;
                    }
                    copyItem.Level = Level;
                    copyItem.PrefixComments = PrefixComments;
                    copyItem.SuffixComments = SuffixComments;
                    if (Occurs == 0)
                    {
                        copyItem.Occurs = 1;
                    }
                    else
                    {
                        copyItem.Occurs = Occurs;
                    }
                    copyItem.Redefines = Redfines;
                    copyItem.Index = this.Index;
                    this.Index++;
                    currentItem = this.copyItem;

                    return copyItem;
                }
                else
                {
                    CopyItem Item = new CopyItem();
                    Item.Name = Name;
                    Item.Object = obj;
                    if (Type.Length >= 7 && Type.Substring(0, 7) == "ADDRESS")
                    {
                        Item.Type = string.Empty;
                        Item.IsAddress = true;
                    }
                    else
                    {
                        Item.Type = Type;
                    }
                    Item.Level = Level;
                    Item.PrefixComments = PrefixComments;
                    Item.SuffixComments = SuffixComments;
                    if (Occurs == 0)
                    {
                        Item.Occurs = 1;
                    }
                    else
                    {
                        Item.Occurs = Occurs;
                    }
                    Item.Redefines = Redfines;
                    Item.Index = this.Index;
                    this.Index++;

                    if (currentItem.Level < Item.Level)
                    {
                        //子項目
                        Item.ParentItem = currentItem;
                        currentItem.ChileItem.Add(Item);
                    }
                    else if (currentItem.Level == Item.Level)
                    {
                        //同一レベル
                        Item.ParentItem = currentItem.ParentItem;
                        currentItem.ParentItem.ChileItem.Add(Item);
                    }
                    else
                    {
                        //親
                        CopyItem parentItem = currentItem.ParentItem;
                        while (parentItem != null && parentItem.Level >= Item.Level)
                        {
                            parentItem = parentItem.ParentItem;
                        }
                        Item.ParentItem = parentItem;
                        parentItem.ChileItem.Add(Item);
                    }
                    currentItem = Item;

                    return Item;
                }
            }

            public CopyItem Add(int Level, string ID, string PREFIXING, string SUFFIXING, List<string> PrefixComments, List<string> SuffixComments, Object obj)
            {
                CopyItem Item = new CopyItem();
                Item.Object = obj;
                Item.Level = Level;
                Item.ID = ID;
                Item.PREFIXING = PREFIXING;
                Item.SUFFIXING = SUFFIXING;
                Item.PrefixComments = PrefixComments;
                Item.SuffixComments = SuffixComments;
                Item.Index = this.Index;
                this.Index++;

                if (currentItem.Level < Item.Level)
                {
                    //子項目
                    Item.ParentItem = currentItem;
                    currentItem.ChileItem.Add(Item);
                }
                else if (currentItem.Level == Item.Level)
                {
                    //同一レベル
                    Item.ParentItem = currentItem.ParentItem;
                    currentItem.ParentItem.ChileItem.Add(Item);
                }
                currentItem = Item;
                return Item;
            }

            public CopyItem Add(int Level, string ID, string PREFIXING, string SUFFIXING, List<string> PrefixComments, List<string> SuffixComments)
            {
                return this.Add(Level, ID, PREFIXING, SUFFIXING, PrefixComments, SuffixComments, null);
            }

            /// <summary>
            /// 追加・コメント
            /// </summary>
            /// <param name="Comments"></param>
            /// <returns></returns>
            public CopyItem AddComment(List<string> Comments)
            {
                return this.AddComment(Comments, null);
            }
            public CopyItem AddComment(List<string> Comments, Object obj)
            {
                CopyItem Item = new CopyItem();
                Item.Object = obj;
                if (currentItem.Type == string.Empty)
                {
                    Item.Level = currentItem.Level + 2;
                    Item.IsComment = true;
                    Item.SuffixComments.AddRange(Comments);
                    Item.ParentItem = currentItem;
                    currentItem.ChileItem.Add(Item);
                }
                else
                {
                    Item.Level = currentItem.Level;
                    Item.IsComment = true;
                    Item.SuffixComments.AddRange(Comments);
                    Item.ParentItem = currentItem.ParentItem;
                    currentItem.ParentItem.ChileItem.Add(Item);
                }
                currentItem = Item;
                return Item;
            }

            public string ToString(int TopLevel)
            {
                StringBuilder sb = new StringBuilder(); //マスターバッファ

                int level = TopLevel;
                try
                {
                    sb.Append(this.ToString(this.copyItem, TopLevel, level));
                }
                catch
                {
                    throw;
                }
                return sb.ToString();

            }

            private string ToString(CopyItem Item, int TopLevel, int level)
            {
                StringBuilder sbAll = new StringBuilder();
                StringBuilder sbLine = new StringBuilder(); //１行バッファ
                StringBuilder sb = new StringBuilder();     //項目バッファ
                StringBuilder sp = new StringBuilder();     //PICTURE句バッファ
                StringBuilder sm = new StringBuilder();     //その他修飾子バッファ

                int bufLength = 0;
                int picLength = 0;
                int modLength = 0;

                if (Item == null) return string.Empty;

                if (Item.ID == null || Item.ID == string.Empty)
                {
                    // 先頭～項目名までを項目バッファに格納する
                    sbLine.Append(new string(' ', 10 + (level - TopLevel) * 1 - 1));
                    // レベル番号
                    sbLine.Append(string.Format("{0:D2}", level));
                    // 項目区切りのスペース
                    sbLine.Append(string.Format("{0}", new string(' ', 2)));
                    // 項目名
                    if (Item.Name == "FILLER")
                    {
                        sbLine.Append(string.Format("{0}", "FILLER"));
                    }
                    else
                    {
                        sbLine.Append(string.Format("{0}{1}{2}", Item.PREFIXING, Item.Name, Item.SUFFIXING));
                    }
                    // ここまでの格納サイズを算出する
                    bufLength = Encoding.GetEncoding("Shift_Jis").GetByteCount(sbLine.ToString());

                    //PICTURE句バッファにPICTURE句の内容を格納する
                    if (Item.Type != string.Empty)
                    {
                        sp.Append("PIC");
                        // 属性のスペース
                        sp.Append(string.Format("{0}", new string(' ', 1)));
                        // 属性＆サイズ
                        sp.Append(string.Format("{0}", Item.Type));
                        // ここまでの格納サイズを算出する
                        picLength = Encoding.GetEncoding("Shift_Jis").GetByteCount(sp.ToString());
                    }


                    //その他修飾子バッファにOCCURSの内容を格納する
                    if (Item.IsAddress || Item.Occurs > 1)
                    {
                        if (Item.IsAddress)
                        {
                            sm.Append("ADDRESS");
                        }
                        else
                        {
                            // OCCURS
                            sm.Append("OCCURS");
                            // 属性のスペース
                            sm.Append(string.Format("{0}", new string(' ', 1)));
                            // 繰り返し数
                            sm.Append(string.Format("{0,2:D}", Item.Occurs));
                        }
                        // ここまでの格納サイズを算出する
                        modLength = Encoding.GetEncoding("Shift_Jis").GetByteCount(sm.ToString());
                    }

                    // PICTURE句バッファの内容を項目バッファに追加する
                    // この時、以下の処理を行う
                    // ・PICTURE句の開始位置までスペースを設定する
                    //   但し、開始位置を超えている場合は改行し、次の行にPICTURE句を設定する
                    if (picLength > 0)
                    {
                        //PICTURE句開始位置までスペースを設定し、PICTURE句の内容を出力する
                        //PICTURE句開始位置を超えている場合は、改行しPICTURE句開始位置からPICTURE句の内容を出力する
                        if (bufLength < (48 - 1))
                        {
                            //位置調整
                            sbLine.Append(string.Format("{0}", new string(' ', 48 - bufLength - 1)));
                        }
                        else
                        {
                            // 改行
                            sb.Append(sbLine.ToString());
                            sb.Append("\r\n");
                            sbLine.Clear();
                            bufLength = 0;
                            // 出力位置までのスペース
                            sbLine.Append(new string(' ', 48 - 1));
                        }
                        // PICTURE句の内容
                        sbLine.Append(sp.ToString());
                        // １行の桁数を再度算出する
                        bufLength = Encoding.GetEncoding("Shift_Jis").GetByteCount(sbLine.ToString());
                    }

                    // その他修飾子バッファの内容を項目バッファに追加する
                    // この時、以下の処理を行う
                    // ・OCCURS句の開始位置までスペースを設定する
                    //   但し、開始位置を超えている場合は改行し、次の行にOCCURS句を設定する
                    if (modLength > 0)
                    {
                        if (picLength > 0)
                        {
                            //整形しないので、そのまま追加する。
                            //但し、結合後のサイズが制限72文字を超える場合は、改行し出力開始位置より出力する
                            if ((bufLength + modLength + 1 + 1) > 72)
                            {
                                // 改行
                                sb.Append(sbLine.ToString());
                                sb.Append("\r\n");
                                sbLine.Clear();
                                bufLength = 0;
                                // 出力位置までのスペース
                                sbLine.Append(new string(' ', 48 - 1));
                            }
                            else
                            {
                                // 項目区切りのスペース
                                sbLine.Append(string.Format("{0}", new string(' ', 1)));
                            }
                        }
                        else
                        {
                            //その他修飾子開始位置までスペースを設定し、その他修飾子の内容を出力する
                            //その他修飾子開始位置を超えている場合は、改行しその他修飾子開始位置からその他修飾子の内容を出力する
                            if (bufLength < (48 - 1))
                            {
                                //位置調整
                                sbLine.Append(string.Format("{0}", new string(' ', 48 - bufLength - 1)));
                            }
                            else
                            {
                                // 改行
                                sb.Append(sbLine.ToString());
                                sb.Append("\r\n");
                                sbLine.Clear();
                                bufLength = 0;
                                // 出力位置までのスペース
                                sbLine.Append(new string(' ', 48 - 1));
                            }
                        }
                        // その他修飾子の内容
                        sbLine.Append(sm.ToString());
                    }
                }

                // 終端(.)
                sbLine.Append(string.Format("."));
                sb.Append(sbLine.ToString());
                sb.Append("\r\n");
                sbLine.Clear();
                bufLength = 0;

                sbAll.Append(sb.ToString());

                // レベル番号を２加算し、子項目についても処理を行う
                level += 2;
                foreach (CopyItem ChildItem in Item.ChileItem)
                {
                    sbAll.Append(this.ToString(ChildItem, TopLevel, level));
                }

                return sbAll.ToString();
            }

            /// <summary>
            /// コピー句クラスの内部矛盾のチェック
            /// </summary>
            /// <returns>最初に見つかったエラーを返す。エラーが無い場合はOKを返す</returns>
            public CheckReturn Check()
            {
                CheckItem = null;
                CopyItem RootItem = this.copyItem;
                if (RootItem == null)
                {
                    return CheckReturn.NoItem;
                }
                return this.Check(RootItem);
            }
            private CheckReturn Check(CopyItem Item)
            {
                if (Item.IsComment == false && Item.Type != string.Empty && Item.ChileItem.Count > 0)
                {
                    CheckItem = Item;
                    return CheckReturn.TypeErr;
                }
                int childCount = 0;
                foreach (CopyItem Child in Item.ChileItem)
                {
                    if (Child.IsComment == false)
                    {
                        childCount++;
                    }
                    CheckReturn rc = this.Check(Child);
                    if (rc != CheckReturn.OK)
                    {
                        return rc;
                    }
                }
                if (Item.IsComment == false && Item.Type == string.Empty && childCount == 0)
                {
                    CheckItem = Item;
                    return CheckReturn.NoChild;
                }
                return CheckReturn.OK;
            }
        }

        /// <summary>
        /// COBOLのPICTURE句、USAGE句の内容を検定する
        /// </summary>
        /// <param name="PictureValue">PICTURE句、USAGE句の内容</param>
        /// <returns>本ツールで対応するPICTURE句、USAGE句の場合はTrueを返す</returns>
        static public bool TypeCheck(string PictureValue)
        {
            bool BracketsFlag = false;

            //引数が不正の場合
            if (PictureValue == null || PictureValue == string.Empty) return false;

            //ADDRESS句は許可する
            if(PictureValue.Length >= 7 && PictureValue.StartsWith("ADDRESS"))
            {
                if (PictureValue.Length == 7) return true;
                //サイズ以外が設定されていないか検定する
                BracketsFlag = false;
                for(int i=7;i<PictureValue.Length;i++)
                {
                    switch(PictureValue[i])
                    {
                        case '(':
                            if (BracketsFlag) return false;
                            BracketsFlag = true;
                            break;
                        case ')':
                            if (BracketsFlag == false) return false;
                            BracketsFlag = false;
                            break;
                        case ' ':
                            break;
                        default:
                            if (PictureValue[i] < '0' || PictureValue[i] > '9') return false;
                            break;
                    }
                }
                return true;
            }

            //PICTURE句 と USAGE句 と その他 に分割する
            string[] Item =  Regex.Replace(PictureValue, @"\s+", " ").Split(' ');

            int Index = 0;
            BracketsFlag = false;

            //PICTURE句の検定
            foreach (char t in Item[Index].ToCharArray())
            {
                switch(t)
                {
                    case '1':
                    case '9':
                    case 'Z':
                    case 'X':
                        break;
                    case 'S':
                    case 'V':
                    case ',':
                    case '\\':
                        break;
                    case '(':
                        if (BracketsFlag) return false;
                        BracketsFlag = true;
                        break;
                    case ')':
                        if (BracketsFlag == false) return false;
                        BracketsFlag = false;
                        break;
                    default:
                        if (BracketsFlag == false)
                        {
                            return false;
                        }
                        break;
                }
            }

            //USAGE句 の検定
            Index++;
            if(Item.Count() > 1)
            {
                switch(Item[Index])
                {
                    case "BINARY":
                    case "COMP-X":
                    case "COMP":
                    case "COMP-3":
                    case "COMP-5":
                    case "BIT":
                        break;
                    default:
                        return false;
                }
                Index++;
            }

            if(Index != Item.Count())   //USAGE句の後ろの何か設定されている場合はエラーとする
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// PICTURE句、USAGE句からサイズを算出する
        /// </summary>
        /// <param name="PictureValue">PICTURE句、USAGE句の内容</param>
        /// <returns>算出されたサイズ</returns>
        static public int GetSize(string PictureValue)
        {
            bool BracketsFlag = false;

            //引数が不正の場合
            if (PictureValue == null || PictureValue == string.Empty) return 0;

            //ADDRESS句が指定されていた場合のサイズ算出
            if (PictureValue.Length >= 7 && PictureValue.StartsWith("ADDRESS"))
            {
                if (PictureValue.Length == 7) return 4; //サイズ指定が無い場合は４とする
                //サイズの取得
                BracketsFlag = false;
                for (int i = 7; i < PictureValue.Length; i++)
                {
                    switch (PictureValue[i])
                    {
                        case '(':
                            BracketsFlag = true;
                            //括弧の中の数値を取得し、サイズを算出する
                            int epos = PictureValue.IndexOf(')', i);
                            if (epos > 0)
                            {
                                string strNum = PictureValue.Substring(i + 1, epos - i - 1);
                                if (int.TryParse(strNum, out int iNum))
                                {
                                    return iNum;
                                }
                            }
                            break;
                        default:
                            break;
                    }
                }
                return 0;
            }

            //PICTURE句 と USAGE句 と その他 に分割する
            string[] Item = Regex.Replace(PictureValue, @"\s+", " ").Split(' ');

            int Index = 0;
            int Size = 0;
            int BeforeItemSize = 0;
            BracketsFlag = false;

            //PICTURE句のサイズ算出
            for (int pos = 0;pos < Item[Index].Length; pos ++)
            {
                switch (Item[Index][pos])
                {
                    case '1':
                    case '9':
                    case 'Z':
                    case 'X':
                        if (BracketsFlag == false)
                        {
                            Size += 1;
                            BeforeItemSize = 1;
                        }
                        break;
                    case 'S':
                    case 'V':
                    case ',':
                    case '\\':
                        //サイズ計算対象外なので何もしない
                        break;
                    case '(':
                        //括弧の中の数値を取得し、サイズを算出する
                        int epos = Item[Index].IndexOf(')', pos);
                        if (epos > 0)
                        {
                            string strNum = Item[Index].Substring(pos + 1, epos - pos - 1);
                            if(int.TryParse(strNum, out int iNum))
                            {
                                //既にBeforeItemSize分足しているので、BeforeItemSize分は引いておく
                                Size += ((BeforeItemSize * iNum) - BeforeItemSize);
                                BracketsFlag = true;
                            }
                        }
                        break;
                    case ')':
                        BracketsFlag = false;
                        break;
                    default:
                        break;
                }
            }

            //OCCURS句が設定されている場合の処理
            int Count = 1;
            if (Item.Count() > 2 && Item[Item.Count() - 2] == "OCCURS")
            {
                if (int.TryParse(Item[Item.Count() - 1], out int iCount))
                {
                    Count = iCount;
                }
            }

            //USAGE句のサイズ算出
            Index++;
            if (Item.Count() > 1)
            {
                //OCCURS句の場合は処理を抜ける
                if (Item[Index] == "OCCURS")
                {
                    return (Size * Count);
                }

                switch (Item[Index])
                {
                    case "BINARY":
                        if (Size >= 1 && Size <= 4) return (2 * Count);
                        if (Size >= 5 && Size <= 9) return (4 * Count);
                        return (8 * Count);
                    case "COMP-X":
                        if (Size >= 1 && Size <= 2) return (1 * Count);
                        if (Size >= 3 && Size <= 4) return (2 * Count);
                        if (Size >= 5 && Size <= 9) return (4 * Count);
                        return (8 * Count);
                    case "COMP":
                        if (Size >= 1 && Size <= 4) return (2 * Count);
                        if (Size >= 5 && Size <= 9) return (4 * Count);
                        return (8 * Count);
                    case "COMP-3":
                        return (((Size / 2) + 1) * Count); 
                    case "COMP-5":
                        if (Size >= 1 && Size <= 4) return (2 * Count);
                        if (Size >= 5 && Size <= 9) return (4 * Count);
                        return (8 * Count);
                    case "BIT":
                        return (Size * Count);
                    default:
                        return (Size * Count);
                }
            }
            return (Size * Count);
        }
    }
}
