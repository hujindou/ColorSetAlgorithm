﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsTool
{
    public class MessageId
    {
        public const String DEN00001_E = "DEN00001_E";
        public const String TSR00002_E = "入力ファイル読み込み処理に失敗しました。ファイル名：";
        public const String TSR00003_E = "シートのフォーマットは間違っています。";
        public const String TSR00004_E = "必須入力項目は記入していません。";
        public const String TSR00005_E = "要求応答区分は「E」又は「R」になっていないです。";
        public const String TSR00006_E = "ＩＦパターン番号は数字になっていないです。";
        public const String TSR00007_E = "物理ＩＤは物理Ｍパーサ情報テーブルに存在しません。";
        public const String TSR00008_E = "データベースにアクセスできません。";
        public const String TSR00009_E = "電文構成パターンの登録処理に失敗しました。";
        public const String TSR00010_I = "電文構成パターンの登録処理が完了しました。" + "\n" + "登録の状態についてはログファイルを確認してください。";
        public const String TSR00011_W = "対象電文構成パターン情報はＤＢに既に存在しています。当該電文構成パターン情報の登録をスキップします。";
        public const String TSR00012_E = "予期せぬエラーが発生しました。";
        public const String TSR00013_I = "電文構成パターン登録処理を開始します。";
        public const String TSR00014_I = "電文構成パターン登録処理が終了しました。";
        public const String TSR00015_E = "対象物理ＩＤは物理コビー句テーブルには存在しません。当該電文構成パターン情報の登録をスキップします。";
        public const String TSR00016_I = "対象電文構成パターン情報はＤＢに登録されました。";
        public const String TSR00017_E = "当該電文構成パターン情報に物理ＩＤはありません。当該電文構成パターン情報の登録をスキップします。";
    }
}
