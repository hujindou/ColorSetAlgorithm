﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace MarsTool.Common
{
    public class CommonConstant
    {
        public const string PHYSICAL_SH_TITLE = "ツール専用入力シート（電文構成パターン）";
        public const string SUB_SYS_ID = "対象サブシステムＩＤ";
        public const string SUBSYSID = "対象サブシステムＩＤ";
        public const string NO = "項番";
        public const string TEL_SUBSYS_ID = "相手サブシステムＩＤ";
        public const string REQUEST_CLS = "要求応答区分";
        public const string PATTERN_NO = "ＩＦパターン番号";
        public const string INFOGROUP_ID = "情報部グループＩＤ";
        public const string PHYSICAL_ID = "物理ＩＤ(1)";
        public const string PHYSICALID = "物理ＩＤ";
        public const string T_PHYPRS_TB = "t_phyprs";
        public const string COMMENT = "コメント";
        public const string ERROR = "E";
        public const string INFO = "I";
        public const string YOBI = "YOBI";
        public const string YOBI_NM = "予備";
        public const string ID = "1";
        public const string YB = "2";
        public const int SUBSYSID_LEN = 4;
        public const int TELSUBSYSID_LEN = 4;
        public const int TELTYPE_LEN = 1;
        public const int PATNO_LEN = 10;
        public const int GROUPID_LEN = 15;
        public const int PHYID_LEN = 15;
        public const int COMMENT_LEN = 60;
        public const int SUBSYSID_COL = 4;
        public const int COMMENT_COL = 2;
        public const int TELSUBSYSID_COL = 3;
        public const int TELTYPE_COL = 4;
        public const int PATNO_COL = 5;
        public const int GROUPID_COL = 6;
        public const int PHYID_START_COL = 7;
        public const string T_DENSTRB_TB = "t_denstrb";
        public const string T_DENSTRBITM_TB = "t_denstrbitm";
        public const string T_TMSEQUE = "t_tmseque";
        public const string T_DENSTRBITM_STR = "T_DENSTRBITM";
        public const string NO_STR = "、項番：";
        public const string SPACE = " ";
        public const string ERR_MSG = "エラー内容の詳細はログファイルに参照してください。";
    }
}
