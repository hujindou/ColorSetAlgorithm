﻿//-----------------------------------------------------------
// All Rights Reserved , Copyright (C) 2018, Hitachi , Ltd.
//-----------------------------------------------------------
using System;
using MarsTool.Common;
using MarsTool.Exceptions;
using MarsTool.Properties;

namespace MarsTool.Common
{
    /// <summary>
    /// KohoLogUtils Class<br/>
    /// ログユーティリティクラス<br/>
    /// To write log info.<br/>
    /// ログ情報を書き込む<br/>
    /// </summary>
    /// <remarks>
    /// 2018/03/14 新規作成<br/>
    /// </remarks>
    class KohoLogUtils
    {
        #region variable

        // Get logger
        // ロガーを取得
        //private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        #endregion

        #region public method

        ///// <summary>
        ///// Write LogInfo<br/>
        ///// ログファイルにログ情報を書き込む<br/>
        ///// </summary>
        ///// <param name="logInfo">
        ///// logInfo used to write log<br/>
        ///// ログに記録するため、logInfoを使用<br/>
        ///// </param>
        ///// <param name="msgCode">
        ///// msgCode used to write log<br/>
        ///// ログに記録するため、msgCodeを使用<br/>
        ///// </param>
        ///// <param name="errorExpection">
        ///// errorExpection used to write log<br/>
        ///// ログに記録するため、errorExpectionを使用<br/>
        ///// </param>
        ///// <exception cref="CodeCadidateRegException">
        ///// Throw exception if exception occurs at writing logInfo.<br/>
        ///// ログ情報を書き込む時に例外が発生した場合、例外をスローする<br/>
        ///// </exception>
        ///// <remarks>
        ///// 2018/03/14 新規作成<br/>
        ///// </remarks>
        //public static void WriteLogInfo(string logInfo, String msgCode, Exception errorExpection)
        //{
        //    try
        //    {
        //        log.Info(System.DateTime.Now.ToString(ConstantUtils.DATETIMEFORMAT) + " " + msgCode + " " + logInfo, errorExpection);
        //    }
        //    catch (Exception e)
        //    {
        //        //Throw Error SCT00099-E
        //        //SCT00099-E　エラーをスロー
        //        throw new CodeCadidateRegException(KohoLogUtils.GetMsgInfo(Resources.CVR00099_E, e.Message), e);
        //    }
        //}

        ///// <summary>
        ///// ログ情報の記録<br/>
        ///// Write LogInfo<br/>
        ///// ログファイルにログ情報を書き込む<br/>
        ///// </summary>
        ///// <param name="logInfo">
        ///// logInfo used to write log<br/>
        ///// ログに記録するため、logInfoを使用<br/>
        ///// </param>
        ///// <param name="msgCode">
        ///// msgCode used to write log<br/>
        ///// ログに記録するため、msgCodeを使用<br/>
        ///// </param>
        ///// <exception cref="CodeCadidateRegException">
        ///// Throw exception if exception occurs at writing logInfo.<br/>
        ///// ログ情報を書き込んでいる時に例外が発生した場合、例外をスロー<br/>
        ///// </exception>
        ///// <remarks>
        ///// 2018/03/14 新規作成<br/>
        ///// </remarks>
        //public static void WriteLogInfo(string logInfo, String msgCode)
        //{
        //    try
        //    {
        //        log.Info(System.DateTime.Now.ToString(ConstantUtils.DATETIMEFORMAT) + " " + msgCode + " " + logInfo);
        //    }
        //    catch (Exception e)
        //    {
        //        //Throw Error SCT00099-E
        //        //SCT00099-E　エラーをスロー
        //        throw new CodeCadidateRegException(KohoLogUtils.GetMsgInfo(Resources.CVR00099_E, e.Message), e);
        //    }
        //}

        ///// <summary>
        ///// ログ情報メッセージフォーマット<br/>
        ///// Format Log Info Message<br/>
        ///// </summary>
        ///// <param name="getMsgValue">
        ///// getMsgValue used to get message.<br/>
        ///// メッセージを取得するため、getMsgValueを使用<br/>
        ///// </param>
        ///// <param name="param">
        ///// param used to replace parameter value of log message.<br/>
        ///// ログメッセージのパラメータ値を置き換えるため、パラメータを使用<br/>
        ///// </param>
        ///// <returns>
        ///// Return formatted log message.<br/>
        ///// フォーメットしたログメッセージを返却<br/>
        ///// </returns>
        ///// <remarks>
        ///// 2018/03/14 新規作成<br/>
        ///// </remarks>
        //public static string GetMsgInfo(string getMsgValue, params string[] param)
        //{
        //    return String.Format(getMsgValue, param);
        //}

        #endregion
    }
}
