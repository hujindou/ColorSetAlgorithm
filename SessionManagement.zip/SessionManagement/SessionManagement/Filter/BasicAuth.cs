﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SessionManagement.Filter
{
    public class BasicAuth : ActionFilterAttribute
    {
        public string BasicRealm { get; set; }
        protected string Username { get; set; }
        protected string Password { get; set; }

        public BasicAuth(string username, string password)
        {
            this.Username = username;
            this.Password = password;
        }

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var req = filterContext.HttpContext.Request;
            var auth = req.Headers["Authorization"];
            if (!String.IsNullOrEmpty(auth))
            {
                var cred = System.Text.ASCIIEncoding.ASCII.GetString(Convert.FromBase64String(auth.Substring(6))).Split(':');
                var user = new { Name = cred[0], Pass = cred[1] };

                var config = System.Configuration.ConfigurationManager.GetSection("userConfig") as SessionManagement.Models.UserConfig;
                if (config != null && config.SessionLogAdmins != null)
                {
                    var res = from SessionManagement.Models.UserElement tmp in config.SessionLogAdmins
                              select new { U = tmp.Username, P = tmp.Password };
                    if(res.Any(r => user.Name.Equals(r.U) && user.Pass.Equals(r.P))) return;
                }
            }
            filterContext.HttpContext.Response.AddHeader("WWW-Authenticate", String.Format("Basic realm=\"{0}\"", BasicRealm ?? "PASCO"));
            filterContext.Result = new HttpUnauthorizedResult();
        }
    }
}