﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SessionManagement.Models;
using SessionManagement.Filter;

namespace SessionManagement.Controllers
{
    public class HomeController : Controller
    {
        protected override void OnException(ExceptionContext filterContext)
        {
            Exception ex = filterContext.Exception;
            filterContext.ExceptionHandled = true;

            var model = new HandleErrorInfo(filterContext.Exception, "Controller", "Action");

            filterContext.Result = new ContentResult() { Content = "<h1>エラーが発生しました。</h1>", ContentEncoding = System.Text.Encoding.UTF8 };

        }

        private dbEntity db = new dbEntity();

        public ActionResult Index()
        {
            return RedirectToAction("Main");
            //return Content("Index Page");
            
            //if (String.IsNullOrEmpty(Session["username"] as string))
            //{
            //    Response.AddHeader("WWW-Authenticate", @" Basic realm=""Access to the staging site"", charset=""UTF-8""");
            //    return new HttpUnauthorizedResult();
            //}
            //else
            //{
            //    return RedirectToAction("Main");
            //}
        }

        [BasicAuth("pasco", "pasco", BasicRealm = "Login Please")]
        public ActionResult Main()
        {
            return View();
            //if (String.IsNullOrEmpty(Session["username"] as string))
            //{
            //    return RedirectToAction("Index");
            //}
            //else
            //{
            //    return View();
            //}
        }

        [ValidateInput(false)]
        [HttpPost]
        public ActionResult Login(string username, string password)
        {
            return RedirectToAction("Main");
            //if ("pasco".Equals(username, StringComparison.OrdinalIgnoreCase) && "pasco".Equals(password, StringComparison.OrdinalIgnoreCase))
            //{
            //    Session["username"] = "pasco";
            //    return RedirectToAction("Main");
            //}
            //else
            //{
            //    return RedirectToAction("Index");
            //}
        }

        [HttpGet]
        public ActionResult Login()
        {
            return RedirectToAction("Main");
            //if (String.IsNullOrEmpty(Session["username"] as string))
            //{
            //    return RedirectToAction("Index");
            //}
            //else
            //{
            //    return RedirectToAction("Main");
            //}
        }

        [BasicAuth("pasco", "pasco", BasicRealm = "Login Please")]
        public ActionResult QuerySession(int? requestPage, int? currentPage, string startDate, string endDate, string accountID)
        {
            if (!Request.IsAjaxRequest())
            {
                return Content("<h1>セッション管理画面にて操作お願いします。</h1>");
            }
            ViewModelQuerySession m = queryData(requestPage, startDate, endDate, accountID);
            return PartialView(m);
            
            //if (String.IsNullOrEmpty(Session["username"] as string))
            //{
            //    return Content("<h1>タイマーアウト！ログインお願いします。</h1>");
            //}
            //else
            //{
            //    if (!Request.IsAjaxRequest())
            //    {
            //        return Content("<h1>セッション管理画面にて操作お願いします。</h1>");
            //    }
            //    ViewModelQuerySession m = queryData(requestPage, startDate, endDate, accountID);
            //    return PartialView(m);
            //}
        }

        private ViewModelQuerySession queryData(int? requestPage, string startDate, string endDate, string accountID)
        {
            ViewModelQuerySession m = new ViewModelQuerySession();
            m.PageList = new List<int>();
            m.PageContent = null;
            int pgPerPage = 50;

            m.CountPerPage = pgPerPage;
            DateTime dt1;
            if (DateTime.TryParse(startDate, out dt1))
            {
                m.PageContent = db.SESSION_KNR.Where(r => r.YUUKOU_KIGEN >= dt1).ToList();
            }
            DateTime dt2;
            if (DateTime.TryParse(endDate, out dt2))
            {
                if (m.PageContent == null)
                    m.PageContent = db.SESSION_KNR.Where(r => r.YUUKOU_KIGEN <= dt2).ToList();
                else
                    m.PageContent = m.PageContent.Where(r => r.YUUKOU_KIGEN <= dt2).ToList();
            }
            if (!String.IsNullOrEmpty(accountID))
            {
                if (m.PageContent == null)
                    m.PageContent = db.SESSION_KNR.Where(r => r.ACCOUNT_ID.Contains(accountID)).ToList();
                else
                    m.PageContent = m.PageContent.Where(r => r.ACCOUNT_ID.Contains(accountID)).ToList();
            }

            //initial request or next/previous page request
            if (requestPage == null)
            {
                if (m.PageContent == null)
                {
                    m.TotalResultCount = db.SESSION_KNR.Count();
                    m.PageContent = db.SESSION_KNR.OrderByDescending(r => r.YUUKOU_KIGEN).Take(pgPerPage).ToList();
                }
                else
                {
                    m.TotalResultCount = m.PageContent.Count;
                    m.PageContent = m.PageContent.OrderByDescending(r => r.YUUKOU_KIGEN).Take(pgPerPage).ToList();
                }
            }
            else
            {
                if (m.PageContent == null)
                {
                    m.TotalResultCount = db.SESSION_KNR.Count();
                    if (db.SESSION_KNR.OrderByDescending(r => r.YUUKOU_KIGEN).Skip((requestPage.Value - 1) * 50).Count() < 1 && requestPage.Value - 2 > -1)
                    {
                        m.PageContent = db.SESSION_KNR.OrderByDescending(r => r.YUUKOU_KIGEN).Skip((requestPage.Value - 2) * 50).Take(pgPerPage).ToList();
                    }
                    else
                        m.PageContent = db.SESSION_KNR.OrderByDescending(r => r.YUUKOU_KIGEN).Skip((requestPage.Value - 1) * 50).Take(pgPerPage).ToList();
                }
                else
                {
                    m.TotalResultCount = m.PageContent.Count;
                    if (m.PageContent.OrderByDescending(r => r.YUUKOU_KIGEN).Skip((requestPage.Value - 1) * 50).Count() < 1 && requestPage.Value - 2 > -1)
                        m.PageContent = m.PageContent.OrderByDescending(r => r.YUUKOU_KIGEN).Skip((requestPage.Value - 2) * 50).Take(pgPerPage).ToList();
                    else
                        m.PageContent = m.PageContent.OrderByDescending(r => r.YUUKOU_KIGEN).Skip((requestPage.Value - 1) * 50).Take(pgPerPage).ToList();
                }
            }


            int x = m.TotalResultCount / 50;
            int y = m.TotalResultCount % 50;
            if (y != 0) x++;
            if (requestPage == null)
            {
                m.StartTagClickable = false;
                foreach (var tmp in Enumerable.Range(1, (x <= 9 ? x : 9)))
                {
                    m.PageList.Add(tmp);
                    m.CurrentPageNumber = 1;
                }
            }
            else
            {
                if (requestPage.Value == 1)
                    m.StartTagClickable = false;
                else
                    m.StartTagClickable = true;
                if (requestPage.Value >= x)
                {
                    requestPage = x;
                    m.EndTagClickable = false;
                }
                else
                    m.EndTagClickable = true;
                if (x <= 9)
                {
                    foreach (var tmp in Enumerable.Range(1, x))
                    {
                        m.PageList.Add(tmp);
                        m.CurrentPageNumber = requestPage.Value;
                    }
                }
                else
                {
                    if (requestPage.Value - 4 >= 1 && requestPage.Value + 4 <= x)
                    {
                        m.PageList.Add(requestPage.Value - 4);
                        m.PageList.Add(requestPage.Value - 3);
                        m.PageList.Add(requestPage.Value - 2);
                        m.PageList.Add(requestPage.Value - 1);
                        m.PageList.Add(requestPage.Value);
                        m.PageList.Add(requestPage.Value + 1);
                        m.PageList.Add(requestPage.Value + 2);
                        m.PageList.Add(requestPage.Value + 3);
                        m.PageList.Add(requestPage.Value + 4);
                        m.CurrentPageNumber = requestPage.Value;
                    }
                    else if (requestPage.Value - 4 < 1)
                    {
                        for (int ii = requestPage.Value - 4; ii < 20; ii++)
                        {
                            if (ii >= 1 && m.PageList.Count < 9)
                                m.PageList.Add(ii);
                        }
                        m.CurrentPageNumber = requestPage.Value;
                    }
                    else
                    {
                        for (int ii = x - 8; ii <= x; ii++)
                        {
                            if (ii >= 1 && m.PageList.Count < 9)
                                m.PageList.Add(ii);
                        }
                        m.CurrentPageNumber = requestPage.Value;
                    }
                }

            }
            return m;
        }

        [ValidateInput(false)]
        [BasicAuth("pasco", "pasco", BasicRealm = "Login Please")]
        public ActionResult Delete(string sessionId, int? requestPage, string startDate, string endDate, string accountID)
        {
            if (!Request.IsAjaxRequest())
            {
                return Content("<h1>セッション管理画面にて操作お願いします。</h1>");
            }

            var res = db.SESSION_KNR.FirstOrDefault(r => r.SESSION_ID == sessionId);

            if (res != null)
            {
                db.SESSION_KNR.Remove(res);
                db.SaveChanges();
            }

            ViewModelQuerySession m = queryData(requestPage, startDate, endDate, accountID);

            return PartialView("QuerySession", m);

            //if (String.IsNullOrEmpty(Session["username"] as string))
            //{
            //    return Content("<h1>タイマーアウト！ログインお願いします。</h1>");
            //}
            //else
            //{
            //    if (!Request.IsAjaxRequest())
            //    {
            //        return Content("<h1>セッション管理画面にて操作お願いします。</h1>");
            //    }

            //    var res = db.SESSION_KNR.FirstOrDefault(r => r.SESSION_ID == sessionId);

            //    if (res != null)
            //    {
            //        db.SESSION_KNR.Remove(res);
            //        db.SaveChanges();
            //    }

            //    ViewModelQuerySession m = queryData(requestPage, startDate, endDate, accountID);

            //    return PartialView("QuerySession", m);
            //}
        }
    }
}
