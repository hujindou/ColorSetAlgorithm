﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SessionManagement.Filter;
using SessionManagement.Models;

namespace SessionManagement.Controllers
{
    public class LogController : Controller
    {
        protected override void OnException(ExceptionContext filterContext)
        {
            Exception ex = filterContext.Exception;
            filterContext.ExceptionHandled = true;

            var model = new HandleErrorInfo(filterContext.Exception, "Controller", "Action");

            filterContext.Result = new ContentResult() { Content = "<h1>エラーが発生しました。</h1>", ContentEncoding = System.Text.Encoding.UTF8 };

        }
        //
        // GET: /Log/

        private dbEntity db = new dbEntity();

        [BasicAuth("pasco", "pasco", BasicRealm = "Login Please")]
        public ActionResult Main()
        {  
            return View();
        }

        [ValidateInput(false)]
        [BasicAuth("pasco", "pasco", BasicRealm = "Login Please")]
        public ActionResult Detail(string logid)
        {
            int id = -1;
            if (int.TryParse(logid, out id))
            {
                var res = db.OPERATION_LOG.AsNoTracking().FirstOrDefault(r => r.LOG_ID == id);
                if (res == null)
                {
                    return View("Error1");
                }
                else
                {
                    return View(res);
                }
            }

            return View("Error1");
        }

        [ValidateInput(false)]
        [BasicAuth("pasco", "pasco", BasicRealm = "Login Please")]
        public ActionResult QueryLog(int? requestPage, int? currentPage, string startDate, string endDate, string accountID)
        {
            if (!Request.IsAjaxRequest())
            {
                return Content("<h1>セッション管理画面にて操作お願いします。</h1>");
            }
            ViewModelQueryLog m = queryData(requestPage, startDate, endDate, accountID);
            return PartialView(m);
        }

        private ViewModelQueryLog queryData(int? requestPage, string startDate, string endDate, string accountID)
        {
            ViewModelQueryLog m = new ViewModelQueryLog();
            m.PageList = new List<int>();
            m.PageContent = null;
            int pgPerPage = 50;

            m.CountPerPage = pgPerPage;

            //calculate page data with query conditions
            DateTime dt1;
            if (DateTime.TryParse(startDate, out dt1))
            {
                m.PageContent = db.OPERATION_LOG.Where(r => r.UPDDATE >= dt1).ToList();
            }
            DateTime dt2;
            if (DateTime.TryParse(endDate, out dt2))
            {
                if (m.PageContent == null)
                    m.PageContent = db.OPERATION_LOG.Where(r => r.UPDDATE <= dt2).ToList();
                else
                    m.PageContent = m.PageContent.Where(r => r.UPDDATE <= dt2).ToList();
            }
            if (!String.IsNullOrEmpty(accountID))
            {
                if (m.PageContent == null)
                    m.PageContent = db.OPERATION_LOG.Where(r => r.ACCOUNT_ID.Contains(accountID)).ToList();
                else
                    m.PageContent = m.PageContent.Where(r => r.ACCOUNT_ID.Contains(accountID)).ToList();
            }
            if (requestPage == null)
            {
                if (m.PageContent == null)
                {
                    m.TotalResultCount = db.SESSION_KNR.Count();
                    m.PageContent = db.OPERATION_LOG.OrderByDescending(r => r.UPDDATE).Take(pgPerPage).ToList();
                }
                else
                {
                    m.TotalResultCount = m.PageContent.Count;
                    m.PageContent = m.PageContent.OrderByDescending(r => r.UPDDATE).Take(pgPerPage).ToList();
                }
            }
            else
            {
                if (m.PageContent == null)
                {
                    m.TotalResultCount = db.SESSION_KNR.Count();
                    if (db.SESSION_KNR.OrderByDescending(r => r.YUUKOU_KIGEN).Skip((requestPage.Value - 1) * 50).Count() < 1 && requestPage.Value - 2 > -1)
                    {
                        m.PageContent = db.OPERATION_LOG.OrderByDescending(r => r.UPDDATE).Skip((requestPage.Value - 2) * 50).Take(pgPerPage).ToList();
                    }
                    else
                        m.PageContent = db.OPERATION_LOG.OrderByDescending(r => r.UPDDATE).Skip((requestPage.Value - 1) * 50).Take(pgPerPage).ToList();
                }
                else
                {
                    m.TotalResultCount = m.PageContent.Count;
                    if (m.PageContent.OrderByDescending(r => r.UPDDATE).Skip((requestPage.Value - 1) * 50).Count() < 1 && requestPage.Value - 2 > -1)
                        m.PageContent = m.PageContent.OrderByDescending(r => r.UPDDATE).Skip((requestPage.Value - 2) * 50).Take(pgPerPage).ToList();
                    else
                        m.PageContent = m.PageContent.OrderByDescending(r => r.UPDDATE).Skip((requestPage.Value - 1) * 50).Take(pgPerPage).ToList();
                }
            }


            //calculate nav links
            int x = m.TotalResultCount / 50;
            int y = m.TotalResultCount % 50;
            if (y != 0) x++;
            if (requestPage == null)
            {
                m.StartTagClickable = false;
                foreach (var tmp in Enumerable.Range(1, (x <= 9 ? x : 9)))
                {
                    m.PageList.Add(tmp);
                    m.CurrentPageNumber = 1;
                }
            }
            else
            {
                if (requestPage.Value == 1)
                    m.StartTagClickable = false;
                else
                    m.StartTagClickable = true;
                if (requestPage.Value >= x)
                {
                    requestPage = x;
                    m.EndTagClickable = false;
                }
                else
                    m.EndTagClickable = true;
                if (x <= 9)
                {
                    foreach (var tmp in Enumerable.Range(1, x))
                    {
                        m.PageList.Add(tmp);
                        m.CurrentPageNumber = requestPage.Value;
                    }
                }
                else
                {
                    if (requestPage.Value - 4 >= 1 && requestPage.Value + 4 <= x)
                    {
                        m.PageList.Add(requestPage.Value - 4);
                        m.PageList.Add(requestPage.Value - 3);
                        m.PageList.Add(requestPage.Value - 2);
                        m.PageList.Add(requestPage.Value - 1);
                        m.PageList.Add(requestPage.Value);
                        m.PageList.Add(requestPage.Value + 1);
                        m.PageList.Add(requestPage.Value + 2);
                        m.PageList.Add(requestPage.Value + 3);
                        m.PageList.Add(requestPage.Value + 4);
                        m.CurrentPageNumber = requestPage.Value;
                    }
                    else if (requestPage.Value - 4 < 1)
                    {
                        for (int ii = requestPage.Value - 4; ii < 20; ii++)
                        {
                            if (ii >= 1 && m.PageList.Count < 9)
                                m.PageList.Add(ii);
                        }
                        m.CurrentPageNumber = requestPage.Value;
                    }
                    else
                    {
                        for (int ii = x - 8; ii <= x; ii++)
                        {
                            if (ii >= 1 && m.PageList.Count < 9)
                                m.PageList.Add(ii);
                        }
                        m.CurrentPageNumber = requestPage.Value;
                    }
                }

            }
            return m;
        }

    }
}
