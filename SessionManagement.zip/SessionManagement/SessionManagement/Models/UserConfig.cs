﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace SessionManagement.Models
{
    public class UserConfig : ConfigurationSection
    {
        [ConfigurationProperty("SessionLogAdmins")]
        public UserElementCollection SessionLogAdmins
        {
            get { return base["SessionLogAdmins"] as UserElementCollection; }
            set { base["SessionLogAdmins"] = value; }
        }
    }

    public class UserElement : ConfigurationElement
    {
        [ConfigurationProperty("username", IsRequired = true)]
        public string Username
        {
            get { return (string)base["username"]; }
            set { base["username"] = value; }
        }

        [ConfigurationProperty("password", IsRequired = true)]
        public string Password
        {
            get { return (string)base["password"]; }
            set { base["password"] = value; }
        }
    }

    public class UserElementCollection : ConfigurationElementCollection
    {
        protected override ConfigurationElement CreateNewElement()
        {
            UserElement newElement = new UserElement();
            return newElement;
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((UserElement)element).Username;
        }
    }
}