﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SessionManagement.Models
{
    public class ViewModelQueryLog
    {
        public int TotalResultCount { get; set; }
        public int CountPerPage { get; set; }
        public bool StartTagClickable { get; set; }
        public bool EndTagClickable { get; set; }
        public int CurrentPageNumber { get; set; }
        public List<OPERATION_LOG> PageContent { get; set; }
        public List<int> PageList { get; set; }
    }
}