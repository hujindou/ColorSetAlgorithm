﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;

namespace SessionManagement.Models
{
    public class dbEntity : System.Data.Entity.DbContext
    {
        public dbEntity()
            : base("name=dbContext")
        {
        }

        public virtual DbSet<SESSION_KNR> SESSION_KNR { get; set; }
        public virtual DbSet<OPERATION_LOG> OPERATION_LOG { get; set; }

        protected override void OnModelCreating(System.Data.Entity.DbModelBuilder modelBuilder)
        {
            if (!String.IsNullOrWhiteSpace(System.Configuration.ConfigurationManager.AppSettings["SessionTableName"]))
                modelBuilder.Entity<SESSION_KNR>().ToTable(System.Configuration.ConfigurationManager.AppSettings["SessionTableName"]);
            if (!String.IsNullOrWhiteSpace(System.Configuration.ConfigurationManager.AppSettings["LogTableName"]))
                modelBuilder.Entity<OPERATION_LOG>().ToTable(System.Configuration.ConfigurationManager.AppSettings["LogTableName"]);
        }
    }

    public class SESSION_KNR
    {
        [Key]
        public string SESSION_ID { get; set; }
        public string ACCOUNT_ID { get; set; }
        public DateTime YUUKOU_KIGEN { get; set; }
        public DateTime UPDDATE { get; set; }
    }

    public class OPERATION_LOG
    {
        [Key]
        public long LOG_ID { get; set; }
        public string SESSION_ID { get; set; }
        public string ACCOUNT_ID { get; set; }
        public string LOG_TYPE { get; set; }
        public Decimal? MAP_ID { get; set; }
        public string LOG_DETAIL { get; set; }
        public DateTime UPDDATE { get; set; }
    }
}