﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SessionManagement.Models
{
    public class ViewModelQuerySession
    {
        public int TotalResultCount { get; set; }
        public int CountPerPage { get; set; }
        public bool StartTagClickable { get; set; }
        public bool EndTagClickable { get; set; }
        public int CurrentPageNumber { get; set; }
        public List<SESSION_KNR> PageContent { get; set; }
        public List<int> PageList { get; set; }
    }
}