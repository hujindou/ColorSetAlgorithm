﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.jndatagridview.Rows.Clear();
            this.jndatagridview.Refresh();
            using (var context = new JN_Tool.Models.DB.mysqlcontext())
            {
                var res = context.JNPattern.Where(r => r.JN_CUPID != null);
                if (res != null)
                {
                    foreach (var tmp in res)
                    {
                        this.jndatagridview.Rows.Add(tmp.JN_PATTERNID, tmp.JN_PATTERNNO, tmp.JN_CUPID, tmp.JN_TYPE);
                    }
                }
            }
        }

        private void dbc(object sender, DataGridViewCellEventArgs e)
        {
            JN_Tool.MForm f = new JN_Tool.MForm((int)this.jndatagridview.Rows[e.RowIndex].Cells[0].Value);
            f.ShowDialog();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            this.jndatagridview.CellDoubleClick += dbc;
        }

        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {
            this.label17.Enabled = true;
            this.textBox11.Enabled = true;
            this.label13.Enabled = false;
            this.textBox10.Enabled = false;
        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            this.label17.Enabled = false;
            this.textBox11.Enabled = false;
            this.label13.Enabled = true;
            this.textBox10.Enabled = true;
        }

    }

}
