﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JN_Tool.Models
{
    public class JNInfoBlock
    {
        public int JN_PATTERNID { get; set; }
        public string JN_INTERFACEID { get; set; }

        /// <summary>
        /// インタフェーステーブルに存在しない情報部
        /// システムにて定義する情報部の名前
        /// </summary>
        public string JN_NAME { get; set; }
        /// <summary>
        /// インタフェーステーブルに存在しない情報部
        /// システムにて定義する情報部のサイズ
        /// </summary>
        public int? JN_SIZE { get; set; }

        public int JN_ORDER { get; set; }

        /// <summary>
        /// 要求/回答
        /// </summary>
        public string JN_REQRESFLG { get; set; }

        /// <summary>
        /// 区間１、区間２、先乗列車など
        /// </summary>
        public string JN_PROPERTY2 { get; set; }

        /// <summary>
        /// 予約/解約
        /// JN_PROPERTY4と同時に設定されたら、エラー
        /// </summary>
        public string JN_PROPERTY3 { get; set; }

        /// <summary>
        /// 変更前/変更後
        /// JN_PROPERTY3と同時に設定されたら、エラー
        /// </summary>
        public string JN_PROPERTY4 { get; set; }

        /// <summary>
        /// 重複設定
        /// </summary>
        public string JN_PROPERTY5 { get; set; }

        /// <summary>
        /// 稀のパターンのための属性
        /// </summary>
        public string JN_PROPERTY6 { get; set; }
        public string JN_PROPERTY7 { get; set; }

        /// <summary>
        /// 世代管理ID
        /// </summary>
        public string TMCPK_DEVID { get; set; }
    }
}
