﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JN_Tool.Models
{
    public class JNPattern
    {
        public int? JN_PATTERNID { get; set; }
        public string JN_PATTERNNO { get; set; }

        public string JN_CUPID { get; set; }

        /// <summary>
        /// 券種別
        /// </summary>
        public string JN_TYPE { get; set; }

        /// <summary>
        /// 操作種別
        /// </summary>
        public string JN_OPTYPE { get; set; }


        public string JN_ANS { get; set; }

        /// <summary>
        /// 記事
        /// </summary>
        public string JN_COMMNENT { get; set; }

        public virtual List<JNInfoBlock> JN_INFOBLOCKS { get; set; }
    }
}
