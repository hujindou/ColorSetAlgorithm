﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JN_Tool.Models.DB
{
    [Table("Interface")]
    public class InterfaceShort
    {
        /// <summary>
        /// 開発ID
        /// </summary>
        [Key]
        [Column(Order = 0)]
        public string TMCPK_DEVID { get; set; }

        /// <summary>
        /// １．アイテム説明書の場合、空白にする。
        /// ２．コピー句の場合、コピー句ファイル名を格納する。
        /// ３．専用シートの場合、コピー句ＩＤを格納する。
        /// </summary>
        [Key]
        [Column(Order = 1)]
        public string TMCPK_BCPID { get; set; }

        /// <summary>
        /// １．アイテム説明書の場合、一番目アイテム名称を格納する。
        /// ２．コピー句の場合、トップアイテム名称を格納する。
        /// ３．専用シートの場合、コピー句名を格納する。
        /// </summary>
        public string TMCPK_BCPNM { get; set; }

        /// <summary>
        /// １．アイテム説明書の場合、一番目アイテムの「ﾃﾞｰﾀ長」を格納する
        /// ２．その以外の場合、メンバのサイズを合計する
        /// </summary>
        public int TMCPK_SIZE { get; set; }

    }
}
