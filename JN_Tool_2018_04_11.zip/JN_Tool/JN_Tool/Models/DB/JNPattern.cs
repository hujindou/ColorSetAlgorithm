namespace JN_Tool.Models.DB
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("JNPattern")]
    public partial class JNPattern
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int JN_PATTERNID { get; set; }

        [StringLength(16)]
        public string JN_PATTERNNO { get; set; }

        [StringLength(16)]
        public string JN_CUPID { get; set; }

        [StringLength(256)]
        public string JN_TYPE { get; set; }

        [StringLength(2048)]
        public string JN_OPTYPE { get; set; }

        [StringLength(16)]
        public string JN_ANS { get; set; }

        [StringLength(2048)]
        public string JN_COMMNENT { get; set; }

        public virtual ICollection<JNInfoBlock> JN_INFOBLOCKS { get; set; }

        public static implicit operator JNPattern(Models.JNPattern v)
        {
            JNPattern res = new JNPattern();
            res.JN_ANS = v.JN_ANS;
            res.JN_COMMNENT = v.JN_COMMNENT;
            res.JN_CUPID = v.JN_CUPID;
            res.JN_OPTYPE = v.JN_OPTYPE;
            res.JN_PATTERNNO = v.JN_PATTERNNO;
            res.JN_TYPE = v.JN_TYPE;
            res.JN_PATTERNID = v.JN_PATTERNID.Value;
            res.JN_INFOBLOCKS = new List<JNInfoBlock>();
            int i = 0;
            foreach (var xx in v.JN_INFOBLOCKS)
            {
                i++;
                //
                xx.JN_PATTERNID = v.JN_PATTERNID.Value;
                JNInfoBlock yy = xx;
                //���Ԃ�����
                yy.JN_ORDER = i;
                res.JN_INFOBLOCKS.Add(yy);
            }
                
            return res;
        }
    }
}
