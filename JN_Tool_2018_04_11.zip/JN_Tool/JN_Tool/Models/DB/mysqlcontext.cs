﻿using MySql.Data.Entity;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JN_Tool.Models.DB
{
    [DbConfigurationType(typeof(MySqlEFConfiguration))]
    class mysqlcontext : DbContext
    {
        public mysqlcontext()
            : base("name=mysqldb")
        {
        }

        public virtual DbSet<JNInfoBlock> JNInfoBlock { get; set; }
        public virtual DbSet<JNPattern> JNPattern { get; set; }

        public virtual DbSet<InterfaceShort> Interface { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<JNInfoBlock>()
                .Property(e => e.JN_INTERFACEID)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<JNPattern>().HasMany<JNInfoBlock>(e => e.JN_INFOBLOCKS);

        }
    }
}
