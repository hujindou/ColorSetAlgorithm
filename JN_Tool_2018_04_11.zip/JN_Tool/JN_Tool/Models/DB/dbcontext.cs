namespace JN_Tool.Models.DB
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class dbcontext : DbContext
    {
        public dbcontext()
            : base("name=dbcontext")
        {
            
        }

        public virtual DbSet<JNInfoBlock> JNInfoBlock { get; set; }
        public virtual DbSet<JNPattern> JNPattern { get; set; }

        public virtual DbSet<InterfaceShort> Interface { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<JNInfoBlock>()
                .Property(e => e.JN_INTERFACEID)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<JNPattern>().HasMany<JNInfoBlock>( e => e.JN_INFOBLOCKS);

        }
    }
}
