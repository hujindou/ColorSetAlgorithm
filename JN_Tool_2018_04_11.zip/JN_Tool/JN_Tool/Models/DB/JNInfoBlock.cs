namespace JN_Tool.Models.DB
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("JNInfoBlock")]
    public partial class JNInfoBlock
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int JN_PATTERNID { get; set; }

        [Required]
        [StringLength(10)]
        public string JN_INTERFACEID { get; set; }

        /// <summary>
        /// �J��ID
        /// </summary>
        public string TMCPK_DEVID { get; set; }

        [StringLength(64)]
        public string JN_NAME { get; set; }

        public int? JN_SIZE { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int JN_ORDER { get; set; }

        [StringLength(64)]
        public string JN_REQRESFLG { get; set; }

        [StringLength(64)]
        public string JN_PROPERTY1 { get; set; }

        [StringLength(64)]
        public string JN_PROPERTY2 { get; set; }

        [StringLength(64)]
        public string JN_PROPERTY3 { get; set; }

        [StringLength(64)]
        public string JN_PROPERTY4 { get; set; }

        [StringLength(64)]
        public string JN_PROPERTY5 { get; set; }

        [StringLength(64)]
        public string JN_PROPERTY6 { get; set; }

        [StringLength(64)]
        public string JN_PROPERTY7 { get; set; }

        public virtual JNPattern JN_Pattern { get; set; }

        public static implicit operator JNInfoBlock(Models.JNInfoBlock v)
        {
            JNInfoBlock res = new JNInfoBlock();
            res.JN_NAME = v.JN_NAME;
            res.JN_SIZE = v.JN_SIZE;
            res.TMCPK_DEVID = v.TMCPK_DEVID;
            res.JN_PATTERNID = v.JN_PATTERNID;
            res.JN_PROPERTY2 = v.JN_PROPERTY2;
            res.JN_PROPERTY3 = v.JN_PROPERTY3;
            res.JN_PROPERTY4 = v.JN_PROPERTY4;
            res.JN_PROPERTY5 = v.JN_PROPERTY5;
            res.JN_PROPERTY6 = v.JN_PROPERTY6;
            res.JN_PROPERTY7 = v.JN_PROPERTY7;
            res.JN_REQRESFLG = v.JN_REQRESFLG;
            res.JN_INTERFACEID = v.JN_INTERFACEID;
            return res;
        }
    }
}
