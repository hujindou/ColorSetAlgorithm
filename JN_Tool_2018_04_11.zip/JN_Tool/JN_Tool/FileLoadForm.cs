﻿using JN_Tool.LGC;
using JN_Tool.Models;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace JN_Tool
{
    public partial class FileLoadForm : Form
    {
        public FileLoadForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 1 - 5はヘッダ
        /// 6行以降は入力内容
        /// </summary>
        private const int startRow = 6;

        private NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        private void button2_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrWhiteSpace(this.textBox1.Text))
            {
                MessageBox.Show("ジャーナル専用入力シートを選択してください", "注意", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            this.button2.Enabled = false;

            //read xlsx
            List<JNPattern> alldata = null;

            try
            {
                alldata = readExcel(this.textBox1.Text);
            }
            catch(Exception exp)
            {
                //
                logger.Error(exp, "存在しないか破損か、対象ファイルは読み込みできません。");
                MessageBox.Show("存在しないか破損か、対象ファイルは読み込みできません。");
                return;
            }

            //check excel data
            if (alldata.Count > 0)
            {
                //Excel Data Check

                Regex reg2 = new Regex(@"\*MAX\([1-9][0-9]*\)");
                Regex reg = new Regex(@"MAX\([1-9][0-9]*\)");
                //var tmpmatch = reg.Match("asdfsdf*MAX(1000)asdfs");
                //MessageBox.Show("[" + tmpmatch.Value + "]");

                for (int i = 0; i < alldata.Count; i++)
                {
                    if(String.IsNullOrWhiteSpace(alldata[i].JN_CUPID))
                    {
                        //
                        MessageBox.Show($"");
                    }
                    if (String.IsNullOrWhiteSpace(alldata[i].JN_PATTERNNO))
                    {
                        //
                    }
                    if (String.IsNullOrWhiteSpace(alldata[i].JN_ANS))
                    {
                        //
                    }
                    if (String.IsNullOrWhiteSpace(alldata[i].JN_OPTYPE))
                    {
                        //
                    }
                    foreach (var tmp in alldata[i].JN_INFOBLOCKS)
                    {
                        //要求/回答設定
                        switch (tmp.JN_REQRESFLG)
                        {
                            case var o when String.IsNullOrWhiteSpace(o):
                                tmp.JN_REQRESFLG = "";
                                break;

                            case var o when o.Contains("要求"):
                                tmp.JN_REQRESFLG = "要求";
                                break;

                            case var o when o.Contains("回答"):
                                tmp.JN_REQRESFLG = "回答";
                                break;

                            default:
                                tmp.JN_REQRESFLG = "";
                                break;
                        }
                        //要求/回答以外の設定
                        if (String.IsNullOrWhiteSpace(tmp.JN_PROPERTY2))
                        {
                            tmp.JN_PROPERTY2 = "";
                            tmp.JN_PROPERTY3 = "";
                            tmp.JN_PROPERTY4 = "";
                            tmp.JN_PROPERTY5 = "";
                            tmp.JN_PROPERTY6 = "";
                            tmp.JN_PROPERTY7 = "";
                        }
                        else
                        {
                            if (tmp.JN_PROPERTY2.Contains("予約"))
                            {
                                tmp.JN_PROPERTY2 = tmp.JN_PROPERTY2.Replace("予約", "");
                                tmp.JN_PROPERTY3 = "予約";
                            }
                            if (tmp.JN_PROPERTY2.Contains("解約"))
                            {
                                tmp.JN_PROPERTY2 = tmp.JN_PROPERTY2.Replace("解約", "");
                                tmp.JN_PROPERTY3 = "解約";
                            }
                            if (tmp.JN_PROPERTY2.Contains("変更前"))
                            {
                                tmp.JN_PROPERTY2 = tmp.JN_PROPERTY2.Replace("変更前", "");
                                tmp.JN_PROPERTY4 = "前";
                            }
                            if (tmp.JN_PROPERTY2.Contains("変更後"))
                            {
                                tmp.JN_PROPERTY2 = tmp.JN_PROPERTY2.Replace("変更後", "");
                                tmp.JN_PROPERTY4 = "後";
                            }

                            var m1 = reg.Match(tmp.JN_PROPERTY2);
                            var m2 = reg2.Match(tmp.JN_PROPERTY2);

                            if (m2.Success)
                            {
                                tmp.JN_PROPERTY2 = tmp.JN_PROPERTY2.Replace(m2.Value, "");
                                tmp.JN_PROPERTY5 = m2.Value;
                            }
                            else if (m1.Success)
                            {
                                tmp.JN_PROPERTY2 = tmp.JN_PROPERTY2.Replace(m1.Value, "");
                                tmp.JN_PROPERTY5 = m1.Value;
                            }

                            tmp.JN_PROPERTY2 = tmp.JN_PROPERTY2.Replace("/", "").Trim();
                        }
                    }
                }
            }

            storeToDB(alldata);

            this.button2.Enabled = true;

            //System.Diagnostics.Debug.WriteLine(alldata.Count);
            this.richTextBox1.Text = "読込完了！";
        }

        /// <summary>
        /// Excelから読んだデータをチェックしてから、DBに保存する
        /// </summary>
        /// <param name="alldata"></param>
        private void storeToDB(List<JNPattern> alldata)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Read Excel to memory
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        private List<JNPattern> readExcel(string text)
        {
            List<JNPattern> res = new List<JNPattern>();
            if (String.IsNullOrWhiteSpace(text))
                return res;
            var fi = new FileInfo(text);
            using (var package = new ExcelPackage(fi))
            {
                var workbook = package.Workbook;
                var s = workbook.Worksheets.FirstOrDefault(r => r.Name.Equals("ALLDATA", StringComparison.OrdinalIgnoreCase));
                int i = startRow;
                while (true)
                {
                    if (String.IsNullOrWhiteSpace(s.Cells[i, 1].Text))
                    {
                        break;
                    }
                    JNPattern jnp = new JNPattern();
                    jnp.JN_CUPID = s.Cells[i, 1].Text;
                    jnp.JN_PATTERNNO = s.Cells[i, 2].Text;
                    jnp.JN_TYPE = s.Cells[i, 3].Text;
                    jnp.JN_ANS = s.Cells[i, 4].Text;
                    jnp.JN_OPTYPE = s.Cells[i, 5].Text;
                    jnp.JN_COMMNENT = s.Cells[i, 6].Text;
                    jnp.JN_INFOBLOCKS = new List<JNInfoBlock>();
                    //情報部リスト設定
                    for (int j = 1; ; j++)
                    {
                        if (String.IsNullOrWhiteSpace(s.Cells[i, j + 6].Text))
                        {
                            break;
                        }
                        JNInfoBlock block = new JNInfoBlock();
                        block.JN_ORDER = j;
                        block.JN_NAME = s.Cells[i, j + 6].Text;
                        block.JN_SIZE = null;
                        block.JN_REQRESFLG = s.Cells[i + 1, j + 6].Text;
                        block.JN_PROPERTY2 = s.Cells[i + 2, j + 6].Text;
                        jnp.JN_INFOBLOCKS.Add(block);
                    }
                    res.Add(jnp);
                    i += 3;
                }
            }
            return res;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            isDialog2 = true;
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Title = "ジャーナル専用入力シート選択";
            openFileDialog.Filter = "Excel Files | *.xlsx";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                this.textBox1.Text = openFileDialog.FileName;
            }
            isDialog2 = false;
        }

        private void FileLoadForm_Load(object sender, EventArgs e)
        {
            this.MaximizeBox = false;
            this.MinimizeBox = false;
        }

        private bool isDialog = false;
        private bool isDialog2 = false;

        /// <summary>
        /// パス選択ダイアログ
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {
            isDialog = true;
            using (var fbd = new FolderBrowserDialog())
            {
                DialogResult result = fbd.ShowDialog();

                if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(fbd.SelectedPath))
                {
                    this.textBox2.Text = fbd.SelectedPath;
                }
            }
            isDialog = false;
        }

        /// <summary>
        /// 出力
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button4_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrWhiteSpace(this.textBox2.Text))
            {
                MessageBox.Show("出力先を選択してください", "注意",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return;
            }
            List<JNPattern> lst = new List<JNPattern>();
            using (var context = new Models.DB.mysqlcontext())
            {
                List<Models.DB.JNPattern> total = context.JNPattern.ToList();
                foreach (var jp in total)
                {
                    var jnPattern = new JNPattern();
                    jnPattern.JN_INFOBLOCKS = new List<JNInfoBlock>();
                    jnPattern.JN_ANS = jp.JN_ANS;
                    jnPattern.JN_COMMNENT = jp.JN_COMMNENT;
                    jnPattern.JN_CUPID = jp.JN_CUPID;
                    jnPattern.JN_OPTYPE = jp.JN_OPTYPE;
                    jnPattern.JN_PATTERNNO = jp.JN_PATTERNNO;
                    jnPattern.JN_TYPE = jp.JN_TYPE;
                    foreach (var tmp in jp.JN_INFOBLOCKS)
                    {
                        jnPattern.JN_INFOBLOCKS.Add(new JNInfoBlock
                        {
                            JN_INTERFACEID = tmp.JN_INTERFACEID,
                            JN_PATTERNID = tmp.JN_PATTERNID,
                            JN_PROPERTY2 = tmp.JN_PROPERTY2,
                            JN_PROPERTY3 = tmp.JN_PROPERTY3,
                            JN_PROPERTY4 = tmp.JN_PROPERTY4,
                            JN_PROPERTY5 = tmp.JN_PROPERTY5,
                            JN_PROPERTY6 = tmp.JN_PROPERTY6,
                            JN_PROPERTY7 = tmp.JN_PROPERTY7,
                            JN_REQRESFLG = tmp.JN_REQRESFLG,
                            JN_SIZE = tmp.JN_SIZE,
                            JN_ORDER = tmp.JN_ORDER,
                            JN_NAME = tmp.JN_NAME,
                            TMCPK_DEVID = tmp.TMCPK_DEVID
                        });
                    }
                    lst.Add(jnPattern);
                }

            }
            FileOutputOfficeCom fop = new FileOutputOfficeCom();
            fop.writeDataToExcel(lst, this.textBox2.Text);
        }

        /// <summary>
        /// 全て出力チェック
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                checkBox2.Enabled = false;
                checkBox3.Enabled = false;
                checkBox4.Enabled = false;
                checkBox5.Enabled = false;
                checkBox6.Enabled = false;
            }
            else
            {
                checkBox2.Enabled = true;
                checkBox3.Enabled = true;
                checkBox4.Enabled = true;
                checkBox5.Enabled = true;
                checkBox6.Enabled = true;
            }
        }

        //手入力の場合、textboxをクリアする
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (isDialog)
            {
            }
            else
            {
                ((TextBox)sender).Text = "";
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MForm f = new MForm();
            f.ShowDialog();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked &&
                checkBox3.Checked &&
                checkBox4.Checked &&
                checkBox5.Checked &&
                checkBox6.Checked)
            {
                checkBox1.Checked = true;
                checkBox2.Checked = false;
                checkBox3.Checked = false;
                checkBox4.Checked = false;
                checkBox5.Checked = false;
                checkBox6.Checked = false;
            }
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked &&
                checkBox3.Checked &&
                checkBox4.Checked &&
                checkBox5.Checked &&
                checkBox6.Checked)
            {
                checkBox1.Checked = true;
                checkBox2.Checked = false;
                checkBox3.Checked = false;
                checkBox4.Checked = false;
                checkBox5.Checked = false;
                checkBox6.Checked = false;
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked &&
                checkBox3.Checked &&
                checkBox4.Checked &&
                checkBox5.Checked &&
                checkBox6.Checked)
            {
                checkBox1.Checked = true;
                checkBox2.Checked = false;
                checkBox3.Checked = false;
                checkBox4.Checked = false;
                checkBox5.Checked = false;
                checkBox6.Checked = false;
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked &&
                checkBox3.Checked &&
                checkBox4.Checked &&
                checkBox5.Checked &&
                checkBox6.Checked)
            {
                checkBox1.Checked = true;
                checkBox2.Checked = false;
                checkBox3.Checked = false;
                checkBox4.Checked = false;
                checkBox5.Checked = false;
                checkBox6.Checked = false;
            }
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked &&
                checkBox3.Checked &&
                checkBox4.Checked &&
                checkBox5.Checked &&
                checkBox6.Checked)
            {
                checkBox1.Checked = true;
                checkBox2.Checked = false;
                checkBox3.Checked = false;
                checkBox4.Checked = false;
                checkBox5.Checked = false;
                checkBox6.Checked = false;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (isDialog2)
            {
            }
            else
            {
                ((TextBox)sender).Text = "";
            }
        }
    }

}
