﻿using JN_Tool.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JN_Tool
{
    public partial class MForm : Form
    {
        /// <summary>
        /// 一番目の情報部のX座標
        /// </summary>
        public const int X_Start = 5;
        /// <summary>
        /// 一番目の情報部のY座標
        /// </summary>
        public const int Y_Start = 56;
        /// <summary>
        /// 情報部の広さ
        /// </summary>
        public const int W = 72;
        /// <summary>
        /// 情報部の高さ
        /// </summary>
        public const int H = 72;
        /// <summary>
        /// 属性の高さ
        /// </summary>
        public const int PH = 30;

        private JNPattern jnPattern = null;

        private Color bkgColor = Color.FromArgb(223, 229, 219);

        private Dictionary<Button, JNInfoBlock> dic = new Dictionary<Button, JNInfoBlock>();
        private Dictionary<string, Models.DB.InterfaceShort> quickDic = new Dictionary<string, Models.DB.InterfaceShort>();

        private NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        public MForm(int value)
        {
            InitializeComponent();
            jnPattern = new JNPattern();
            jnPattern.JN_INFOBLOCKS = new List<JNInfoBlock>();
            jnPattern.JN_PATTERNID = value;
        }

        public MForm()
        {
            InitializeComponent();
            jnPattern = new JNPattern();
            jnPattern.JN_INFOBLOCKS = new List<JNInfoBlock>();
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            Button bt = new Button();
            bt.Text = "未指定の情報部";
            bt.Height = H;
            bt.Width = W;

            bt.Left = pictureBox1.Left;

            bt.Top = Y_Start;
            bt.FlatStyle = FlatStyle.Flat;
            bt.FlatAppearance.BorderSize = 1;

            //mouse over color
            bt.FlatAppearance.MouseOverBackColor = bkgColor;

            bt.Click += btclick;
            bt.MouseDown += btmd;
            bt.MouseUp += btmu;
            bt.MouseMove += btmov;

            //bt.ContextMenu = ctm;

            pictureBox1.Left += bt.Width - 1;

            this.panel1.Controls.Add(bt);
            JNInfoBlock tmpblock = new JNInfoBlock { JN_NAME = bt.Text };
            jnPattern.JN_INFOBLOCKS.Add(tmpblock);
            dic.Add(bt, tmpblock);
        }

        private Control clickedcontrol;
        private Point previousLocation;
        //button mouse up
        private void btmu(object sender, MouseEventArgs e)
        {
            this.ActiveControl = null;
            clickedcontrol = null;
            var tmplst = dic.Keys.OrderBy(r => r.Left);
            int tmpleft = X_Start;
            foreach (var tmp in tmplst)
            {
                tmp.Left = tmpleft + this.panel1.AutoScrollPosition.X;
                tmp.Top = Y_Start;
                tmpleft += tmp.Width - 1;
            }
            this.panel1.Refresh();
            Cursor.Clip = Rectangle.Empty;
        }
        //button mouse down
        private void btmd(object sender, MouseEventArgs e)
        {
            //Ctrl
            if (ModifierKeys.HasFlag(Keys.Control))
            {
                ((Button)sender).BackColor = bkgColor;
            }
            else
            {
                if (((Button)sender).BackColor.ToArgb() == bkgColor.ToArgb() && e.Button == MouseButtons.Right)
                {
                }
                else
                {
                    foreach (Control tmp in this.panel1.Controls)
                    {
                        if (tmp is Button)
                        {
                            tmp.BackColor = Color.White;
                        }
                    }
                    ((Button)sender).BackColor = bkgColor;
                }
            }
            if (e.Button == MouseButtons.Right)
            {
                if (this.radioButton1.Checked)
                    ctm2.Show(sender as Control, e.Location);
                else if (this.radioButton2.Checked)
                    ctm.Show(sender as Control, e.Location);
            }

            this.panel1.Controls.SetChildIndex(((Button)sender), 0);

            clickedcontrol = sender as Control;
            previousLocation = e.Location;

            if (e.Button == MouseButtons.Left)
            {
                Cursor.Clip = new Rectangle(0, Cursor.Position.Y, 4096, 1);
            }
        }
        //button mouse move
        private void btmov(object sender, MouseEventArgs e)
        {
            //普通モードは移動機能禁止
            if (this.radioButton2.Checked)
            {
                return;
            }

            if (clickedcontrol == null || clickedcontrol != sender || e.Button != MouseButtons.Left)
                return;

            //情報部の位置を再設定
            var location = clickedcontrol.Location;
            location.Offset(e.Location.X - previousLocation.X, e.Location.Y - previousLocation.Y);
            clickedcontrol.Location = location;
            var tmplst = dic.Keys.OrderBy(r => r.Left);
            int tmpleft = X_Start;
            foreach (var tmp in tmplst)
            {
                if (tmp != sender)
                {
                    tmp.Left = tmpleft + this.panel1.AutoScrollPosition.X;
                    tmpleft += tmp.Width - 1;
                }
                else
                {
                    //tmp.Top = Y_Start;
                    tmpleft += tmp.Width - 1;
                }
            }
            this.panel1.Refresh();
        }

        private void btclick(object sender, EventArgs e)
        {
            //((Button)sender).BackColor = Color.FromArgb(223, 229, 219);
            //this.ActiveControl = null;
        }

        private ContextMenu ctm = null;
        private ContextMenu ctm2 = null;

        private void MForm_Load(object sender, EventArgs e)
        {
            this.Location = new Point(40, 20);
            this.pictureBox1.Left = X_Start;
            this.pictureBox1.Top = Y_Start;
            ctm = new ContextMenu();
            ctm2 = new ContextMenu();

            MenuItem m1 = new MenuItem("情報部設定");
            MenuItem m11 = new MenuItem("情報部設定");
            MenuItem m2 = new MenuItem("要求/回答設定");
            MenuItem m3 = new MenuItem("予約/解約/前/後設定");
            //MenuItem m4 = new MenuItem("前/後設定");
            MenuItem m5 = new MenuItem("レピート設定", m5click);
            MenuItem m6 = new MenuItem("その他属性設定", m6click);
            MenuItem m7 = new MenuItem("P6属性設定", m7click);
            MenuItem m8 = new MenuItem("P7属性設定", m8click);
            MenuItem m9 = new MenuItem("情報部削除", m9click);
            //setm1(m1);
            //setm1(m11);
            setm2(m2);
            setm3(m3);
            //setm4(m4);
            ctm.MenuItems.Add(m1);
            ctm.MenuItems.Add(m2);
            ctm.MenuItems.Add(m3);
            //ctm.MenuItems.Add(m4);
            ctm.MenuItems.Add(m6);
            ctm.MenuItems.Add(m5);
            //ctm.MenuItems.Add(m7);
            //ctm.MenuItems.Add(m8);
            //ctm.MenuItems.Add(m9);

            ctm2.MenuItems.Add(m11);
            ctm2.MenuItems.Add(m9);

            this.panel1.Paint += paint;

            try
            {
                using (var context = new Models.DB.mysqlcontext())
                {
                    //頻繁的に使われた情報部を取得する
                    string sql = @"select TMCPK_DEVID,TMCPK_BCPID,TMCPK_BCPNM,TMCPK_SIZE from interface inner join ( 
                               select Max(TMCPK_DEVID) as M,TMCPK_BCPNM as N from interface inner join (
                               select JN_NAME, count(*) as CT from jninfoblock
                               group by JN_NAME limit 10) as freq
                               on interface.TMCPK_BCPNM = freq.JN_NAME
                               group by TMCPK_BCPNM ) as tb
                               on tb.M = TMCPK_DEVID and tb.N = TMCPK_BCPNM";
                    var res = context.Database.SqlQuery<Models.DB.InterfaceShort>(sql);

                    m1.MenuItems.Add(">>全情報部を検索する<<", m11click);
                    m11.MenuItems.Add(">>全情報部を検索する<<", m11click);

                    if (res != null && res.Count() > 0)
                    {
                        m1.MenuItems.Add("-");
                        m11.MenuItems.Add("-");
                        foreach (var t in res)
                        {
                            m1.MenuItems.Add(t.TMCPK_BCPNM, m1click);
                            m11.MenuItems.Add(t.TMCPK_BCPNM, m1click);
                            quickDic.Add(t.TMCPK_BCPNM, t);
                        }
                    }
                    if (jnPattern.JN_PATTERNID != null)
                    {
                        var jp = context.JNPattern.FirstOrDefault(r => r.JN_PATTERNID == jnPattern.JN_PATTERNID);
                        if (jp != null)
                        {
                            //
                            jnPattern.JN_ANS = jp.JN_ANS;
                            jnPattern.JN_COMMNENT = jp.JN_COMMNENT;
                            jnPattern.JN_CUPID = jp.JN_CUPID;
                            jnPattern.JN_OPTYPE = jp.JN_OPTYPE;
                            jnPattern.JN_PATTERNNO = jp.JN_PATTERNNO;
                            jnPattern.JN_TYPE = jp.JN_TYPE;
                            foreach (var tmp in jp.JN_INFOBLOCKS)
                            {
                                jnPattern.JN_INFOBLOCKS.Add(new JNInfoBlock
                                {
                                    JN_INTERFACEID = tmp.JN_INTERFACEID,
                                    JN_PATTERNID = tmp.JN_PATTERNID,
                                    JN_PROPERTY2 = tmp.JN_PROPERTY2,
                                    JN_PROPERTY3 = tmp.JN_PROPERTY3,
                                    JN_PROPERTY4 = tmp.JN_PROPERTY4,
                                    JN_PROPERTY5 = tmp.JN_PROPERTY5,
                                    JN_PROPERTY6 = tmp.JN_PROPERTY6,
                                    JN_PROPERTY7 = tmp.JN_PROPERTY7,
                                    JN_REQRESFLG = tmp.JN_REQRESFLG,
                                    JN_SIZE = tmp.JN_SIZE,
                                    JN_ORDER = tmp.JN_ORDER,
                                    JN_NAME = tmp.JN_NAME,
                                    TMCPK_DEVID = tmp.TMCPK_DEVID
                                });
                            }
                        }
                    }
                }
            }
            catch (Exception exp)
            {
                logger.Error(exp , "DBエラー");
                MessageBox.Show("DBエラーが発生したので、機能が使えない", "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Dispose();
            }


            this.textBox5.Text = jnPattern.JN_ANS;
            this.textBox7.Text = jnPattern.JN_COMMNENT;
            this.textBox2.Text = jnPattern.JN_CUPID;
            this.textBox6.Text = jnPattern.JN_OPTYPE;
            this.textBox3.Text = jnPattern.JN_PATTERNNO;
            this.textBox4.Text = jnPattern.JN_TYPE;
            foreach (var tmp in jnPattern.JN_INFOBLOCKS)
            {
                Button bt = new Button();
                bt.Text = tmp.JN_NAME;
                bt.Height = H;
                bt.Width = W;

                bt.Left = pictureBox1.Left;

                bt.Top = Y_Start;
                bt.FlatStyle = FlatStyle.Flat;
                bt.FlatAppearance.BorderSize = 1;

                //mouse over color
                bt.FlatAppearance.MouseOverBackColor = bkgColor;

                bt.Click += btclick;
                bt.MouseDown += btmd;
                bt.MouseUp += btmu;
                bt.MouseMove += btmov;

                bt.ContextMenu = ctm;
                pictureBox1.Left += bt.Width - 1;

                this.panel1.Controls.Add(bt);
                dic.Add(bt, tmp);
            }

            //編集のTABを選択
            this.tabControl1.SelectedTab = this.tabPage2;
        }

        /// <summary>
        /// 情報部の削除
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void m9click(object sender, EventArgs e)
        {
            var itm = sender as MenuItem;
            var p1 = itm.Parent as ContextMenu;
            var s = p1.SourceControl as Button;

            if (dic.ContainsKey(s))
            {
                jnPattern.JN_INFOBLOCKS.Remove(dic[s]);
                dic.Remove(s);
                this.panel1.Controls.Remove(s);

                var tmplst = dic.Keys.OrderBy(r => r.Left);
                int tmpleft = X_Start;
                foreach (var tmp in tmplst)
                {
                    tmp.Left = tmpleft + this.panel1.AutoScrollPosition.X;
                    tmp.Top = Y_Start;
                    tmpleft += tmp.Width - 1;
                }
                this.pictureBox1.Left = this.pictureBox1.Left - (s.Width - 1);
                this.panel1.Refresh();
            }
        }

        private void m8click(object sender, EventArgs e)
        {
            MessageBox.Show("未開放の機能");
        }

        private void m7click(object sender, EventArgs e)
        {
            MessageBox.Show("未開放の機能");
        }

        /// <summary>
        /// 先乗列車、後乗列車、区間１、区間２など
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void m6click(object sender, EventArgs e)
        {
            var tmplst = new List<string>();
            tmplst.AddRange(p2dic.Keys);
            OtherFM f = new OtherFM(tmplst);
            var res = f.ShowDialog(this);
            string xx = null;
            if (res == DialogResult.Yes)
            {
                xx = f.comboBox1.SelectedItem as string;
            }
            else if (res == DialogResult.Ignore)
            {
                xx = f.textBox1.Text;
            }
            else
            {
                return;
            }

            if (!String.IsNullOrWhiteSpace(xx))
            {
                var itm = sender as MenuItem;
                var p1 = itm.Parent as ContextMenu;
                var s = p1.SourceControl as Button;

                if (dic.ContainsKey(s))
                {
                    dic[s].JN_PROPERTY2 = xx.Trim();
                }

                this.panel1.Refresh();
            }
            else
            {
                var itm = sender as MenuItem;
                var p1 = itm.Parent as ContextMenu;
                var s = p1.SourceControl as Button;

                if (dic.ContainsKey(s))
                {
                    dic[s].JN_PROPERTY2 = null;
                }

                this.panel1.Refresh();
            }
        }

        /// <summary>
        /// 重複設定
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void m5click(object sender, EventArgs e)
        {
            RepeatFM f = new RepeatFM();
            if (f.ShowDialog(this) == DialogResult.OK)
            {
                string xx = f.comboBox1.SelectedItem.ToString();
                var itm = sender as MenuItem;
                //var p1 = itm.Parent as ContextMenu;
                //var s = p1.SourceControl as Button;

                int count = 0;

                foreach (var s in dic.Keys)
                {
                    if (s.BackColor.ToArgb() == bkgColor.ToArgb())
                    {
                        count++;
                    }
                }

                foreach (var s in dic.Keys)
                {
                    if (s.BackColor.ToArgb() == bkgColor.ToArgb())
                    {
                        if (xx == "1")
                        {
                            dic[s].JN_PROPERTY5 = null;
                        }
                        else
                        {
                            if (count > 1)
                            {
                                dic[s].JN_PROPERTY5 = "*MAX(" + xx + ")";
                            }
                            else
                            {
                                dic[s].JN_PROPERTY5 = "MAX(" + xx + ")";
                            }

                        }
                    }
                }

                this.panel1.Refresh();
            }
            else
            {

            }
            f.Dispose();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="g"></param>
        /// <param name="content"></param>
        /// <param name="x">文字の中央点</param>
        /// <param name="y">文字の中央点</param>
        private void drawText(Graphics g, string content, float x, float y)
        {
            if (content == null) content = "";

            Font stringFont = new Font("MS UI Gothic", 9);

            // Measure string.
            SizeF stringSize = new SizeF();
            stringSize = g.MeasureString(content, stringFont);

            float a = x - stringSize.Width / 2 - 2;
            float b = y - stringSize.Height / 2;

            // Draw rectangle representing size of string.
            g.FillRectangle(Brushes.White, a, b, stringSize.Width + 4, stringSize.Height);

            // Draw string to screen.
            g.DrawString(content, stringFont, Brushes.Black, new PointF(a + 2F, b + 2F));

            stringFont.Dispose();
        }


        //その他情報文字列を保存するため
        private Dictionary<string, int> p2dic = new Dictionary<string, int>();

        /// <summary>
        /// サイズ、要求/回答、予約/解約などの属性描き
        /// 
        /// paintで線、文字の描きより、完全的にControlの追加で対応する
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void paint(object sender, PaintEventArgs e)
        {
            Pen clear_flight_line_pen = new Pen(System.Drawing.Color.Black, 1);
            Pen dashpen = new Pen(System.Drawing.Color.Black, 1);
            dashpen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dot;
            Graphics formGraphics = e.Graphics;
            //formGraphics.Clear(Color.White);

            var data = dic.OrderBy(r => r.Key.Left).ToList();

            p2dic.Clear();

            if (data.Count > 0)
            {
                //サイズ情報
                for (int i = 0; i < data.Count; i++)
                {
                    if (data[i].Value.JN_SIZE != null)
                    {
                        formGraphics.DrawLine(clear_flight_line_pen,
                            data[i].Key.Left,
                            data[i].Key.Height + Y_Start,
                            data[i].Key.Left,
                            data[i].Key.Height + Y_Start + PH);
                        formGraphics.DrawLine(clear_flight_line_pen,
                            data[i].Key.Left + data[i].Key.Width - 1,
                            data[i].Key.Height + Y_Start,
                            data[i].Key.Left + data[i].Key.Width - 1,
                            data[i].Key.Height + Y_Start + PH);
                        formGraphics.DrawLine(clear_flight_line_pen,
                            data[i].Key.Left,
                            data[i].Key.Height + Y_Start + PH / 2,
                            data[i].Key.Left + data[i].Key.Width - 1,
                            data[i].Key.Height + Y_Start + PH / 2);

                        drawText(formGraphics, data[i].Value.JN_SIZE.ToString(), data[i].Key.Left + (data[i].Key.Width - 1) / 2, data[i].Key.Height + Y_Start + PH / 2);
                    }
                    if (!String.IsNullOrWhiteSpace(data[i].Value.JN_PROPERTY2))
                    {
                        if (p2dic.ContainsKey(data[i].Value.JN_PROPERTY2))
                        {
                            //do nothing
                        }
                        else
                        {
                            if (p2dic.Count == 0)
                                p2dic.Add(data[i].Value.JN_PROPERTY2, 1);
                            else
                                p2dic.Add(data[i].Value.JN_PROPERTY2, p2dic.Values.Max() + 1);
                        }
                    }
                }

                bool P34Flag = false;
                bool P2Flag = false;
                bool ReqResFlag = false;
                int offset = 0;

                //Property 3 4
                for (int i = 0; i < data.Count; i++)
                {
                    if (!String.IsNullOrWhiteSpace(data[i].Value.JN_PROPERTY3))
                    {
                        if (i >= 1 && data[i].Value.JN_PROPERTY3 == data[i - 1].Value.JN_PROPERTY3)
                        {
                            //already set .
                        }
                        else
                        {
                            int endblock = 0;
                            for (int k = i + 1; k < data.Count; k++)
                            {
                                if (data[i].Value.JN_PROPERTY3 != data[k].Value.JN_PROPERTY3)
                                {
                                    endblock = k - i - 1;
                                    break;
                                }
                                if (k == data.Count - 1)
                                {
                                    endblock = k - i;
                                }
                            }
                            formGraphics.DrawLine(clear_flight_line_pen,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH + PH);
                            formGraphics.DrawLine(clear_flight_line_pen,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH + PH);
                            formGraphics.DrawLine(clear_flight_line_pen,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH + PH / 2,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH + PH / 2);

                            drawText(formGraphics,
                                data[i].Value.JN_PROPERTY3,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1) / 2,
                                data[i].Key.Height + Y_Start + PH + PH / 2);

                            P34Flag = true;
                        }
                    }
                    if (!String.IsNullOrWhiteSpace(data[i].Value.JN_PROPERTY4))
                    {
                        if (i >= 1 && data[i].Value.JN_PROPERTY4 == data[i - 1].Value.JN_PROPERTY4)
                        {
                            //already set .
                        }
                        else
                        {
                            int endblock = 0;
                            for (int k = i + 1; k < data.Count; k++)
                            {
                                if (data[i].Value.JN_PROPERTY4 != data[k].Value.JN_PROPERTY4)
                                {
                                    endblock = k - i - 1;
                                    break;
                                }
                                if (k == data.Count - 1)
                                {
                                    endblock = k - i;
                                }
                            }
                            formGraphics.DrawLine(clear_flight_line_pen,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH + PH);
                            formGraphics.DrawLine(clear_flight_line_pen,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH + PH);
                            formGraphics.DrawLine(clear_flight_line_pen,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH + PH / 2,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH + PH / 2);

                            drawText(formGraphics,
                                data[i].Value.JN_PROPERTY4,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1) / 2,
                                data[i].Key.Height + Y_Start + PH + PH / 2);

                            P34Flag = true;
                        }
                    }
                }
                if (P34Flag)
                {
                    offset = offset + PH;
                }
                //要求回答
                for (int i = 0; i < data.Count; i++)
                {
                    if (!String.IsNullOrWhiteSpace(data[i].Value.JN_REQRESFLG))
                    {
                        if (i >= 1 && data[i].Value.JN_REQRESFLG == data[i - 1].Value.JN_REQRESFLG)
                        {
                            //already set .
                        }
                        else
                        {
                            int endblock = 0;
                            for (int k = i + 1; k < data.Count; k++)
                            {
                                if (data[i].Value.JN_REQRESFLG != data[k].Value.JN_REQRESFLG)
                                {
                                    endblock = k - i - 1;
                                    break;
                                }
                                if (k == data.Count - 1)
                                {
                                    endblock = k - i;
                                }
                            }
                            ReqResFlag = true;
                            formGraphics.DrawLine(clear_flight_line_pen,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH + offset,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH + PH + offset);
                            formGraphics.DrawLine(clear_flight_line_pen,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH + offset,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH + PH + offset);
                            formGraphics.DrawLine(clear_flight_line_pen,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset);

                            drawText(formGraphics,
                                data[i].Value.JN_REQRESFLG,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1) / 2,
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset);
                        }
                    }
                }
                if (ReqResFlag)
                {
                    offset = offset + PH;
                }

                //Property 2
                for (int i = 0; i < data.Count; i++)
                {
                    if (!String.IsNullOrWhiteSpace(data[i].Value.JN_PROPERTY2))
                    {
                        if (i >= 1 && data[i].Value.JN_PROPERTY2 == data[i - 1].Value.JN_PROPERTY2)
                        {
                            //already set .
                        }
                        else
                        {
                            int endblock = 0;
                            for (int k = i + 1; k < data.Count; k++)
                            {
                                if (data[i].Value.JN_PROPERTY2 != data[k].Value.JN_PROPERTY2)
                                {
                                    endblock = k - i - 1;
                                    break;
                                }
                                if (k == data.Count - 1)
                                {
                                    endblock = k - i;
                                }
                            }

                            P2Flag = true;

                            formGraphics.DrawLine(dashpen,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH + offset,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset);
                            formGraphics.DrawLine(dashpen,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH + offset,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset);
                            formGraphics.DrawLine(dashpen,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset);

                            drawText(formGraphics,
                                "＊ " + p2dic[data[i].Value.JN_PROPERTY2],
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1) / 2,
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset);
                        }
                    }
                }

                if (P2Flag)
                {
                    offset = offset + PH / 2;
                }

                //Property 5
                for (int i = 0; i < data.Count; i++)
                {
                    if (!String.IsNullOrWhiteSpace(data[i].Value.JN_PROPERTY5))
                    {
                        if (i >= 1 && data[i].Value.JN_PROPERTY5 == data[i - 1].Value.JN_PROPERTY5 && data[i].Value.JN_PROPERTY5.StartsWith("*"))
                        {
                            //already set .
                        }
                        else
                        {
                            int endblock = 0;
                            if (data[i].Value.JN_PROPERTY5.StartsWith("*"))
                            {
                                for (int k = i + 1; k < data.Count; k++)
                                {
                                    if (data[k].Value.JN_PROPERTY5 != data[i].Value.JN_PROPERTY5)
                                    {
                                        endblock = k - i - 1;
                                        break;
                                    }
                                    if (k == data.Count - 1)
                                    {
                                        endblock = k - i;
                                    }
                                }
                            }
                            formGraphics.DrawLine(dashpen,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH + offset,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset);
                            formGraphics.DrawLine(dashpen,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH + offset,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset);
                            formGraphics.DrawLine(dashpen,
                                data[i].Key.Left,
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset,
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1),
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset);

                            drawText(formGraphics,
                                data[i].Value.JN_PROPERTY5.Replace("*", ""),
                                data[i].Key.Left + (data[i].Key.Width - 1) * (endblock + 1) / 2,
                                data[i].Key.Height + Y_Start + PH + PH / 2 + offset);
                        }

                    }
                }

                //P2 text
                if (p2dic.Count > 0)
                {
                    Font stringFont = new Font("MS UI Gothic", 9);

                    // Measure string.
                    SizeF s = new SizeF();

                    int tmpcnt = 0;
                    float tmpmaxwidth = 0;

                    var lst = p2dic.OrderBy(r => r.Value);
                    float tmpx = data[0].Key.Left;
                    float tmpy = 320;
                    foreach (var t in lst)
                    {
                        s = formGraphics.MeasureString("* " + t.Value + " : " + t.Key, stringFont);

                        if (s.Width > tmpmaxwidth)
                            tmpmaxwidth = s.Width;

                        formGraphics.DrawString("* " + t.Value + " : " + t.Key, stringFont, Brushes.Black, tmpx, tmpy);
                        tmpy += s.Height;
                        tmpcnt++;
                        if (tmpcnt % 4 == 0)
                        {
                            tmpy = 320;
                            tmpx = tmpx + tmpmaxwidth + 10;
                            tmpmaxwidth = 0;
                        }
                    }
                    stringFont.Dispose();
                }
            }

            clear_flight_line_pen.Dispose();
            dashpen.Dispose();
            formGraphics.Dispose();
        }

        private void setm3(MenuItem m3)
        {
            m3.MenuItems.Add("予約", m3click);
            m3.MenuItems.Add("解約", m3click);
            m3.MenuItems.Add("変更前", m3click);
            m3.MenuItems.Add("変更後", m3click);
            m3.MenuItems.Add("設定消し", m3click);
        }
        private void m3click(object sender, EventArgs e)
        {
            var itm = sender as MenuItem;

            foreach (var s in dic.Keys)
            {
                if (s.BackColor.ToArgb() == bkgColor.ToArgb())
                {
                    if (itm.Text == "予約" || itm.Text == "解約")
                    {
                        dic[s].JN_PROPERTY3 = null;
                        dic[s].JN_PROPERTY4 = null;
                        dic[s].JN_PROPERTY3 = itm.Text;
                    }
                    else if (itm.Text == "変更前" || itm.Text == "変更後")
                    {
                        dic[s].JN_PROPERTY3 = null;
                        dic[s].JN_PROPERTY4 = null;
                        dic[s].JN_PROPERTY4 = itm.Text.Replace("変更", "");
                    }
                    else
                    {
                        dic[s].JN_PROPERTY3 = null;
                        dic[s].JN_PROPERTY4 = null;
                    }
                }
            }

            this.panel1.Refresh();
        }

        private void setm2(MenuItem m2)
        {
            m2.MenuItems.Add("要求", m2click);
            m2.MenuItems.Add("回答", m2click);
            m2.MenuItems.Add("設定消し", m2click);
        }
        private void m2click(object sender, EventArgs e)
        {
            var itm = sender as MenuItem;
            //var p = itm.Parent as MenuItem;
            //var p1 = p.Parent as ContextMenu;
            //var s = p1.SourceControl as Button;

            foreach (var s in dic.Keys)
            {
                if (s.BackColor.ToArgb() == bkgColor.ToArgb())
                {
                    if (itm.Text != "設定消し")
                    {
                        dic[s].JN_REQRESFLG = itm.Text;
                    }
                    else
                    {
                        dic[s].JN_REQRESFLG = null;
                    }
                }
            }

            this.panel1.Refresh();
        }

        private void setm1(MenuItem m1)
        {
            m1.MenuItems.Add(">>全情報部を検索する<<", m11click);

            m1.MenuItems.Add("-");

            m1.MenuItems.Add("制御情報", m1click);
            m1.MenuItems.Add("ジャーナル共通情報１", m1click);
            m1.MenuItems.Add("ジャーナル共通情報２", m1click);
            m1.MenuItems.Add("ジャーナル共通情報３", m1click);
            m1.MenuItems.Add("列車情報部", m1click);
            m1.MenuItems.Add("座席情報部（一般）", m1click);
            m1.MenuItems.Add("回答共通情報部", m1click);

        }
        //選択した情報部を設定する
        private void m11click(object sender, EventArgs e)
        {
            InfoblockSearch f = new InfoblockSearch();
            if (f.ShowDialog(this) == DialogResult.OK)
            {
                foreach (var s in dic.Keys)
                {
                    if (s.BackColor.ToArgb() == bkgColor.ToArgb())
                    {
                        s.Text = f.infoBlock.TMCPK_BCPNM;
                        dic[s].JN_SIZE = f.infoBlock.TMCPK_SIZE;
                        dic[s].JN_NAME = f.infoBlock.TMCPK_BCPNM;
                        dic[s].JN_INTERFACEID = f.infoBlock.TMCPK_BCPID;
                        dic[s].TMCPK_DEVID = f.infoBlock.TMCPK_DEVID;
                    }
                }

                this.panel1.Refresh();
            }
            else
            {

            }
            f.Dispose();
        }
        //情報部設定
        private void m1click(object sender, EventArgs e)
        {
            var itm = sender as MenuItem;

            foreach (var s in dic.Keys)
            {
                if (s.BackColor.ToArgb() == bkgColor.ToArgb())
                {
                    s.Text = quickDic[itm.Text].TMCPK_BCPNM;
                    dic[s].JN_NAME = s.Text;
                    dic[s].JN_SIZE = quickDic[itm.Text].TMCPK_SIZE;
                    dic[s].TMCPK_DEVID = quickDic[itm.Text].TMCPK_DEVID;
                    dic[s].JN_INTERFACEID = quickDic[itm.Text].TMCPK_BCPID;
                }
            }

            this.panel1.Refresh();
        }

        /// <summary>
        /// 普通モードへ切り替え
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void radioButton2_MouseDown(object sender, MouseEventArgs e)
        {
            if (!this.radioButton2.Checked)
            {
                if (MessageBox.Show("普通モードへ切り替えますか？\n普通モードへ切り替えると「移動」、「削除」機能が使えなくなりますが、情報部の属性設定機能が使える",
                "注意", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
                {
                    this.radioButton2.Checked = true;
                }
            }
        }


        /// <summary>
        /// Ａモードへ切り替え
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void radioButton1_MouseDown(object sender, MouseEventArgs e)
        {
            if (!this.radioButton1.Checked)
            {
                if (MessageBox.Show("Ａモードへ切り替えますか？\nＡモードへ切り替えると設定した属性情報が削除されますが、\n情報部の「移動」、「削除」機能が使える",
                "注意", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
                {
                    this.radioButton1.Checked = true;

                    foreach (var tmp in dic)
                    {
                        tmp.Value.JN_REQRESFLG = null;
                        tmp.Value.JN_PROPERTY2 = null;
                        tmp.Value.JN_PROPERTY3 = null;
                        tmp.Value.JN_PROPERTY4 = null;
                        tmp.Value.JN_PROPERTY5 = null;
                        tmp.Value.JN_PROPERTY6 = null;
                        tmp.Value.JN_PROPERTY7 = null;
                    }

                    this.panel1.Refresh();
                }
            }

        }

        /// <summary>
        /// ジャーナルパターン削除
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {

            if (MessageBox.Show("このジャーナルパターンを削除しますか？\n削除すると復旧できません。",
                "注意", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
            {
                //this.button2.Enabled = false;
                if (jnPattern.JN_PATTERNID != null)
                {
                    using (var context = new Models.DB.mysqlcontext())
                    {
                        bool jp = context.JNPattern.Any(r => r.JN_PATTERNID == jnPattern.JN_PATTERNID);
                        if (jp)
                        {
                            context.Database.ExecuteSqlCommand(String.Format("delete from JNInfoBlock where JN_PATTERNID = {0};delete from JNPattern where JN_PATTERNID = {0}", jnPattern.JN_PATTERNID));
                            context.SaveChanges();
                        }
                    }
                }

                MessageBox.Show("削除は完了しました");
                this.Dispose();
            }

        }

        /// <summary>
        /// DBにジャーナルパターン情報を保存する
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            if (checkInterface(jnPattern))
            {
                //save data to data base
                try
                {
                    jnPattern.JN_ANS = this.textBox5.Text;
                    jnPattern.JN_COMMNENT = this.textBox7.Text;
                    jnPattern.JN_CUPID = this.textBox2.Text;
                    jnPattern.JN_OPTYPE = this.textBox6.Text;
                    jnPattern.JN_PATTERNNO = this.textBox3.Text;
                    jnPattern.JN_TYPE = this.textBox4.Text;

                    //自動採番
                    if (jnPattern.JN_PATTERNID == null)
                        jnPattern.JN_PATTERNID = getPatternID();

                    Models.DB.JNPattern jp = jnPattern;

                    using (var context = new Models.DB.mysqlcontext())
                    {
                        bool exist = context.JNPattern.Any(r => r.JN_PATTERNID == jnPattern.JN_PATTERNID);
                        if (exist)
                        {
                            context.Database.ExecuteSqlCommand(String.Format("delete from JNInfoBlock where JN_PATTERNID = {0};delete from JNPattern where JN_PATTERNID = {0}", jnPattern.JN_PATTERNID));
                        }
                        context.JNPattern.Add(jp);
                        context.SaveChanges();
                    }

                    MessageBox.Show("ジャーナルパターンをDBに保存しました。", "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Dispose();
                }
                catch(Exception exp)
                {
                    logger.Error(exp, "ジャーナルパターンをＤＢに保存する時、エラーが発生しました。");
                    MessageBox.Show("ジャーナルパターンをＤＢに保存する時、エラーが発生しました。", "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// ＤＢの採番関数を使って、採番する
        /// </summary>
        /// <returns></returns>
        private int? getPatternID()
        {
            int? res = null;
            using (var context = new Models.DB.mysqlcontext())
            {
                res = context.Database.SqlQuery<int>("select nextval('JNL')").Single();
            }
            return res;
        }

        /// <summary>
        /// 情報部リストに元素があるかどうかのチェック
        /// 未設定の情報部があるかどうかのチェック
        /// </summary>
        /// <param name="jnPattern"></param>
        private bool checkInterface(JNPattern jnPattern)
        {
            if (jnPattern.JN_INFOBLOCKS.Count < 1)
            {
                MessageBox.Show("ジャーナルパターンに情報部は少なくとも一個が必要です");
                return false;
            }

            if (jnPattern.JN_INFOBLOCKS.Any(r => r.JN_NAME == "未指定の情報部"))
            {
                MessageBox.Show("「未指定の情報部」はまだ残っている");
                return false;
            }

            return true;
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.tabControl1.SelectedTab == this.tabPage2)
            {
                this.Width = 1010;
                this.Height = 686;
            }
            else if (this.tabControl1.SelectedTab == this.tabPage3)
            {
                this.Width = 740;
                this.Height = 370;
            }
        }
    }
}
