﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            JN_Tool.FileLoadForm f = new JN_Tool.FileLoadForm();
            f.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WindowsFormsApp2.Form3 m = new WindowsFormsApp2.Form3();
            m.Show();
        }

        private void Form5_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Owner.Dispose();
        }
    }
}
