﻿using JN_Tool.LGC;
using JN_Tool.Models;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JN_Tool
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.jndatagridview.Rows.Clear();
            this.jndatagridview.Refresh();
            using (var context = new Models.DB.mysqlcontext())
            {
                //context.JNPattern.Add(jp);
                var res = context.JNPattern.Where(r => r.JN_CUPID != null);
                if (res != null)
                {
                    foreach (var tmp in res)
                    {
                        this.jndatagridview.Rows.Add(tmp.JN_PATTERNID, tmp.JN_PATTERNNO, tmp.JN_CUPID, tmp.JN_TYPE);
                    }
                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            MForm f = new MForm();
            f.ShowDialog();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("すべてのジャーナルパターンデータをクリアしますか？\nクリアすると復旧できません。",
                "注意", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            this.jndatagridview.CellDoubleClick += dbc;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
        }

        private void dbc(object sender, DataGridViewCellEventArgs e)
        {
            MForm f = new MForm((int)this.jndatagridview.Rows[e.RowIndex].Cells[0].Value);
            f.ShowDialog();
        }
    }
}
