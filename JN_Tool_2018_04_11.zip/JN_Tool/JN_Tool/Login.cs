﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JN_Tool
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WindowsFormsApp1.Form5 mf = new WindowsFormsApp1.Form5();
            mf.Show(this);
            this.Hide();
        }

        private void Login_Load(object sender, EventArgs e)
        {
            this.comboBox1.DataSource = new List<string>() { "Ｈ３０／０４切替" , "Ｈ３０／０９切替", "Ｈ３１／０２切替" };
        }
    }
}
