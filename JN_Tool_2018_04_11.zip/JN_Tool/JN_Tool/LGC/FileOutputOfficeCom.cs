﻿using JN_Tool.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Excel = Microsoft.Office.Interop.Excel;

namespace JN_Tool.LGC
{
    class FileOutputOfficeCom
    {
        private NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        /// <summary>
        /// 情報部の高さ - 1
        /// </summary>
        public const int BH = 3;
        /// <summary>
        /// 情報部の広さ - 1
        /// </summary>
        public const int BW = 6;

        /// <summary>
        /// サイズ、属性2 3 4 5の高さ - 1
        /// </summary>
        public const int BSH = 1;

        /// <summary>
        /// サイズ属性の高さ
        /// </summary>
        public const int SH = 2;
        /// <summary>
        /// 属性5 の高さ
        /// </summary>
        public const int P5H = 2;
        /// <summary>
        /// 属性3 4 の高さ
        /// </summary>
        public const int P34H = 2;
        /// <summary>
        /// 属性2の高さ
        /// </summary>
        public const int P2H = 2;
        /// <summary>
        /// 属性1の高さ
        /// </summary>
        public const int P1H = 2;
        /// <summary>
        /// 要求回答属性の高さ
        /// </summary>
        public const int RESREQH = 2;

        /// <summary>
        /// 操作種別の起点列
        /// </summary>
        public const int OPCS = 77;
        /// <summary>
        /// 操作種別の終点列
        /// </summary>
        public const int OPCE = 88;

        /// <summary>
        /// ANSの起点列
        /// </summary>
        public const int AS = 89;
        /// <summary>
        /// ANSの終点列
        /// </summary>
        public const int AE = 91;

        /// <summary>
        /// パターン番号の起点列
        /// </summary>
        public const int PS = 92;
        /// <summary>
        /// パターン番号の終点列
        /// </summary>
        public const int PE = 95;

        /// <summary>
        /// 記事の起点列
        /// </summary>
        public const int CS = 96;
        /// <summary>
        /// 記事の終点列
        /// </summary>
        public const int CE = 99;
        /// <summary>
        /// ページの最後行
        /// </summary>
        public const int PageLastRow = 58;

        struct LVL
        {
            /// <summary>
            /// 要求/回答情報描くフラッグ
            /// </summary>
            public bool REQRES;

            /// <summary>
            /// 
            /// </summary>
            public bool L1;

            /// <summary>
            /// 区間１、区間２、先乗列車描くフラッグ
            /// </summary>
            public bool L2;

            /// <summary>
            /// 予約/解約描くフラッグ
            /// </summary>
            public bool L3;
            /// <summary>
            /// 変更前/変更後描くフラッグ
            /// </summary>
            public bool L4;

            /// <summary>
            /// レピート描くフラッグ
            /// </summary>
            public bool L5;


            public int totalHeight;

            /// <summary>
            /// 
            /// </summary>
            public bool L6;
            /// <summary>
            /// 
            /// </summary>
            public bool L7;
        }

        /// <summary>
        /// 属性情報出力各フラッグ
        /// </summary>
        /// <param name="jp"></param>
        /// <param name="p2dic"></param>
        /// <returns></returns>
        private LVL calcLVL(JNPattern jp, Dictionary<string, int> p2dic)
        {
            LVL res;
            res.REQRES = false;
            res.L1 = false;
            res.L2 = false;
            res.L3 = false;
            res.L4 = false;
            res.L5 = false;
            res.L6 = false;
            res.L7 = false;
            res.totalHeight = 0;

            p2dic.Clear();

            if (jp == null || jp.JN_INFOBLOCKS == null || jp.JN_INFOBLOCKS.Count == 0)
                return res;

            for (int i = 0; i < jp.JN_INFOBLOCKS.Count; i++)
            {
                if (!String.IsNullOrWhiteSpace(jp.JN_INFOBLOCKS[i].JN_REQRESFLG))
                {
                    res.REQRES = true;
                }
                if (!String.IsNullOrWhiteSpace(jp.JN_INFOBLOCKS[i].JN_PROPERTY2))
                {
                    res.L2 = true;
                }
                if (!String.IsNullOrWhiteSpace(jp.JN_INFOBLOCKS[i].JN_PROPERTY3))
                {
                    res.L3 = true;
                }
                if (!String.IsNullOrWhiteSpace(jp.JN_INFOBLOCKS[i].JN_PROPERTY4))
                {
                    res.L4 = true;
                }
                if (!String.IsNullOrWhiteSpace(jp.JN_INFOBLOCKS[i].JN_PROPERTY5))
                {
                    res.L5 = true;
                }
                if (!String.IsNullOrWhiteSpace(jp.JN_INFOBLOCKS[i].JN_PROPERTY6))
                {
                    res.L6 = true;
                }
                if (!String.IsNullOrWhiteSpace(jp.JN_INFOBLOCKS[i].JN_PROPERTY7))
                {
                    res.L7 = true;
                }

                if (!String.IsNullOrWhiteSpace(jp.JN_INFOBLOCKS[i].JN_PROPERTY2))
                {
                    if (p2dic.ContainsKey(jp.JN_INFOBLOCKS[i].JN_PROPERTY2))
                    {
                    }
                    else
                    {
                        if (p2dic.Count == 0)
                            p2dic.Add(jp.JN_INFOBLOCKS[i].JN_PROPERTY2, 1);
                        else
                            p2dic.Add(jp.JN_INFOBLOCKS[i].JN_PROPERTY2, p2dic.Values.Max() + 1);
                    }
                }
            }

            int h = BH + 1;
            h += SH;
            if (res.L3 || res.L4)
                h += P34H;
            if (res.REQRES)
                h += RESREQH;
            if (res.L2)
                h += P2H;
            if (res.L5)
                h += P5H;
            h += 1;

            int t1 = 0;
            if (jp.JN_OPTYPE != null)
                t1 += jp.JN_OPTYPE.Split('\n').Length;
            t1 += p2dic.Count;

            int t2 = 0;

            if (jp.JN_INFOBLOCKS.Count <= 10)
            {
                t2 = h;
            }
            else if (jp.JN_INFOBLOCKS.Count <= 20)
            {
                t2 = h * 2;
            }
            else
            {
                //N行と同じ処理
                int totalcnt = jp.JN_INFOBLOCKS.Count;
                List<int> allrow = new List<int>();
                while (totalcnt > 0)
                {
                    if (allrow.Count == 0)
                    {
                        allrow.Add(10);
                        totalcnt -= 10;
                    }
                    else
                    {
                        int r = totalcnt - 8;
                        if (r > 2)
                        {
                            allrow.Add(8);
                            totalcnt = r;
                        }
                        else
                        {
                            allrow.Add(r);
                            totalcnt = 0;
                        }
                    }
                }

                t2 = allrow.Count * h;
            }

            res.totalHeight = t1 > t2 ? t1 : t2;

            return res;
        }

        private void SaveStreamToFile(string fileFullPath, System.IO.Stream stream)
        {
            if (stream.Length == 0) return;
            // Create a FileStream object to write a stream to a file
            using (System.IO.FileStream fileStream = System.IO.File.Create(fileFullPath, (int)stream.Length))
            {
                // Fill the bytes[] array with the stream data
                byte[] bytesInStream = new byte[stream.Length];
                stream.Read(bytesInStream, 0, (int)bytesInStream.Length);

                // Use FileStream object to write to the specified file
                fileStream.Write(bytesInStream, 0, bytesInStream.Length);
            }
        }

        public void writeDataToExcel(List<JNPattern> alldata, string output)
        {
            string template = "tmp.xlsx";

            output = System.IO.Path.Combine(output , "ジャーナルパターン仕様書-" + DateTime.Now.ToString("yyyyMMdd") + ".xlsx");

            System.Reflection.Assembly asm = System.Reflection.Assembly.GetExecutingAssembly();
            string file = null;
            System.IO.Stream fileStream = null;
            var xx = asm.GetManifestResourceNames();
            if (xx != null && xx.Count(r => r != null && r.EndsWith(".T.xlsx")) == 1)
            {
                file = xx.FirstOrDefault(r => r != null && r.EndsWith(".T.xlsx"));
                fileStream = asm.GetManifestResourceStream(file);
                SaveStreamToFile(System.IO.Path.Combine(System.IO.Path.GetTempPath(), template), fileStream);
            }
            Excel.Application xlApp = new Excel.Application();
            //xlApp.Visible = true;
            xlApp.DisplayAlerts = false;
            Excel.Workbook workbook = xlApp.Workbooks.Open(System.IO.Path.Combine(System.IO.Path.GetTempPath(), template));
            Excel.Worksheet tplt = workbook.Sheets[1];
            tplt.Copy(Type.Missing, workbook.Sheets[workbook.Sheets.Count]);
            Excel.Worksheet s = workbook.Sheets[workbook.Sheets.Count];

            int pageIdx = 1;

            s.Name = "P" + pageIdx.ToString("D2");
            //s.Select("A1");
            s.Range["A1", "A1"].Select();

            //タイトル設定
            s.Cells[5, 3].Value = String.Format("表１．３－４－５　　　{0}　{1}　　（１／２）", alldata[0].JN_CUPID, alldata[0].JN_TYPE);
            Dictionary<string, int> p2dic = new Dictionary<string, int>();

            int sr = 9;
            int sr2 = 9;

            for (int i = 0; i < alldata.Count; i++)
            {
                //必要のレベル情報を出力する
                LVL level = calcLVL(alldata[i], p2dic);

                if (level.totalHeight + 2 > 51)
                {
                    //MessageBox.Show("ジャーナルパターンの情報が印刷範囲を超えています");
                    continue;
                }
                else if (level.totalHeight + sr2 > PageLastRow)
                {
                    //MessageBox.Show("Page count out of range");
                    pageIdx++;
                    tplt.Copy(Type.Missing, workbook.Sheets[workbook.Sheets.Count]);
                    s = workbook.Sheets[workbook.Sheets.Count];
                    s.Name = "P" + pageIdx.ToString("D2");
                    //s.Select("A1");
                    s.Range["A1", "A1"].Select();
                    sr = 9;
                    sr2 = 9;
                    s.Cells[5, 3].Value = String.Format("表１．３－４－５　　　{0}　{1}　　（１／２）", alldata[i].JN_CUPID, alldata[i].JN_TYPE);
                }

                //情報部１０以内の場合
                if (alldata[i].JN_INFOBLOCKS.Count <= 10)
                {
                    int sc = 4;
                    int RM1 = 0;
                    int RM2 = 0;
                    bool P34Flag = false;
                    bool P1Flag = false;
                    bool P2Flag = false;
                    bool P5Flag = false;

                    //情報部
                    for (int j = 0; j < alldata[i].JN_INFOBLOCKS.Count; j++)
                    {
                        //情報部ボックス
                        drawJNBlock(s.Range[s.Cells[sr, sc], s.Cells[sr + BH, sc + BW]], alldata[i].JN_INFOBLOCKS[j].JN_NAME);
                        //サイズ情報
                        s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                        s.Range[s.Cells[sr + BH + 1, sc + BW], s.Cells[sr + BH + 1 + BSH, sc + BW]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                        s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                        drawSize(s.Range[s.Cells[sr + BH + 1, sc + 2], s.Cells[sr + BH + 1 + BSH, sc + BW - 2]], alldata[i].JN_INFOBLOCKS[j].JN_SIZE);
                        sc = sc + BW + 1;
                        //PROPERTY2の辞典作成
                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2))
                        {
                            if (p2dic.ContainsKey(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2))
                            {
                                //do nothing
                            }
                            else
                            {
                                if (p2dic.Count == 0)
                                    p2dic.Add(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2, 1);
                                else
                                    p2dic.Add(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2, p2dic.Values.Max() + 1);
                            }
                        }
                    }

                    //情報部ボックス＋サイズ属性
                    RM1 = RM1 + BH + 1 + SH;

                    //予約、解約、変更前、変更後
                    //PROPERTY3、PROPERTY4
                    sc = 4;
                    for (int j = 0; j < alldata[i].JN_INFOBLOCKS.Count; j++)
                    {
                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3))
                        {
                            if (j >= 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY3 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3)
                            {
                                //already set .
                            }
                            else
                            {
                                int endblock = 0;
                                for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                {
                                    if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY3)
                                    {
                                        endblock = k - j - 1;
                                        break;
                                    }
                                    if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                    {
                                        endblock = k - j;
                                    }
                                }
                                P34Flag = true;
                                s.Range[s.Cells[sr + BH + SH + 1, sc], s.Cells[sr + BH + SH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                s.Range[s.Cells[sr + BH + SH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + SH + 1 + BSH, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                s.Range[s.Cells[sr + BH + SH + 1, sc], s.Cells[sr + BH + SH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                drawP3P4(s.Range[s.Cells[sr + BH + SH + 1,
                                    sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                    s.Cells[sr + BH + SH + 1 + BSH,
                                    sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3);
                            }

                        }
                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4))
                        {
                            if (j >= 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY4 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4)
                            {
                                //already set .
                            }
                            else
                            {
                                int endblock = 0;
                                for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                {
                                    if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY4)
                                    {
                                        endblock = k - j - 1;
                                        break;
                                    }
                                    if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                    {
                                        endblock = k - j;
                                    }
                                }
                                P34Flag = true;
                                s.Range[s.Cells[sr + BH + SH + 1, sc], s.Cells[sr + BH + SH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                s.Range[s.Cells[sr + BH + SH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + SH + 1 + BSH, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                s.Range[s.Cells[sr + BH + SH + 1, sc], s.Cells[sr + BH + SH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                drawP3P4(s.Range[s.Cells[sr + BH + SH + 1,
                                    sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                    s.Cells[sr + BH + SH + 1 + BSH,
                                    sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4);
                            }

                        }
                        sc = sc + BW + 1;
                    }
                    if (P34Flag)
                    {
                        RM1 = RM1 + P34H;
                    }

                    //要求回答設定
                    sc = 4;
                    for (int j = 0; j < alldata[i].JN_INFOBLOCKS.Count; j++)
                    {
                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG))
                        {
                            if (j >= 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_REQRESFLG == alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG)
                            {
                                //already set .
                            }
                            else
                            {
                                int endblock = 0;

                                //要求、回答を別々移動しなくて、全体移動
                                for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                {
                                    if (alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG != alldata[i].JN_INFOBLOCKS[k].JN_REQRESFLG)
                                    {
                                        endblock = k - j - 1;
                                        break;
                                    }
                                    if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                    {
                                        endblock = k - j;
                                    }
                                }
                                P1Flag = true;
                                if (P34Flag)
                                {
                                    s.Range[s.Cells[sr + BH + SH + P34H + 1, sc], s.Cells[sr + BH + SH + P34H + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                    s.Range[s.Cells[sr + BH + SH + P34H + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + SH + P34H + 1 + BSH, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                    s.Range[s.Cells[sr + BH + SH + P34H + 1, sc], s.Cells[sr + BH + SH + P34H + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                    drawP3P4(s.Range[s.Cells[sr + BH + SH + P34H + 1,
                                        sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                        s.Cells[sr + BH + SH + P34H + 1 + BSH,
                                        sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG);
                                }
                                else
                                {
                                    s.Range[s.Cells[sr + BH + SH + 1, sc], s.Cells[sr + BH + SH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                    s.Range[s.Cells[sr + BH + SH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + SH + 1 + BSH, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                    s.Range[s.Cells[sr + BH + SH + 1, sc], s.Cells[sr + BH + SH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                    drawP3P4(s.Range[s.Cells[sr + BH + SH + 1,
                                        sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                        s.Cells[sr + BH + SH + 1 + BSH,
                                        sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG);
                                }
                            }

                        }
                        sc = sc + BW + 1;
                    }
                    if (P1Flag)
                    {
                        RM1 = RM1 + P1H;
                    }

                    //PROPERTY2設定
                    sc = 4;
                    for (int j = 0; j < alldata[i].JN_INFOBLOCKS.Count; j++)
                    {
                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2))
                        {
                            if (j >= 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY2 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2)
                            {
                                //already set .
                            }
                            else
                            {
                                int endblock = 0;
                                for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                {
                                    if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY2)
                                    {
                                        endblock = k - j - 1;
                                        break;
                                    }
                                    if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                    {
                                        endblock = k - j;
                                    }
                                }
                                P2Flag = true;
                                int tmpsr = sr;
                                if (P34Flag) tmpsr = tmpsr + P34H;
                                if (P1Flag) tmpsr = tmpsr + P1H;
                                s.Range[s.Cells[tmpsr + BH + SH + 1, sc], s.Cells[tmpsr + BH + SH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDot;
                                s.Range[s.Cells[tmpsr + BH + SH + 1, sc + BW + endblock * (BW + 1)], s.Cells[tmpsr + BH + SH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlDot;
                                s.Range[s.Cells[tmpsr + BH + SH + 1, sc], s.Cells[tmpsr + BH + SH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlDot;
                                drawP3P4(s.Range[s.Cells[tmpsr + BH + SH + 1,
                                    sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                    s.Cells[tmpsr + BH + SH + 1 + BSH,
                                    sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], "＊ " + p2dic[alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2]);
                            }
                        }
                        sc = sc + BW + 1;
                    }
                    if (P2Flag)
                    {
                        RM1 = RM1 + P2H;
                    }

                    //property5
                    //drawing max property will not effect total height
                    sc = 4;
                    for (int j = 0; j < alldata[i].JN_INFOBLOCKS.Count; j++)
                    {
                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5))
                        {
                            if (j >= 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY5 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5 && alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5.StartsWith("*"))
                            {
                                //already set .
                            }
                            else
                            {
                                int endblock = 0;
                                if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5.StartsWith("*"))
                                {
                                    for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                    {
                                        if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY5)
                                        {
                                            endblock = k - j - 1;
                                            break;
                                        }
                                        if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                        {
                                            endblock = k - j;
                                        }
                                    }
                                }
                                P5Flag = true;
                                int tmpsr = sr;
                                if (P34Flag) tmpsr = tmpsr + P34H;
                                if (P1Flag) tmpsr = tmpsr + P1H;
                                if (P2Flag) tmpsr = tmpsr + P5H;
                                s.Range[s.Cells[tmpsr + BH + SH + 1, sc], s.Cells[tmpsr + BH + SH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDot;
                                s.Range[s.Cells[tmpsr + BH + SH + 1, sc + BW + endblock * (BW + 1)], s.Cells[tmpsr + BH + SH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlDot;
                                s.Range[s.Cells[tmpsr + BH + SH + 1, sc], s.Cells[tmpsr + BH + SH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlDot;
                                drawP3P4(s.Range[s.Cells[tmpsr + BH + SH + 1,
                                    sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                    s.Cells[tmpsr + BH + SH + 1 + BSH,
                                    sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5.Replace("*", ""));
                                //drawMax(sr + BH + SH + 1, sc, sc + BW + endblock * (BW + 1) - 1, alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5.Replace("*", ""), s);
                            }

                        }
                        sc = sc + BW + 1;
                    }
                    if (P5Flag)
                    {
                        RM1 = RM1 + P5H;
                    }

                    //操作種別設定
                    if (!String.IsNullOrWhiteSpace(alldata[i].JN_OPTYPE))
                    {
                        string[] arr = alldata[i].JN_OPTYPE.Split('\n');
                        for (int tmpi = 0; tmpi < arr.Length; tmpi++)
                        {
                            if (String.IsNullOrEmpty(arr[tmpi]) || !arr[tmpi].StartsWith(" "))
                            {
                                drawTextLA(s.Range[s.Cells[sr + tmpi, OPCS], s.Cells[sr + tmpi, OPCE]], arr[tmpi]);
                            }
                            else
                            {
                                drawTextRA(s.Range[s.Cells[sr + tmpi, OPCS], s.Cells[sr + tmpi, OPCE]], arr[tmpi]);
                            }
                        }
                        RM2++;
                    }
                    //PROPERTY2が存在する場合、操作種別に出力する
                    RM2 = RM2 + p2dic.Count;

                    //ANS設定
                    if (!String.IsNullOrWhiteSpace(alldata[i].JN_ANS))
                    {
                        string[] arr = alldata[i].JN_ANS.Split('\n');
                        for (int tmpi = 0; tmpi < arr.Length; tmpi++)
                        {

                            drawTextCA(s.Range[s.Cells[sr + tmpi, AS], s.Cells[sr + tmpi, AE]], arr[tmpi]);
                        }
                    }

                    //パターン番号設定
                    if (!String.IsNullOrWhiteSpace(alldata[i].JN_PATTERNNO))
                    {
                        string[] arr = alldata[i].JN_PATTERNNO.Split('\n');
                        for (int tmpi = 0; tmpi < arr.Length; tmpi++)
                        {

                            drawTextCA(s.Range[s.Cells[sr + tmpi, PS], s.Cells[sr + tmpi, PE]], arr[tmpi]);
                        }
                    }

                    //記事設定
                    int totalHeight = RM1 > RM2 ? RM1 : RM2;
                    if (!String.IsNullOrWhiteSpace(alldata[i].JN_COMMNENT))
                    {
                        drawTextLTA(s.Range[s.Cells[sr, CS], s.Cells[sr + totalHeight, CE]], alldata[i].JN_COMMNENT);
                    }
                    //PROPERTY2文字辞典設定
                    if (p2dic.Count > 0)
                    {
                        var lst = p2dic.OrderByDescending(r => r.Value);
                        int ri = 0;
                        foreach (var ttmp in lst)
                        {
                            drawTextLA(s.Range[s.Cells[sr + totalHeight - ri, OPCS], s.Cells[sr + totalHeight - ri, OPCE]], "*" + ttmp.Value + ":" + ttmp.Key);
                            ri++;
                        }
                    }

                    //Totalサイズ設定
                    drawTextRA2(s.Cells[sr + totalHeight, OPCS - 2], alldata[i].JN_INFOBLOCKS.Sum(r => r.JN_SIZE).ToString());

                    //番号つける
                    drawTextCA2(s.Cells[sr, 2], (i + 1).ToString());

                    int lr = sr + totalHeight + 1;
                    //枠線
                    //bottom line
                    s.Range[s.Cells[lr, 2], s.Cells[lr, CE]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                    //left line
                    s.Range[s.Cells[sr - 1, 2], s.Cells[lr, 2]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                    s.Range[s.Cells[sr - 1, 2], s.Cells[lr, 2]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                    //right line
                    s.Range[s.Cells[sr - 1, CE], s.Cells[lr, CE]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                    //inside line
                    s.Range[s.Cells[sr - 1, OPCS], s.Cells[lr, OPCS]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                    s.Range[s.Cells[sr - 1, AS], s.Cells[lr, AS]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                    s.Range[s.Cells[sr - 1, PS], s.Cells[lr, PS]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                    s.Range[s.Cells[sr - 1, CS], s.Cells[lr, CS]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;

                    sr = lr + 2;
                    sr2 = sr;
                }
                else
                {
                    //情報部は１０個以上の場合
                    var ansfirst = alldata[i].JN_INFOBLOCKS.FirstOrDefault(r => r.JN_REQRESFLG == "回答");
                    int location = 0;
                    if (ansfirst != null)
                        location = alldata[i].JN_INFOBLOCKS.IndexOf(ansfirst);

                    int left = alldata[i].JN_INFOBLOCKS.Count - location;

                    //丁度二行に出力される場合
                    if (location <= 10 && left <= 10)
                    {
                        int sc = 4;

                        //一行目の情報部
                        for (int j = 0; j < location; j++)
                        {
                            //情報部ボックス
                            drawJNBlock(s.Range[s.Cells[sr, sc], s.Cells[sr + BH, sc + BW]], alldata[i].JN_INFOBLOCKS[j].JN_NAME);
                            //サイズ情報
                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                            s.Range[s.Cells[sr + BH + 1, sc + BW], s.Cells[sr + BH + 1 + BSH, sc + BW]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                            drawSize(s.Range[s.Cells[sr + BH + 1, sc + 2], s.Cells[sr + BH + 1 + BSH, sc + BW - 2]], alldata[i].JN_INFOBLOCKS[j].JN_SIZE);
                            sc = sc + BW + 1;
                        }
                        //右側の短線
                        s.Cells[sr, sc].Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle = Excel.XlLineStyle.xlContinuous;
                        s.Cells[sr + BH, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                        s.Cells[sr + BH + 1, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                        sr = sr + SH;

                        //予約、解約、変更前、変更後
                        //PROPERTY3、PROPERTY4
                        if (level.L3 || level.L4)
                        {
                            sc = 4;
                            for (int j = 0; j < location; j++)
                            {
                                if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3))
                                {
                                    if (j >= 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY3 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3)
                                    {
                                        //already set .
                                    }
                                    else
                                    {
                                        int endblock = 0;
                                        bool tmpflg = false;
                                        for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                        {
                                            if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY3)
                                            {
                                                if (k > location) tmpflg = true;
                                                endblock = k - j - 1;
                                                break;
                                            }
                                            if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                            {
                                                if (k >= location) tmpflg = true;
                                                endblock = k - j;
                                            }
                                        }
                                        if (endblock == 0) tmpflg = false;
                                        if (tmpflg)
                                        {
                                            endblock = location - j - 1;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            //s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1), sr + BH + 1 + BSH, sc + BW + endblock * (BW + 1)].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                s.Cells[sr + BH + 1 + BSH,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3);
                                        }
                                        else
                                        {
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1 + BSH, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                s.Cells[sr + BH + 1 + BSH,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3);
                                        }

                                    }

                                }
                                if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4))
                                {
                                    if (j >= 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY4 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4)
                                    {
                                        //already set .
                                    }
                                    else
                                    {
                                        int endblock = 0;
                                        bool tmpflg = false;
                                        for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                        {
                                            if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY4)
                                            {
                                                if (k > location) tmpflg = true;
                                                endblock = k - j - 1;
                                                break;
                                            }
                                            if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                            {
                                                if (k >= location) tmpflg = true;
                                                endblock = k - j;
                                            }
                                        }
                                        if (endblock == 0) tmpflg = false;
                                        if (tmpflg)
                                        {
                                            endblock = location - j - 1;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                s.Cells[sr + BH + 1 + BSH,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4);
                                        }
                                        else
                                        {
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1 + BSH, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                s.Cells[sr + BH + 1 + BSH,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4);
                                        }
                                    }
                                }
                                sc = sc + BW + 1;
                            }

                            //右側の短線
                            if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY3 + alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY4)
                                && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY3 + alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY4))
                                s.Cells[sr + BH + 1, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                            sr = sr + P34H;
                        }

                        //要求回答設定
                        if (level.REQRES)
                        {
                            sc = 4;
                            for (int j = 0; j < location; j++)
                            {
                                if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG))
                                {
                                    if (j >= 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_REQRESFLG == alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG)
                                    {
                                        //already set .
                                    }
                                    else
                                    {
                                        int endblock = 0;
                                        bool tmpflg = false;
                                        for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                        {
                                            if (alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG != alldata[i].JN_INFOBLOCKS[k].JN_REQRESFLG)
                                            {
                                                if (k > location) tmpflg = true;
                                                endblock = k - j - 1;
                                                break;
                                            }
                                            if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                            {
                                                endblock = k - j;
                                                if (k > location) tmpflg = true;
                                            }
                                        }
                                        if (endblock == 0) tmpflg = false;
                                        if (tmpflg)
                                        {
                                            endblock = location - j - 1;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                s.Cells[sr + BH + 1 + BSH,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG);
                                        }
                                        else
                                        {
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1 + BSH, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                            drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                s.Cells[sr + BH + 1 + BSH,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG);
                                        }

                                    }
                                }
                                sc = sc + BW + 1;
                            }

                            //右側の短線
                            if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_REQRESFLG)
                                && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_REQRESFLG))
                                s.Cells[sr + BH + 1, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                            sr = sr + RESREQH;
                        }

                        //PROPERTY2設定
                        if (level.L2)
                        {
                            sc = 4;
                            for (int j = 0; j < location; j++)
                            {
                                if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2))
                                {
                                    if (j >= 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY2 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2)
                                    {
                                        //already set .
                                    }
                                    else
                                    {
                                        int endblock = 0;
                                        bool tmpflg = false;
                                        for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                        {
                                            if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY2)
                                            {
                                                if (k > location) tmpflg = true;
                                                endblock = k - j - 1;
                                                break;
                                            }
                                            if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                            {
                                                if (k > location) tmpflg = true;
                                                endblock = k - j;
                                            }
                                        }
                                        if (endblock == 0) tmpflg = false;
                                        if (tmpflg)
                                        {
                                            endblock = location - j - 1;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDot;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlDot;
                                            drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                s.Cells[sr + BH + 1 + BSH,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], "＊ " + p2dic[alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2]);
                                        }
                                        else
                                        {
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDot;
                                            s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlDot;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlDot;
                                            drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                s.Cells[sr + BH + 1 + BSH,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], "＊ " + p2dic[alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2]);
                                        }

                                    }
                                }
                                sc = sc + BW + 1;
                            }

                            if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY2)
                                && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY2))
                                s.Cells[sr + BH + 1, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlDot;

                            sr = sr + P2H;
                        }

                        //property5
                        if (level.L5)
                        {
                            sc = 4;
                            for (int j = 0; j < location; j++)
                            {
                                if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5))
                                {
                                    if (j >= 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY5 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5 && alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5.StartsWith("*"))
                                    {
                                        //already set .
                                    }
                                    else
                                    {
                                        int endblock = 0;
                                        bool tmpflg = false;
                                        if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5.StartsWith("*"))
                                        {
                                            for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                            {
                                                if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY5)
                                                {
                                                    if (k > location) tmpflg = true;
                                                    endblock = k - j - 1;
                                                    break;
                                                }
                                                if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                                {
                                                    if (k > location) tmpflg = true;
                                                    endblock = k - j;
                                                }
                                            }
                                        }
                                        if (endblock == 0) tmpflg = false;
                                        if (tmpflg)
                                        {
                                            endblock = location - j - 1;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDot;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlDot;
                                            drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                s.Cells[sr + BH + 1 + BSH,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5.Replace("*", ""));
                                        }
                                        else
                                        {
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDot;
                                            s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlDot;
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlDot;
                                            drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                s.Cells[sr + BH + 1 + BSH,
                                                sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5.Replace("*", ""));
                                        }
                                    }

                                }
                                sc = sc + BW + 1;
                            }

                            if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY5)
                                && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY5))
                                s.Cells[sr + BH + 1, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlDot;

                            sr = sr + P5H;
                        }

                        //二行目
                        //二行目
                        //二行目

                        sc = 4 + 1;
                        sc = sc + (BW + 1) * (10 - (alldata[i].JN_INFOBLOCKS.Count - location));
                        //情報部ボックスの高　＋　下の一行移動
                        sr = sr + BH + 1 + 1;

                        //左側の短線
                        s.Cells[sr, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle = Excel.XlLineStyle.xlContinuous;
                        s.Cells[sr + BH, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                        s.Cells[sr + BH + 1, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                        for (int j = location; j < alldata[i].JN_INFOBLOCKS.Count; j++)
                        {
                            //情報部ボックス
                            drawJNBlock(s.Range[s.Cells[sr, sc], s.Cells[sr + BH, sc + BW]], alldata[i].JN_INFOBLOCKS[j].JN_NAME);
                            //サイズ情報
                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                            s.Range[s.Cells[sr + BH + 1, sc + BW], s.Cells[sr + BH + 1 + BSH, sc + BW]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                            drawSize(s.Range[s.Cells[sr + BH + 1, sc + 2], s.Cells[sr + BH + 1 + BSH, sc + BW - 2]], alldata[i].JN_INFOBLOCKS[j].JN_SIZE);
                            sc = sc + BW + 1;
                        }
                        sr = sr + SH;

                        //予約、解約、変更前、変更後
                        //PROPERTY3、PROPERTY4
                        if (level.L3 || level.L4)
                        {
                            sc = 4 + 1;
                            sc = sc + (BW + 1) * (10 - (alldata[i].JN_INFOBLOCKS.Count - location));

                            //先頭の短線
                            if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY3 + alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY4)
                                && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY3 + alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY4))
                                s.Cells[sr + BH + 1, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                            for (int j = location; j < alldata[i].JN_INFOBLOCKS.Count; j++)
                            {
                                if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3))
                                {
                                    if (j >= location + 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY3 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3)
                                    {
                                        //already set .
                                    }
                                    else
                                    {
                                        int endblock = 0;
                                        for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                        {
                                            if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY3)
                                            {
                                                endblock = k - j - 1;
                                                break;
                                            }
                                            if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                            {
                                                endblock = k - j;
                                            }
                                        }
                                        if (alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY3 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3
                                            && j == location)
                                        {
                                            //前行の最後の元素と同じ場合
                                        }
                                        else
                                        {
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        }
                                        s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1 + BSH, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                            s.Cells[sr + BH + 1 + BSH,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3);
                                    }

                                }
                                if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4))
                                {
                                    if (j >= location + 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY4 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4)
                                    {
                                        //already set .
                                    }
                                    else
                                    {
                                        int endblock = 0;
                                        for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                        {
                                            if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY4)
                                            {
                                                endblock = k - j - 1;
                                                break;
                                            }
                                            if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                            {
                                                endblock = k - j;
                                            }
                                        }

                                        if (alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY4 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4
                                            && j == location)
                                        {
                                            //前行の最後の元素と同じ場合
                                        }
                                        else
                                        {
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        }

                                        s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1 + BSH, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                            s.Cells[sr + BH + 1 + BSH,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4);
                                    }
                                }
                                sc = sc + BW + 1;
                            }

                            sr = sr + P34H;
                        }

                        //要求回答設定
                        if (level.REQRES)
                        {
                            sc = 4 + 1;
                            sc = sc + (BW + 1) * (10 - (alldata[i].JN_INFOBLOCKS.Count - location));

                            //先頭の短線
                            if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_REQRESFLG)
                                && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_REQRESFLG))
                                s.Cells[sr + BH + 1, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                            for (int j = location; j < alldata[i].JN_INFOBLOCKS.Count; j++)
                            {
                                if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG))
                                {
                                    if (j >= location + 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_REQRESFLG == alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG)
                                    {
                                        //already set .
                                    }
                                    else
                                    {
                                        int endblock = 0;
                                        for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                        {
                                            if (alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG != alldata[i].JN_INFOBLOCKS[k].JN_REQRESFLG)
                                            {
                                                endblock = k - j - 1;
                                                break;
                                            }
                                            if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                            {
                                                endblock = k - j;
                                            }
                                        }

                                        if (alldata[i].JN_INFOBLOCKS[j - 1].JN_REQRESFLG == alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG
                                            && j == location)
                                        {
                                            //前行の最後の元素と同じ場合
                                        }
                                        else
                                        {
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        }
                                        //s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1 + BSH, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                        drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                            s.Cells[sr + BH + 1 + BSH,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG);
                                    }
                                }
                                sc = sc + BW + 1;
                            }

                            sr = sr + RESREQH;
                        }

                        //PROPERTY2設定
                        if (level.L2)
                        {
                            sc = 4 + 1;
                            sc = sc + (BW + 1) * (10 - (alldata[i].JN_INFOBLOCKS.Count - location));

                            //先頭の短線
                            if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY2)
                                && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY2))
                                s.Cells[sr + BH + 1, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlDot;

                            for (int j = location; j < alldata[i].JN_INFOBLOCKS.Count; j++)
                            {
                                if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2))
                                {
                                    if (j >= location + 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY2 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2)
                                    {
                                        //already set .
                                    }
                                    else
                                    {
                                        int endblock = 0;
                                        for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                        {
                                            if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY2)
                                            {
                                                endblock = k - j - 1;
                                                break;
                                            }
                                            if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                            {
                                                endblock = k - j;
                                            }
                                        }
                                        if (alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY2 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2
                                            && j == location)
                                        {
                                            //前行の最後の元素と同じ場合
                                        }
                                        else
                                        {
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDot;
                                        }
                                        s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlDot;
                                        s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlDot;
                                        drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                            s.Cells[sr + BH + 1 + BSH,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], "＊ " + p2dic[alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2]);
                                    }
                                }
                                sc = sc + BW + 1;
                            }

                            sr = sr + P2H;
                        }

                        //property5
                        //MAX(N)
                        if (level.L5)
                        {
                            sc = 4 + 1;
                            sc = sc + (BW + 1) * (10 - (alldata[i].JN_INFOBLOCKS.Count - location));

                            //先頭の短線
                            if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY5)
                                && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY5))
                                s.Cells[sr + BH + 1, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlDot;

                            for (int j = location; j < alldata[i].JN_INFOBLOCKS.Count; j++)
                            {
                                if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5))
                                {
                                    if (j >= location + 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY5 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5 && alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5.StartsWith("*"))
                                    {
                                        //already set .
                                    }
                                    else
                                    {
                                        int endblock = 0;
                                        if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5.StartsWith("*"))
                                        {
                                            for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                            {
                                                if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY5)
                                                {
                                                    endblock = k - j - 1;
                                                    break;
                                                }
                                                if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                                {
                                                    endblock = k - j;
                                                }
                                            }
                                        }
                                        if (alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY5 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5
                                            && j == location)
                                        {
                                            //前行の最後の元素と同じ場合
                                        }
                                        else
                                        {
                                            s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDot;
                                        }
                                        //s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDot;
                                        s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlDot;
                                        s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlDot;
                                        drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                            s.Cells[sr + BH + 1 + BSH,
                                            sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5.Replace("*", ""));

                                    }

                                }
                                sc = sc + BW + 1;
                            }

                            sr = sr + P5H;
                        }

                        //操作種別設定
                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_OPTYPE))
                        {
                            string[] arr = alldata[i].JN_OPTYPE.Split('\n');
                            for (int tmpi = 0; tmpi < arr.Length; tmpi++)
                            {
                                if (String.IsNullOrEmpty(arr[tmpi]) || !arr[tmpi].StartsWith(" "))
                                {
                                    drawTextLA(s.Range[s.Cells[sr2 + tmpi, OPCS], s.Cells[sr2 + tmpi, OPCE]], arr[tmpi]);
                                }
                                else
                                {
                                    drawTextRA(s.Range[s.Cells[sr2 + tmpi, OPCS], s.Cells[sr2 + tmpi, OPCE]], arr[tmpi]);
                                }
                            }
                        }

                        //ANS設定
                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_ANS))
                        {
                            string[] arr = alldata[i].JN_ANS.Split('\n');
                            for (int tmpi = 0; tmpi < arr.Length; tmpi++)
                            {

                                drawTextCA(s.Range[s.Cells[sr2 + tmpi, AS], s.Cells[sr2 + tmpi, AE]], arr[tmpi]);
                            }
                        }

                        //パターン番号設定
                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_PATTERNNO))
                        {
                            string[] arr = alldata[i].JN_PATTERNNO.Split('\n');
                            for (int tmpi = 0; tmpi < arr.Length; tmpi++)
                            {

                                drawTextCA(s.Range[s.Cells[sr2 + tmpi, PS], s.Cells[sr2 + tmpi, PE]], arr[tmpi]);
                            }
                        }

                        //記事設定
                        //int totalHeight = 0;
                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_COMMNENT))
                        {
                            drawTextLTA(s.Range[s.Cells[sr2, CS], s.Cells[sr2 + level.totalHeight, CE]], alldata[i].JN_COMMNENT);
                        }
                        //PROPERTY2文字辞典設定
                        if (p2dic.Count > 0)
                        {
                            var lst = p2dic.OrderByDescending(r => r.Value);
                            int ri = 0;
                            foreach (var ttmp in lst)
                            {
                                ri++;
                                drawTextLA(s.Range[s.Cells[sr2 + level.totalHeight - ri, OPCS], s.Cells[sr2 + level.totalHeight - ri, OPCE]], "*" + ttmp.Value + ":" + ttmp.Key);
                            }
                        }

                        //Totalサイズ設定
                        drawTextRA2(s.Cells[sr2 + level.totalHeight - 1, OPCS - 2], alldata[i].JN_INFOBLOCKS.Sum(r => r.JN_SIZE).ToString());

                        //番号つける
                        drawTextCA2(s.Cells[sr2, 2], (i + 1).ToString());

                        int lr = sr2 + level.totalHeight;
                        //枠線
                        //bottom line
                        s.Range[s.Cells[lr, 2], s.Cells[lr, CE]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                        //left line
                        s.Range[s.Cells[sr2 - 1, 2], s.Cells[lr, 2]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                        s.Range[s.Cells[sr2 - 1, 2], s.Cells[lr, 2]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                        //right line
                        s.Range[s.Cells[sr2 - 1, CE], s.Cells[lr, CE]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                        //inside line
                        s.Range[s.Cells[sr2 - 1, OPCS], s.Cells[lr, OPCS]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                        s.Range[s.Cells[sr2 - 1, AS], s.Cells[lr, AS]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                        s.Range[s.Cells[sr2 - 1, PS], s.Cells[lr, PS]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                        s.Range[s.Cells[sr2 - 1, CS], s.Cells[lr, CS]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;

                        sr = lr + 2;
                        sr2 = lr + 2;

                    }
                    else
                    {
                        //N行と同じ処理
                        int totalcnt = alldata[i].JN_INFOBLOCKS.Count;
                        List<int> allrow = new List<int>();
                        while (totalcnt > 0)
                        {
                            if (allrow.Count == 0)
                            {
                                allrow.Add(10);
                                totalcnt -= 10;
                            }
                            else
                            {
                                int res = totalcnt - 8;
                                if (res > 2)
                                {
                                    allrow.Add(8);
                                    totalcnt = res;
                                }
                                else
                                {
                                    allrow.Add(totalcnt);
                                    totalcnt = 0;
                                }
                            }
                        }

                        //
                        for (int lstid = 0; lstid < allrow.Count; lstid++)
                        {
                            if (lstid == 0)
                            {
                                //first row
                                int sc = 4;
                                location = 10;

                                //一行目の情報部
                                for (int j = 0; j < location; j++)
                                {
                                    //情報部ボックス
                                    drawJNBlock(s.Range[s.Cells[sr, sc], s.Cells[sr + BH, sc + BW]], alldata[i].JN_INFOBLOCKS[j].JN_NAME);
                                    //サイズ情報
                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                    s.Range[s.Cells[sr + BH + 1, sc + BW], s.Cells[sr + BH + 1 + BSH, sc + BW]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                    drawSize(s.Range[s.Cells[sr + BH + 1, sc + 2], s.Cells[sr + BH + 1 + BSH, sc + BW - 2]], alldata[i].JN_INFOBLOCKS[j].JN_SIZE);
                                    sc = sc + BW + 1;
                                }
                                //右側の短線
                                s.Cells[sr, sc].Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle = Excel.XlLineStyle.xlContinuous;
                                s.Cells[sr + BH, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                s.Cells[sr + BH + 1, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                sr = sr + SH;

                                //予約、解約、変更前、変更後
                                //PROPERTY3、PROPERTY4
                                if (level.L3 || level.L4)
                                {
                                    sc = 4;
                                    for (int j = 0; j < location; j++)
                                    {
                                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3))
                                        {
                                            if (j >= 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY3 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3)
                                            {
                                                //already set .
                                            }
                                            else
                                            {
                                                int endblock = 0;
                                                bool tmpflg = false;
                                                for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                                {
                                                    if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY3)
                                                    {
                                                        if (k > location) tmpflg = true;
                                                        endblock = k - j - 1;
                                                        break;
                                                    }
                                                    if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                                    {
                                                        if (k >= location) tmpflg = true;
                                                        endblock = k - j;
                                                    }
                                                }
                                                if (endblock == 0) tmpflg = false;
                                                if (tmpflg)
                                                {
                                                    endblock = location - j - 1;
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                    //s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1), sr + BH + 1 + BSH, sc + BW + endblock * (BW + 1)].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                    drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                        sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                        s.Cells[sr + BH + 1 + BSH,
                                                        sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3);
                                                }
                                                else
                                                {
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                    s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1 + BSH, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                    drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                        sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                        s.Cells[sr + BH + 1 + BSH,
                                                        sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3);
                                                }

                                            }

                                        }
                                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4))
                                        {
                                            if (j >= 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY4 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4)
                                            {
                                                //already set .
                                            }
                                            else
                                            {
                                                int endblock = 0;
                                                bool tmpflg = false;
                                                for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                                {
                                                    if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY4)
                                                    {
                                                        if (k > location) tmpflg = true;
                                                        endblock = k - j - 1;
                                                        break;
                                                    }
                                                    if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                                    {
                                                        if (k >= location) tmpflg = true;
                                                        endblock = k - j;
                                                    }
                                                }
                                                if (endblock == 0) tmpflg = false;
                                                if (tmpflg)
                                                {
                                                    endblock = location - j - 1;
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                    drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                        sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                        s.Cells[sr + BH + 1 + BSH,
                                                        sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4);
                                                }
                                                else
                                                {
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                    s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1 + BSH, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                    drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                        sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                        s.Cells[sr + BH + 1 + BSH,
                                                        sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4);
                                                }
                                            }
                                        }
                                        sc = sc + BW + 1;
                                    }

                                    //右側の短線
                                    if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY3 + alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY4)
                                        && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY3 + alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY4))
                                        s.Cells[sr + BH + 1, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                                    sr = sr + P34H;
                                }

                                //要求回答設定
                                if (level.REQRES)
                                {
                                    sc = 4;
                                    for (int j = 0; j < location; j++)
                                    {
                                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG))
                                        {
                                            if (j >= 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_REQRESFLG == alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG)
                                            {
                                                //already set .
                                            }
                                            else
                                            {
                                                int endblock = 0;
                                                bool tmpflg = false;
                                                for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                                {
                                                    if (alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG != alldata[i].JN_INFOBLOCKS[k].JN_REQRESFLG)
                                                    {
                                                        if (k > location) tmpflg = true;
                                                        endblock = k - j - 1;
                                                        break;
                                                    }
                                                    if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                                    {
                                                        endblock = k - j;
                                                        if (k > location) tmpflg = true;
                                                    }
                                                }
                                                if (endblock == 0) tmpflg = false;
                                                if (tmpflg)
                                                {
                                                    endblock = location - j - 1;
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                    drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                        sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                        s.Cells[sr + BH + 1 + BSH,
                                                        sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG);
                                                }
                                                else
                                                {
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                    s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1 + BSH, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                    drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                        sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                        s.Cells[sr + BH + 1 + BSH,
                                                        sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG);
                                                }

                                            }
                                        }
                                        sc = sc + BW + 1;
                                    }

                                    //右側の短線
                                    if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_REQRESFLG)
                                        && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_REQRESFLG))
                                        s.Cells[sr + BH + 1, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                                    sr = sr + RESREQH;
                                }

                                //PROPERTY2設定
                                if (level.L2)
                                {
                                    sc = 4;
                                    for (int j = 0; j < location; j++)
                                    {
                                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2))
                                        {
                                            if (j >= 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY2 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2)
                                            {
                                                //already set .
                                            }
                                            else
                                            {
                                                int endblock = 0;
                                                bool tmpflg = false;
                                                for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                                {
                                                    if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY2)
                                                    {
                                                        if (k > location) tmpflg = true;
                                                        endblock = k - j - 1;
                                                        break;
                                                    }
                                                    if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                                    {
                                                        if (k > location) tmpflg = true;
                                                        endblock = k - j;
                                                    }
                                                }
                                                if (endblock == 0) tmpflg = false;
                                                if (tmpflg)
                                                {
                                                    endblock = location - j - 1;
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDot;
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlDot;
                                                    drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                        sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                        s.Cells[sr + BH + 1 + BSH,
                                                        sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], "＊ " + p2dic[alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2]);
                                                }
                                                else
                                                {
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDot;
                                                    s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlDot;
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlDot;
                                                    drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                        sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                        s.Cells[sr + BH + 1 + BSH,
                                                        sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], "＊ " + p2dic[alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2]);
                                                }

                                            }
                                        }
                                        sc = sc + BW + 1;
                                    }

                                    if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY2)
                                        && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY2))
                                        s.Cells[sr + BH + 1, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlDot;

                                    sr = sr + P2H;
                                }

                                //property5
                                if (level.L5)
                                {
                                    sc = 4;
                                    for (int j = 0; j < location; j++)
                                    {
                                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5))
                                        {
                                            if (j >= 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY5 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5 && alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5.StartsWith("*"))
                                            {
                                                //already set .
                                            }
                                            else
                                            {
                                                int endblock = 0;
                                                bool tmpflg = false;
                                                if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5.StartsWith("*"))
                                                {
                                                    for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                                    {
                                                        if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY5)
                                                        {
                                                            if (k > location) tmpflg = true;
                                                            endblock = k - j - 1;
                                                            break;
                                                        }
                                                        if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                                        {
                                                            if (k > location) tmpflg = true;
                                                            endblock = k - j;
                                                        }
                                                    }
                                                }
                                                if (endblock == 0) tmpflg = false;
                                                if (tmpflg)
                                                {
                                                    endblock = location - j - 1;
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDot;
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlDot;
                                                    drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                        sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                        s.Cells[sr + BH + 1 + BSH,
                                                        sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5.Replace("*", ""));
                                                }
                                                else
                                                {
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDot;
                                                    s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlDot;
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlDot;
                                                    drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                        sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                        s.Cells[sr + BH + 1 + BSH,
                                                        sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5.Replace("*", ""));
                                                }
                                            }

                                        }
                                        sc = sc + BW + 1;
                                    }

                                    if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY5)
                                        && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY5))
                                        s.Cells[sr + BH + 1, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlDot;

                                    sr = sr + P5H;
                                }
                            }
                            else if (lstid == allrow.Count - 1)
                            {
                                //last row

                                int sc = 4 + 1;
                                location = 10 + (lstid - 1) * 8;
                                sc = sc + (BW + 1) * (10 - (alldata[i].JN_INFOBLOCKS.Count - location));
                                //情報部ボックスの高　＋　下の一行移動
                                sr = sr + BH + 1 + 1;

                                //左側の短線
                                s.Cells[sr, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle = Excel.XlLineStyle.xlContinuous;
                                s.Cells[sr + BH, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                s.Cells[sr + BH + 1, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                for (int j = location; j < alldata[i].JN_INFOBLOCKS.Count; j++)
                                {
                                    //情報部ボックス
                                    drawJNBlock(s.Range[s.Cells[sr, sc], s.Cells[sr + BH, sc + BW]], alldata[i].JN_INFOBLOCKS[j].JN_NAME);
                                    //サイズ情報
                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                    s.Range[s.Cells[sr + BH + 1, sc + BW], s.Cells[sr + BH + 1 + BSH, sc + BW]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                    drawSize(s.Range[s.Cells[sr + BH + 1, sc + 2], s.Cells[sr + BH + 1 + BSH, sc + BW - 2]], alldata[i].JN_INFOBLOCKS[j].JN_SIZE);
                                    sc = sc + BW + 1;
                                }
                                sr = sr + SH;

                                //予約、解約、変更前、変更後
                                //PROPERTY3、PROPERTY4
                                if (level.L3 || level.L4)
                                {
                                    sc = 4 + 1;
                                    sc = sc + (BW + 1) * (10 - (alldata[i].JN_INFOBLOCKS.Count - location));

                                    //先頭の短線
                                    if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY3 + alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY4)
                                        && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY3 + alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY4))
                                        s.Cells[sr + BH + 1, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                                    for (int j = location; j < alldata[i].JN_INFOBLOCKS.Count; j++)
                                    {
                                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3))
                                        {
                                            if (j >= location + 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY3 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3)
                                            {
                                                //already set .
                                            }
                                            else
                                            {
                                                int endblock = 0;
                                                for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                                {
                                                    if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY3)
                                                    {
                                                        endblock = k - j - 1;
                                                        break;
                                                    }
                                                    if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                                    {
                                                        endblock = k - j;
                                                    }
                                                }
                                                if (alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY3 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3
                                                    && j == location)
                                                {
                                                    //前行の最後の元素と同じ場合
                                                }
                                                else
                                                {
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                }
                                                s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1 + BSH, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                    sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                    s.Cells[sr + BH + 1 + BSH,
                                                    sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3);
                                            }

                                        }
                                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4))
                                        {
                                            if (j >= location + 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY4 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4)
                                            {
                                                //already set .
                                            }
                                            else
                                            {
                                                int endblock = 0;
                                                for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                                {
                                                    if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY4)
                                                    {
                                                        endblock = k - j - 1;
                                                        break;
                                                    }
                                                    if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                                    {
                                                        endblock = k - j;
                                                    }
                                                }

                                                if (alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY4 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4
                                                    && j == location)
                                                {
                                                    //前行の最後の元素と同じ場合
                                                }
                                                else
                                                {
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                }

                                                s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1 + BSH, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                    sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                    s.Cells[sr + BH + 1 + BSH,
                                                    sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4);
                                            }
                                        }
                                        sc = sc + BW + 1;
                                    }

                                    sr = sr + P34H;
                                }

                                //要求回答設定
                                if (level.REQRES)
                                {
                                    sc = 4 + 1;
                                    sc = sc + (BW + 1) * (10 - (alldata[i].JN_INFOBLOCKS.Count - location));

                                    //先頭の短線
                                    if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_REQRESFLG)
                                        && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_REQRESFLG))
                                        s.Cells[sr + BH + 1, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                                    for (int j = location; j < alldata[i].JN_INFOBLOCKS.Count; j++)
                                    {
                                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG))
                                        {
                                            if (j >= location + 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_REQRESFLG == alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG)
                                            {
                                                //already set .
                                            }
                                            else
                                            {
                                                int endblock = 0;
                                                for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                                {
                                                    if (alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG != alldata[i].JN_INFOBLOCKS[k].JN_REQRESFLG)
                                                    {
                                                        endblock = k - j - 1;
                                                        break;
                                                    }
                                                    if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                                    {
                                                        endblock = k - j;
                                                    }
                                                }

                                                if (alldata[i].JN_INFOBLOCKS[j - 1].JN_REQRESFLG == alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG
                                                    && j == location)
                                                {
                                                    //前行の最後の元素と同じ場合
                                                }
                                                else
                                                {
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                }
                                                //s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1 + BSH, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                    sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                    s.Cells[sr + BH + 1 + BSH,
                                                    sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG);
                                            }
                                        }
                                        sc = sc + BW + 1;
                                    }

                                    sr = sr + RESREQH;
                                }

                                //PROPERTY2設定
                                if (level.L2)
                                {
                                    sc = 4 + 1;
                                    sc = sc + (BW + 1) * (10 - (alldata[i].JN_INFOBLOCKS.Count - location));

                                    //先頭の短線
                                    if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY2)
                                        && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY2))
                                        s.Cells[sr + BH + 1, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlDot;

                                    for (int j = location; j < alldata[i].JN_INFOBLOCKS.Count; j++)
                                    {
                                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2))
                                        {
                                            if (j >= location + 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY2 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2)
                                            {
                                                //already set .
                                            }
                                            else
                                            {
                                                int endblock = 0;
                                                for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                                {
                                                    if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY2)
                                                    {
                                                        endblock = k - j - 1;
                                                        break;
                                                    }
                                                    if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                                    {
                                                        endblock = k - j;
                                                    }
                                                }
                                                if (alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY2 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2
                                                    && j == location)
                                                {
                                                    //前行の最後の元素と同じ場合
                                                }
                                                else
                                                {
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDot;
                                                }
                                                s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlDot;
                                                s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlDot;
                                                drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                    sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                    s.Cells[sr + BH + 1 + BSH,
                                                    sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], "＊ " + p2dic[alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2]);
                                            }
                                        }
                                        sc = sc + BW + 1;
                                    }

                                    sr = sr + P2H;
                                }

                                //property5
                                //MAX(N)
                                if (level.L5)
                                {
                                    sc = 4 + 1;
                                    sc = sc + (BW + 1) * (10 - (alldata[i].JN_INFOBLOCKS.Count - location));

                                    //先頭の短線
                                    if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY5)
                                        && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY5))
                                        s.Cells[sr + BH + 1, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlDot;

                                    for (int j = location; j < alldata[i].JN_INFOBLOCKS.Count; j++)
                                    {
                                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5))
                                        {
                                            if (j >= location + 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY5 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5 && alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5.StartsWith("*"))
                                            {
                                                //already set .
                                            }
                                            else
                                            {
                                                int endblock = 0;
                                                if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5.StartsWith("*"))
                                                {
                                                    for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                                    {
                                                        if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY5)
                                                        {
                                                            endblock = k - j - 1;
                                                            break;
                                                        }
                                                        if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                                        {
                                                            endblock = k - j;
                                                        }
                                                    }
                                                }
                                                if (alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY5 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5
                                                    && j == location)
                                                {
                                                    //前行の最後の元素と同じ場合
                                                }
                                                else
                                                {
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDot;
                                                }
                                                //s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDot;
                                                s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlDot;
                                                s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlDot;
                                                drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                    sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                    s.Cells[sr + BH + 1 + BSH,
                                                    sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5.Replace("*", ""));

                                            }

                                        }
                                        sc = sc + BW + 1;
                                    }

                                    sr = sr + P5H;
                                }
                            }
                            else
                            {

                                int sc = 11;
                                location = 10 + (lstid - 1) * 8;

                                //情報部ボックスの高　＋　下の一行移動
                                sr = sr + BH + 1 + 1;

                                //左側の短線
                                s.Cells[sr, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle = Excel.XlLineStyle.xlContinuous;
                                s.Cells[sr + BH, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                s.Cells[sr + BH + 1, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                for (int j = location; j < location + 8; j++)
                                {
                                    //情報部ボックス
                                    drawJNBlock(s.Range[s.Cells[sr, sc], s.Cells[sr + BH, sc + BW]], alldata[i].JN_INFOBLOCKS[j].JN_NAME);
                                    //サイズ情報
                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                    s.Range[s.Cells[sr + BH + 1, sc + BW], s.Cells[sr + BH + 1 + BSH, sc + BW]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                    drawSize(s.Range[s.Cells[sr + BH + 1, sc + 2], s.Cells[sr + BH + 1 + BSH, sc + BW - 2]], alldata[i].JN_INFOBLOCKS[j].JN_SIZE);
                                    sc = sc + BW + 1;
                                }
                                //右側の短線
                                s.Cells[sr, sc].Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle = Excel.XlLineStyle.xlContinuous;
                                s.Cells[sr + BH, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                s.Cells[sr + BH + 1, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                sr = sr + SH;

                                //予約、解約、変更前、変更後
                                //PROPERTY3、PROPERTY4
                                if (level.L3 || level.L4)
                                {
                                    sc = 11;

                                    //先頭の短線
                                    if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY3 + alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY4)
                                        && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY3 + alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY4))
                                        s.Cells[sr + BH + 1, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                                    for (int j = location; j < location + 8; j++)
                                    {
                                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3))
                                        {
                                            if (j >= location + 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY3 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3)
                                            {
                                                //already set .
                                            }
                                            else
                                            {
                                                int endblock = 0;
                                                bool tmpflg = false;
                                                for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                                {
                                                    if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY3)
                                                    {
                                                        if (k > location) tmpflg = true;
                                                        endblock = k - j - 1;
                                                        break;
                                                    }
                                                    if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                                    {
                                                        if (k > location) tmpflg = true;
                                                        endblock = k - j;
                                                    }
                                                }
                                                if (endblock == 0) tmpflg = false;
                                                if (tmpflg) endblock = location - j - 1;
                                                if (alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY3 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3
                                                    && j == location)
                                                {
                                                    //前行の最後の元素と同じ場合
                                                }
                                                else
                                                {
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                }
                                                if (tmpflg == false)
                                                    s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1 + BSH, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                    sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                    s.Cells[sr + BH + 1 + BSH,
                                                    sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY3);
                                            }

                                        }
                                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4))
                                        {
                                            if (j >= location + 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY4 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4)
                                            {
                                                //already set .
                                            }
                                            else
                                            {
                                                int endblock = 0;
                                                bool tmpflg = false;
                                                for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                                {
                                                    if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY4)
                                                    {
                                                        if (k > location) tmpflg = true;
                                                        endblock = k - j - 1;
                                                        break;
                                                    }
                                                    if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                                    {
                                                        if (k > location) tmpflg = true;
                                                        endblock = k - j;
                                                    }
                                                }
                                                if (endblock == 0) tmpflg = false;
                                                if (tmpflg) endblock = location - j - 1;
                                                if (alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY4 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4
                                                    && j == location)
                                                {
                                                    //前行の最後の元素と同じ場合
                                                }
                                                else
                                                {
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                }
                                                if (tmpflg == false)
                                                    s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1 + BSH, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                    sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                    s.Cells[sr + BH + 1 + BSH,
                                                    sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY4);
                                            }
                                        }
                                        sc = sc + BW + 1;
                                    }

                                    //右側の短線
                                    if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location + 8 - 1].JN_PROPERTY3 + alldata[i].JN_INFOBLOCKS[location + 8 - 1].JN_PROPERTY4)
                                        && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location + 8].JN_PROPERTY3 + alldata[i].JN_INFOBLOCKS[location + 8].JN_PROPERTY4))
                                        s.Cells[sr + BH + 1, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                                    sr = sr + P34H;
                                }

                                //要求回答設定
                                if (level.REQRES)
                                {
                                    sc = 11;

                                    //先頭の短線
                                    if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_REQRESFLG)
                                        && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_REQRESFLG))
                                        s.Cells[sr + BH + 1, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;

                                    for (int j = location; j < location + 8; j++)
                                    {
                                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG))
                                        {
                                            if (j >= location + 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_REQRESFLG == alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG)
                                            {
                                                //already set .
                                            }
                                            else
                                            {
                                                int endblock = 0;
                                                bool tmpflg = false;
                                                for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                                {
                                                    if (alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG != alldata[i].JN_INFOBLOCKS[k].JN_REQRESFLG)
                                                    {
                                                        if (k > location) tmpflg = true;
                                                        endblock = k - j - 1;
                                                        break;
                                                    }
                                                    if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                                    {
                                                        if (k > location) tmpflg = true;
                                                        endblock = k - j;
                                                    }
                                                }
                                                if (endblock == 0) tmpflg = false;
                                                if (tmpflg) endblock = location - j - 1;
                                                if (alldata[i].JN_INFOBLOCKS[j - 1].JN_REQRESFLG == alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG
                                                    && j == location)
                                                {
                                                    //前行の最後の元素と同じ場合
                                                }
                                                else
                                                {
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1 + BSH, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                }
                                                if (tmpflg == false)
                                                    s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1 + BSH, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                                drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                    sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                    s.Cells[sr + BH + 1 + BSH,
                                                    sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_REQRESFLG);
                                            }
                                        }
                                        sc = sc + BW + 1;
                                    }

                                    //右側の短線
                                    if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location + 8 - 1].JN_REQRESFLG)
                                        && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location + 8].JN_REQRESFLG))
                                        s.Cells[sr + BH + 1, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                                    sr = sr + RESREQH;
                                }

                                //PROPERTY2設定
                                if (level.L2)
                                {
                                    sc = 11;

                                    //先頭の短線
                                    if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY2)
                                        && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY2))
                                        s.Cells[sr + BH + 1, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlDot;

                                    for (int j = location; j < location + 8; j++)
                                    {
                                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2))
                                        {
                                            if (j >= location + 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY2 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2)
                                            {
                                                //already set .
                                            }
                                            else
                                            {
                                                int endblock = 0;
                                                bool tmpflg = false;
                                                for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                                {
                                                    if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY2)
                                                    {
                                                        endblock = k - j - 1;
                                                        if (k > location) tmpflg = true;
                                                        break;
                                                    }
                                                    if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                                    {
                                                        if (k > location) tmpflg = true;
                                                        endblock = k - j;
                                                    }
                                                }
                                                if (endblock == 0) tmpflg = false;
                                                if (tmpflg) endblock = location - j - 1;
                                                if (alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY2 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2
                                                    && j == location)
                                                {
                                                    //前行の最後の元素と同じ場合
                                                }
                                                else
                                                {
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDot;
                                                }
                                                if (tmpflg == false)
                                                    s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlDot;
                                                s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlDot;
                                                drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                    sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                    s.Cells[sr + BH + 1 + BSH,
                                                    sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], "＊ " + p2dic[alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY2]);
                                            }
                                        }
                                        sc = sc + BW + 1;
                                    }

                                    if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location + 8 - 1].JN_PROPERTY2)
                                        && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location + 8].JN_PROPERTY2))
                                        s.Cells[sr + BH + 1, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlDot;
                                    sr = sr + P2H;
                                }

                                //property5
                                //MAX(N)
                                if (level.L5)
                                {
                                    sc = 11;

                                    //先頭の短線
                                    if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location - 1].JN_PROPERTY5)
                                        && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location].JN_PROPERTY5))
                                        s.Cells[sr + BH + 1, sc - 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlDot;

                                    for (int j = location; j < location + 8; j++)
                                    {
                                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5))
                                        {
                                            if (j >= location + 1 && alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY5 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5 && alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5.StartsWith("*"))
                                            {
                                                //already set .
                                            }
                                            else
                                            {
                                                int endblock = 0;
                                                //do not delete this one
                                                bool tmpflg = false;
                                                if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5.StartsWith("*"))
                                                {
                                                    for (int k = j + 1; k < alldata[i].JN_INFOBLOCKS.Count; k++)
                                                    {
                                                        if (alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5 != alldata[i].JN_INFOBLOCKS[k].JN_PROPERTY5)
                                                        {
                                                            if (k > location) tmpflg = true;
                                                            endblock = k - j - 1;
                                                            break;
                                                        }
                                                        if (k == alldata[i].JN_INFOBLOCKS.Count - 1)
                                                        {
                                                            if (k > location) tmpflg = true;
                                                            endblock = k - j;
                                                        }
                                                    }
                                                }
                                                if (endblock == 0) tmpflg = false;
                                                if (tmpflg) endblock = location - j - 1;
                                                if (alldata[i].JN_INFOBLOCKS[j - 1].JN_PROPERTY5 == alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5
                                                    && j == location)
                                                {
                                                    //前行の最後の元素と同じ場合
                                                }
                                                else
                                                {
                                                    s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDot;
                                                }
                                                if (tmpflg == false)
                                                    s.Range[s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlDot;
                                                s.Range[s.Cells[sr + BH + 1, sc], s.Cells[sr + BH + 1, sc + BW + endblock * (BW + 1)]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlDot;
                                                drawP3P4(s.Range[s.Cells[sr + BH + 1,
                                                    sc + ((endblock + 1) * (BW + 1) - 5) / 2],
                                                    s.Cells[sr + BH + 1 + BSH,
                                                    sc + ((endblock + 1) * (BW + 1) - 5) / 2 + 4]], alldata[i].JN_INFOBLOCKS[j].JN_PROPERTY5.Replace("*", ""));

                                            }

                                        }
                                        sc = sc + BW + 1;
                                    }

                                    if (!String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location + 8 - 1].JN_PROPERTY5)
                                        && !String.IsNullOrWhiteSpace(alldata[i].JN_INFOBLOCKS[location + 8].JN_PROPERTY5))
                                        s.Cells[sr + BH + 1, sc].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlDot;

                                    sr = sr + P5H;
                                }

                            }
                        }

                        //操作種別設定
                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_OPTYPE))
                        {
                            string[] arr = alldata[i].JN_OPTYPE.Split('\n');
                            for (int tmpi = 0; tmpi < arr.Length; tmpi++)
                            {
                                if (String.IsNullOrEmpty(arr[tmpi]) || !arr[tmpi].StartsWith(" "))
                                {
                                    drawTextLA(s.Range[s.Cells[sr2 + tmpi, OPCS], s.Cells[sr2 + tmpi, OPCE]], arr[tmpi]);
                                }
                                else
                                {
                                    drawTextRA(s.Range[s.Cells[sr2 + tmpi, OPCS], s.Cells[sr2 + tmpi, OPCE]], arr[tmpi]);
                                }
                            }
                        }

                        //ANS設定
                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_ANS))
                        {
                            string[] arr = alldata[i].JN_ANS.Split('\n');
                            for (int tmpi = 0; tmpi < arr.Length; tmpi++)
                            {

                                drawTextCA(s.Range[s.Cells[sr2 + tmpi, AS], s.Cells[sr2 + tmpi, AE]], arr[tmpi]);
                            }
                        }

                        //パターン番号設定
                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_PATTERNNO))
                        {
                            string[] arr = alldata[i].JN_PATTERNNO.Split('\n');
                            for (int tmpi = 0; tmpi < arr.Length; tmpi++)
                            {

                                drawTextCA(s.Range[s.Cells[sr2 + tmpi, PS], s.Cells[sr2 + tmpi, PE]], arr[tmpi]);
                            }
                        }

                        //記事設定
                        //int totalHeight = 0;
                        if (!String.IsNullOrWhiteSpace(alldata[i].JN_COMMNENT))
                        {
                            drawTextLTA(s.Range[s.Cells[sr2, CS], s.Cells[sr2 + level.totalHeight, CE]], alldata[i].JN_COMMNENT);
                        }
                        //PROPERTY2文字辞典設定
                        if (p2dic.Count > 0)
                        {
                            var lst = p2dic.OrderByDescending(r => r.Value);
                            int ri = 0;
                            foreach (var ttmp in lst)
                            {
                                ri++;
                                drawTextLA(s.Range[s.Cells[sr2 + level.totalHeight - ri, OPCS], s.Cells[sr2 + level.totalHeight - ri, OPCE]], "*" + ttmp.Value + ":" + ttmp.Key);
                            }
                        }

                        //Totalサイズ設定
                        drawTextRA2(s.Cells[sr2 + level.totalHeight - 1, OPCS - 2], alldata[i].JN_INFOBLOCKS.Sum(r => r.JN_SIZE).ToString());

                        //番号つける
                        drawTextCA2(s.Cells[sr2, 2], (i + 1).ToString());

                        int lr = sr2 + level.totalHeight;
                        //枠線
                        //bottom line
                        s.Range[s.Cells[lr, 2], s.Cells[lr, CE]].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                        //left line
                        s.Range[s.Cells[sr2 - 1, 2], s.Cells[lr, 2]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                        s.Range[s.Cells[sr2 - 1, 2], s.Cells[lr, 2]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                        //right line
                        s.Range[s.Cells[sr2 - 1, CE], s.Cells[lr, CE]].Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = Excel.XlLineStyle.xlContinuous;
                        //inside line
                        s.Range[s.Cells[sr2 - 1, OPCS], s.Cells[lr, OPCS]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                        s.Range[s.Cells[sr2 - 1, AS], s.Cells[lr, AS]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                        s.Range[s.Cells[sr2 - 1, PS], s.Cells[lr, PS]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                        s.Range[s.Cells[sr2 - 1, CS], s.Cells[lr, CS]].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;

                        sr = lr + 2;
                        sr2 = lr + 2;
                    }
                }

                //break;
            }

            //不要シート削除
            //workbook.Worksheets.Delete("テンプレート");
            //workbook.Worksheets.Delete("サンプル");
            workbook.Sheets["T"].Delete();
            //xlApp.DisplayAlerts = true;
            workbook.SaveAs(output, Excel.XlFileFormat.xlWorkbookDefault, Type.Missing, Type.Missing, false, false, Excel.XlSaveAsAccessMode.xlNoChange, Excel.XlSaveConflictResolution.xlLocalSessionChanges, Type.Missing, Type.Missing);
            workbook.Close(false);

            xlApp.Quit();

            if (xlApp != null)
            {
                int excelProcessId = -1;
                GetWindowThreadProcessId(new IntPtr(xlApp.Hwnd), ref excelProcessId);

                System.Diagnostics.Process ExcelProc = System.Diagnostics.Process.GetProcessById(excelProcessId);
                if (ExcelProc != null)
                {
                    ExcelProc.Kill();
                }
            }

            System.Diagnostics.Process.Start(output);
        }

        [System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true)]
        private static extern int GetWindowThreadProcessId(IntPtr hwnd, ref int lpdwProcessId);

        //文字設定、左揃え、結合
        private void drawTextLA(Excel.Range er, string content)
        {
            er.Merge();
            er.Value = content;
            er.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;
            er.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
        }

        //文字設定、左揃え、結合
        private void drawTextLTA(Excel.Range er, string content)
        {
            er.Merge();
            er.Value = content;
            er.VerticalAlignment = Excel.XlVAlign.xlVAlignTop;
            er.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
            er.WrapText = true;

        }

        //文字設定、右揃え、結合
        private void drawTextRA(Excel.Range er, string content)
        {
            er.Merge();
            er.Value = content;
            er.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;
            er.HorizontalAlignment = Excel.XlHAlign.xlHAlignRight;
        }

        //文字設定、右揃え、結合
        private void drawTextRA2(Excel.Range er, string content)
        {
            er.Value = content;
            er.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;
            er.HorizontalAlignment = Excel.XlHAlign.xlHAlignRight;
        }

        //文字設定、中央揃え、結合
        private void drawTextCA(Excel.Range er, string content)
        {
            er.Merge();
            er.Value = content;
            er.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;
            er.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
        }

        //文字設定、中央揃え、結合
        private void drawTextCA2(Excel.Range er, string content)
        {
            er.Value = content;
            er.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;
            er.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
        }

        //情報部設定
        private void drawJNBlock(Excel.Range er, string content)
        {
            er.Merge();
            er.Value = content;
            er.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
            er.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;
            er.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
            er.WrapText = true;
        }

        //情報部のサイズ情報設定
        private void drawSize(Excel.Range er, int? content)
        {
            er.Merge();
            er.Value = content;
            er.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;
            er.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
            er.WrapText = true;
        }

        //PROPERTY3、4情報設定
        private void drawP3P4(Excel.Range er, string content)
        {
            er.Merge();
            er.Value = content;
            er.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;
            er.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
            er.Borders.LineStyle = Excel.XlLineStyle.xlLineStyleNone;
            er.WrapText = true;
        }
    }
}
