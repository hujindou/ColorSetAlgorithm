﻿using Models.DB;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace marstooluseradmin
{
    class Program
    {
        /// <summary>
        /// 入力したコマンドチェック
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        private static bool checkcommand(string[] args)
        {
            switch (args[0].ToLower())
            {
                case "-loaduser":
                    if (args.Length != 2)
                        return false;
                    else
                        return true;

                case "-listuser":
                    if (args.Length > 2)
                        return false;
                    else
                        return true;

                default:
                    return false;
            }
        }


        static void Main(string[] args)
        {
            if (args == null || args.Length <= 0 || checkcommand(args) == false)
            {
                printHelp();
                return;
            }

            switch (args[0].ToLower())
            {
                case "-loaduser":
                    loaduser(args);
                    break;

                case "-listuser":
                    listuser(args);
                    break;

                default:
                    break;
            }
        }

        private static void listuser(string[] args)
        {
            string userid = null;

            if (args.Length == 2)
                userid = args[1].Trim();

            try
            {
                using (var context = new commondbcontext())
                {
                    if (String.IsNullOrWhiteSpace(userid))
                    {
                        Console.WriteLine("ユーザーIDリスト：");
                        foreach (var xx in context.T_USERS)
                        {
                            Console.WriteLine($"{xx.USERID}");
                        }
                    }
                    else
                    {
                        var grp = context.T_USERS.FirstOrDefault(r => r.USERID == userid);
                        if (grp != null)
                        {
                            Console.WriteLine($"ユーザーID：{userid}");
                            Console.WriteLine($"名前：{grp.USERNAME}");
                            Console.WriteLine($"部署：{grp.GRP}");
                            Console.WriteLine($"権限：{grp.ROLE}");

                            //string g = "";
                            //if (grp.GROUP != null && !String.IsNullOrWhiteSpace(grp.GROUP.SUBSYSLIST))
                            //{
                            //    g = grp.GROUP.SUBSYSLIST.ToUpper() + " ";
                            //}

                            //Console.WriteLine($"更新権限のあるサブシステム：[ {String.Join(" , ", g.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Distinct())} ]");

                        }
                        else
                        {
                            Console.WriteLine($"ユーザー「{userid}」が存在しない");
                        }
                    }
                }
            }
            catch
            {
                Console.WriteLine("DBエラーが発生しました");
                //Console.WriteLine(exp);
                return;
            }
        }

        //private static void listgrouppri(string[] args)
        //{
        //    string groupname = null;
        //    if (args.Length > 1)
        //        groupname = args[1].Trim();

        //    try
        //    {
        //        using (var context = new commondbcontext())
        //        {
        //            if (String.IsNullOrWhiteSpace(groupname))
        //            {
        //                Console.WriteLine("所属リスト：");
        //                foreach (var xx in context.T_GRPS)
        //                {
        //                    Console.WriteLine($"{xx.GRPNAME}");
        //                }
        //            }
        //            else
        //            {
        //                var grp = context.T_GRPS.FirstOrDefault(r => r.GRPNAME == groupname);

        //                if (grp != null)
        //                {
        //                    Console.WriteLine($"所属：{grp.GRPNAME}");

        //                    Console.WriteLine($"更新権限のあるサブシステム：[ {String.Join(" , ", grp.SUBSYSLIST.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Distinct())} ]");

        //                }
        //                else
        //                {
        //                    Console.WriteLine($"所属「{groupname}」が管轄するサブシステムは存在しません");
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception exp)
        //    {
        //        Console.WriteLine("DBエラーが発生しました");
        //        return;
        //    }
        //}


        //private static void rmgrouppri(string[] args)
        //{
        //    string groupname = args[1].Trim();

        //    string pristr = String.Join(" ", args, 2, args.Length - 2);

        //    var ck = pristr.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

        //    //ジャーナルの場合、「JM」で指定する
        //    if (ck.Any(r => (r + "").Length > 4))
        //    {
        //        Console.WriteLine("サブシステムIDは４桁以内です");
        //        return;
        //    }

        //    try
        //    {
        //        using (var context = new commondbcontext())
        //        {
        //            var grp = context.T_GRPS.FirstOrDefault(r => r.GRPNAME == groupname);

        //            if (grp != null)
        //            {
        //                string tmp = grp.SUBSYSLIST;
        //                tmp = tmp.ToUpper();
        //                for (int i = 2; i < args.Length; i++)
        //                {
        //                    if (args[i].Trim().ToUpper().Length > 0)
        //                        tmp = tmp.Replace(args[i].Trim().ToUpper(), "");
        //                }
        //                grp.SUBSYSLIST = tmp;
        //                context.SaveChanges();
        //            }

        //            Console.WriteLine($"所属「{groupname}」が管轄するサブシステムに「{pristr}」を除外しました");
        //        }
        //    }
        //    catch (Exception exp)
        //    {
        //        Console.WriteLine("DBエラーが発生しました");
        //        return;
        //    }
        //}

        //private static void addgrouppri(string[] args)
        //{
        //    string groupname = args[1].Trim();

        //    string pristr = String.Join(" ", args, 2, args.Length - 2);

        //    var ck = pristr.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

        //    //ジャーナルの場合、「JM」で指定する
        //    if (ck.Any(r => (r + "").Length > 4))
        //    {
        //        Console.WriteLine("サブシステムIDは４桁以内です");
        //        return;
        //    }

        //    try
        //    {
        //        using (var context = new commondbcontext())
        //        {

        //            var grp = context.T_GRPS.FirstOrDefault(r => r.GRPNAME == groupname);

        //            if (grp != null)
        //            {
        //                if (String.IsNullOrWhiteSpace(grp.SUBSYSLIST))
        //                {
        //                    grp.SUBSYSLIST = pristr;
        //                }
        //                else
        //                {
        //                    grp.SUBSYSLIST = grp.SUBSYSLIST + " " + pristr;
        //                }
        //                context.SaveChanges();
        //            }
        //            else
        //            {
        //                grp = new T_GRP();
        //                grp.GRPNAME = groupname;
        //                grp.SUBSYSLIST = pristr;

        //                context.T_GRPS.Add(grp);
        //                context.SaveChanges();
        //            }

        //            Console.WriteLine($"所属「{groupname}」が管轄するサブシステムに「{pristr}」を追加しました");
        //        }
        //    }
        //    catch (Exception exp)
        //    {
        //        Console.WriteLine("DBエラーが発生しました");
        //        return;
        //    }
        //}

        //private static void setusergroup(string[] args)
        //{
        //    string userid = args[1].Trim();
        //    string groupname = args[2].Trim();

        //    if (groupname.Length > 16)
        //    {
        //        Console.WriteLine("担当部署名は１６桁以内に設定してください");
        //        return;
        //    }

        //    try
        //    {
        //        using (var context = new commondbcontext())
        //        {
        //            var user = context.T_USERS.FirstOrDefault(r => r.USERID == userid);
        //            if (user != null)
        //            {
        //                user.GRP = groupname;

        //                if (context.T_GRPS.Any(r => r.GRPNAME == groupname))
        //                {

        //                }

        //                context.SaveChanges();
        //                Console.WriteLine($"ユーザー「{userid}」の部署設定は完了しました");
        //            }
        //            else
        //            {
        //                Console.WriteLine($"ユーザー「{userid}」が存在しないため、部署設定は中止");
        //            }
        //        }
        //    }
        //    catch (Exception exp)
        //    {
        //        Console.WriteLine("DBエラーが発生しました");
        //        return;
        //    }
        //}

        private static void loaduser(string[] args)
        {
            bool flg1 = true;
            List<USERModel> lst = new List<USERModel>();
            List<string> msglst = new List<string>();

            try
            {

                string[] all = System.IO.File.ReadAllLines(args[1], Encoding.GetEncoding("shift_jis"));

                int i = 0;

                foreach (var tmpstr in all)
                {
                    //ignore head
                    i++;
                    if (i <= 1)
                    {
                        continue;
                    }

                    if (String.IsNullOrWhiteSpace(tmpstr))
                        continue;

                    string a = "";
                    string b = "";
                    string c = "";
                    string d = "";
                    string e = "";
                    string f = "";

                    string[] arr = tmpstr.Split(',');

                    if (arr.Length > 0)
                        a = (arr[0] + "").Trim();
                    if (arr.Length > 1)
                        b = (arr[1] + "").Trim();
                    if (arr.Length > 2)
                        c = (arr[2] + "").Trim();
                    if (arr.Length > 3)
                        d = (arr[3] + "").Trim();
                    if (arr.Length > 4)
                        e = (arr[4] + "").Trim();
                    if (arr.Length > 5)
                        f = (arr[5] + "").Trim();

                    USERModel inst = new USERModel { OPType = a, UserId = b, UserName = c, Cmp = d, Role = e, GRP = f };

                    var validator = new ValidationContext(inst, null, null);
                    var valres = new List<ValidationResult>();
                    bool isVal = Validator.TryValidateObject(inst, validator, valres, true);

                    if (isVal)
                    {
                        if (lst.Any(r => r.UserId == inst.UserId))
                        {
                            //CSV Data Error
                            flg1 = false;
                            Console.WriteLine($"{i}行目のデータは不正で、ユーザーIDが重複しました");
                        }
                        else
                        {
                            lst.Add(inst);
                        }
                    }
                    else
                    {
                        flg1 = false;
                        Console.WriteLine($"{i}行目のデータは不正で、{valres[0].ErrorMessage}");
                    }
                }

            }
            catch
            {
                Console.WriteLine($"ファイル「{args[1]}」を読込む時、エラーが発生しました");
                return;
            }

            if (flg1 && lst.Count > 0)
            {
                try
                {
                    using (var context = new commondbcontext())
                    {
                        foreach (var xx in lst)
                        {
                            if (xx.OPType == "1")
                            {
                                if (context.T_USERS.Any(r => r.USERID == xx.UserId))
                                {
                                    Console.WriteLine($"ユーザーID「{xx.UserId}」がすでに登録済み、登録処理をスキップしました");
                                    continue;
                                }
                                else
                                {
                                    T_USER t = new T_USER();
                                    t.USERID = xx.UserId;
                                    t.PASSWORD = xx.UserId;
                                    t.USERNAME = xx.UserName;
                                    t.ROLE = xx.Role;
                                    t.COMPANY = xx.Cmp;
                                    t.GRP = xx.GRP;
                                    context.T_USERS.Add(t);
                                    msglst.Add($"ユーザーID「{xx.UserId}」を登録しました");
                                }
                            }

                            if (xx.OPType == "2")
                            {
                                T_USER t = context.T_USERS.FirstOrDefault(r => r.USERID == xx.UserId);
                                if (t != null)
                                {
                                    t.USERNAME = xx.UserName;
                                    t.ROLE = xx.Role;
                                    t.COMPANY = xx.Cmp;
                                    t.GRP = xx.GRP;
                                    msglst.Add($"ユーザーID「{xx.UserId}」を更新しました");
                                }
                                else
                                {
                                    Console.WriteLine($"ユーザーID「{xx.UserId}」が存在しないので、変更処理をスキップしました");
                                    continue;
                                }
                            }

                            if (xx.OPType == "3")
                            {
                                T_USER t = context.T_USERS.FirstOrDefault(r => r.USERID == xx.UserId);
                                if (t != null)
                                {
                                    context.T_USERS.Remove(t);
                                    msglst.Add($"ユーザーID「{xx.UserId}」を削除しました");
                                }
                                else
                                {
                                    Console.WriteLine($"ユーザーID「{xx.UserId}」が存在しないので、削除処理をスキップしました");
                                    continue;
                                }
                            }

                        }
                        context.SaveChanges();
                        if(msglst.Count >0)
                        {
                            foreach(var tmpstr in msglst)
                            {
                                Console.WriteLine(tmpstr);
                            }
                        }

                        Console.WriteLine("ユーザー登録処理は完了しました");
                    }
                }
                catch
                {
                    Console.WriteLine("DBエラーが発生しました");
                    return;
                }
            }
            else if (flg1 && lst.Count == 0)
            {
                Console.WriteLine($"処理しようとするユーザー情報はありません");
            }

            return;
        }


        class USERModel
        {
            /// <summary>
            /// 申請区分
            /// </summary>
            [RegularExpression("^[1-3]$", ErrorMessage = "申請区分は半角の「1」、「2」、「3」三つしか設定できない")]
            [Required(ErrorMessage = "申請区分は空白に設定できない")]
            [StringLength(1, ErrorMessage = "申請区分は１桁")]
            public string OPType { get; set; }

            /// <summary>
            /// ユーザーID
            /// </summary>
            [RegularExpression("^[a-zA-Z0-9]+$", ErrorMessage = "ユーザーIDは半角英数字しか設定できない")]
            [Required(ErrorMessage = "ユーザーIDは空白に設定できない")]
            [StringLength(7, ErrorMessage = "ユーザーIDは７桁")]
            public string UserId { get; set; }

            /// <summary>
            /// ユーザー名
            /// </summary>
            [StringLength(16, ErrorMessage = "ユーザー名は１６桁以内")]
            public string UserName { get; set; }

            /// <summary>
            /// 所属会社
            /// </summary>
            [StringLength(3, ErrorMessage = "所属会社は３桁以内")]
            public string Cmp { get; set; }

            /// <summary>
            /// ロール
            /// </summary>
            [StringLength(16, ErrorMessage = "マルス権限は１６桁以内")]
            public string Role { get; set; }

            /// <summary>
            /// 所属
            /// </summary>
            [StringLength(16, ErrorMessage = "担当部署は１６桁以内")]
            public string GRP { get; set; }
        }

        private static void printHelp()
        {
            Console.WriteLine(
@"使用法:  -loaduser ユーザー登録CSVファイル
         -listuser ユーザーID

");
        }
    }
}
