﻿using MarsTool.Common;
using MarsTool.Common.Forms;
using MarsTool.Exceptions;
using MarsTool.Models;
using MarsTool.Models.DB;
using MarsTool.Properties;
using MarsTool.Services;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MarsTool
{
    /// <summary>
    /// 候補値管理機能クラス
    /// </summary>
    public partial class KohoForm : MarsForm
    {
        private int RowIndex { set; get; }
        private bool UpdateFlg { set; get; }

        #region 登録
        /// <summary>
        /// 候補値グループ入力パス
        /// </summary>
        private void button6_Click(object sender, EventArgs e)
        {
            // 「OpenFileDialog」のオブジェクトを作成
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "Excelファイル|*.xlsx";
            openFileDialog1.Title = "候補値グループ入力パスを入力してください！";

            // ファイルダイアログを表示して、ＯＫでクリックするとテキストボックスに表示される。 
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this.txtInputPath.Text = openFileDialog1.FileName;
            }
        }
        /// <summary>
        /// 「登録」ボタン
        /// </summary>
        private void button5_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(this.txtInputPath.Text))
            {
                MessageBox.Show("入力ファイルにファイルパスを入力してください。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (!System.IO.File.Exists(this.txtInputPath.Text))
            {
                MessageBox.Show("入力ファイルに指定したファイルパスが不正です。正しいファイルパスを入力してください。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            String inputPath = txtInputPath.Text;
            try
            {
                CodeCandidateValueRegistration instance = new CodeCandidateValueRegistration(this.Version);

                Boolean result = instance.RegisterCodeCandidate(inputPath);

                if (result)
                {
                    MessageBox.Show(Resources.CVR00002_I,
                    Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("異常終了。",
                    Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            catch (CodeCadidateRegException ex)
            {
                MessageBox.Show(ex.Message,
                    Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        /// <summary>
        /// 「クリア」ボタン
        /// </summary>
        private void button7_Click(object sender, EventArgs e)
        {
            // 「クリア」ボタンを押すと、電文構成パターン入力パスがクリアされる。
            this.txtInputPath.Text = "";
        }

        #endregion

        #region 編集
        private CheckDataGridView CheckDgv { get; set; }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public KohoForm(VersionModel version) : base(version)
        {
            InitializeComponent();

            this.CheckDgv = new CheckDataGridView(this.dgvGroup, this.chkAll);
            this.CheckDgv.ChangeStatus += ChangeStatus;
        }

        protected void ChangeStatus(bool nodata)
        {
            this.btnDelete.Enabled = !nodata;
        }

        /// <summary>
        /// グループ名一覧検索
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                this.dgvGroup.Rows.Clear();
                this.dgvKoho.Rows.Clear();
                this.RowIndex = -1;
                this.chkAll.Checked = false;
                this.chkAll.Enabled = false;
                this.btnUpdate.Enabled = false;

                var groupArray = this.Context.T_KOHO.AsNoTracking().Select(r => r.KOHO_GROUP)
                    .Where(g => g.Contains(this.txtGroupNm.Text)).Distinct().ToArray();
                if (groupArray == null || groupArray.Length == 0)
                {
                    MessageBox.Show("候補値グループ名が存在しませんでした。",
                        Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                var fields = new List<string>();
                foreach (var group in groupArray)
                {
                    fields.Clear();
                    // 選択
                    fields.Add("0");
                    // グループ
                    fields.Add(group);

                    this.dgvGroup.Rows.Add(fields.ToArray());
                }

                this.RowIndex = 0;
                this.SetDgvKoho();

                this.chkAll.Enabled = true;
                this.btnUpdate.Enabled = true;
            }
            catch (Exception ex)
            {
                this.Logger.Error(ex.Message);
                var msg = $"{MessageId.TSR00012_E}\n{ex.Message}";
                MessageBox.Show(msg, Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 画面内容変更判定
        /// </summary>
        /// <returns></returns>
        private bool IsEdited()
        {
            return this.dgvKoho.Rows.Cast<DataGridViewRow>().Any(
                r =>
                {
                    if (RowUtils.IsNew(r)) return true;

                    var koho = RowUtils.GetData<T_KOHO>(r);
                    if (koho == null) return false;
                    if (RowUtils.IsDelete(r)) return true;

                    // コード
                    if (!koho.KOHO_CODE.Equals(RowUtils.GetValue(r, "CODE"))) return true;
                    // 内容
                    if (!koho.KOHO_CONTENT.Equals(RowUtils.GetValue(r, "CONTENT"))) return true;

                    return false;
                });
        }

        /// <summary>
        /// グループ名を選択
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DgvGroup_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || this.RowIndex == e.RowIndex) return;

            if (this.IsEdited())
            {
                if (MessageBox.Show("編集内容が破棄されます、よろしいですか？。",
                    Resources.WARNING, MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.Cancel)
                {
                    this.dgvGroup.Rows[e.RowIndex].Selected = false;
                    this.dgvGroup.Rows[this.RowIndex].Selected = true;
                    return;
                }
            }

            this.RowIndex = e.RowIndex;
            this.SetDgvKoho();
        }

        /// <summary>
        /// 選択したグループ名の候補値を表示する
        /// </summary>
        /// <param name="group"></param>
        private void SetDgvKoho()
        {
            if (this.RowIndex < 0) return;

            var groupRow = this.dgvGroup.Rows[this.RowIndex];
            var group = RowUtils.GetValue(groupRow, "GROUP");

            try
            {
                this.UpdateFlg = false;
                this.dgvKoho.Rows.Clear();
                var kohoArray = this.Context.T_KOHO.AsNoTracking()
                    .Where(r => r.KOHO_GROUP.Equals(group)).OrderBy(r => r.KOHO_ORDER).ToArray();

                var fields = new List<string>();
                foreach (var record in kohoArray)
                {
                    fields.Clear();
                    // コード
                    fields.Add(record.KOHO_CODE);
                    // 内容
                    fields.Add(record.KOHO_CONTENT);

                    var index = this.dgvKoho.Rows.Add(fields.ToArray());

                    RowUtils.SetData<T_KOHO>(this.dgvKoho.Rows[index], record);
                }

                if (kohoArray.Length > 0)
                {
                    RowUtils.SetData<T_KOHO>(groupRow, kohoArray[0]);
                }
            }
            catch (Exception ex)
            {
                this.Logger.Error(ex.Message);
                var msg = $"{MessageId.TSR00012_E}\n{ex.Message}";
                MessageBox.Show(msg, Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 右クリックして、メニューを表示する
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DgvKoho_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex < 0) return;

            // 無効行が編集できない
            var curRow = this.dgvKoho.Rows[e.RowIndex];

            if (e.ColumnIndex >= 0)
            {
                curRow.Cells[e.ColumnIndex].ReadOnly = RowUtils.IsDelete(curRow);
            }

            // メニュー表示
            if (e.Button == MouseButtons.Right)
            {
                this.DelMenuItem.Visible = !RowUtils.IsDelete(curRow);

                var cellRect = 
                    this.dgvKoho.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, false);
                this.dgvMenu.Tag = this.dgvKoho.Rows[e.RowIndex];
                this.dgvMenu.Show(this.dgvKoho, new Point(cellRect.X + e.X, cellRect.Y + e.Y));
            }
        }

        /// <summary>
        /// 候補値を追加処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AddMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dgvMenu.Tag is DataGridViewRow)
            {

                var fields = new List<string>();
                // コード
                fields.Add(string.Empty);
                // 内容
                fields.Add(string.Empty);

                var index = (this.dgvMenu.Tag as DataGridViewRow).Index;
                if (sender == this.AddAfterMenuItem)
                {
                    index++;
                }
                this.dgvKoho.Rows.Insert(index, fields.ToArray());

                RowUtils.SetNew(this.dgvKoho.Rows[index]);
            }
        }

        /// <summary>
        /// 候補値を削除処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DelMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dgvMenu.Tag is DataGridViewRow)
            {
                var row = this.dgvMenu.Tag as DataGridViewRow;
                RowUtils.SetDelete(row);
            }
        }

        private bool ValidateDgv()
        {
            var rows = this.dgvKoho.Rows.Cast<DataGridViewRow>();
            // 全て削除判定
            if (rows.All(r => RowUtils.IsDelete(r)))
            {
                MessageBox.Show("全て候補値を削除できません。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            // 削除された行が検証対象外
            rows = rows.Where(r => !RowUtils.IsDelete(r));

            // コード必須判定
            if (rows.Any(r => string.Empty.Equals(RowUtils.GetValue(r, "CODE"))))
            {
                MessageBox.Show("コードは必須入力項目です。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            // 内容必須判定
            if (rows.Any(r => string.Empty.Equals(RowUtils.GetValue(r, "CONTENT"))))
            {
                MessageBox.Show("内容は必須入力項目です。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        private void DgvKoho_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            var value = e.FormattedValue.ToString();
            if (string.IsNullOrWhiteSpace(value)) return;

            var rows = this.dgvKoho.Rows.Cast<DataGridViewRow>().Where(r => !RowUtils.IsDelete(r));

            switch (this.dgvKoho.Columns[e.ColumnIndex].Name)
            {
                // 候補値コード
                case "CODE":
                    {
                        if (rows.Where(r => value.Equals(RowUtils.GetValue(r, "CODE")) &&
                        r.Index != e.RowIndex).Count() > 0)
                        {
                            MessageBox.Show("コードが既に存在する。",
                                Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            e.Cancel = true;
                        }
                    }
                    break;

                default:
                    break;
            }
        }

        /// <summary>
        /// 編集した候補値がＤＢに更新する
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("更新処理を行いますか?",
                Resources.QUESTION, MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (result == DialogResult.Cancel) return;

            if (!this.ValidateDgv()) return;

            if (!this.IsEdited())
            {
                MessageBox.Show("何も編集していないため、更新されませんでした。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                var groupRow = this.dgvGroup.Rows[this.RowIndex];
                var group = RowUtils.GetValue(groupRow, "GROUP");

                var dateTime = DateTime.Now.ToString();

                var rowKoho = RowUtils.GetData<T_KOHO>(groupRow);

                // 候補値
                var rtn = this.Context.Database.ExecuteSqlCommand($"UPDATE T_KOHO " +
                    $" SET KOHO_UPDTIME   = '{dateTime}'" +
                    $" WHERE KOHO_GROUP   = '{group}'" +
                    $"   AND KOHO_UPDTIME = '{rowKoho.KOHO_UPDTIME}'");
                this.Context.SaveChanges();
                if (rtn == 0)
                {
                    throw new ExclusiveException();
                }

                // 削除
                this.Context.Database.ExecuteSqlCommand(
                    $"DELETE FROM T_KOHO WHERE KOHO_GROUP = '{group}'");

                // 登録
                var rows = this.dgvKoho.Rows.Cast<DataGridViewRow>();
                var insertRows = rows.Where(r => !RowUtils.IsDelete(r));

                var order = 1;
                foreach (var row in insertRows)
                {
                    this.Context.Database.ExecuteSqlCommand(
                        "INSERT INTO T_KOHO " +
                        "           (KOHO_GROUP," +
                        "            KOHO_CODE," +
                        "            KOHO_CONTENT," +
                        "            KOHO_ORDER," +
                        "            KOHO_USERID," +
                        "            KOHO_UPDTIME)" +
                        "     VALUES(" +
                        $"           '{group}'," +
                        $"           '{RowUtils.GetValue(row, "CODE")}'," +
                        $"           '{RowUtils.GetValue(row, "CONTENT")}'," +
                        $"           '{order++}'," +
                        $"           '{this.Version.User.USERID}'," +
                        $"           '{dateTime}'" +
                        "           )"
                        );
                }

                this.Context.SaveChanges();
                this.SetDgvKoho();

                MessageBox.Show("更新処理が正常終了しました。",
                    Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (ExclusiveException ee)
            {
                this.Logger.Error(ee.Message);
                MessageBox.Show(ee.Message, Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                this.Logger.Error(ex.Message);
                var msg = $"{MessageId.TSR00012_E}\n{ex.Message}";
                MessageBox.Show(msg, Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// グループ単位で、削除する
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnDelete_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("削除処理を行いますか?",
                Resources.QUESTION, MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (result == DialogResult.Cancel) return;

            try
            {
                var groupList = new List<string>();

                this.dgvGroup.Rows[this.RowIndex].Selected = false;
                var rows = this.dgvGroup.Rows.Cast<DataGridViewRow>();
                var delList = rows.Where(r => "1".Equals(RowUtils.GetValue(r, 0))).Reverse();
                foreach (var rdata in delList)
                {
                    var group = RowUtils.GetValue(rdata, "GROUP");

                    // グループ名は使用中の判定
                    if (this.Context.T_PHYITM.AsNoTracking().Any(r => group.Equals(r.PHYITM_GROUP)))
                    {
                        groupList.Add(group);
                        continue;
                    }

                    // 削除
                    this.Context.Database.ExecuteSqlCommand(
                        $"DELETE FROM T_KOHO WHERE KOHO_GROUP = '{group}'");

                    this.dgvGroup.Rows.Remove(rdata);
                }

                if (this.dgvGroup.Rows.Count <= 0)
                {
                    this.ChangeStatus(true);
                    this.chkAll.Checked = false;
                    this.chkAll.Enabled = false;
                    this.btnUpdate.Enabled = false;

                    this.dgvKoho.Rows.Clear();
                    this.RowIndex = -1;
                }
                else
                {
                    this.RowIndex = 0;
                    this.SetDgvKoho();
                    this.dgvGroup.Rows[this.RowIndex].Selected = true;
                }

                var msg = "削除処理が完了しました。";
                if (groupList.Count > 0)
                {
                    msg = $"{msg}\n使用中のため、削除できないグループ名がありました。\nログファイルを参照してください。";

                    this.Logger.Warn($"下記グループ名は使用中のため、削除できません。\n{string.Join("\n", groupList.ToArray())}");
                }
                MessageBox.Show(msg, Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                this.Logger.Error(ex.Message);
                var msg = $"{MessageId.TSR00012_E}\n{ex.Message}";
                MessageBox.Show(msg, Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion
    }
}
