﻿using MarsTool.Models;

namespace MarsTool
{
    partial class Interface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Interface));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtCopyKuNm = new System.Windows.Forms.TextBox();
            this.rdoCpyNm = new System.Windows.Forms.RadioButton();
            this.rdoRDataTbId = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.txtInitInfoId = new System.Windows.Forms.TextBox();
            this.combInitSubSysID = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtCopyKuID = new System.Windows.Forms.TextBox();
            this.combLogSubSysID = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.btnSearchOutput = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.txtOutputPath = new System.Windows.Forms.TextBox();
            this.chkMParser = new System.Windows.Forms.CheckBox();
            this.chkSettingCond = new System.Windows.Forms.CheckBox();
            this.chkLogCpyKu = new System.Windows.Forms.CheckBox();
            this.chkItem = new System.Windows.Forms.CheckBox();
            this.chkItmMap = new System.Windows.Forms.CheckBox();
            this.chkPhyLogMapping = new System.Windows.Forms.CheckBox();
            this.chkPhyCpyKu = new System.Windows.Forms.CheckBox();
            this.btnOutput = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.inputTypeGBox = new System.Windows.Forms.GroupBox();
            this.RdoItemInfoFile = new System.Windows.Forms.RadioButton();
            this.RdoCopyKuToolRefSheet = new System.Windows.Forms.RadioButton();
            this.RdoCopyku = new System.Windows.Forms.RadioButton();
            this.clearBtn = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.cmbSubSysID = new System.Windows.Forms.ComboBox();
            this.cmbAddSize = new System.Windows.Forms.ComboBox();
            this.lblAddressSize = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtInputPath = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.txtInfoId = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.Excute = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.grpEditMPaser = new System.Windows.Forms.GroupBox();
            this.btnEditMPaserSet = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.txtEditMPaserLayoutDef = new System.Windows.Forms.TextBox();
            this.grpColumn = new System.Windows.Forms.GroupBox();
            this.grpEditRequirement = new System.Windows.Forms.GroupBox();
            this.btnEditRequirementRename = new System.Windows.Forms.Button();
            this.btnEditRequirementDel = new System.Windows.Forms.Button();
            this.btnEditRequirementAdd = new System.Windows.Forms.Button();
            this.txtEditRequirement = new System.Windows.Forms.TextBox();
            this.lstEditRequirement = new System.Windows.Forms.ListBox();
            this.label8 = new System.Windows.Forms.Label();
            this.grpEditLogicif = new System.Windows.Forms.GroupBox();
            this.btnEditLogicifRename = new System.Windows.Forms.Button();
            this.btnEditLogicifDel = new System.Windows.Forms.Button();
            this.btnEditLogicifAdd = new System.Windows.Forms.Button();
            this.txtEditLogicifCopyId = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btnEditLogicifCopyComment = new System.Windows.Forms.Button();
            this.txtEditLogicifName = new System.Windows.Forms.TextBox();
            this.lstEditLogicif = new System.Windows.Forms.ListBox();
            this.label9 = new System.Windows.Forms.Label();
            this.grpEditOutput = new System.Windows.Forms.GroupBox();
            this.btnEditOutput = new System.Windows.Forms.Button();
            this.chkEditOutputLayoutText = new System.Windows.Forms.CheckBox();
            this.chkEditOutputLayoutCsv = new System.Windows.Forms.CheckBox();
            this.chkEditOutputCopy = new System.Windows.Forms.CheckBox();
            this.btnEditOutputRef = new System.Windows.Forms.Button();
            this.txtEditOutputPath = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.pnlEdit1 = new System.Windows.Forms.Panel();
            this.tsEditToolBar = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.btnEditViewItemInfo = new System.Windows.Forms.ToolStripButton();
            this.btnEditViewCopyInfo = new System.Windows.Forms.ToolStripButton();
            this.btnEditViewRequirment = new System.Windows.Forms.ToolStripButton();
            this.btnEditViewLogicif = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btnEditCommit = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.dgvEditItemEditor = new MarsTool.Common.Forms.GroupDataGridView();
            this.colEdit1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEdit2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEdit3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEdit4 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.colEdit5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEdit6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEdit7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEdit8 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.colEdit9 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.colEdit10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEdit11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEdit12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEdit13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEdit14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEdit15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEdit16 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.colEdit17 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colEdit18 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.colEdit19 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colEdit20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEdit21 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.colEdit22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.colEdit23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEdit24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grpEditPhysicif = new System.Windows.Forms.GroupBox();
            this.btnEditPhysicifDel = new System.Windows.Forms.Button();
            this.btnEditPhysicifCopyComment = new System.Windows.Forms.Button();
            this.txtEditPhysicInfoID = new System.Windows.Forms.TextBox();
            this.txtEditPhysicCopyName = new System.Windows.Forms.TextBox();
            this.txtEditPhysicCopyID = new System.Windows.Forms.TextBox();
            this.txtEditPhysicSubsys = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.grpEditPhysicFile = new System.Windows.Forms.GroupBox();
            this.btnEditPhysicFileIn = new System.Windows.Forms.Button();
            this.btnEditPhysicFileRef = new System.Windows.Forms.Button();
            this.txtEditPhysicFile = new System.Windows.Forms.TextBox();
            this.grpEditSubsys = new System.Windows.Forms.GroupBox();
            this.btnEditTargetSubsys = new System.Windows.Forms.Button();
            this.cmbEditTargetSubsys = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cvsSheet = new MarsTool.Common.Forms.Canvas();
            this.tsSheetToolBar = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.btnSheetPagepre = new System.Windows.Forms.ToolStripButton();
            this.cmbSheetPage = new System.Windows.Forms.ToolStripComboBox();
            this.btnSheetPagenext = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.btnSheetSave = new System.Windows.Forms.ToolStripButton();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cvsPicture = new MarsTool.Common.Forms.Canvas();
            this.tsPictureToolBar = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel4 = new System.Windows.Forms.ToolStripLabel();
            this.btnPicturePagePre = new System.Windows.Forms.ToolStripButton();
            this.cmbPicturePage = new System.Windows.Forms.ToolStripComboBox();
            this.btnPicturePageNext = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel5 = new System.Windows.Forms.ToolStripLabel();
            this.btnPictureSave = new System.Windows.Forms.ToolStripButton();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.rdbTxt = new System.Windows.Forms.RadioButton();
            this.rdbCSV = new System.Windows.Forms.RadioButton();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.chkRDataAll = new System.Windows.Forms.CheckBox();
            this.dgvPhyData = new System.Windows.Forms.DataGridView();
            this.Column21 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.msEditMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmInsertUp = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmInsertDown = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmRemove = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Privilege = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.inputTypeGBox.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.grpEditMPaser.SuspendLayout();
            this.grpColumn.SuspendLayout();
            this.grpEditRequirement.SuspendLayout();
            this.grpEditLogicif.SuspendLayout();
            this.grpEditOutput.SuspendLayout();
            this.pnlEdit1.SuspendLayout();
            this.tsEditToolBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEditItemEditor)).BeginInit();
            this.grpEditPhysicif.SuspendLayout();
            this.grpEditPhysicFile.SuspendLayout();
            this.grpEditSubsys.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tsSheetToolBar.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tsPictureToolBar.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhyData)).BeginInit();
            this.msEditMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.txtCopyKuNm);
            this.groupBox2.Controls.Add(this.rdoCpyNm);
            this.groupBox2.Controls.Add(this.rdoRDataTbId);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtInitInfoId);
            this.groupBox2.Controls.Add(this.combInitSubSysID);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.txtCopyKuID);
            this.groupBox2.Location = new System.Drawing.Point(5, 7);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(750, 50);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "物理";
            // 
            // txtCopyKuNm
            // 
            this.txtCopyKuNm.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCopyKuNm.Location = new System.Drawing.Point(560, 21);
            this.txtCopyKuNm.Name = "txtCopyKuNm";
            this.txtCopyKuNm.Size = new System.Drawing.Size(181, 19);
            this.txtCopyKuNm.TabIndex = 5;
            // 
            // rdoCpyNm
            // 
            this.rdoCpyNm.AutoSize = true;
            this.rdoCpyNm.Location = new System.Drawing.Point(476, 22);
            this.rdoCpyNm.Margin = new System.Windows.Forms.Padding(0);
            this.rdoCpyNm.Name = "rdoCpyNm";
            this.rdoCpyNm.Size = new System.Drawing.Size(80, 16);
            this.rdoCpyNm.TabIndex = 4;
            this.rdoCpyNm.Text = "コピー句名：";
            this.rdoCpyNm.UseVisualStyleBackColor = true;
            // 
            // rdoRDataTbId
            // 
            this.rdoRDataTbId.AutoSize = true;
            this.rdoRDataTbId.Checked = true;
            this.rdoRDataTbId.Location = new System.Drawing.Point(298, 22);
            this.rdoRDataTbId.Margin = new System.Windows.Forms.Padding(0);
            this.rdoRDataTbId.Name = "rdoRDataTbId";
            this.rdoRDataTbId.Size = new System.Drawing.Size(80, 16);
            this.rdoRDataTbId.TabIndex = 2;
            this.rdoRDataTbId.TabStop = true;
            this.rdoRDataTbId.Text = "コピー句ＩＤ：";
            this.rdoRDataTbId.UseVisualStyleBackColor = true;
            this.rdoRDataTbId.CheckedChanged += new System.EventHandler(this.rdoRDataTbId_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(163, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 12);
            this.label2.TabIndex = 26;
            this.label2.Text = "情報部ＩＤ：";
            // 
            // txtInitInfoId
            // 
            this.txtInitInfoId.Location = new System.Drawing.Point(226, 21);
            this.txtInitInfoId.Name = "txtInitInfoId";
            this.txtInitInfoId.Size = new System.Drawing.Size(65, 19);
            this.txtInitInfoId.TabIndex = 1;
            // 
            // combInitSubSysID
            // 
            this.combInitSubSysID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combInitSubSysID.FormattingEnabled = true;
            this.combInitSubSysID.Location = new System.Drawing.Point(90, 20);
            this.combInitSubSysID.Name = "combInitSubSysID";
            this.combInitSubSysID.Size = new System.Drawing.Size(65, 20);
            this.combInitSubSysID.TabIndex = 0;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(8, 24);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(80, 12);
            this.label14.TabIndex = 23;
            this.label14.Text = "サブシステムＩＤ：";
            // 
            // txtCopyKuID
            // 
            this.txtCopyKuID.Location = new System.Drawing.Point(382, 21);
            this.txtCopyKuID.Name = "txtCopyKuID";
            this.txtCopyKuID.Size = new System.Drawing.Size(85, 19);
            this.txtCopyKuID.TabIndex = 3;
            // 
            // combLogSubSysID
            // 
            this.combLogSubSysID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combLogSubSysID.FormattingEnabled = true;
            this.combLogSubSysID.Location = new System.Drawing.Point(110, 20);
            this.combLogSubSysID.Name = "combLogSubSysID";
            this.combLogSubSysID.Size = new System.Drawing.Size(65, 20);
            this.combLogSubSysID.TabIndex = 6;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(5, 24);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(104, 12);
            this.label19.TabIndex = 21;
            this.label19.Text = "論理サブシステムＩＤ：";
            // 
            // btnSearchOutput
            // 
            this.btnSearchOutput.Location = new System.Drawing.Point(21, 18);
            this.btnSearchOutput.Name = "btnSearchOutput";
            this.btnSearchOutput.Size = new System.Drawing.Size(54, 23);
            this.btnSearchOutput.TabIndex = 1;
            this.btnSearchOutput.Text = "検索";
            this.btnSearchOutput.UseVisualStyleBackColor = true;
            this.btnSearchOutput.Click += new System.EventHandler(this.btnSearchOutput_Click_1);
            // 
            // button3
            // 
            this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button3.Location = new System.Drawing.Point(983, 11);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(30, 23);
            this.button3.TabIndex = 2;
            this.button3.Text = "…";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // txtOutputPath
            // 
            this.txtOutputPath.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtOutputPath.Location = new System.Drawing.Point(60, 13);
            this.txtOutputPath.Name = "txtOutputPath";
            this.txtOutputPath.Size = new System.Drawing.Size(919, 19);
            this.txtOutputPath.TabIndex = 1;
            this.txtOutputPath.TextChanged += new System.EventHandler(this.txtOutputPath_TextChanged);
            // 
            // chkMParser
            // 
            this.chkMParser.AutoSize = true;
            this.chkMParser.Location = new System.Drawing.Point(6, 21);
            this.chkMParser.Name = "chkMParser";
            this.chkMParser.Size = new System.Drawing.Size(78, 16);
            this.chkMParser.TabIndex = 1;
            this.chkMParser.Text = "パーサ定義";
            this.chkMParser.UseVisualStyleBackColor = true;
            this.chkMParser.CheckedChanged += new System.EventHandler(this.chkMParser_CheckedChanged);
            // 
            // chkSettingCond
            // 
            this.chkSettingCond.AutoSize = true;
            this.chkSettingCond.Location = new System.Drawing.Point(554, 21);
            this.chkSettingCond.Name = "chkSettingCond";
            this.chkSettingCond.Size = new System.Drawing.Size(84, 16);
            this.chkSettingCond.TabIndex = 6;
            this.chkSettingCond.Text = "設定条件表";
            this.chkSettingCond.UseVisualStyleBackColor = true;
            this.chkSettingCond.CheckedChanged += new System.EventHandler(this.chkSettingCond_CheckedChanged);
            // 
            // chkLogCpyKu
            // 
            this.chkLogCpyKu.AutoSize = true;
            this.chkLogCpyKu.Location = new System.Drawing.Point(108, 21);
            this.chkLogCpyKu.Name = "chkLogCpyKu";
            this.chkLogCpyKu.Size = new System.Drawing.Size(87, 16);
            this.chkLogCpyKu.TabIndex = 2;
            this.chkLogCpyKu.Text = "論理コピー句";
            this.chkLogCpyKu.UseVisualStyleBackColor = true;
            this.chkLogCpyKu.CheckedChanged += new System.EventHandler(this.chkLogCpyKu_CheckedChanged);
            // 
            // chkItem
            // 
            this.chkItem.AutoSize = true;
            this.chkItem.Location = new System.Drawing.Point(344, 21);
            this.chkItem.Name = "chkItem";
            this.chkItem.Size = new System.Drawing.Size(97, 16);
            this.chkItem.TabIndex = 4;
            this.chkItem.Text = "アイテム説明書";
            this.chkItem.UseVisualStyleBackColor = true;
            this.chkItem.CheckedChanged += new System.EventHandler(this.chkItem_CheckedChanged);
            // 
            // chkItmMap
            // 
            this.chkItmMap.AutoSize = true;
            this.chkItmMap.Location = new System.Drawing.Point(449, 21);
            this.chkItmMap.Name = "chkItmMap";
            this.chkItmMap.Size = new System.Drawing.Size(97, 16);
            this.chkItmMap.TabIndex = 5;
            this.chkItmMap.Text = "アイテム構成図";
            this.chkItmMap.UseVisualStyleBackColor = true;
            this.chkItmMap.CheckedChanged += new System.EventHandler(this.chkItmMap_CheckedChanged);
            // 
            // chkPhyLogMapping
            // 
            this.chkPhyLogMapping.AutoSize = true;
            this.chkPhyLogMapping.Location = new System.Drawing.Point(203, 21);
            this.chkPhyLogMapping.Name = "chkPhyLogMapping";
            this.chkPhyLogMapping.Size = new System.Drawing.Size(133, 16);
            this.chkPhyLogMapping.TabIndex = 3;
            this.chkPhyLogMapping.Text = "物理/論理マッピング表";
            this.chkPhyLogMapping.UseVisualStyleBackColor = true;
            this.chkPhyLogMapping.CheckedChanged += new System.EventHandler(this.chkPhyLogMapping_CheckedChanged);
            // 
            // chkPhyCpyKu
            // 
            this.chkPhyCpyKu.AutoSize = true;
            this.chkPhyCpyKu.Location = new System.Drawing.Point(13, 21);
            this.chkPhyCpyKu.Name = "chkPhyCpyKu";
            this.chkPhyCpyKu.Size = new System.Drawing.Size(87, 16);
            this.chkPhyCpyKu.TabIndex = 1;
            this.chkPhyCpyKu.Text = "物理コピー句";
            this.chkPhyCpyKu.UseVisualStyleBackColor = true;
            this.chkPhyCpyKu.CheckedChanged += new System.EventHandler(this.chkPhyCpyKu_CheckedChanged_1);
            // 
            // btnOutput
            // 
            this.btnOutput.Location = new System.Drawing.Point(825, 18);
            this.btnOutput.Name = "btnOutput";
            this.btnOutput.Size = new System.Drawing.Size(54, 23);
            this.btnOutput.TabIndex = 8;
            this.btnOutput.Text = "出力";
            this.btnOutput.UseVisualStyleBackColor = true;
            this.btnOutput.Click += new System.EventHandler(this.btnOutput_Click_1);
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1045, 697);
            this.tabControl1.TabIndex = 13;
            this.tabControl1.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl1_Selecting);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage1.Controls.Add(this.groupBox5);
            this.tabPage1.Controls.Add(this.inputTypeGBox);
            this.tabPage1.Controls.Add(this.clearBtn);
            this.tabPage1.Controls.Add(this.groupBox8);
            this.tabPage1.Controls.Add(this.Excute);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1037, 671);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "登録";
            // 
            // groupBox5
            // 
            this.groupBox5.AccessibleRole = System.Windows.Forms.AccessibleRole.Cursor;
            this.groupBox5.Controls.Add(this.label21);
            this.groupBox5.Controls.Add(this.label20);
            this.groupBox5.Controls.Add(this.label18);
            this.groupBox5.Controls.Add(this.label17);
            this.groupBox5.Location = new System.Drawing.Point(3, 293);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(1031, 144);
            this.groupBox5.TabIndex = 20;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "情報部ＩＤの入力方";
            this.groupBox5.Enter += new System.EventHandler(this.groupBox5_Enter);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(29, 108);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(314, 12);
            this.label21.TabIndex = 4;
            this.label21.Text = "・　パーサ定義で必要となるインタフェースは最上位項目タグを入力";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(29, 82);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(270, 12);
            this.label20.TabIndex = 3;
            this.label20.Text = "・　内部インタフェースコピー句の場合はコピー句ＩＤを入力";
            this.label20.Click += new System.EventHandler(this.label20_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(15, 57);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(352, 12);
            this.label18.TabIndex = 2;
            this.label18.Text = "２．システム間インタフェース以外の場合は、以下に従って入力してください。";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(15, 30);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(315, 12);
            this.label17.TabIndex = 1;
            this.label17.Text = "１．システム間インタフェースの場合は情報部ＩＤを入力してください。";
            // 
            // inputTypeGBox
            // 
            this.inputTypeGBox.Controls.Add(this.RdoItemInfoFile);
            this.inputTypeGBox.Controls.Add(this.RdoCopyKuToolRefSheet);
            this.inputTypeGBox.Controls.Add(this.RdoCopyku);
            this.inputTypeGBox.Location = new System.Drawing.Point(0, 5);
            this.inputTypeGBox.Name = "inputTypeGBox";
            this.inputTypeGBox.Size = new System.Drawing.Size(1031, 129);
            this.inputTypeGBox.TabIndex = 23;
            this.inputTypeGBox.TabStop = false;
            this.inputTypeGBox.Text = "入力種別";
            // 
            // RdoItemInfoFile
            // 
            this.RdoItemInfoFile.AutoSize = true;
            this.RdoItemInfoFile.Location = new System.Drawing.Point(18, 59);
            this.RdoItemInfoFile.Name = "RdoItemInfoFile";
            this.RdoItemInfoFile.Size = new System.Drawing.Size(96, 16);
            this.RdoItemInfoFile.TabIndex = 17;
            this.RdoItemInfoFile.TabStop = true;
            this.RdoItemInfoFile.Text = "アイテム説明書";
            this.RdoItemInfoFile.UseVisualStyleBackColor = true;
            this.RdoItemInfoFile.CheckedChanged += new System.EventHandler(this.RdoItemInfoFile_CheckedChanged);
            // 
            // RdoCopyKuToolRefSheet
            // 
            this.RdoCopyKuToolRefSheet.AutoSize = true;
            this.RdoCopyKuToolRefSheet.Location = new System.Drawing.Point(18, 90);
            this.RdoCopyKuToolRefSheet.Name = "RdoCopyKuToolRefSheet";
            this.RdoCopyKuToolRefSheet.Size = new System.Drawing.Size(239, 16);
            this.RdoCopyKuToolRefSheet.TabIndex = 16;
            this.RdoCopyKuToolRefSheet.TabStop = true;
            this.RdoCopyKuToolRefSheet.Text = "ツール専用入力シート（コピー句情報入力用）";
            this.RdoCopyKuToolRefSheet.UseVisualStyleBackColor = true;
            this.RdoCopyKuToolRefSheet.CheckedChanged += new System.EventHandler(this.RdoCopyKuToolRefSheet_CheckedChanged);
            // 
            // RdoCopyku
            // 
            this.RdoCopyku.AutoSize = true;
            this.RdoCopyku.Location = new System.Drawing.Point(18, 24);
            this.RdoCopyku.Name = "RdoCopyku";
            this.RdoCopyku.Size = new System.Drawing.Size(154, 16);
            this.RdoCopyku.TabIndex = 15;
            this.RdoCopyku.TabStop = true;
            this.RdoCopyku.Text = "コピー句ファイル（ＣＯＢＯＬ）";
            this.RdoCopyku.UseVisualStyleBackColor = true;
            this.RdoCopyku.CheckedChanged += new System.EventHandler(this.RdoCopyku_CheckedChanged);
            // 
            // clearBtn
            // 
            this.clearBtn.Location = new System.Drawing.Point(872, 556);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(111, 29);
            this.clearBtn.TabIndex = 22;
            this.clearBtn.Text = "クリア";
            this.clearBtn.UseVisualStyleBackColor = true;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.AccessibleRole = System.Windows.Forms.AccessibleRole.Cursor;
            this.groupBox8.Controls.Add(this.cmbSubSysID);
            this.groupBox8.Controls.Add(this.cmbAddSize);
            this.groupBox8.Controls.Add(this.lblAddressSize);
            this.groupBox8.Controls.Add(this.label12);
            this.groupBox8.Controls.Add(this.txtInputPath);
            this.groupBox8.Controls.Add(this.label13);
            this.groupBox8.Controls.Add(this.btnBrowse);
            this.groupBox8.Controls.Add(this.txtInfoId);
            this.groupBox8.Controls.Add(this.label15);
            this.groupBox8.Location = new System.Drawing.Point(0, 140);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(1031, 147);
            this.groupBox8.TabIndex = 19;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "入力パラメタ";
            // 
            // cmbSubSysID
            // 
            this.cmbSubSysID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSubSysID.Font = new System.Drawing.Font("ＭＳ 明朝", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.cmbSubSysID.FormattingEnabled = true;
            this.cmbSubSysID.Location = new System.Drawing.Point(93, 28);
            this.cmbSubSysID.Name = "cmbSubSysID";
            this.cmbSubSysID.Size = new System.Drawing.Size(101, 20);
            this.cmbSubSysID.TabIndex = 10;
            // 
            // cmbAddSize
            // 
            this.cmbAddSize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAddSize.Font = new System.Drawing.Font("ＭＳ 明朝", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.cmbAddSize.FormattingEnabled = true;
            this.cmbAddSize.Items.AddRange(new object[] {
            "",
            "4",
            "8"});
            this.cmbAddSize.Location = new System.Drawing.Point(518, 26);
            this.cmbAddSize.Name = "cmbAddSize";
            this.cmbAddSize.Size = new System.Drawing.Size(101, 20);
            this.cmbAddSize.TabIndex = 9;
            // 
            // lblAddressSize
            // 
            this.lblAddressSize.AutoSize = true;
            this.lblAddressSize.Location = new System.Drawing.Point(409, 31);
            this.lblAddressSize.Name = "lblAddressSize";
            this.lblAddressSize.Size = new System.Drawing.Size(103, 12);
            this.lblAddressSize.TabIndex = 8;
            this.lblAddressSize.Text = "ＡＤＤＲＥＳＳサイズ：";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 31);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(80, 12);
            this.label12.TabIndex = 6;
            this.label12.Text = "サブシステムＩＤ：";
            // 
            // txtInputPath
            // 
            this.txtInputPath.Location = new System.Drawing.Point(84, 74);
            this.txtInputPath.Name = "txtInputPath";
            this.txtInputPath.Size = new System.Drawing.Size(805, 19);
            this.txtInputPath.TabIndex = 5;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(3, 77);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(69, 12);
            this.label13.TabIndex = 4;
            this.label13.Text = "入力ファイル：";
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(895, 72);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(54, 23);
            this.btnBrowse.TabIndex = 2;
            this.btnBrowse.Text = "参照";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // txtInfoId
            // 
            this.txtInfoId.Location = new System.Drawing.Point(281, 27);
            this.txtInfoId.Name = "txtInfoId";
            this.txtInfoId.Size = new System.Drawing.Size(106, 19);
            this.txtInfoId.TabIndex = 3;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(216, 31);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(59, 12);
            this.label15.TabIndex = 2;
            this.label15.Text = "情報部ＩＤ：";
            // 
            // Excute
            // 
            this.Excute.Location = new System.Drawing.Point(734, 556);
            this.Excute.Name = "Excute";
            this.Excute.Size = new System.Drawing.Size(111, 29);
            this.Excute.TabIndex = 21;
            this.Excute.Text = "登録";
            this.Excute.UseVisualStyleBackColor = true;
            this.Excute.Click += new System.EventHandler(this.Excute_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage2.Controls.Add(this.grpEditMPaser);
            this.tabPage2.Controls.Add(this.grpColumn);
            this.tabPage2.Controls.Add(this.grpEditOutput);
            this.tabPage2.Controls.Add(this.pnlEdit1);
            this.tabPage2.Controls.Add(this.grpEditPhysicif);
            this.tabPage2.Controls.Add(this.grpEditPhysicFile);
            this.tabPage2.Controls.Add(this.grpEditSubsys);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1037, 671);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "編集";
            // 
            // grpEditMPaser
            // 
            this.grpEditMPaser.Controls.Add(this.btnEditMPaserSet);
            this.grpEditMPaser.Controls.Add(this.label16);
            this.grpEditMPaser.Controls.Add(this.txtEditMPaserLayoutDef);
            this.grpEditMPaser.Enabled = false;
            this.grpEditMPaser.Location = new System.Drawing.Point(8, 204);
            this.grpEditMPaser.Name = "grpEditMPaser";
            this.grpEditMPaser.Size = new System.Drawing.Size(297, 43);
            this.grpEditMPaser.TabIndex = 3;
            this.grpEditMPaser.TabStop = false;
            this.grpEditMPaser.Text = "物理Ｍパーサ情報";
            // 
            // btnEditMPaserSet
            // 
            this.btnEditMPaserSet.Enabled = false;
            this.btnEditMPaserSet.Location = new System.Drawing.Point(231, 15);
            this.btnEditMPaserSet.Name = "btnEditMPaserSet";
            this.btnEditMPaserSet.Size = new System.Drawing.Size(54, 23);
            this.btnEditMPaserSet.TabIndex = 15;
            this.btnEditMPaserSet.Text = "反映";
            this.btnEditMPaserSet.UseVisualStyleBackColor = true;
            this.btnEditMPaserSet.Click += new System.EventHandler(this.btnEditMPaserSet_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 20);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(73, 12);
            this.label16.TabIndex = 14;
            this.label16.Text = "レイアウト定義";
            // 
            // txtEditMPaserLayoutDef
            // 
            this.txtEditMPaserLayoutDef.Location = new System.Drawing.Point(86, 17);
            this.txtEditMPaserLayoutDef.Name = "txtEditMPaserLayoutDef";
            this.txtEditMPaserLayoutDef.Size = new System.Drawing.Size(139, 19);
            this.txtEditMPaserLayoutDef.TabIndex = 13;
            this.txtEditMPaserLayoutDef.TextChanged += new System.EventHandler(this.txtEditMPaserLayoutDef_TextChanged);
            // 
            // grpColumn
            // 
            this.grpColumn.Controls.Add(this.grpEditRequirement);
            this.grpColumn.Controls.Add(this.grpEditLogicif);
            this.grpColumn.Location = new System.Drawing.Point(311, 65);
            this.grpColumn.Name = "grpColumn";
            this.grpColumn.Size = new System.Drawing.Size(509, 182);
            this.grpColumn.TabIndex = 4;
            this.grpColumn.TabStop = false;
            this.grpColumn.Text = "カラム編集";
            // 
            // grpEditRequirement
            // 
            this.grpEditRequirement.Controls.Add(this.btnEditRequirementRename);
            this.grpEditRequirement.Controls.Add(this.btnEditRequirementDel);
            this.grpEditRequirement.Controls.Add(this.btnEditRequirementAdd);
            this.grpEditRequirement.Controls.Add(this.txtEditRequirement);
            this.grpEditRequirement.Controls.Add(this.lstEditRequirement);
            this.grpEditRequirement.Controls.Add(this.label8);
            this.grpEditRequirement.Enabled = false;
            this.grpEditRequirement.Location = new System.Drawing.Point(6, 21);
            this.grpEditRequirement.Name = "grpEditRequirement";
            this.grpEditRequirement.Size = new System.Drawing.Size(208, 154);
            this.grpEditRequirement.TabIndex = 1;
            this.grpEditRequirement.TabStop = false;
            this.grpEditRequirement.Text = "設定条件";
            // 
            // btnEditRequirementRename
            // 
            this.btnEditRequirementRename.Enabled = false;
            this.btnEditRequirementRename.Location = new System.Drawing.Point(137, 125);
            this.btnEditRequirementRename.Name = "btnEditRequirementRename";
            this.btnEditRequirementRename.Size = new System.Drawing.Size(54, 23);
            this.btnEditRequirementRename.TabIndex = 5;
            this.btnEditRequirementRename.Text = "変更";
            this.btnEditRequirementRename.UseVisualStyleBackColor = true;
            this.btnEditRequirementRename.Click += new System.EventHandler(this.btnEditRequirementRename_Click);
            // 
            // btnEditRequirementDel
            // 
            this.btnEditRequirementDel.Enabled = false;
            this.btnEditRequirementDel.Location = new System.Drawing.Point(77, 125);
            this.btnEditRequirementDel.Name = "btnEditRequirementDel";
            this.btnEditRequirementDel.Size = new System.Drawing.Size(54, 23);
            this.btnEditRequirementDel.TabIndex = 4;
            this.btnEditRequirementDel.Text = "削除";
            this.btnEditRequirementDel.UseVisualStyleBackColor = true;
            this.btnEditRequirementDel.Click += new System.EventHandler(this.btnEditRequirementDel_Click);
            // 
            // btnEditRequirementAdd
            // 
            this.btnEditRequirementAdd.Enabled = false;
            this.btnEditRequirementAdd.Location = new System.Drawing.Point(17, 125);
            this.btnEditRequirementAdd.Name = "btnEditRequirementAdd";
            this.btnEditRequirementAdd.Size = new System.Drawing.Size(54, 23);
            this.btnEditRequirementAdd.TabIndex = 3;
            this.btnEditRequirementAdd.Text = "追加";
            this.btnEditRequirementAdd.UseVisualStyleBackColor = true;
            this.btnEditRequirementAdd.Click += new System.EventHandler(this.btnEditRequirementAdd_Click);
            // 
            // txtEditRequirement
            // 
            this.txtEditRequirement.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtEditRequirement.Location = new System.Drawing.Point(65, 76);
            this.txtEditRequirement.Name = "txtEditRequirement";
            this.txtEditRequirement.Size = new System.Drawing.Size(126, 19);
            this.txtEditRequirement.TabIndex = 2;
            // 
            // lstEditRequirement
            // 
            this.lstEditRequirement.FormattingEnabled = true;
            this.lstEditRequirement.ItemHeight = 12;
            this.lstEditRequirement.Location = new System.Drawing.Point(65, 18);
            this.lstEditRequirement.Name = "lstEditRequirement";
            this.lstEditRequirement.Size = new System.Drawing.Size(126, 52);
            this.lstEditRequirement.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 21);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 12);
            this.label8.TabIndex = 2;
            this.label8.Text = "条件";
            // 
            // grpEditLogicif
            // 
            this.grpEditLogicif.Controls.Add(this.btnEditLogicifRename);
            this.grpEditLogicif.Controls.Add(this.btnEditLogicifDel);
            this.grpEditLogicif.Controls.Add(this.btnEditLogicifAdd);
            this.grpEditLogicif.Controls.Add(this.txtEditLogicifCopyId);
            this.grpEditLogicif.Controls.Add(this.label10);
            this.grpEditLogicif.Controls.Add(this.btnEditLogicifCopyComment);
            this.grpEditLogicif.Controls.Add(this.txtEditLogicifName);
            this.grpEditLogicif.Controls.Add(this.lstEditLogicif);
            this.grpEditLogicif.Controls.Add(this.label9);
            this.grpEditLogicif.Enabled = false;
            this.grpEditLogicif.Location = new System.Drawing.Point(220, 21);
            this.grpEditLogicif.Name = "grpEditLogicif";
            this.grpEditLogicif.Size = new System.Drawing.Size(283, 154);
            this.grpEditLogicif.TabIndex = 2;
            this.grpEditLogicif.TabStop = false;
            this.grpEditLogicif.Text = "論理インタフェース";
            // 
            // btnEditLogicifRename
            // 
            this.btnEditLogicifRename.Enabled = false;
            this.btnEditLogicifRename.Location = new System.Drawing.Point(137, 125);
            this.btnEditLogicifRename.Name = "btnEditLogicifRename";
            this.btnEditLogicifRename.Size = new System.Drawing.Size(54, 23);
            this.btnEditLogicifRename.TabIndex = 7;
            this.btnEditLogicifRename.Text = "変更";
            this.btnEditLogicifRename.UseVisualStyleBackColor = true;
            // 
            // btnEditLogicifDel
            // 
            this.btnEditLogicifDel.Enabled = false;
            this.btnEditLogicifDel.Location = new System.Drawing.Point(77, 125);
            this.btnEditLogicifDel.Name = "btnEditLogicifDel";
            this.btnEditLogicifDel.Size = new System.Drawing.Size(54, 23);
            this.btnEditLogicifDel.TabIndex = 6;
            this.btnEditLogicifDel.Text = "削除";
            this.btnEditLogicifDel.UseVisualStyleBackColor = true;
            // 
            // btnEditLogicifAdd
            // 
            this.btnEditLogicifAdd.Enabled = false;
            this.btnEditLogicifAdd.Location = new System.Drawing.Point(17, 126);
            this.btnEditLogicifAdd.Name = "btnEditLogicifAdd";
            this.btnEditLogicifAdd.Size = new System.Drawing.Size(54, 23);
            this.btnEditLogicifAdd.TabIndex = 5;
            this.btnEditLogicifAdd.Text = "追加";
            this.btnEditLogicifAdd.UseVisualStyleBackColor = true;
            // 
            // txtEditLogicifCopyId
            // 
            this.txtEditLogicifCopyId.Location = new System.Drawing.Point(65, 101);
            this.txtEditLogicifCopyId.Name = "txtEditLogicifCopyId";
            this.txtEditLogicifCopyId.Size = new System.Drawing.Size(126, 19);
            this.txtEditLogicifCopyId.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 104);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 12);
            this.label10.TabIndex = 11;
            this.label10.Text = "コピー句ＩＤ";
            // 
            // btnEditLogicifCopyComment
            // 
            this.btnEditLogicifCopyComment.Location = new System.Drawing.Point(197, 99);
            this.btnEditLogicifCopyComment.Name = "btnEditLogicifCopyComment";
            this.btnEditLogicifCopyComment.Size = new System.Drawing.Size(80, 23);
            this.btnEditLogicifCopyComment.TabIndex = 4;
            this.btnEditLogicifCopyComment.Text = "コメント編集";
            this.btnEditLogicifCopyComment.UseVisualStyleBackColor = true;
            this.btnEditLogicifCopyComment.Click += new System.EventHandler(this.btnEditLogicifCopyComment_Click);
            // 
            // txtEditLogicifName
            // 
            this.txtEditLogicifName.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtEditLogicifName.Location = new System.Drawing.Point(65, 76);
            this.txtEditLogicifName.Name = "txtEditLogicifName";
            this.txtEditLogicifName.Size = new System.Drawing.Size(126, 19);
            this.txtEditLogicifName.TabIndex = 2;
            // 
            // lstEditLogicif
            // 
            this.lstEditLogicif.FormattingEnabled = true;
            this.lstEditLogicif.ItemHeight = 12;
            this.lstEditLogicif.Location = new System.Drawing.Point(65, 18);
            this.lstEditLogicif.Name = "lstEditLogicif";
            this.lstEditLogicif.Size = new System.Drawing.Size(126, 52);
            this.lstEditLogicif.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 21);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 2;
            this.label9.Text = "論理条件";
            // 
            // grpEditOutput
            // 
            this.grpEditOutput.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.grpEditOutput.Controls.Add(this.btnEditOutput);
            this.grpEditOutput.Controls.Add(this.chkEditOutputLayoutText);
            this.grpEditOutput.Controls.Add(this.chkEditOutputLayoutCsv);
            this.grpEditOutput.Controls.Add(this.chkEditOutputCopy);
            this.grpEditOutput.Controls.Add(this.btnEditOutputRef);
            this.grpEditOutput.Controls.Add(this.txtEditOutputPath);
            this.grpEditOutput.Controls.Add(this.label11);
            this.grpEditOutput.Enabled = false;
            this.grpEditOutput.Location = new System.Drawing.Point(6, 617);
            this.grpEditOutput.Name = "grpEditOutput";
            this.grpEditOutput.Size = new System.Drawing.Size(1006, 46);
            this.grpEditOutput.TabIndex = 6;
            this.grpEditOutput.TabStop = false;
            this.grpEditOutput.Text = "出力";
            // 
            // btnEditOutput
            // 
            this.btnEditOutput.Enabled = false;
            this.btnEditOutput.Location = new System.Drawing.Point(929, 16);
            this.btnEditOutput.Name = "btnEditOutput";
            this.btnEditOutput.Size = new System.Drawing.Size(54, 23);
            this.btnEditOutput.TabIndex = 6;
            this.btnEditOutput.Text = "出力";
            this.btnEditOutput.UseVisualStyleBackColor = true;
            this.btnEditOutput.Click += new System.EventHandler(this.btnEditOutput_Click);
            // 
            // chkEditOutputLayoutText
            // 
            this.chkEditOutputLayoutText.AutoSize = true;
            this.chkEditOutputLayoutText.Location = new System.Drawing.Point(779, 20);
            this.chkEditOutputLayoutText.Name = "chkEditOutputLayoutText";
            this.chkEditOutputLayoutText.Size = new System.Drawing.Size(144, 16);
            this.chkEditOutputLayoutText.TabIndex = 5;
            this.chkEditOutputLayoutText.Text = "物理レイアウト定義(text)";
            this.chkEditOutputLayoutText.UseVisualStyleBackColor = true;
            this.chkEditOutputLayoutText.CheckedChanged += new System.EventHandler(this.chkEditOutputLayoutText_CheckedChanged);
            // 
            // chkEditOutputLayoutCsv
            // 
            this.chkEditOutputLayoutCsv.AutoSize = true;
            this.chkEditOutputLayoutCsv.Location = new System.Drawing.Point(631, 20);
            this.chkEditOutputLayoutCsv.Name = "chkEditOutputLayoutCsv";
            this.chkEditOutputLayoutCsv.Size = new System.Drawing.Size(142, 16);
            this.chkEditOutputLayoutCsv.TabIndex = 4;
            this.chkEditOutputLayoutCsv.Text = "物理レイアウト定義(csv)";
            this.chkEditOutputLayoutCsv.UseVisualStyleBackColor = true;
            this.chkEditOutputLayoutCsv.CheckedChanged += new System.EventHandler(this.chkEditOutputLayoutCsv_CheckedChanged);
            // 
            // chkEditOutputCopy
            // 
            this.chkEditOutputCopy.AutoSize = true;
            this.chkEditOutputCopy.Location = new System.Drawing.Point(562, 20);
            this.chkEditOutputCopy.Name = "chkEditOutputCopy";
            this.chkEditOutputCopy.Size = new System.Drawing.Size(63, 16);
            this.chkEditOutputCopy.TabIndex = 3;
            this.chkEditOutputCopy.Text = "コピー句";
            this.chkEditOutputCopy.UseVisualStyleBackColor = true;
            this.chkEditOutputCopy.CheckedChanged += new System.EventHandler(this.chkEditOutputCopy_CheckedChanged);
            // 
            // btnEditOutputRef
            // 
            this.btnEditOutputRef.Location = new System.Drawing.Point(502, 16);
            this.btnEditOutputRef.Name = "btnEditOutputRef";
            this.btnEditOutputRef.Size = new System.Drawing.Size(54, 23);
            this.btnEditOutputRef.TabIndex = 2;
            this.btnEditOutputRef.Text = "...";
            this.btnEditOutputRef.UseVisualStyleBackColor = true;
            this.btnEditOutputRef.Click += new System.EventHandler(this.btnEditOutputRef_Click);
            // 
            // txtEditOutputPath
            // 
            this.txtEditOutputPath.Location = new System.Drawing.Point(67, 18);
            this.txtEditOutputPath.Name = "txtEditOutputPath";
            this.txtEditOutputPath.Size = new System.Drawing.Size(429, 19);
            this.txtEditOutputPath.TabIndex = 1;
            this.txtEditOutputPath.TextChanged += new System.EventHandler(this.txtEditOutputPath_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(8, 21);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 12);
            this.label11.TabIndex = 5;
            this.label11.Text = "格納場所";
            // 
            // pnlEdit1
            // 
            this.pnlEdit1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlEdit1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlEdit1.Controls.Add(this.tsEditToolBar);
            this.pnlEdit1.Controls.Add(this.dgvEditItemEditor);
            this.pnlEdit1.Location = new System.Drawing.Point(6, 253);
            this.pnlEdit1.Name = "pnlEdit1";
            this.pnlEdit1.Size = new System.Drawing.Size(1025, 358);
            this.pnlEdit1.TabIndex = 5;
            // 
            // tsEditToolBar
            // 
            this.tsEditToolBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel1,
            this.btnEditViewItemInfo,
            this.btnEditViewCopyInfo,
            this.btnEditViewRequirment,
            this.btnEditViewLogicif,
            this.toolStripSeparator1,
            this.btnEditCommit,
            this.toolStripSeparator2});
            this.tsEditToolBar.Location = new System.Drawing.Point(0, 0);
            this.tsEditToolBar.Name = "tsEditToolBar";
            this.tsEditToolBar.Size = new System.Drawing.Size(1023, 25);
            this.tsEditToolBar.TabIndex = 0;
            this.tsEditToolBar.Text = "toolStrip1";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(32, 22);
            this.toolStripLabel1.Text = "表示";
            // 
            // btnEditViewItemInfo
            // 
            this.btnEditViewItemInfo.Checked = true;
            this.btnEditViewItemInfo.CheckOnClick = true;
            this.btnEditViewItemInfo.CheckState = System.Windows.Forms.CheckState.Checked;
            this.btnEditViewItemInfo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnEditViewItemInfo.Image = ((System.Drawing.Image)(resources.GetObject("btnEditViewItemInfo.Image")));
            this.btnEditViewItemInfo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnEditViewItemInfo.Name = "btnEditViewItemInfo";
            this.btnEditViewItemInfo.Size = new System.Drawing.Size(84, 22);
            this.btnEditViewItemInfo.Text = "アイテム情報";
            this.btnEditViewItemInfo.CheckedChanged += new System.EventHandler(this.btnEditViewItemInfo_CheckedChanged);
            // 
            // btnEditViewCopyInfo
            // 
            this.btnEditViewCopyInfo.Checked = true;
            this.btnEditViewCopyInfo.CheckOnClick = true;
            this.btnEditViewCopyInfo.CheckState = System.Windows.Forms.CheckState.Checked;
            this.btnEditViewCopyInfo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnEditViewCopyInfo.Image = ((System.Drawing.Image)(resources.GetObject("btnEditViewCopyInfo.Image")));
            this.btnEditViewCopyInfo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnEditViewCopyInfo.Name = "btnEditViewCopyInfo";
            this.btnEditViewCopyInfo.Size = new System.Drawing.Size(84, 22);
            this.btnEditViewCopyInfo.Text = "コピー句情報";
            this.btnEditViewCopyInfo.CheckedChanged += new System.EventHandler(this.btnEditViewCopyInfo_CheckedChanged);
            // 
            // btnEditViewRequirment
            // 
            this.btnEditViewRequirment.Checked = true;
            this.btnEditViewRequirment.CheckOnClick = true;
            this.btnEditViewRequirment.CheckState = System.Windows.Forms.CheckState.Checked;
            this.btnEditViewRequirment.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnEditViewRequirment.Image = ((System.Drawing.Image)(resources.GetObject("btnEditViewRequirment.Image")));
            this.btnEditViewRequirment.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnEditViewRequirment.Name = "btnEditViewRequirment";
            this.btnEditViewRequirment.Size = new System.Drawing.Size(60, 22);
            this.btnEditViewRequirment.Text = "設定条件";
            this.btnEditViewRequirment.CheckedChanged += new System.EventHandler(this.btnEditViewRequirment_CheckedChanged);
            // 
            // btnEditViewLogicif
            // 
            this.btnEditViewLogicif.Checked = true;
            this.btnEditViewLogicif.CheckOnClick = true;
            this.btnEditViewLogicif.CheckState = System.Windows.Forms.CheckState.Checked;
            this.btnEditViewLogicif.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnEditViewLogicif.Image = ((System.Drawing.Image)(resources.GetObject("btnEditViewLogicif.Image")));
            this.btnEditViewLogicif.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnEditViewLogicif.Name = "btnEditViewLogicif";
            this.btnEditViewLogicif.Size = new System.Drawing.Size(120, 22);
            this.btnEditViewLogicif.Text = "論理インタフェース";
            this.btnEditViewLogicif.CheckedChanged += new System.EventHandler(this.btnEditViewLogicif_CheckedChanged);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // btnEditCommit
            // 
            this.btnEditCommit.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnEditCommit.Enabled = false;
            this.btnEditCommit.Image = ((System.Drawing.Image)(resources.GetObject("btnEditCommit.Image")));
            this.btnEditCommit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnEditCommit.Name = "btnEditCommit";
            this.btnEditCommit.Size = new System.Drawing.Size(52, 22);
            this.btnEditCommit.Text = "更新";
            this.btnEditCommit.Click += new System.EventHandler(this.btnEditCommit_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // dgvEditItemEditor
            // 
            this.dgvEditItemEditor.AllowUserToAddRows = false;
            this.dgvEditItemEditor.AllowUserToDeleteRows = false;
            this.dgvEditItemEditor.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvEditItemEditor.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvEditItemEditor.ColumnHeadersHeight = 80;
            this.dgvEditItemEditor.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colEdit1,
            this.colEdit2,
            this.colEdit3,
            this.colEdit4,
            this.colEdit5,
            this.colEdit6,
            this.colEdit7,
            this.colEdit8,
            this.colEdit9,
            this.colEdit10,
            this.colEdit11,
            this.colEdit12,
            this.colEdit13,
            this.colEdit14,
            this.colEdit15,
            this.colEdit16,
            this.colEdit17,
            this.colEdit18,
            this.Column1,
            this.colEdit19,
            this.colEdit20,
            this.colEdit21,
            this.colEdit22,
            this.Column2,
            this.colEdit23,
            this.colEdit24});
            this.dgvEditItemEditor.Location = new System.Drawing.Point(3, 28);
            this.dgvEditItemEditor.Name = "dgvEditItemEditor";
            this.dgvEditItemEditor.ReadOnly = true;
            this.dgvEditItemEditor.RowTemplate.Height = 21;
            this.dgvEditItemEditor.Size = new System.Drawing.Size(1017, 325);
            this.dgvEditItemEditor.TabIndex = 1;
            this.dgvEditItemEditor.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgvEditItemEditor_CellBeginEdit);
            this.dgvEditItemEditor.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvEditItemEditor_CellContentClick);
            this.dgvEditItemEditor.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvEditItemEditor_CellEndEdit);
            this.dgvEditItemEditor.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvEditItemEditor_CellValueChanged);
            this.dgvEditItemEditor.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvEditItemEditor_RowEnter);
            this.dgvEditItemEditor.RowValidated += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvEditItemEditor_RowValidated);
            // 
            // colEdit1
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            this.colEdit1.DefaultCellStyle = dataGridViewCellStyle1;
            this.colEdit1.HeaderText = "レベル";
            this.colEdit1.Name = "colEdit1";
            this.colEdit1.ReadOnly = true;
            this.colEdit1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colEdit1.Width = 50;
            // 
            // colEdit2
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            this.colEdit2.DefaultCellStyle = dataGridViewCellStyle2;
            this.colEdit2.HeaderText = "アイテム記号名称";
            this.colEdit2.Name = "colEdit2";
            this.colEdit2.ReadOnly = true;
            this.colEdit2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colEdit2.Width = 140;
            // 
            // colEdit3
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            this.colEdit3.DefaultCellStyle = dataGridViewCellStyle3;
            this.colEdit3.HeaderText = "アイテム名称";
            this.colEdit3.Name = "colEdit3";
            this.colEdit3.ReadOnly = true;
            this.colEdit3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colEdit3.Width = 140;
            // 
            // colEdit4
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            this.colEdit4.DefaultCellStyle = dataGridViewCellStyle4;
            this.colEdit4.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.colEdit4.HeaderText = "データ形式";
            this.colEdit4.Items.AddRange(new object[] {
            "ADR",
            "BIN",
            "BIT",
            "CHAR",
            "CODE",
            "DEC",
            "GROUP",
            "HED",
            "HEX",
            "JISC",
            "JISK",
            "SJIS"});
            this.colEdit4.Name = "colEdit4";
            this.colEdit4.ReadOnly = true;
            // 
            // colEdit5
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            this.colEdit5.DefaultCellStyle = dataGridViewCellStyle5;
            this.colEdit5.HeaderText = "データサイズ";
            this.colEdit5.Name = "colEdit5";
            this.colEdit5.ReadOnly = true;
            this.colEdit5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colEdit5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colEdit6
            // 
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            this.colEdit6.DefaultCellStyle = dataGridViewCellStyle6;
            this.colEdit6.HeaderText = "繰返し数";
            this.colEdit6.Name = "colEdit6";
            this.colEdit6.ReadOnly = true;
            this.colEdit6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colEdit6.Width = 70;
            // 
            // colEdit7
            // 
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colEdit7.DefaultCellStyle = dataGridViewCellStyle7;
            this.colEdit7.HeaderText = "アイテム内容";
            this.colEdit7.Name = "colEdit7";
            this.colEdit7.ReadOnly = true;
            this.colEdit7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colEdit7.Width = 500;
            // 
            // colEdit8
            // 
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            this.colEdit8.DefaultCellStyle = dataGridViewCellStyle8;
            this.colEdit8.HeaderText = "候補値";
            this.colEdit8.Name = "colEdit8";
            this.colEdit8.ReadOnly = true;
            // 
            // colEdit9
            // 
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            this.colEdit9.DefaultCellStyle = dataGridViewCellStyle9;
            this.colEdit9.HeaderText = "図表";
            this.colEdit9.Name = "colEdit9";
            this.colEdit9.ReadOnly = true;
            // 
            // colEdit10
            // 
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colEdit10.DefaultCellStyle = dataGridViewCellStyle10;
            this.colEdit10.HeaderText = "記事";
            this.colEdit10.Name = "colEdit10";
            this.colEdit10.ReadOnly = true;
            this.colEdit10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colEdit10.Width = 200;
            // 
            // colEdit11
            // 
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            this.colEdit11.DefaultCellStyle = dataGridViewCellStyle11;
            this.colEdit11.HeaderText = "開始レベル番号";
            this.colEdit11.Name = "colEdit11";
            this.colEdit11.ReadOnly = true;
            this.colEdit11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colEdit12
            // 
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            this.colEdit12.DefaultCellStyle = dataGridViewCellStyle12;
            this.colEdit12.HeaderText = "データ形式";
            this.colEdit12.Name = "colEdit12";
            this.colEdit12.ReadOnly = true;
            this.colEdit12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colEdit13
            // 
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            this.colEdit13.DefaultCellStyle = dataGridViewCellStyle13;
            this.colEdit13.HeaderText = "";
            this.colEdit13.Name = "colEdit13";
            this.colEdit13.ReadOnly = true;
            this.colEdit13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colEdit14
            // 
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            this.colEdit14.DefaultCellStyle = dataGridViewCellStyle14;
            this.colEdit14.HeaderText = "物理ＩＤ";
            this.colEdit14.Name = "colEdit14";
            this.colEdit14.ReadOnly = true;
            this.colEdit14.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colEdit15
            // 
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            this.colEdit15.DefaultCellStyle = dataGridViewCellStyle15;
            this.colEdit15.HeaderText = "タグ名";
            this.colEdit15.Name = "colEdit15";
            this.colEdit15.ReadOnly = true;
            this.colEdit15.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colEdit16
            // 
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            this.colEdit16.DefaultCellStyle = dataGridViewCellStyle16;
            this.colEdit16.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.colEdit16.HeaderText = "Mﾊﾟｰｻ物理属性";
            this.colEdit16.Name = "colEdit16";
            this.colEdit16.ReadOnly = true;
            // 
            // colEdit17
            // 
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle17.NullValue = false;
            this.colEdit17.DefaultCellStyle = dataGridViewCellStyle17;
            this.colEdit17.HeaderText = "コード変換要";
            this.colEdit17.Name = "colEdit17";
            this.colEdit17.ReadOnly = true;
            // 
            // colEdit18
            // 
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle18.NullValue = false;
            this.colEdit18.DefaultCellStyle = dataGridViewCellStyle18;
            this.colEdit18.HeaderText = "符号有無";
            this.colEdit18.Name = "colEdit18";
            this.colEdit18.ReadOnly = true;
            // 
            // Column1
            // 
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            this.Column1.DefaultCellStyle = dataGridViewCellStyle19;
            this.Column1.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.Column1.HeaderText = "文字コード";
            this.Column1.Items.AddRange(new object[] {
            "SJIS",
            "UTF-8"});
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // colEdit19
            // 
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle20.NullValue = false;
            this.colEdit19.DefaultCellStyle = dataGridViewCellStyle20;
            this.colEdit19.HeaderText = "対象";
            this.colEdit19.Name = "colEdit19";
            this.colEdit19.ReadOnly = true;
            // 
            // colEdit20
            // 
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            this.colEdit20.DefaultCellStyle = dataGridViewCellStyle21;
            this.colEdit20.HeaderText = "開始レベル";
            this.colEdit20.Name = "colEdit20";
            this.colEdit20.ReadOnly = true;
            this.colEdit20.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colEdit21
            // 
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            this.colEdit21.DefaultCellStyle = dataGridViewCellStyle22;
            this.colEdit21.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.colEdit21.HeaderText = "Mﾊﾟｰｻ論理属性";
            this.colEdit21.Name = "colEdit21";
            this.colEdit21.ReadOnly = true;
            // 
            // colEdit22
            // 
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            this.colEdit22.DefaultCellStyle = dataGridViewCellStyle23;
            this.colEdit22.HeaderText = "Mﾊﾟｰｻ論理サイズ";
            this.colEdit22.Name = "colEdit22";
            this.colEdit22.ReadOnly = true;
            this.colEdit22.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column2
            // 
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            this.Column2.DefaultCellStyle = dataGridViewCellStyle24;
            this.Column2.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.Column2.HeaderText = "文字コード";
            this.Column2.Items.AddRange(new object[] {
            "SJIS",
            "UTF-8"});
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // colEdit23
            // 
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            this.colEdit23.DefaultCellStyle = dataGridViewCellStyle25;
            this.colEdit23.HeaderText = "コピー句Prefix";
            this.colEdit23.Name = "colEdit23";
            this.colEdit23.ReadOnly = true;
            this.colEdit23.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colEdit24
            // 
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            this.colEdit24.DefaultCellStyle = dataGridViewCellStyle26;
            this.colEdit24.HeaderText = "コピー句データ形式";
            this.colEdit24.Name = "colEdit24";
            this.colEdit24.ReadOnly = true;
            this.colEdit24.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // grpEditPhysicif
            // 
            this.grpEditPhysicif.Controls.Add(this.btnEditPhysicifDel);
            this.grpEditPhysicif.Controls.Add(this.btnEditPhysicifCopyComment);
            this.grpEditPhysicif.Controls.Add(this.txtEditPhysicInfoID);
            this.grpEditPhysicif.Controls.Add(this.txtEditPhysicCopyName);
            this.grpEditPhysicif.Controls.Add(this.txtEditPhysicCopyID);
            this.grpEditPhysicif.Controls.Add(this.txtEditPhysicSubsys);
            this.grpEditPhysicif.Controls.Add(this.label7);
            this.grpEditPhysicif.Controls.Add(this.label6);
            this.grpEditPhysicif.Controls.Add(this.label5);
            this.grpEditPhysicif.Controls.Add(this.label4);
            this.grpEditPhysicif.Enabled = false;
            this.grpEditPhysicif.Location = new System.Drawing.Point(8, 65);
            this.grpEditPhysicif.Name = "grpEditPhysicif";
            this.grpEditPhysicif.Size = new System.Drawing.Size(297, 133);
            this.grpEditPhysicif.TabIndex = 2;
            this.grpEditPhysicif.TabStop = false;
            this.grpEditPhysicif.Text = "物理ＩＦ";
            // 
            // btnEditPhysicifDel
            // 
            this.btnEditPhysicifDel.Location = new System.Drawing.Point(211, 91);
            this.btnEditPhysicifDel.Name = "btnEditPhysicifDel";
            this.btnEditPhysicifDel.Size = new System.Drawing.Size(80, 23);
            this.btnEditPhysicifDel.TabIndex = 6;
            this.btnEditPhysicifDel.Text = "情報部削除";
            this.btnEditPhysicifDel.UseVisualStyleBackColor = true;
            this.btnEditPhysicifDel.Click += new System.EventHandler(this.btnEditPhysicifDel_Click);
            // 
            // btnEditPhysicifCopyComment
            // 
            this.btnEditPhysicifCopyComment.Location = new System.Drawing.Point(211, 41);
            this.btnEditPhysicifCopyComment.Name = "btnEditPhysicifCopyComment";
            this.btnEditPhysicifCopyComment.Size = new System.Drawing.Size(80, 23);
            this.btnEditPhysicifCopyComment.TabIndex = 3;
            this.btnEditPhysicifCopyComment.Text = "コメント編集";
            this.btnEditPhysicifCopyComment.UseVisualStyleBackColor = true;
            this.btnEditPhysicifCopyComment.Click += new System.EventHandler(this.btnEditPhysicifCopyComment_Click);
            // 
            // txtEditPhysicInfoID
            // 
            this.txtEditPhysicInfoID.Location = new System.Drawing.Point(86, 93);
            this.txtEditPhysicInfoID.Name = "txtEditPhysicInfoID";
            this.txtEditPhysicInfoID.ReadOnly = true;
            this.txtEditPhysicInfoID.Size = new System.Drawing.Size(119, 19);
            this.txtEditPhysicInfoID.TabIndex = 5;
            // 
            // txtEditPhysicCopyName
            // 
            this.txtEditPhysicCopyName.Location = new System.Drawing.Point(86, 68);
            this.txtEditPhysicCopyName.Name = "txtEditPhysicCopyName";
            this.txtEditPhysicCopyName.ReadOnly = true;
            this.txtEditPhysicCopyName.Size = new System.Drawing.Size(199, 19);
            this.txtEditPhysicCopyName.TabIndex = 4;
            // 
            // txtEditPhysicCopyID
            // 
            this.txtEditPhysicCopyID.Location = new System.Drawing.Point(86, 43);
            this.txtEditPhysicCopyID.Name = "txtEditPhysicCopyID";
            this.txtEditPhysicCopyID.ReadOnly = true;
            this.txtEditPhysicCopyID.Size = new System.Drawing.Size(119, 19);
            this.txtEditPhysicCopyID.TabIndex = 2;
            // 
            // txtEditPhysicSubsys
            // 
            this.txtEditPhysicSubsys.Location = new System.Drawing.Point(86, 18);
            this.txtEditPhysicSubsys.Name = "txtEditPhysicSubsys";
            this.txtEditPhysicSubsys.ReadOnly = true;
            this.txtEditPhysicSubsys.Size = new System.Drawing.Size(139, 19);
            this.txtEditPhysicSubsys.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 96);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 4;
            this.label7.Text = "情報部ＩＤ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 71);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 12);
            this.label6.TabIndex = 3;
            this.label6.Text = "コピー句名称";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 46);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 12);
            this.label5.TabIndex = 2;
            this.label5.Text = "コピー句ＩＤ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 12);
            this.label4.TabIndex = 1;
            this.label4.Text = "サブシステムＩＤ";
            // 
            // grpEditPhysicFile
            // 
            this.grpEditPhysicFile.Controls.Add(this.btnEditPhysicFileIn);
            this.grpEditPhysicFile.Controls.Add(this.btnEditPhysicFileRef);
            this.grpEditPhysicFile.Controls.Add(this.txtEditPhysicFile);
            this.grpEditPhysicFile.Enabled = false;
            this.grpEditPhysicFile.Location = new System.Drawing.Point(311, 6);
            this.grpEditPhysicFile.Name = "grpEditPhysicFile";
            this.grpEditPhysicFile.Size = new System.Drawing.Size(609, 53);
            this.grpEditPhysicFile.TabIndex = 1;
            this.grpEditPhysicFile.TabStop = false;
            this.grpEditPhysicFile.Text = "物理コピー句ファイル";
            // 
            // btnEditPhysicFileIn
            // 
            this.btnEditPhysicFileIn.Enabled = false;
            this.btnEditPhysicFileIn.Location = new System.Drawing.Point(542, 16);
            this.btnEditPhysicFileIn.Name = "btnEditPhysicFileIn";
            this.btnEditPhysicFileIn.Size = new System.Drawing.Size(54, 23);
            this.btnEditPhysicFileIn.TabIndex = 2;
            this.btnEditPhysicFileIn.Text = "読込";
            this.btnEditPhysicFileIn.UseVisualStyleBackColor = true;
            this.btnEditPhysicFileIn.Click += new System.EventHandler(this.btnEditPhysicFileIn_Click);
            // 
            // btnEditPhysicFileRef
            // 
            this.btnEditPhysicFileRef.Location = new System.Drawing.Point(482, 16);
            this.btnEditPhysicFileRef.Name = "btnEditPhysicFileRef";
            this.btnEditPhysicFileRef.Size = new System.Drawing.Size(54, 23);
            this.btnEditPhysicFileRef.TabIndex = 1;
            this.btnEditPhysicFileRef.Text = "...";
            this.btnEditPhysicFileRef.UseVisualStyleBackColor = true;
            this.btnEditPhysicFileRef.Click += new System.EventHandler(this.btnEditPhysicFileRef_Click);
            // 
            // txtEditPhysicFile
            // 
            this.txtEditPhysicFile.Location = new System.Drawing.Point(6, 18);
            this.txtEditPhysicFile.Name = "txtEditPhysicFile";
            this.txtEditPhysicFile.Size = new System.Drawing.Size(470, 19);
            this.txtEditPhysicFile.TabIndex = 0;
            this.txtEditPhysicFile.TextChanged += new System.EventHandler(this.txtEditPhysicFile_TextChanged);
            // 
            // grpEditSubsys
            // 
            this.grpEditSubsys.Controls.Add(this.btnEditTargetSubsys);
            this.grpEditSubsys.Controls.Add(this.cmbEditTargetSubsys);
            this.grpEditSubsys.Controls.Add(this.label3);
            this.grpEditSubsys.Location = new System.Drawing.Point(8, 6);
            this.grpEditSubsys.Name = "grpEditSubsys";
            this.grpEditSubsys.Size = new System.Drawing.Size(297, 53);
            this.grpEditSubsys.TabIndex = 0;
            this.grpEditSubsys.TabStop = false;
            this.grpEditSubsys.Text = "サブシステム";
            // 
            // btnEditTargetSubsys
            // 
            this.btnEditTargetSubsys.Enabled = false;
            this.btnEditTargetSubsys.Location = new System.Drawing.Point(231, 16);
            this.btnEditTargetSubsys.Name = "btnEditTargetSubsys";
            this.btnEditTargetSubsys.Size = new System.Drawing.Size(54, 23);
            this.btnEditTargetSubsys.TabIndex = 2;
            this.btnEditTargetSubsys.Text = "設定";
            this.btnEditTargetSubsys.UseVisualStyleBackColor = true;
            this.btnEditTargetSubsys.Click += new System.EventHandler(this.btnEditTargetSubsys_Click);
            // 
            // cmbEditTargetSubsys
            // 
            this.cmbEditTargetSubsys.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEditTargetSubsys.FormattingEnabled = true;
            this.cmbEditTargetSubsys.Location = new System.Drawing.Point(86, 18);
            this.cmbEditTargetSubsys.Name = "cmbEditTargetSubsys";
            this.cmbEditTargetSubsys.Size = new System.Drawing.Size(139, 20);
            this.cmbEditTargetSubsys.TabIndex = 1;
            this.cmbEditTargetSubsys.SelectedIndexChanged += new System.EventHandler(this.cmbEditTargetSubsys_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "サブシステムＩＤ";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage4.Controls.Add(this.panel1);
            this.tabPage4.Controls.Add(this.tsSheetToolBar);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1037, 671);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "アイテム説明書";
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.cvsSheet);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 29);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1031, 639);
            this.panel1.TabIndex = 3;
            // 
            // cvsSheet
            // 
            this.cvsSheet.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("cvsSheet.BackgroundImage")));
            this.cvsSheet.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.cvsSheet.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cvsSheet.CanvasItems = null;
            this.cvsSheet.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.cvsSheet.Location = new System.Drawing.Point(0, 0);
            this.cvsSheet.MinimumSize = new System.Drawing.Size(1130, 770);
            this.cvsSheet.Name = "cvsSheet";
            this.cvsSheet.Size = new System.Drawing.Size(1130, 770);
            this.cvsSheet.TabIndex = 2;
            // 
            // tsSheetToolBar
            // 
            this.tsSheetToolBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel2,
            this.btnSheetPagepre,
            this.cmbSheetPage,
            this.btnSheetPagenext,
            this.toolStripSeparator3,
            this.toolStripLabel3,
            this.btnSheetSave});
            this.tsSheetToolBar.Location = new System.Drawing.Point(3, 3);
            this.tsSheetToolBar.Name = "tsSheetToolBar";
            this.tsSheetToolBar.Size = new System.Drawing.Size(1031, 26);
            this.tsSheetToolBar.TabIndex = 0;
            this.tsSheetToolBar.Text = "toolStrip1";
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(44, 23);
            this.toolStripLabel2.Text = "頁番号";
            // 
            // btnSheetPagepre
            // 
            this.btnSheetPagepre.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSheetPagepre.Image = ((System.Drawing.Image)(resources.GetObject("btnSheetPagepre.Image")));
            this.btnSheetPagepre.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSheetPagepre.Name = "btnSheetPagepre";
            this.btnSheetPagepre.Size = new System.Drawing.Size(23, 23);
            this.btnSheetPagepre.Text = "前頁";
            this.btnSheetPagepre.Click += new System.EventHandler(this.btnSheetPagepre_Click);
            // 
            // cmbSheetPage
            // 
            this.cmbSheetPage.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSheetPage.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.cmbSheetPage.Name = "cmbSheetPage";
            this.cmbSheetPage.Size = new System.Drawing.Size(75, 26);
            this.cmbSheetPage.SelectedIndexChanged += new System.EventHandler(this.cmbSheetPage_SelectedIndexChanged);
            // 
            // btnSheetPagenext
            // 
            this.btnSheetPagenext.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSheetPagenext.Image = ((System.Drawing.Image)(resources.GetObject("btnSheetPagenext.Image")));
            this.btnSheetPagenext.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSheetPagenext.Name = "btnSheetPagenext";
            this.btnSheetPagenext.Size = new System.Drawing.Size(23, 23);
            this.btnSheetPagenext.Text = "次頁";
            this.btnSheetPagenext.Click += new System.EventHandler(this.btnSheetPagenext_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 26);
            // 
            // toolStripLabel3
            // 
            this.toolStripLabel3.Name = "toolStripLabel3";
            this.toolStripLabel3.Size = new System.Drawing.Size(32, 23);
            this.toolStripLabel3.Text = "出力";
            // 
            // btnSheetSave
            // 
            this.btnSheetSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSheetSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSheetSave.Image")));
            this.btnSheetSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSheetSave.Name = "btnSheetSave";
            this.btnSheetSave.Size = new System.Drawing.Size(23, 23);
            this.btnSheetSave.Text = "保存";
            this.btnSheetSave.Click += new System.EventHandler(this.btnSheetSave_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage5.Controls.Add(this.panel2);
            this.tabPage5.Controls.Add(this.tsPictureToolBar);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1037, 671);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "アイテム構成図";
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.cvsPicture);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 29);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1031, 639);
            this.panel2.TabIndex = 2;
            // 
            // cvsPicture
            // 
            this.cvsPicture.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("cvsPicture.BackgroundImage")));
            this.cvsPicture.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.cvsPicture.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cvsPicture.CanvasItems = null;
            this.cvsPicture.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.cvsPicture.Location = new System.Drawing.Point(0, 0);
            this.cvsPicture.Name = "cvsPicture";
            this.cvsPicture.Size = new System.Drawing.Size(1100, 792);
            this.cvsPicture.TabIndex = 1;
            // 
            // tsPictureToolBar
            // 
            this.tsPictureToolBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel4,
            this.btnPicturePagePre,
            this.cmbPicturePage,
            this.btnPicturePageNext,
            this.toolStripSeparator4,
            this.toolStripLabel5,
            this.btnPictureSave});
            this.tsPictureToolBar.Location = new System.Drawing.Point(3, 3);
            this.tsPictureToolBar.Name = "tsPictureToolBar";
            this.tsPictureToolBar.Size = new System.Drawing.Size(1031, 26);
            this.tsPictureToolBar.TabIndex = 0;
            this.tsPictureToolBar.Text = "toolStrip1";
            // 
            // toolStripLabel4
            // 
            this.toolStripLabel4.Name = "toolStripLabel4";
            this.toolStripLabel4.Size = new System.Drawing.Size(44, 23);
            this.toolStripLabel4.Text = "頁番号";
            // 
            // btnPicturePagePre
            // 
            this.btnPicturePagePre.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnPicturePagePre.Image = ((System.Drawing.Image)(resources.GetObject("btnPicturePagePre.Image")));
            this.btnPicturePagePre.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPicturePagePre.Name = "btnPicturePagePre";
            this.btnPicturePagePre.Size = new System.Drawing.Size(23, 23);
            this.btnPicturePagePre.Text = "前頁";
            this.btnPicturePagePre.Click += new System.EventHandler(this.btnPicturePagepre_Click);
            // 
            // cmbPicturePage
            // 
            this.cmbPicturePage.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPicturePage.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.cmbPicturePage.Name = "cmbPicturePage";
            this.cmbPicturePage.Size = new System.Drawing.Size(75, 26);
            this.cmbPicturePage.SelectedIndexChanged += new System.EventHandler(this.cmbPicturePage_SelectedIndexChanged);
            // 
            // btnPicturePageNext
            // 
            this.btnPicturePageNext.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnPicturePageNext.Image = ((System.Drawing.Image)(resources.GetObject("btnPicturePageNext.Image")));
            this.btnPicturePageNext.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPicturePageNext.Name = "btnPicturePageNext";
            this.btnPicturePageNext.Size = new System.Drawing.Size(23, 23);
            this.btnPicturePageNext.Text = "次頁";
            this.btnPicturePageNext.Click += new System.EventHandler(this.btnPicturePagenext_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 26);
            // 
            // toolStripLabel5
            // 
            this.toolStripLabel5.Name = "toolStripLabel5";
            this.toolStripLabel5.Size = new System.Drawing.Size(32, 23);
            this.toolStripLabel5.Text = "出力";
            // 
            // btnPictureSave
            // 
            this.btnPictureSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnPictureSave.Image = ((System.Drawing.Image)(resources.GetObject("btnPictureSave.Image")));
            this.btnPictureSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPictureSave.Name = "btnPictureSave";
            this.btnPictureSave.Size = new System.Drawing.Size(23, 23);
            this.btnPictureSave.Text = "保存";
            this.btnPictureSave.Click += new System.EventHandler(this.btnPictureSave_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage3.Controls.Add(this.groupBox10);
            this.tabPage3.Controls.Add(this.groupBox9);
            this.tabPage3.Controls.Add(this.groupBox7);
            this.tabPage3.Controls.Add(this.groupBox6);
            this.tabPage3.Controls.Add(this.groupBox2);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1037, 671);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "出力";
            // 
            // groupBox10
            // 
            this.groupBox10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox10.Controls.Add(this.btnSearchOutput);
            this.groupBox10.Location = new System.Drawing.Point(931, 7);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(96, 50);
            this.groupBox10.TabIndex = 3;
            this.groupBox10.TabStop = false;
            // 
            // groupBox9
            // 
            this.groupBox9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox9.Controls.Add(this.label19);
            this.groupBox9.Controls.Add(this.combLogSubSysID);
            this.groupBox9.Location = new System.Drawing.Point(752, 7);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(183, 50);
            this.groupBox9.TabIndex = 2;
            this.groupBox9.TabStop = false;
            // 
            // groupBox7
            // 
            this.groupBox7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox7.Controls.Add(this.label1);
            this.groupBox7.Controls.Add(this.txtOutputPath);
            this.groupBox7.Controls.Add(this.button3);
            this.groupBox7.Controls.Add(this.groupBox1);
            this.groupBox7.Location = new System.Drawing.Point(6, 570);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(1023, 99);
            this.groupBox7.TabIndex = 5;
            this.groupBox7.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 12);
            this.label1.TabIndex = 15;
            this.label1.Text = "出力バス：";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chkPhyCpyKu);
            this.groupBox1.Controls.Add(this.chkItem);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.btnOutput);
            this.groupBox1.Controls.Add(this.chkPhyLogMapping);
            this.groupBox1.Controls.Add(this.chkSettingCond);
            this.groupBox1.Controls.Add(this.chkItmMap);
            this.groupBox1.Controls.Add(this.chkLogCpyKu);
            this.groupBox1.Location = new System.Drawing.Point(4, 42);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1007, 50);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "出力種別";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(888, 18);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(112, 23);
            this.button1.TabIndex = 9;
            this.button1.Text = "コピー句一括出力";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.rdbTxt);
            this.groupBox3.Controls.Add(this.chkMParser);
            this.groupBox3.Controls.Add(this.rdbCSV);
            this.groupBox3.Location = new System.Drawing.Point(640, 0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(180, 50);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            // 
            // rdbTxt
            // 
            this.rdbTxt.AutoSize = true;
            this.rdbTxt.Location = new System.Drawing.Point(135, 21);
            this.rdbTxt.Name = "rdbTxt";
            this.rdbTxt.Size = new System.Drawing.Size(37, 16);
            this.rdbTxt.TabIndex = 3;
            this.rdbTxt.Text = "txt";
            this.rdbTxt.UseVisualStyleBackColor = true;
            // 
            // rdbCSV
            // 
            this.rdbCSV.AutoSize = true;
            this.rdbCSV.Checked = true;
            this.rdbCSV.Location = new System.Drawing.Point(88, 21);
            this.rdbCSV.Name = "rdbCSV";
            this.rdbCSV.Size = new System.Drawing.Size(41, 16);
            this.rdbCSV.TabIndex = 2;
            this.rdbCSV.TabStop = true;
            this.rdbCSV.Text = "csv";
            this.rdbCSV.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox6.Controls.Add(this.chkRDataAll);
            this.groupBox6.Controls.Add(this.dgvPhyData);
            this.groupBox6.Location = new System.Drawing.Point(6, 63);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(1023, 512);
            this.groupBox6.TabIndex = 4;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "物理情報一覧";
            // 
            // chkRDataAll
            // 
            this.chkRDataAll.AutoSize = true;
            this.chkRDataAll.Enabled = false;
            this.chkRDataAll.Location = new System.Drawing.Point(8, 19);
            this.chkRDataAll.Name = "chkRDataAll";
            this.chkRDataAll.Size = new System.Drawing.Size(15, 14);
            this.chkRDataAll.TabIndex = 2;
            this.chkRDataAll.UseVisualStyleBackColor = true;
            // 
            // dgvPhyData
            // 
            this.dgvPhyData.AllowUserToAddRows = false;
            this.dgvPhyData.AllowUserToResizeRows = false;
            this.dgvPhyData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPhyData.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column21,
            this.Column10,
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewTextBoxColumn20});
            this.dgvPhyData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvPhyData.Location = new System.Drawing.Point(3, 15);
            this.dgvPhyData.Name = "dgvPhyData";
            this.dgvPhyData.ReadOnly = true;
            this.dgvPhyData.RowHeadersVisible = false;
            this.dgvPhyData.RowTemplate.Height = 21;
            this.dgvPhyData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPhyData.Size = new System.Drawing.Size(1017, 494);
            this.dgvPhyData.TabIndex = 1;
            // 
            // Column21
            // 
            this.Column21.FalseValue = "0";
            this.Column21.HeaderText = "";
            this.Column21.Name = "Column21";
            this.Column21.ReadOnly = true;
            this.Column21.TrueValue = "1";
            this.Column21.Width = 20;
            // 
            // Column10
            // 
            this.Column10.HeaderText = "情報部ＩＤ";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.HeaderText = "コピー句ＩＤ";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.HeaderText = "コピー句名";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.ReadOnly = true;
            this.dataGridViewTextBoxColumn20.Width = 200;
            // 
            // msEditMenu
            // 
            this.msEditMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmInsertUp,
            this.tsmInsertDown,
            this.toolStripSeparator5,
            this.tsmRemove});
            this.msEditMenu.Name = "msEditMenu";
            this.msEditMenu.ShowImageMargin = false;
            this.msEditMenu.Size = new System.Drawing.Size(157, 76);
            // 
            // tsmInsertUp
            // 
            this.tsmInsertUp.Name = "tsmInsertUp";
            this.tsmInsertUp.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Insert)));
            this.tsmInsertUp.Size = new System.Drawing.Size(156, 22);
            this.tsmInsertUp.Text = "上に追加";
            this.tsmInsertUp.Click += new System.EventHandler(this.tsmInsert_Click);
            // 
            // tsmInsertDown
            // 
            this.tsmInsertDown.Name = "tsmInsertDown";
            this.tsmInsertDown.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.I)));
            this.tsmInsertDown.Size = new System.Drawing.Size(156, 22);
            this.tsmInsertDown.Text = "下に追加";
            this.tsmInsertDown.Click += new System.EventHandler(this.tsmInsert_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(153, 6);
            // 
            // tsmRemove
            // 
            this.tsmRemove.Name = "tsmRemove";
            this.tsmRemove.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Delete)));
            this.tsmRemove.Size = new System.Drawing.Size(156, 22);
            this.tsmRemove.Text = "削除";
            this.tsmRemove.Click += new System.EventHandler(this.tsmRemove_Click);
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            // 
            // Privilege
            // 
            this.Privilege.Name = "Privilege";
            // 
            // Interface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1045, 697);
            this.Controls.Add(this.tabControl1);
            this.Name = "Interface";
            this.Text = "インタフェース管理機能";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Interface_FormClosing);
            this.Load += new System.EventHandler(this.Interface_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.inputTypeGBox.ResumeLayout(false);
            this.inputTypeGBox.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.grpEditMPaser.ResumeLayout(false);
            this.grpEditMPaser.PerformLayout();
            this.grpColumn.ResumeLayout(false);
            this.grpEditRequirement.ResumeLayout(false);
            this.grpEditRequirement.PerformLayout();
            this.grpEditLogicif.ResumeLayout(false);
            this.grpEditLogicif.PerformLayout();
            this.grpEditOutput.ResumeLayout(false);
            this.grpEditOutput.PerformLayout();
            this.pnlEdit1.ResumeLayout(false);
            this.pnlEdit1.PerformLayout();
            this.tsEditToolBar.ResumeLayout(false);
            this.tsEditToolBar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEditItemEditor)).EndInit();
            this.grpEditPhysicif.ResumeLayout(false);
            this.grpEditPhysicif.PerformLayout();
            this.grpEditPhysicFile.ResumeLayout(false);
            this.grpEditPhysicFile.PerformLayout();
            this.grpEditSubsys.ResumeLayout(false);
            this.grpEditSubsys.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tsSheetToolBar.ResumeLayout(false);
            this.tsSheetToolBar.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.tsPictureToolBar.ResumeLayout(false);
            this.tsPictureToolBar.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhyData)).EndInit();
            this.msEditMenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtCopyKuNm;
        private System.Windows.Forms.Button btnSearchOutput;
        private System.Windows.Forms.TextBox txtCopyKuID;
        private System.Windows.Forms.Button btnOutput;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox txtOutputPath;
        private System.Windows.Forms.CheckBox chkPhyLogMapping;
        private System.Windows.Forms.CheckBox chkPhyCpyKu;
        private System.Windows.Forms.CheckBox chkItem;
        private System.Windows.Forms.CheckBox chkItmMap;
        private System.Windows.Forms.CheckBox chkLogCpyKu;
        private System.Windows.Forms.CheckBox chkMParser;
        private System.Windows.Forms.CheckBox chkSettingCond;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox combLogSubSysID;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox combInitSubSysID;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtInitInfoId;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RadioButton rdbTxt;
        private System.Windows.Forms.RadioButton rdbCSV;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox grpEditPhysicif;
        private System.Windows.Forms.Button btnEditPhysicifCopyComment;
        private System.Windows.Forms.TextBox txtEditPhysicInfoID;
        private System.Windows.Forms.TextBox txtEditPhysicCopyName;
        private System.Windows.Forms.TextBox txtEditPhysicCopyID;
        private System.Windows.Forms.TextBox txtEditPhysicSubsys;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox grpEditPhysicFile;
        private System.Windows.Forms.Button btnEditPhysicFileIn;
        private System.Windows.Forms.Button btnEditPhysicFileRef;
        private System.Windows.Forms.TextBox txtEditPhysicFile;
        private System.Windows.Forms.GroupBox grpEditSubsys;
        private System.Windows.Forms.Button btnEditTargetSubsys;
        private System.Windows.Forms.ComboBox cmbEditTargetSubsys;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox grpEditLogicif;
        private System.Windows.Forms.Button btnEditLogicifRename;
        private System.Windows.Forms.Button btnEditLogicifDel;
        private System.Windows.Forms.Button btnEditLogicifAdd;
        private System.Windows.Forms.TextBox txtEditLogicifCopyId;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnEditLogicifCopyComment;
        private System.Windows.Forms.TextBox txtEditLogicifName;
        private System.Windows.Forms.ListBox lstEditLogicif;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox grpEditRequirement;
        private System.Windows.Forms.Button btnEditRequirementRename;
        private System.Windows.Forms.Button btnEditRequirementDel;
        private System.Windows.Forms.Button btnEditRequirementAdd;
        private System.Windows.Forms.TextBox txtEditRequirement;
        private System.Windows.Forms.ListBox lstEditRequirement;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox grpEditOutput;
        private System.Windows.Forms.Button btnEditOutput;
        private System.Windows.Forms.CheckBox chkEditOutputLayoutText;
        private System.Windows.Forms.CheckBox chkEditOutputLayoutCsv;
        private System.Windows.Forms.CheckBox chkEditOutputCopy;
        private System.Windows.Forms.Button btnEditOutputRef;
        private System.Windows.Forms.TextBox txtEditOutputPath;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel pnlEdit1;
        private Common.Forms.GroupDataGridView dgvEditItemEditor;
        private System.Windows.Forms.ToolStrip tsEditToolBar;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripButton btnEditViewItemInfo;
        private System.Windows.Forms.ToolStripButton btnEditViewCopyInfo;
        private System.Windows.Forms.ToolStripButton btnEditViewRequirment;
        private System.Windows.Forms.ToolStripButton btnEditViewLogicif;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton btnEditCommit;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.Button btnEditPhysicifDel;
        private System.Windows.Forms.ToolStrip tsSheetToolBar;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripButton btnSheetPagepre;
        private System.Windows.Forms.ToolStripComboBox cmbSheetPage;
        private System.Windows.Forms.ToolStripButton btnSheetPagenext;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripLabel toolStripLabel3;
        private System.Windows.Forms.ToolStripButton btnSheetSave;
        private Common.Forms.Canvas cvsSheet;
        private System.Windows.Forms.ToolStrip tsPictureToolBar;
        private System.Windows.Forms.ToolStripLabel toolStripLabel4;
        private System.Windows.Forms.ToolStripButton btnPicturePagePre;
        private System.Windows.Forms.ToolStripComboBox cmbPicturePage;
        private System.Windows.Forms.ToolStripButton btnPicturePageNext;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripLabel toolStripLabel5;
        private System.Windows.Forms.ToolStripButton btnPictureSave;
        private Common.Forms.Canvas cvsPicture;
        private System.Windows.Forms.Button clearBtn;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.ComboBox cmbSubSysID;
        private System.Windows.Forms.ComboBox cmbAddSize;
        private System.Windows.Forms.Label lblAddressSize;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtInputPath;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.TextBox txtInfoId;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button Excute;
        private System.Windows.Forms.RadioButton rdoCpyNm;
        private System.Windows.Forms.RadioButton rdoRDataTbId;
        private System.Windows.Forms.ContextMenuStrip msEditMenu;
        private System.Windows.Forms.ToolStripMenuItem tsmInsertUp;
        private System.Windows.Forms.ToolStripMenuItem tsmRemove;
        private System.Windows.Forms.ToolStripMenuItem tsmInsertDown;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.GroupBox inputTypeGBox;
        private System.Windows.Forms.RadioButton RdoItemInfoFile;
        private System.Windows.Forms.RadioButton RdoCopyKuToolRefSheet;
        private System.Windows.Forms.RadioButton RdoCopyku;
        private System.Windows.Forms.GroupBox grpColumn;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox grpEditMPaser;
        private System.Windows.Forms.Button btnEditMPaserSet;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtEditMPaserLayoutDef;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.CheckBox chkRDataAll;
        private System.Windows.Forms.DataGridView dgvPhyData;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column21;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Privilege;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEdit1;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEdit2;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEdit3;
        private System.Windows.Forms.DataGridViewComboBoxColumn colEdit4;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEdit5;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEdit6;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEdit7;
        private System.Windows.Forms.DataGridViewButtonColumn colEdit8;
        private System.Windows.Forms.DataGridViewButtonColumn colEdit9;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEdit10;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEdit11;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEdit12;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEdit13;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEdit14;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEdit15;
        private System.Windows.Forms.DataGridViewComboBoxColumn colEdit16;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colEdit17;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colEdit18;
        private System.Windows.Forms.DataGridViewComboBoxColumn Column1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colEdit19;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEdit20;
        private System.Windows.Forms.DataGridViewComboBoxColumn colEdit21;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEdit22;
        private System.Windows.Forms.DataGridViewComboBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEdit23;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEdit24;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox10;
    }
}