﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MarsTool.Properties;
using MarsTool.Models;
using System.Text.RegularExpressions;
using MarsTool.Models.DB;

namespace MarsTool
{
    public partial class PhysicStrDialog : Form
    {
        public class ResultItem
        {
            /// <summary>情報部名称</summary>
            public string InfoName { get; set; }
            /// <summary>論理名称</summary>
            public string LogicName { get; set; }
            /// <summary>コピー句ＩＤ</summary>
            public string LogicID { get; set; }
            /// <summary>サイズ</summary>
            public int Size { get; set; }
            /// <summary>開始エントリ</summary>
            public int StartEntry { get; set; }
            /// <summary>繰返し回数</summary>
            public int Count { get; set; }
            /// <summary>物理ＩＤ</summary>
            public string PHYID { get; set; }
            /// <summary>シーケンス</summary>
            public string SEQ { get; set; }
        }

        private class PhysicInfo
        {
            public T_DENSTRBITM Denstrbitm { get; set; }
            public string SubsysID { get; set; }
            public string InfoID { get; set; }

            public PhysicInfo(T_DENSTRBITM denstrbitm, string subsysID, string infoId)
            {
                this.Denstrbitm = denstrbitm;
                this.SubsysID = subsysID;
                this.InfoID = infoId;
            }
        }


        private VersionModel version;

        private T_DENSTRB DENSTRB;

        private NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        public ResultItem resultItem { get; private set; }

        private PhysicStrDialog()
        {
            InitializeComponent();
        }

        public PhysicStrDialog(VersionModel version, T_DENSTRB denstrb) : this()
        {
            this.logger.Info("【論理パターン管理機能】物理構成ダイアログオープン");
            resultItem = new ResultItem();
            
            ltvPhysic.Items.Clear();
            this.version = version;
            this.DENSTRB = denstrb;

            Dictionary<string, int> dicPID = new Dictionary<string, int>();

            List<T_DENSTRBITM> listDENSTRB = this.version.context.T_DENSTRBITM.AsNoTracking().Where(r =>
                                                                            r.DENSTRBITM_SUBSYSID == denstrb.DENSTRB_SUBSYSID &&
                                                                            r.DENSTRBITM_TELSUBSYSID == denstrb.DENSTRB_TELSUBSYSID &&
                                                                            r.DENSTRBITM_TELTYPE == denstrb.DENSTRB_TELTYPE &&
                                                                            r.DENSTRBITM_PATNO == denstrb.DENSTRB_PATNO).OrderBy(r =>
                                                                                                                            r.DENSTRBITM_ORDER).ToList();
            // 重複する物理ＩＤを登録する
            for (int i = 0; i < listDENSTRB.Count; i++)
            {
                if(dicPID.ContainsKey(listDENSTRB[i].DENSTRBITM_PHYID) == false)
                {
                    for (int j = i + 1; j < listDENSTRB.Count; j++)
                    {
                        if (listDENSTRB[i].DENSTRBITM_PHYID == listDENSTRB[j].DENSTRBITM_PHYID)
                        {
                            dicPID.Add(listDENSTRB[i].DENSTRBITM_PHYID, 1);
                            break;
                        }
                    }
                }
            }

            foreach (T_DENSTRBITM denstrbitm in listDENSTRB)
            {
                ListViewItem ltvItem = new ListViewItem();
                if (denstrbitm.DENSTRBITM_TYPE == "1")   // 物理ＩＤ
                {
                    // 物理Ｍパーサ情報を用いて、情報部ＩＤを取得する
                    T_PHYPRS_EF phyprs = this.version.context.T_PHYPRS.AsNoTracking().Where(r =>
                                                                            r.PHYPRS_SUBSYSID == denstrbitm.DENSTRBITM_SUBSYSID &&
                                                                            r.PHYPRS_PHYID == denstrbitm.DENSTRBITM_PHYID).FirstOrDefault();
                    if (phyprs == null)
                    {
                        this.logger.Error(string.Format("該当する物理コピー句、または物理Ｍパーサ情報が登録されていません。（物理ＩＤ：{0}）", denstrbitm.DENSTRBITM_PHYID));
                        MessageBox.Show(string.Format("該当する物理コピー句、または物理Ｍパーサ情報が登録されていません。（物理ＩＤ：{0}）",  denstrbitm.DENSTRBITM_PHYID), 
                                        Resources.ERROR, 
                                        MessageBoxButtons.OK, 
                                        MessageBoxIcon.Error);

                        ltvItem.Text = "UnKnown";
                        ltvItem.UseItemStyleForSubItems = true;
                        ltvItem.BackColor = Color.Red;
                        ltvItem.SubItems.Add(denstrbitm.DENSTRBITM_PHYID);
                        ltvItem.SubItems.Add(string.Empty);
                        ltvPhysic.Items.Add(ltvItem);
                        continue;
                    }

                    // サブシステムＩＤ、情報部ＩＤから情報部名称を取得する
                    string infoNM = this.version.context.T_CPYPHY.AsNoTracking().Where(r =>
                                                                            r.CPYPHY_SUBSYSID == phyprs.PHYPRS_PHYSYSID &&
                                                                            r.CPYPHY_INFOID == phyprs.PHYPRS_INFOID).Select(r => r.CPYPHY_BCPNM).FirstOrDefault();
                    if(string.IsNullOrEmpty(infoNM))
                    {
                        this.logger.Error(string.Format("該当する物理コピー句が登録されていません。（サブシステムＩＤ：{0}、情報部ＩＤ：{1}）",
                                                                                                                    phyprs.PHYPRS_PHYSYSID,
                                                                                                                    phyprs.PHYPRS_INFOID));
                        MessageBox.Show("該当する物理コピー句が登録されていません。", Resources.ERROR,
                                                                                  MessageBoxButtons.OK,
                                                                                  MessageBoxIcon.Error);
                        ltvItem.Text = "UnKnown";
                        ltvItem.UseItemStyleForSubItems = true;
                        ltvItem.BackColor = Color.Red;
                        ltvItem.SubItems.Add(denstrbitm.DENSTRBITM_PHYID);
                        ltvItem.SubItems.Add(string.Empty);
                        ltvPhysic.Items.Add(ltvItem);
                        continue;
                    }

                    if(dicPID.ContainsKey(denstrbitm.DENSTRBITM_PHYID))
                    {
                        ltvItem.Text = string.Format("{0}[{1:D}]",infoNM, dicPID[denstrbitm.DENSTRBITM_PHYID]);
                        dicPID[denstrbitm.DENSTRBITM_PHYID]++;
                    }
                    else
                    {
                        ltvItem.Text = infoNM;
                    }
                    PhysicInfo physicInfo = new PhysicInfo(denstrbitm, phyprs.PHYPRS_PHYSYSID, phyprs.PHYPRS_INFOID);
                    ltvItem.Tag = physicInfo;
                    ltvItem.SubItems.Add(denstrbitm.DENSTRBITM_PHYID);
                    if (denstrbitm.DENSTRBITM_TURN != null && denstrbitm.DENSTRBITM_TURN > 1)
                    {
                        ltvItem.SubItems.Add(denstrbitm.DENSTRBITM_TURN.ToString());
                    }
                    else
                    {
                        ltvItem.SubItems.Add(string.Empty);
                    }
                    ltvPhysic.Items.Add(ltvItem);
                }
                else                                   // 予備
                {
                    ltvItem.Text = "予備";
                    if (denstrbitm.DENSTRBITM_YOBISIZE != null && denstrbitm.DENSTRBITM_YOBISIZE > 0)
                    {
                        ltvItem.SubItems.Add(string.Format("YOBI({0:d})", denstrbitm.DENSTRBITM_YOBISIZE));
                    }
                    else
                    {
                        ltvItem.SubItems.Add(string.Format("YOBI"));
                    }
                    if (denstrbitm.DENSTRBITM_TURN != null && denstrbitm.DENSTRBITM_TURN > 1)
                    {
                        ltvItem.SubItems.Add(denstrbitm.DENSTRBITM_TURN.ToString());
                    }
                    else
                    {
                        ltvItem.SubItems.Add(string.Empty);
                    }
                    ltvPhysic.Items.Add(ltvItem);
                }
            }
        }

        private void ltvPhysic_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            if(e.IsSelected)
            {
                btnAdd.Enabled = false;
                lblPhysic.Text = string.Empty;
                if (e.Item.Tag == null)
                {
                    pnlLogic.Visible = false;
                    pnlCount.Visible = false;
                }
                else
                {
                    PhysicInfo physicInfo = e.Item.Tag as PhysicInfo;
                    List<T_CPYLOG> listCPYLOG = this.version.context.T_CPYLOG.AsNoTracking().Where(r =>
                                                                            r.CPYLGC_INFOID == physicInfo.InfoID &&
                                                                            r.CPYLGC_SUBSYSID == this.DENSTRB.DENSTRB_SUBSYSID).OrderBy(r => 
                                                                                                                    r.CPYLGC_OUTPUTORDER).ToList();
                    ltvLogic.Items.Clear();
                    lblPhysic.Text = e.Item.Text;
                    foreach (T_CPYLOG cpylog in listCPYLOG)
                    {
                        ListViewItem item = new ListViewItem();
                        item.Text = cpylog.CPYLGC_OPNM;
                        item.SubItems.Add(cpylog.CPYLGC_LCPID);
                        ltvLogic.Items.Add(item);
                    }
                    if(int.TryParse(e.Item.SubItems[2].Text, out int num) && num > 1)
                    {
                        pnlCount.Visible = true;
                        nudStartEntry.Minimum = 1;
                        nudStartEntry.Maximum = num;
                        nudStartEntry.Value = 1;
                        nudCount.Minimum = 1;
                        nudCount.Maximum = num;
                        nudCount.Value = 1;
                    }
                    else
                    {
                        pnlCount.Visible = false;
                    }
                    pnlLogic.Visible = true;
                }
            }
        }

        private void ltvLogic_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            if(e.IsSelected)
            {
                btnAdd.Enabled = true;
            }
            else
            {
                btnAdd.Enabled = false;
            }
        }

        private void EntryCheck(object sender, EventArgs e)
        {
            int count = (int)(nudStartEntry.Value + (nudCount.Value - 1));
            if (count > nudStartEntry.Maximum)
            {
                btnAdd.Enabled = false;
            }
            else
            {
                if(ltvLogic.SelectedItems.Count > 0)
                {
                    btnAdd.Enabled = true;
                }
            }
        }

        private void ltvLogic_DoubleClick(object sender, EventArgs e)
        {
            if(ltvLogic.SelectedItems.Count > 0)
            {
                setResultItem();
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
        }

        private void setResultItem()
        {
            resultItem.InfoName = ltvPhysic.SelectedItems[0].Text;
            resultItem.LogicName = ltvLogic.SelectedItems[0].Text;
            resultItem.LogicID = ltvLogic.SelectedItems[0].SubItems[1].Text;
            if (pnlCount.Visible)
            {
                resultItem.StartEntry = (int)nudStartEntry.Value;
                resultItem.Count = (int)nudCount.Value;
            }
            if(ltvPhysic.SelectedItems[0].Tag != null)
            {
                PhysicInfo physicInfo = ltvPhysic.SelectedItems[0].Tag as PhysicInfo;
                resultItem.SEQ = physicInfo.Denstrbitm.DENSTRBITM_SEQ;
                resultItem.PHYID = physicInfo.Denstrbitm.DENSTRBITM_PHYID;
                resultItem.Size = Common.IntefaceCommon.getLogicSize(this.version,
                                                                     physicInfo.SubsysID,
                                                                     this.DENSTRB.DENSTRB_SUBSYSID,
                                                                     physicInfo.InfoID,
                                                                     resultItem.LogicID);
            }
            this.logger.Info("【論理パターン管理機能】物理構成ダイアログクローズ（Select={0}）", resultItem.LogicID);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            setResultItem();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.logger.Info("【論理パターン管理機能】物理構成ダイアログクローズ（キャンセル）");
        }
    }
}
