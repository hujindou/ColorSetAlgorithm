﻿using MarsTool.Common;
using MarsTool.Common.Forms;
using MarsTool.Models;
using MarsTool.Models.DB;
using MarsTool.Properties;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Threading.Tasks;

namespace MarsTool
{
    public partial class MappingParser : Form
    {
        private struct ParserKey
        {
            public string PHDEFID;
            public int ORDER;
            public ParserKey(string ID, int Order)
            {
                this.PHDEFID = ID;
                this.ORDER = Order;
            }
        }

        private VersionModel version;
        /// <summary>
        /// ログ
        /// </summary>
        private NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();
        private string subsystem = string.Empty;
        private bool NewFlag = false;
        private bool isEdit = false;
        private T_DENSTRB DENSTRB = null;
        private T_DENSTRL DENSTRL = null;
        private Dictionary<ParserKey, T_PARSER> PARSERS = new Dictionary<ParserKey, T_PARSER>();
        private CheckDataGridView checkDataGridView = null;
        private bool ManyOutCheck = false;

        #region 内部クラス
        private class RowItem
        {
            public T_DENSTRB DENSTRB { get; set; }
            public T_DENSTRL DENSTRL { get; set; }
        }

        private class ParserDef
        {
            public ParserKey parserKey { get; set; }
            public T_CPYPHY CPYPHY { get; set; }
            public T_CPYLOG CPYLOG { get; set; }
            public int PhysicOffset { get; set; }
            public int LogiciSize { get; set; }
            public ParserDefItem Item { get; set; }
        }


        private class ParserDefItem
        {
            public string Type { get; set; }
            public T_PHYITM PHYITM { get; set; }
            public T_PHYPRS_EF PHYPRS { get; set; }
            public T_LOGITM LOGITM { get; set; }
            public int Size { get; set; }
            public bool hasBit { get; set; }
            public ParserDefItem ParentItem { get; set; }
            public List<ParserDefItem> ChildItems { get; set; }
            public ParserDefItem DeepClone()
            {
                ParserDefItem cloneItem = new ParserDefItem
                {
                    Type = this.Type,
                    Size = this.Size,
                    hasBit = this.hasBit,
                    ParentItem = this.ParentItem,
                    ChildItems = new List<ParserDefItem>()
                };
                // PHYITM
                cloneItem.PHYITM = new T_PHYITM();
                cloneItem.PHYITM.PHYITM_COMMENT = this.PHYITM.PHYITM_COMMENT;
                cloneItem.PHYITM.PHYITM_CPYDTTYPE = this.PHYITM.PHYITM_CPYDTTYPE;
                cloneItem.PHYITM.PHYITM_DTLEN = this.PHYITM.PHYITM_DTLEN;
                cloneItem.PHYITM.PHYITM_DTTYPE = this.PHYITM.PHYITM_DTTYPE;
                cloneItem.PHYITM.PHYITM_GROUP = this.PHYITM.PHYITM_GROUP;
                cloneItem.PHYITM.PHYITM_IMAGENM = this.PHYITM.PHYITM_IMAGENM;
                cloneItem.PHYITM.PHYITM_INFOID = this.PHYITM.PHYITM_INFOID;
                cloneItem.PHYITM.PHYITM_ITEMFLG = this.PHYITM.PHYITM_ITEMFLG;
                cloneItem.PHYITM.PHYITM_ITEMID = this.PHYITM.PHYITM_ITEMID;
                cloneItem.PHYITM.PHYITM_ITEMNM = this.PHYITM.PHYITM_ITEMNM;
                cloneItem.PHYITM.PHYITM_ITEMNO = this.PHYITM.PHYITM_ITEMNO;
                cloneItem.PHYITM.PHYITM_LEVEL = this.PHYITM.PHYITM_LEVEL;
                cloneItem.PHYITM.PHYITM_NOTE = this.PHYITM.PHYITM_NOTE;
                cloneItem.PHYITM.PHYITM_OCCURS = this.PHYITM.PHYITM_OCCURS;
                cloneItem.PHYITM.PHYITM_PATH = this.PHYITM.PHYITM_PATH;
                cloneItem.PHYITM.PHYITM_SEQ = this.PHYITM.PHYITM_SEQ;
                cloneItem.PHYITM.PHYITM_SUBSYSID = this.PHYITM.PHYITM_SUBSYSID;
                // PHYPRS
                if(this.PHYPRS != null)
                {
                    cloneItem.PHYPRS = new T_PHYPRS_EF();
                    cloneItem.PHYPRS.PHYPRS_CDCHG = this.PHYPRS.PHYPRS_CDCHG;
                    cloneItem.PHYPRS.PHYPRS_FLG = this.PHYPRS.PHYPRS_FLG;
                    cloneItem.PHYPRS.PHYPRS_INFOID = this.PHYPRS.PHYPRS_INFOID;
                    cloneItem.PHYPRS.PHYPRS_LAYDEF = this.PHYPRS.PHYPRS_LAYDEF;
                    cloneItem.PHYPRS.PHYPRS_LTYPE = this.PHYPRS.PHYPRS_LTYPE;
                    cloneItem.PHYPRS.PHYPRS_MCODE = this.PHYPRS.PHYPRS_MCODE;
                    cloneItem.PHYPRS.PHYPRS_PHYID = this.PHYPRS.PHYPRS_PHYID;
                    cloneItem.PHYPRS.PHYPRS_PHYSYSID = this.PHYPRS.PHYPRS_PHYSYSID;
                    cloneItem.PHYPRS.PHYPRS_SEQ = this.PHYPRS.PHYPRS_SEQ;
                    cloneItem.PHYPRS.PHYPRS_SUBSYSID = this.PHYPRS.PHYPRS_SUBSYSID;
                    cloneItem.PHYPRS.PHYPRS_TAGNM = this.PHYPRS.PHYPRS_TAGNM;
                }
                // LOGITM
                if(this.LOGITM != null)
                {
                    cloneItem.LOGITM = new T_LOGITM();
                    cloneItem.LOGITM.LOGITM_DATALEN = this.LOGITM.LOGITM_DATALEN;
                    cloneItem.LOGITM.LOGITM_DTTYPE = this.LOGITM.LOGITM_DTTYPE;
                    cloneItem.LOGITM.LOGITM_LCPID = this.LOGITM.LOGITM_LCPID;
                    cloneItem.LOGITM.LOGITM_MCODE = this.LOGITM.LOGITM_MCODE;
                    cloneItem.LOGITM.LOGITM_PREFIX = this.LOGITM.LOGITM_PREFIX;
                    cloneItem.LOGITM.LOGITM_SEQ = this.LOGITM.LOGITM_SEQ;
                    cloneItem.LOGITM.LOGITM_SUBSYSIDL = this.LOGITM.LOGITM_SUBSYSIDL;
                    cloneItem.LOGITM.LOGITM_TYPE = this.LOGITM.LOGITM_TYPE;
                }
                foreach (ParserDefItem childItem in this.ChildItems)
                {
                    cloneItem.ChildItems.Add(childItem.DeepClone());
                }
                return cloneItem;
            }

            public ParserDefItem()
            {
                this.ChildItems = new List<ParserDefItem>();
            }
        }
        #endregion

        private MappingParser()
        {
            InitializeComponent();
        }

        public MappingParser(VersionModel  v) : this()
        {
            this.logger.Info("【論理パターン管理機能】開始");

            this.version = v;

            //サブシステムを設定
            cmbSubsystem.Items.AddRange(this.version.getModifiableSubsysList().ToArray());
            cmboutSubsys.Items.AddRange(this.version.getModifiableSubsysList().ToArray());
            cmbPhysicSubsys.Items.Add(string.Empty);
            cmbPhysicSubsys.Items.AddRange(this.version.getAllSubsysList().ToArray());

            #region  GroupDataGridViewの設定
            GroupDataGridView.GroupCell groupCellPhysic = new GroupDataGridView.GroupCell
            {
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center,
                Text = "物理情報",
                Start = 0,
                Count = 4
            };
            GroupDataGridView.GroupCell groupCellLogic = new GroupDataGridView.GroupCell
            {
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center,
                Text = "論理情報",
                Start = 4,
                Count = 3
            };
            dgvList.GroupCells.Add(groupCellPhysic);
            dgvList.GroupCells.Add(groupCellLogic);
            dgvPattern.GroupCells.Add(groupCellPhysic);
            dgvPattern.GroupCells.Add(groupCellLogic);
            GroupDataGridView.GroupCell groupCellOutPhysic = new GroupDataGridView.GroupCell
            {
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center,
                Text = "物理情報",
                Start = 1,
                Count = 4
            };
            GroupDataGridView.GroupCell groupCellOutLogic = new GroupDataGridView.GroupCell
            {
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center,
                Text = "論理情報",
                Start = 5,
                Count = 3
            };
            dgvSearch.GroupCells.Add(groupCellOutPhysic);
            dgvSearch.GroupCells.Add(groupCellOutLogic);
            #endregion
            //チェックボックスの制御
            checkDataGridView = new CheckDataGridView(dgvSearch, chkAll);
            checkDataGridView.ChangeStatus += CheckDataGridView_ChangeStatus;
        }

        private void CheckDataGridView_ChangeStatus(bool nodata)
        {
            // 何れかがチェックされていたら、出力を有効にする
            bool check = false;
            foreach(DataGridViewRow row in dgvSearch.Rows)
            {
                if ((string)row.Cells[0].Value == "1")
                {
                    check = true;
                    break;
                }
            }

            ManyOutCheck = chkPatternDef.Checked || check;
            if (Directory.Exists(txtOutputMany.Text) && ManyOutCheck)
            {
                btnSaveMany.Enabled = true;
            }
            else
            {
                btnSaveMany.Enabled = false;
            }
        }

        /// <summary>
        /// 【編集】サブシステムが変更された時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbSubsystem_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(this.subsystem != string.Empty)
            {
                if(this.subsystem != cmbSubsystem.Text)
                {
                    // 編集内容が破棄される旨を通知し変更する
                    if (isEditCheck())
                    {
                        this.subsystem = cmbSubsystem.Text;
                        this.logger.Info(string.Format("【論理パターン管理機能】サブシステムを変更しました（{0}）", this.subsystem));
                        dgvPattern.Rows.Clear();
                        ltvEdit.Items.Clear();
                        initCtrlStatus();
                        setList();
                    }
                    else
                    {
                        //キャンセルの時は、元に戻す
                        cmbSubsystem.Text = this.subsystem;
                    }
                }
            }
            else
            {
                //初回は無条件に変更する
                this.subsystem = cmbSubsystem.Text;
                this.logger.Info(string.Format("【論理パターン管理機能】サブシステムを変更しました（{0}）", this.subsystem));
                dgvPattern.Rows.Clear();
                ltvEdit.Items.Clear();
                setList();
            }
        }

        private void initCtrlStatus()
        {
            grpList.Enabled = false;
            grpPattern.Enabled = false;
            grpEdit.Enabled = false;
            grpOutput.Enabled = false;
            btnUpdate.Enabled = false;
            btnListDel.Enabled = false;
            btnEdit.Enabled = false;
            btnListAdd.Enabled = false;
            btnDel.Enabled = false;
            btnSave.Enabled = false;
        }

        /// <summary>
        /// 【編集】一覧設定
        /// </summary>
        private void setList()
        {
            this.logger.Info(string.Format("【論理パターン管理機能】一覧設定開始"));
            WaitDialog.Show(this);
            try
            {
                dgvList.Rows.Clear();
                List<RowItem> listRow = getList();
                foreach (RowItem rowItem in listRow)
                {
                    dgvList.Rows.Add(rowItem.DENSTRB.DENSTRB_COMMENT,
                                     rowItem.DENSTRB.DENSTRB_TELSUBSYSID,
                                     rowItem.DENSTRB.DENSTRB_TELTYPE,
                                     rowItem.DENSTRB.DENSTRB_PATNO,
                                     rowItem.DENSTRL.DENSTRL_STRNO,
                                     rowItem.DENSTRL.DENSTRL_INOUT,
                                     rowItem.DENSTRL.DENSTRL_PHDEFID);
                    dgvList.Rows[dgvList.Rows.Count - 1].Tag = rowItem;
                }
                grpList.Enabled = true;
                grpPattern.Enabled = true;
            }
            catch (Exception ex)
            {
                this.logger.Error(ex, string.Format("エラーが発生しました。"));
            }
            finally
            {
                WaitDialog.Close();
            }
            this.logger.Info(string.Format("【論理パターン管理機能】一覧設定終了"));
        }

        /// <summary>
        /// 【編集】ＤＢから電文構成パターン情報（物理／論理）を取得する
        /// </summary>
        /// <returns></returns>
        private List<RowItem> getList()
        {
            List<RowItem> listRowItem = new List<RowItem>();
            List<T_DENSTRL> listDENSTRL = this.version.context.T_DENSTRL.AsNoTracking().Where(r =>
                                                                                r.DENSTRL_SUBSYSID == this.subsystem).OrderBy(r => 
                                                                                                                    r.DENSTRL_ORDER).ToList();
            foreach(T_DENSTRL denstrl in listDENSTRL)
            {
                T_DENSTRB denstrb = this.version.context.T_DENSTRB.AsNoTracking().Where(r =>
                                                                                r.DENSTRB_SUBSYSID == denstrl.DENSTRL_SUBSYSID &&
                                                                                r.DENSTRB_TELSUBSYSID == denstrl.DENSTRL_TELSUBSYSID &&
                                                                                r.DENSTRB_TELTYPE == denstrl.DENSTRL_TELTYPE &&
                                                                                r.DENSTRB_PATNO == denstrl.DENSTRL_PATNO).SingleOrDefault();
                RowItem rowItem = new RowItem
                {
                    DENSTRB = denstrb,
                    DENSTRL = denstrl
                };
                listRowItem.Add(rowItem);
            }
            return listRowItem;
        }

        private T_DENSTRL getDENSTRLfromDB(T_DENSTRL denstrl)
        {
            return this.version.context.T_DENSTRL.AsNoTracking().Where(r =>
                                                                        r.DENSTRL_SUBSYSID == denstrl.DENSTRL_SUBSYSID &&
                                                                        r.DENSTRL_TELSUBSYSID == denstrl.DENSTRL_TELSUBSYSID &&
                                                                        r.DENSTRL_TELTYPE == denstrl.DENSTRL_TELTYPE &&
                                                                        r.DENSTRL_PATNO == denstrl.DENSTRL_PATNO &&
                                                                        r.DENSTRL_ORDER == denstrl.DENSTRL_ORDER).SingleOrDefault();
            
        }

        /// <summary>
        /// 【編集】一覧の指定行から設定内容を取得する
        /// </summary>
        /// <param name="RowIndex"></param>
        /// <returns></returns>
        private RowItem getRowItemFromDataGridView(int RowIndex)
        {
            T_DENSTRB denstrb = new T_DENSTRB
            {
                DENSTRB_SUBSYSID = this.subsystem,
                DENSTRB_COMMENT = dgvList.Rows[RowIndex].Cells[0].Value as string,
                DENSTRB_TELSUBSYSID = dgvList.Rows[RowIndex].Cells[1].Value as string,
                DENSTRB_TELTYPE = dgvList.Rows[RowIndex].Cells[2].Value as string,
                DENSTRB_PATNO = dgvList.Rows[RowIndex].Cells[3].Value as string
            };
            T_DENSTRL denstrl = new T_DENSTRL
            {
                DENSTRL_SUBSYSID = denstrb.DENSTRB_SUBSYSID,
                DENSTRL_TELSUBSYSID = denstrb.DENSTRB_TELSUBSYSID,
                DENSTRL_TELTYPE = denstrb.DENSTRB_TELTYPE,
                DENSTRL_PATNO = denstrb.DENSTRB_PATNO,
                DENSTRL_ORDER = RowIndex + 1,
                DENSTRL_STRNO = dgvList.Rows[RowIndex].Cells[4].Value as string,
                DENSTRL_INOUT = dgvList.Rows[RowIndex].Cells[5].Value as string,
                DENSTRL_PHDEFID = dgvList.Rows[RowIndex].Cells[6].Value as string
            };
            RowItem rowItem = new RowItem
            {
                DENSTRB = denstrb,
                DENSTRL = denstrl
            };
            return rowItem;
        }

        /// <summary>
        /// 【編集】パターン編集欄設定
        /// </summary>
        /// <param name="denstrb"></param>
        /// <param name="denstrl"></param>
        private void setPattern(T_DENSTRB denstrb, T_DENSTRL denstrl)
        {
            dgvPattern.Rows.Clear();
            RowItem rowItem = new RowItem
            {
                DENSTRB = denstrb,
                DENSTRL = denstrl
            };
            if (denstrl == null)
            {
                dgvPattern.Rows.Add(denstrb.DENSTRB_COMMENT, 
                                    denstrb.DENSTRB_TELSUBSYSID, 
                                    denstrb.DENSTRB_TELTYPE, 
                                    denstrb.DENSTRB_PATNO,
                                    string.Empty,
                                    string.Empty,
                                    string.Empty);

                dgvPattern.Rows[dgvPattern.Rows.Count - 1].Tag = rowItem;
            }
        }

        /// <summary>
        /// 【編集】パターン編集欄の編集内容検定
        /// </summary>
        /// <returns></returns>
        private bool checkPattern()
        {
            bool result = true;
            dgvPattern.EndEdit();

            // 論理構成番号 は 数値 かつ 最大４文字
            dgvPattern.Rows[0].Cells[4].Style.BackColor = SystemColors.Window;
            if (Common.Utils.IsNum(dgvPattern.Rows[0].Cells[4].Value as string) == false || 
                (dgvPattern.Rows[0].Cells[4].Value as string).Length > 4)
            {
                dgvPattern.Rows[0].Cells[4].Style.BackColor = Color.Red;
                result = false;
            }

            // 入出力区分は I または O
            dgvPattern.Rows[0].Cells[5].Style.BackColor = SystemColors.Window;
            if ((dgvPattern.Rows[0].Cells[5].Value as string) != "I" && (dgvPattern.Rows[0].Cells[5].Value as string) != "O")
            {
                dgvPattern.Rows[0].Cells[5].Style.BackColor = Color.Red;
                result = false;
            }

            // パーサ変換定義ＩＤ は 英数字 かつ ８文字以内
            dgvPattern.Rows[0].Cells[6].Style.BackColor = SystemColors.Window;
            if (Common.Utils.IsAlpahNum(dgvPattern.Rows[0].Cells[6].Value as string) == false || 
                (dgvPattern.Rows[0].Cells[6].Value as string).Length > 8)
            {
                dgvPattern.Rows[0].Cells[6].Style.BackColor = Color.Red;
                result = false;
            }
            return result;
        }

        /// <summary>
        /// リスト一覧検索
        /// </summary>
        /// <param name="rowItem">検索情報</param>
        /// <returns>ヒットした行</returns>
        private int searchList(RowItem rowItem)
        {
            foreach(DataGridViewRow row in dgvList.Rows)
            {
                if(row.Tag != null)
                {
                    RowItem item = row.Tag as RowItem;
                    if(item.DENSTRL.DENSTRL_PHDEFID == rowItem.DENSTRL.DENSTRL_PHDEFID && 
                       item.DENSTRL.DENSTRL_ORDER == rowItem.DENSTRL.DENSTRL_ORDER)
                    {
                        return row.Index;
                    }
                }
            }
            return -1;
        }

        /// <summary>
        /// リスト一覧検索
        /// </summary>
        /// <param name="PHDEFID">パーサ変換定義ＩＤ</param>
        /// <param name="INOUT">入出力区分</param>
        /// <returns>ヒットした行</returns>
        private int searchList(string PHDEFID, string INOUT)
        {
            foreach (DataGridViewRow row in dgvList.Rows)
            {
                if(row.Cells[4].Value as string == PHDEFID && row.Cells[5].Value as string == INOUT)
                {
                    return row.Index;
                }
            }
            return -1;
        }

        /// <summary>
        /// パターン編集より、電文構成パターン論理情報を取得する
        /// </summary>
        /// <param name="denstrb">電文構成パターン物理情報</param>
        /// <returns></returns>
        private bool getDENSTRL(T_DENSTRB denstrb)
        {
            this.DENSTRL = null;
            string strNo = (string)(dgvPattern.Rows[0].Cells[4].Value);
            string inOut = (string)(dgvPattern.Rows[0].Cells[5].Value);

            T_DENSTRL denstrl = this.version.context.T_DENSTRL.AsNoTracking().Where(r =>
                                                                                r.DENSTRL_SUBSYSID == denstrb.DENSTRB_SUBSYSID &&
                                                                                r.DENSTRL_TELSUBSYSID == denstrb.DENSTRB_TELSUBSYSID &&
                                                                                r.DENSTRL_TELTYPE == denstrb.DENSTRB_TELTYPE &&
                                                                                r.DENSTRL_PATNO == denstrb.DENSTRB_PATNO &&
                                                                                r.DENSTRL_STRNO == strNo &&
                                                                                r.DENSTRL_INOUT == inOut).SingleOrDefault();
            if (denstrl == null) return false;
            this.DENSTRL = denstrl;
            return true;
        }

        /// <summary>
        /// 編集中か検定し、編集中の場合は編集内容が破棄される旨を確認する
        /// </summary>
        /// <returns>trueの場合は処理を続行</returns>
        private bool isEditCheck()
        {
            if(isEdit)
            {
                if (MessageBox.Show("編集内容が破棄されます。よろしいですか？", 
                                    Resources.QUESTION, 
                                    MessageBoxButtons.YesNo, 
                                    MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    isEdit = false;
                    return true;
                }
                return false;
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// ListViewItemの作成
        /// </summary>
        /// <param name="resultItem"></param>
        /// <returns></returns>
        private ListViewItem resultItemToListViewItem(PhysicStrDialog.ResultItem resultItem)
        {
            ListViewItem ltvItem = new ListViewItem();
            ltvItem.Text = resultItem.InfoName;
            ltvItem.SubItems.Add(resultItem.LogicName);
            ltvItem.SubItems.Add(resultItem.LogicID);
            if (resultItem.Size > 0)
            {
                ltvItem.SubItems.Add(resultItem.Size.ToString());
            }
            else
            {
                ltvItem.SubItems.Add("-");
            }
            if (resultItem.StartEntry > 0)
            {
                ltvItem.SubItems.Add(resultItem.StartEntry.ToString());
            }
            else
            {
                ltvItem.SubItems.Add("-");
            }
            if (resultItem.Count > 0)
            {
                ltvItem.SubItems.Add(resultItem.Count.ToString());
            }
            else
            {
                ltvItem.SubItems.Add("-");
            }
            ltvItem.Tag = resultItem;
            return ltvItem;
        }

        /// <summary>
        /// 物理-論理パーサ変換定義編集設定
        /// </summary>
        private void setEdit()
        {
            this.logger.Info(string.Format("【論理パターン管理機能】物理-論理パーサ変換定義編集設定開始"));
            ltvEdit.Items.Clear();

            //情報を取得
            string telsubsys = dgvPattern.Rows[0].Cells[1].Value as string;
            string type = dgvPattern.Rows[0].Cells[2].Value as string;
            string ptn = dgvPattern.Rows[0].Cells[3].Value as string;
            string id = dgvPattern.Rows[0].Cells[6].Value as string;
            //該当するＭパーサ物理情報を取得
            List<T_PARSER> listPARSER = this.version.context.T_PARSER.AsNoTracking().Where(r =>
                                                                            r.PARSE_PHDEFID == id).OrderBy(r => r.PARSE_ORDER).ToList();
            #region 該当する物理パターンの情報部名称を取得
            Dictionary<string, int> dicPID = new Dictionary<string, int>();
            List<T_DENSTRBITM> listDENSTRB = this.version.context.T_DENSTRBITM.AsNoTracking().Where(r =>
                                                                            r.DENSTRBITM_SUBSYSID == this.subsystem &&
                                                                            r.DENSTRBITM_TELSUBSYSID == telsubsys &&
                                                                            r.DENSTRBITM_TELTYPE == type &&
                                                                            r.DENSTRBITM_PATNO == ptn).OrderBy(r => 
                                                                                                r.DENSTRBITM_ORDER).ToList();
            for (int i = 0; i < listDENSTRB.Count; i++)
            {
                if (dicPID.ContainsKey(listDENSTRB[i].DENSTRBITM_PHYID) == false)
                {
                    for (int j = i + 1; j < listDENSTRB.Count; j++)
                    {
                        if (listDENSTRB[i].DENSTRBITM_PHYID == listDENSTRB[j].DENSTRBITM_PHYID)
                        {
                            dicPID.Add(listDENSTRB[i].DENSTRBITM_PHYID, 1);
                            break;
                        }
                    }
                }
            }
            Dictionary<string, string> dicNM = new Dictionary<string, string>();
            foreach(T_DENSTRBITM denstrbitm in listDENSTRB)
            {
                // 物理Ｍパーサ情報を用いて、情報部ＩＤを取得する
                T_PHYPRS_EF phyprs = this.version.context.T_PHYPRS.AsNoTracking().Where(r =>
                                                                        r.PHYPRS_SUBSYSID == denstrbitm.DENSTRBITM_SUBSYSID &&
                                                                        r.PHYPRS_PHYID == denstrbitm.DENSTRBITM_PHYID).FirstOrDefault();
                if (phyprs == null)
                {
                    this.logger.Error(string.Format("該当する物理コピー句、または物理Ｍパーサ情報が登録されていません。（物理ＩＤ：{0}）", denstrbitm.DENSTRBITM_PHYID));
                    MessageBox.Show(string.Format("該当する物理コピー句、または物理Ｍパーサ情報が登録されていません。（物理ＩＤ：{0}）", denstrbitm.DENSTRBITM_PHYID),
                                    Resources.ERROR,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
                    return;
                }
                // サブシステムＩＤ、情報部ＩＤから情報部名称を取得する
                string infoNM = this.version.context.T_CPYPHY.AsNoTracking().Where(r =>
                                                                        r.CPYPHY_SUBSYSID == phyprs.PHYPRS_PHYSYSID &&
                                                                        r.CPYPHY_INFOID == phyprs.PHYPRS_INFOID).Select(r => r.CPYPHY_BCPNM).FirstOrDefault();
                if (string.IsNullOrEmpty(infoNM))
                {
                    this.logger.Error(string.Format("該当する物理コピー句が登録されていません。（TBL={0}, SUBSYSID={1}, INFOID={2}）",
                                                                            "T_CPYPHY",
                                                                            phyprs.PHYPRS_PHYSYSID,
                                                                            phyprs.PHYPRS_INFOID));
                    MessageBox.Show("該当する物理コピー句が登録されていません。", Resources.ERROR,
                                                                              MessageBoxButtons.OK,
                                                                              MessageBoxIcon.Error);
                    return;
                }
                string NM;
                if(dicPID.ContainsKey(denstrbitm.DENSTRBITM_PHYID))
                {
                    NM = string.Format("{0}[{1:D}]", infoNM, dicPID[denstrbitm.DENSTRBITM_PHYID]);
                    dicPID[denstrbitm.DENSTRBITM_PHYID]++;
                }
                else
                {
                    NM = infoNM;
                }
                dicNM.Add(denstrbitm.DENSTRBITM_SEQ, NM);
            }
            #endregion

            foreach (T_PARSER parser in listPARSER)
            {
                ListViewItem item = new ListViewItem();
                bool UnKnowFlag = false;
                if (parser.PARSE_TYPE == "1")
                {
                    //情報設定
                    PhysicStrDialog.ResultItem resultItem = new PhysicStrDialog.ResultItem();
                    resultItem.SEQ = parser.PARSE_SEQ;
                    if (parser.PARSE_TURN != null) resultItem.Count = (int)parser.PARSE_TURN;
                    resultItem.LogicID = parser.PARSE_LCPID;
                    if (parser.PARSE_SIZE != null) resultItem.Size = (int)parser.PARSE_SIZE;
                    if (parser.PARSE_ENTRY != null) resultItem.StartEntry = (int)parser.PARSE_ENTRY;
                    resultItem.PHYID = parser.PARSE_BCPID;
                    if(dicNM.ContainsKey(parser.PARSE_SEQ))
                    {
                        resultItem.InfoName = dicNM[parser.PARSE_SEQ];
                        UnKnowFlag = false;
                    }
                    else
                    {
                        resultItem.InfoName = "UnKnown";
                        UnKnowFlag = true;
                    }

                    //情報部ＩＤを取得
                    T_DENSTRBITM denstrbitm = this.version.context.T_DENSTRBITM.AsNoTracking().Where(r =>
                                                                            r.DENSTRBITM_SEQ == parser.PARSE_SEQ).SingleOrDefault();
                    if (denstrbitm == null)
                    {
                        this.logger.Error(string.Format("テーブル取得に失敗しました。（TBL={0}, {1}）", "T_DENSTRBITM", parser.PARSE_SEQ));
                        MessageBox.Show("Ｍパーサ変換情報テーブルが壊れています。", Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    string infoID = this.version.context.T_PHYPRS.AsNoTracking().Where(r =>
                                                                            r.PHYPRS_SUBSYSID == denstrbitm.DENSTRBITM_SUBSYSID &&
                                                                            r.PHYPRS_PHYID == denstrbitm.DENSTRBITM_PHYID).Select(r =>
                                                                                                                    r.PHYPRS_INFOID).FirstOrDefault();
                    if (string.IsNullOrEmpty(infoID))
                    {
                        this.logger.Error(string.Format("該当する物理コピー句、または物理Ｍパーサ情報が登録されていません。（物理ＩＤ：{0}）", denstrbitm.DENSTRBITM_PHYID));
                        MessageBox.Show(string.Format("該当する物理コピー句、または物理Ｍパーサ情報が登録されていません。（物理ＩＤ：{0}）", denstrbitm.DENSTRBITM_PHYID),
                                        Resources.ERROR,
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);
                        return;
                    }

                    // サブシステムＩＤ、情報部ＩＤ、論理コピー句ＩＤから論理名称を取得する
                    T_CPYLOG cpylog = this.version.context.T_CPYLOG.AsNoTracking().Where(r =>
                                                                            r.CPYLGC_INFOID == infoID &&
                                                                            r.CPYLGC_SUBSYSID == this.subsystem &&
                                                                            r.CPYLGC_LCPID == resultItem.LogicID).SingleOrDefault();
                    if (cpylog == null)
                    {
                        this.logger.Error(string.Format("該当する論理コピー句が登録されていません。（TBL={0}, LCPID={1}）",
                                                                                "T_CPYLOG",
                                                                                resultItem.LogicID));
                        MessageBox.Show("該当する論理コピー句が登録されていません。", Resources.ERROR,
                                                                                  MessageBoxButtons.OK,
                                                                                  MessageBoxIcon.Error);
                        return;
                    }
                    resultItem.LogicName = cpylog.CPYLGC_OPNM;
                    //論理コピー句よりサイズを取得する
                    resultItem.Size = Common.IntefaceCommon.getLogicSize(this.version,
                                                                         cpylog.CPYLGC_PHYSYSID,
                                                                         cpylog.CPYLGC_SUBSYSID,
                                                                         infoID,
                                                                         resultItem.LogicID);
                    //リストビューのアイテムに変換する
                    item = resultItemToListViewItem(resultItem);
                    if(UnKnowFlag)
                    {
                        item.BackColor = Color.Red;
                        item.ForeColor = Color.White;
                    }
                }
                else if (parser.PARSE_TYPE == "2")
                {
                    item.Text = "予備";
                    item.SubItems.Add("-");
                    item.SubItems.Add("-");
                    item.SubItems.Add(parser.PARSE_SIZE.ToString());
                    item.SubItems.Add("-");
                    item.SubItems.Add("-");
                }
                else
                {
                    item.Text = "NEXTADDR";
                    item.SubItems.Add("-");
                    item.SubItems.Add("-");
                    item.SubItems.Add("-");
                    item.SubItems.Add("-");
                    item.SubItems.Add("-");
                }
                ltvEdit.Items.Add(item);
            }
            this.PARSERS.Clear();
            foreach (T_PARSER parser in listPARSER)
            {
                this.PARSERS.Add(new ParserKey(parser.PARSE_PHDEFID, parser.PARSE_ORDER), parser);
            }
            this.logger.Info(string.Format("【論理パターン管理機能】物理-論理パーサ変換定義編集設定終了"));
        }

        /// <summary>
        /// 物理-論理パーサ変換定義編集の内容をＤＢに反映する
        /// </summary>
        /// <returns></returns>
        bool updateEdit()
        {
            try
            {
                
                WaitDialog.Show(this);
                this.logger.Info(string.Format("【論理パターン管理機能】更新処理開始"));

                List<T_DENSTRL> listAddDenstrl = new List<T_DENSTRL>();
                List<T_DENSTRL> listDelDenstrl = new List<T_DENSTRL>();
                List<T_PARSER> listAddParser = new List<T_PARSER>();
                List<T_PARSER> listUpdateParser = new List<T_PARSER>();
                List<T_PARSER> listDelParser = new List<T_PARSER>();

                string sql = string.Empty;
                StringBuilder sb = new StringBuilder();

                // 他ユーザによって更新されていないか検定する
                foreach (DataGridViewRow row in dgvList.Rows)
                {
                    if ((row.Tag as RowItem).DENSTRL != null)
                    {
                        RowItem rowItem = row.Tag as RowItem;
                        T_DENSTRL denstrlDB = getDENSTRLfromDB(rowItem.DENSTRL);
                        if (denstrlDB == null)
                        {
                            this.logger.Error(string.Format("編集中に別ユーザによって更新されましたので、更新できません。"));
                            return false;
                        }
                        else
                        {
                            if (denstrlDB.DENSTRL_USERID != rowItem.DENSTRL.DENSTRL_USERID ||
                               denstrlDB.DENSTRL_UPDTIME != rowItem.DENSTRL.DENSTRL_UPDTIME)
                            {
                                this.logger.Error(string.Format("編集中に別ユーザによって更新されましたので、更新できません。"));
                                return false;
                            }
                            else
                            {
                                // 内容が変更されているか検定する
                                RowItem editItem = getRowItemFromDataGridView(row.Index);
                                if (editItem.DENSTRL.DENSTRL_ORDER != rowItem.DENSTRL.DENSTRL_ORDER ||
                                   editItem.DENSTRL.DENSTRL_STRNO != rowItem.DENSTRL.DENSTRL_STRNO ||
                                   editItem.DENSTRL.DENSTRL_INOUT != rowItem.DENSTRL.DENSTRL_INOUT ||
                                   editItem.DENSTRL.DENSTRL_PHDEFID != rowItem.DENSTRL.DENSTRL_PHDEFID)
                                {
                                    listDelDenstrl.Add(rowItem.DENSTRL);
                                    listAddDenstrl.Add(editItem.DENSTRL);
                                    // パーサ変換定義ＩＤが変更された場合、変更前のパーサ変換定義ＩＤが使用されているか検定し、
                                    // 他に使用されていない場合は、パーサ変換テーブルから削除する
                                    if (editItem.DENSTRL.DENSTRL_PHDEFID != rowItem.DENSTRL.DENSTRL_PHDEFID)
                                    {
                                        int count = this.version.context.T_DENSTRL.AsNoTracking().Where(r =>
                                                                                    r.DENSTRL_PHDEFID == rowItem.DENSTRL.DENSTRL_PHDEFID).Count();
                                        if (count == 1)
                                        {
                                            List<T_PARSER> list = this.version.context.T_PARSER.AsNoTracking().Where(r =>
                                                                                    r.PARSE_PHDEFID == rowItem.DENSTRL.DENSTRL_PHDEFID).ToList();
                                            listDelParser.AddRange(list);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        // 追加
                        RowItem addItem = getRowItemFromDataGridView(row.Index);
                        listAddDenstrl.Add(addItem.DENSTRL);
                    }
                }

                //更新情報を収集
                if (dgvPattern.Rows.Count == 1)
                {
                    string ID = dgvPattern.Rows[0].Cells[6].Value as string;
                    int Max = ltvEdit.Items.Count;
                    if (this.PARSERS.Count > Max) Max = this.PARSERS.Count;
                    for (int Index = 0; Index < Max; Index++)
                    {
                        ListViewItem listItem = null;
                        if (Index < ltvEdit.Items.Count)
                        {
                            listItem = ltvEdit.Items[Index];
                        }

                        ParserKey key = new ParserKey
                        {
                            PHDEFID = ID,
                            ORDER = Index + 1
                        };

                        T_PARSER ori = null;
                        T_PARSER parser = null;

                        if (this.PARSERS.ContainsKey(key))
                        {
                            ori = this.PARSERS[key];
                        }

                        if (listItem != null)
                        {
                            if (listItem.Tag != null)    // 物理ＩＤ
                            {
                                PhysicStrDialog.ResultItem resultItem = listItem.Tag as PhysicStrDialog.ResultItem;
                                parser = new T_PARSER
                                {
                                    PARSE_PHDEFID = key.PHDEFID,
                                    PARSE_ORDER = key.ORDER,
                                    PARSE_TYPE = "1",
                                    PARSE_BCPID = resultItem.PHYID,
                                    PARSE_SEQ = resultItem.SEQ,
                                    PARSE_LCPID = resultItem.LogicID,
                                    PARSE_ENTRY = resultItem.StartEntry,
                                    PARSE_SIZE = resultItem.Size,
                                    PARSE_TURN = resultItem.Count
                                };
                            }
                            else
                            {
                                string type;
                                if (listItem.Text == "NEXTADDR")
                                {
                                    type = "3";
                                }
                                else
                                {
                                    type = "2";
                                }
                                parser = new T_PARSER
                                {
                                    PARSE_PHDEFID = key.PHDEFID,
                                    PARSE_ORDER = key.ORDER,
                                    PARSE_TYPE = type,
                                };
                                if (parser.PARSE_TYPE == "2")
                                {
                                    parser.PARSE_SIZE = int.Parse(listItem.SubItems[3].Text);
                                }
                            }

                            if (ori == null)
                            {
                                listAddParser.Add(parser);
                            }
                            else
                            {
                                // 何れかが更新されていること
                                if (ori.PARSE_TYPE != parser.PARSE_TYPE ||
                                   ori.PARSE_BCPID != parser.PARSE_BCPID ||
                                   ori.PARSE_SEQ != parser.PARSE_SEQ ||
                                   ori.PARSE_LCPID != parser.PARSE_LCPID ||
                                   ori.PARSE_ENTRY != parser.PARSE_ENTRY ||
                                   ori.PARSE_SIZE != parser.PARSE_SIZE ||
                                   ori.PARSE_TURN != parser.PARSE_TURN)
                                {
                                    // 更新日時が変わっていないこと
                                    T_PARSER check = this.version.context.T_PARSER.AsNoTracking().Where(r =>
                                                                                                r.PARSE_PHDEFID == ori.PARSE_PHDEFID &&
                                                                                                r.PARSE_ORDER == ori.PARSE_ORDER).SingleOrDefault();
                                    if (ori.PARSE_USERID == check.PARSE_USERID &&
                                       ori.PARSEL_UPDTIME == check.PARSEL_UPDTIME)
                                    {
                                        listUpdateParser.Add(parser);
                                    }
                                    else
                                    {
                                        this.logger.Error(string.Format("編集中に別ユーザによって更新されましたので、更新できません。"));
                                        return false;
                                    }
                                }
                            }
                        }
                        else
                        {
                            if (ori != null)
                            {
                                listDelParser.Add(ori);
                            }
                        }
                    }
                }

                //更新処理
                using (var tran = this.version.context.Database.BeginTransaction())
                {
                    try
                    {
                        // 電文構成パターン論理情報
                        foreach (T_DENSTRL denstrl in listDelDenstrl)
                        {
                            sb.Clear();
                            sb.Append("DELETE FROM T_DENSTRL");
                            sb.Append(" WHERE");
                            sb.Append($" DENSTRL_SUBSYSID='{denstrl.DENSTRL_SUBSYSID}' AND");
                            sb.Append($" DENSTRL_TELSUBSYSID='{denstrl.DENSTRL_TELSUBSYSID}' AND");
                            sb.Append($" DENSTRL_TELTYPE='{denstrl.DENSTRL_TELTYPE}' AND");
                            sb.Append($" DENSTRL_PATNO='{denstrl.DENSTRL_PATNO}' AND");
                            sb.Append($" DENSTRL_ORDER={denstrl.DENSTRL_ORDER}");
                            sql = sb.ToString();
                            this.version.context.Database.ExecuteSqlCommand(sql);
                        }
                        foreach (T_DENSTRL denstrl in listAddDenstrl)
                        {
                            // 追加
                            sb.Clear();
                            sb.Append($"INSERT INTO T_DENSTRL(");
                            sb.Append($" DENSTRL_SUBSYSID,");
                            sb.Append($" DENSTRL_TELSUBSYSID,");
                            sb.Append($" DENSTRL_TELTYPE,");
                            sb.Append($" DENSTRL_PATNO,");
                            sb.Append($" DENSTRL_ORDER,");
                            sb.Append($" DENSTRL_STRNO,");
                            sb.Append($" DENSTRL_INOUT,");
                            sb.Append($" DENSTRL_PHDEFID,");
                            sb.Append($" DENSTRL_USERID,");
                            sb.Append($" DENSTRL_UPDTIME");
                            sb.Append($" ) VALUES(");
                            sb.Append($" '{denstrl.DENSTRL_SUBSYSID}',");
                            sb.Append($" '{denstrl.DENSTRL_TELSUBSYSID}',");
                            sb.Append($" '{denstrl.DENSTRL_TELTYPE}',");
                            sb.Append($" '{denstrl.DENSTRL_PATNO}',");
                            sb.Append($" {denstrl.DENSTRL_ORDER},");
                            sb.Append($" '{denstrl.DENSTRL_STRNO}',");
                            sb.Append($" '{denstrl.DENSTRL_INOUT}',");
                            sb.Append($" '{denstrl.DENSTRL_PHDEFID}',");
                            sb.Append($" '{this.version.User.USERID}',");
                            sb.Append($" '{DateTime.Now.ToString()}'");
                            sb.Append($" )");
                            sql = sb.ToString();
                            this.version.context.Database.ExecuteSqlCommand(sql);
                        }

                        // Ｍパーサ変換情報テーブル
                        foreach (T_PARSER parser in listAddParser)
                        {
                            sb.Clear();
                            sb.Append($"INSERT INTO T_PARSER(");
                            sb.Append($" PARSE_PHDEFID,");
                            sb.Append($" PARSE_ORDER,");
                            sb.Append($" PARSE_TYPE,");
                            sb.Append($" PARSE_BCPID,");
                            sb.Append($" PARSE_SEQ,");
                            sb.Append($" PARSE_LCPID,");
                            if (parser.PARSE_ENTRY != null) sb.Append($" PARSE_ENTRY,");
                            if (parser.PARSE_TYPE == "2" && parser.PARSE_SIZE != null) sb.Append($" PARSE_SIZE,");
                            if (parser.PARSE_TURN != null) sb.Append($" PARSE_TURN,");
                            sb.Append($" PARSE_USERID,");
                            sb.Append($" PARSEL_UPDTIME");
                            sb.Append($" ) VALUES (");
                            sb.Append($" '{parser.PARSE_PHDEFID}',");
                            sb.Append($" {parser.PARSE_ORDER},");
                            sb.Append($" '{parser.PARSE_TYPE}',");
                            sb.Append($" '{parser.PARSE_BCPID}',");
                            sb.Append($" '{parser.PARSE_SEQ}',");
                            sb.Append($" '{parser.PARSE_LCPID}',");
                            if (parser.PARSE_ENTRY != null) sb.Append($" {parser.PARSE_ENTRY},");
                            if (parser.PARSE_TYPE == "2" && parser.PARSE_SIZE != null) sb.Append($" {parser.PARSE_SIZE},");
                            if (parser.PARSE_TURN != null) sb.Append($" {parser.PARSE_TURN},");
                            sb.Append($" '{this.version.User.USERID}',");
                            sb.Append($" '{DateTime.Now.ToString()}'");
                            sb.Append($" )");
                            sql = sb.ToString();
                            this.version.context.Database.ExecuteSqlCommand(sql);
                        }
                        foreach (T_PARSER parser in listUpdateParser)
                        {
                            sb.Clear();
                            sb.Append($"UPDATE T_PARSER SET");
                            sb.Append($" PARSE_TYPE='{parser.PARSE_TYPE}',");
                            sb.Append($" PARSE_BCPID='{parser.PARSE_BCPID}',");
                            sb.Append($" PARSE_SEQ='{parser.PARSE_SEQ}',");
                            sb.Append($" PARSE_LCPID='{parser.PARSE_LCPID}',");
                            if (parser.PARSE_ENTRY != null)
                            {
                                sb.Append($" PARSE_ENTRY={parser.PARSE_ENTRY},");
                            }
                            else
                            {
                                sb.Append($" PARSE_ENTRY=NULL,");
                            }
                            if (parser.PARSE_TYPE == "2" && parser.PARSE_SIZE != null)
                            {
                                sb.Append($" PARSE_SIZE={parser.PARSE_SIZE},");
                            }
                            else
                            {
                                sb.Append($" PARSE_SIZE=NULL,");
                            }
                            if (parser.PARSE_TURN != null)
                            {
                                sb.Append($" PARSE_TURN={parser.PARSE_TURN},");
                            }
                            else
                            {
                                sb.Append($" PARSE_TURN=NULL,");
                            }
                            sb.Append($" PARSE_USERID='{this.version.User.USERID}',");
                            sb.Append($" PARSEL_UPDTIME='{DateTime.Now.ToString()}'");
                            sb.Append($" WHERE");
                            sb.Append($" PARSE_PHDEFID='{parser.PARSE_PHDEFID}' AND");
                            sb.Append($" PARSE_ORDER={parser.PARSE_ORDER}");
                            sql = sb.ToString();
                            this.version.context.Database.ExecuteSqlCommand(sql);
                        }
                        foreach (T_PARSER parser in listDelParser)
                        {
                            sb.Clear();
                            sb.Append("DELETE FROM T_PARSER");
                            sb.Append(" WHERE");
                            sb.Append($" PARSE_PHDEFID='{parser.PARSE_PHDEFID}' AND");
                            sb.Append($" PARSE_ORDER={parser.PARSE_ORDER}");
                            sql = sb.ToString();
                            this.version.context.Database.ExecuteSqlCommand(sql);
                        }
                        tran.Commit();
                    }
                    catch (Exception ex)
                    {
                        this.logger.Error(ex, string.Format("ＤＢの更新に失敗しました。(SQL={0})", sql));
                        return false;
                    }
                }
                this.logger.Info(string.Format("【論理パターン管理機能】更新処理終了"));
                return true;
            }
            catch(Exception ex)
            {
                this.logger.Error(ex, "エラーが発生しました。");
                return false;
            }
            finally
            {
                WaitDialog.Close();
                this.Activate();
            }
        }

        private List<string> makeParserPattern(string Subsustem)
        {
            List<string> listHeader = new List<string>();   //ヘッダ部
            List<string> listCtrlOne = new List<string>();  //制御情報部１
            List<string> listCommon = new List<string>();   //共通部
            List<string> listEntry = new List<string>();    //エントリ部
            List<string> listCtrlTwo = new List<string>();  //制御情報部２
            int Entry = 0;

            List<T_DENSTRL> listDENSTRL = this.version.context.T_DENSTRL.AsNoTracking().Where(r =>
                                                                                        r.DENSTRL_SUBSYSID == Subsustem).OrderBy(r =>
                                                                                                                        r.DENSTRL_ORDER).ToList();
            foreach(T_DENSTRL denstrl in listDENSTRL)
            {
                T_DENSTRB denstrb = this.version.context.T_DENSTRB.AsNoTracking().Where(r =>
                                                                                    r.DENSTRB_SUBSYSID == Subsustem &&
                                                                                    r.DENSTRB_TELSUBSYSID == denstrl.DENSTRL_TELSUBSYSID &&
                                                                                    r.DENSTRB_TELTYPE == denstrl.DENSTRL_TELTYPE &&
                                                                                    r.DENSTRB_PATNO == denstrl.DENSTRL_PATNO).SingleOrDefault();
                string cmt = string.Empty;
                if (denstrb != null && denstrb.DENSTRB_COMMENT != null) cmt = denstrb.DENSTRB_COMMENT;
                // エントリ部
                listEntry.Add("****************************************");
                listEntry.Add(string.Format("* {0}", denstrb.DENSTRB_COMMENT));
                listEntry.Add("****************************************");
                listEntry.Add(string.Format(",論理構成番号,CHAR,4,{0}", denstrl.DENSTRL_STRNO));
                listEntry.Add(string.Format(",入出力区分,CHAR,1,{0}", denstrl.DENSTRL_INOUT));
                listEntry.Add(",ヨビ,CHAR,3,");
                listEntry.Add(string.Format(",パーサ変換定義ＩＤ,CHAR,8,{0}", denstrl.DENSTRL_PHDEFID));
                Entry++;
            }

            // ヘッダ部
            listHeader.Add("CSV");
            listHeader.Add("TBL,4088");
            listHeader.Add("*-------------------------------------------------------------------------------");
            listHeader.Add("*  システム名      マルス７０１");
            listHeader.Add("*");
            listHeader.Add(string.Format("*  サブシステム名  {0}", Utils.ToZenkaku(Subsustem)));
            listHeader.Add("*");
            listHeader.Add("*  テーブル名      パーサ変換パターン（DPCSMPPT）");
            listHeader.Add("*");

            // 制御情報部１
            listCtrlOne.Add("*-------------------------------------------------------------------------------");
            listCtrlOne.Add("制御情報部１");
            listCtrlOne.Add(string.Format(",全体長,BIN,4,{0:D}", 8 + 32 + 16 * Entry + 8));
            listCtrlOne.Add(",チェックＩＤ１,BIN,4,1");

            // 共通部
            listCommon.Add("*-------------------------------------------------------------------------------");
            listCommon.Add("共通情報部");
            listCommon.Add(",テーブルＩＤ,CHAR,8,DPCSMPPT");
            listCommon.Add(",共通情報長,BIN,4,32");
            listCommon.Add(string.Format(",最大エントリ数,BIN,4,{0:D}", Entry));
            listCommon.Add(string.Format(",エントリ数,BIN,4,{0:D}", Entry));
            listCommon.Add(",エントリ長,BIN,4,16");
            listCommon.Add(",テーブル種別,CHAR,4,TEXT");
            listCommon.Add(",可変長フラグ,CHAR,1,0");
            listCommon.Add(",インデックスフラグ,CHAR,1,0");
            listCommon.Add(",FILLER,HEX,2,0000");

            // 制御情報部２
            listCtrlTwo.Add("*-------------------------------------------------------------------------------");
            listCtrlTwo.Add("制御情報部２");
            listCtrlTwo.Add(",チェックＩＤ１,BIN,4,1");
            listCtrlTwo.Add(",予備,BIN,4,0");

            List<string> listResult = new List<string>();
            listResult.AddRange(listHeader);
            listResult.AddRange(listCtrlOne);
            listResult.AddRange(listCommon);
            listResult.Add("*-------------------------------------------------------------------------------");
            listResult.Add("エントリ部START");
            listResult.AddRange(listEntry);
            listResult.Add("エントリ部END");
            listResult.AddRange(listCtrlTwo);
            return listResult;
        }

        /// <summary>
        /// パーサ変換定義作成
        /// </summary>
        /// <param name="Subsustem"></param>
        /// <param name="DENSTRB">電文構成パターン物理情報</param>
        /// <param name="DENSTRL">電文構成パターン論理情報</param>
        /// <returns></returns>
        private List<string> makeParserDef(string Subsustem, T_DENSTRB DENSTRB, T_DENSTRL DENSTRL)
        {
            this.logger.Info(string.Format("【論理パターン管理機能】パーサ変換定義作成開始（{0}）", DENSTRL.DENSTRL_PHDEFID));

            List<ParserDef> listParserDef = null;
            List<T_DENSTRBITM> listDENSTRBITM = null;
            List<T_PARSER> listPARSER = null;

            try
            {
                //ＤＢより必要な情報を収集する
                listParserDef = new List<ParserDef>();
                listDENSTRBITM = this.version.context.T_DENSTRBITM.AsNoTracking().Where(r =>
                                                                        r.DENSTRBITM_SUBSYSID == DENSTRB.DENSTRB_SUBSYSID &&
                                                                        r.DENSTRBITM_TELSUBSYSID == DENSTRB.DENSTRB_TELSUBSYSID &&
                                                                        r.DENSTRBITM_TELTYPE == DENSTRB.DENSTRB_TELTYPE &&
                                                                        r.DENSTRBITM_PATNO == DENSTRB.DENSTRB_PATNO).OrderBy(r => r.DENSTRBITM_ORDER).ToList();
                listPARSER = this.version.context.T_PARSER.AsNoTracking().Where(r =>
                                                                        r.PARSE_PHDEFID == DENSTRL.DENSTRL_PHDEFID).OrderBy(r => r.PARSE_ORDER).ToList();
                
                foreach (T_PARSER parser in listPARSER)
                {
                    int MaxCnt = 1;
                    if (parser.PARSE_TURN != null && parser.PARSE_TURN > 1) MaxCnt = (int)parser.PARSE_TURN;
                    for (int cnt = 0; cnt < MaxCnt; cnt++)
                    {
                        ParserDef parserDef = new ParserDef();
                        parserDef.parserKey = new ParserKey
                        {
                            PHDEFID = parser.PARSE_PHDEFID,
                            ORDER = parser.PARSE_ORDER
                        };

                        if (parser.PARSE_TYPE == "1")
                        {
                            T_CPYLOG cpylog = this.version.context.T_CPYLOG.AsNoTracking().Where(r =>
                                                                                        r.CPYLGC_SUBSYSID == Subsustem &&
                                                                                        r.CPYLGC_LCPID == parser.PARSE_LCPID).SingleOrDefault();
                            List<T_LOGITM> listLOGITM = this.version.context.T_LOGITM.AsNoTracking().Where(r =>
                                                                                        r.LOGITM_SUBSYSIDL == cpylog.CPYLGC_SUBSYSID &&
                                                                                        r.LOGITM_LCPID == cpylog.CPYLGC_LCPID).ToList();
                            T_CPYPHY CPYPHY = this.version.context.T_CPYPHY.AsNoTracking().Where(r =>
                                                                                        r.CPYPHY_SUBSYSID == cpylog.CPYLGC_PHYSYSID &&
                                                                                        r.CPYPHY_INFOID == cpylog.CPYLGC_INFOID).SingleOrDefault();
                            List<T_PHYITM> listPHYITM = this.version.context.T_PHYITM.AsNoTracking().Where(r =>
                                                                                        r.PHYITM_SUBSYSID == CPYPHY.CPYPHY_SUBSYSID &&
                                                                                        r.PHYITM_INFOID == CPYPHY.CPYPHY_INFOID).OrderBy(r =>
                                                                                                                            r.PHYITM_ITEMNO).ToList();
                            List<T_PHYPRS_EF> listPHYPRS = this.version.context.T_PHYPRS.AsNoTracking().Where(r =>
                                                                                        r.PHYPRS_PHYSYSID == CPYPHY.CPYPHY_SUBSYSID &&
                                                                                        r.PHYPRS_INFOID == CPYPHY.CPYPHY_INFOID &&
                                                                                        r.PHYPRS_SUBSYSID == cpylog.CPYLGC_SUBSYSID).ToList();
                            parserDef.CPYPHY = CPYPHY;
                            parserDef.CPYLOG = cpylog;
                            int offset = 0;
                            foreach (T_DENSTRBITM itm in listDENSTRBITM)
                            {
                                if (itm.DENSTRBITM_SEQ == parser.PARSE_SEQ)
                                {
                                    int target = 1;
                                    if (parser.PARSE_ENTRY != null && parser.PARSE_ENTRY > 1) target = (int)parser.PARSE_ENTRY;
                                    target += cnt;
                                    if(target != 1)
                                    {
                                        T_CPYLOG c = this.version.context.T_CPYLOG.AsNoTracking().Where(r =>
                                                                                                    r.CPYLGC_SUBSYSID == DENSTRL.DENSTRL_SUBSYSID &&
                                                                                                    r.CPYLGC_LCPID == parser.PARSE_LCPID).SingleOrDefault();
                                        int ItemSize = IntefaceCommon.getPhysicSize(this.version, c.CPYLGC_PHYSYSID, c.CPYLGC_INFOID);
                                        offset += ItemSize * (target - 1);
                                    }
                                    break;
                                }
                                if (itm.DENSTRBITM_TYPE == "1")
                                {
                                    T_CPYLOG c = this.version.context.T_CPYLOG.AsNoTracking().Where(r =>
                                                                                                r.CPYLGC_SUBSYSID == DENSTRL.DENSTRL_SUBSYSID &&
                                                                                                r.CPYLGC_LCPID == parser.PARSE_LCPID).SingleOrDefault();
                                    offset += IntefaceCommon.getPhysicSize(this.version, c.CPYLGC_PHYSYSID, c.CPYLGC_INFOID);
                                }
                                else
                                {
                                    offset += (int)itm.DENSTRBITM_YOBISIZE;
                                }
                            }
                            parserDef.PhysicOffset = offset;

                            parserDef.LogiciSize = IntefaceCommon.getLogicSize(this.version, cpylog.CPYLGC_PHYSYSID, cpylog.CPYLGC_SUBSYSID,
                                                                                             cpylog.CPYLGC_INFOID, cpylog.CPYLGC_LCPID);
                            List<ParserDefItem> listItem = new List<ParserDefItem>();
                            foreach (T_PHYITM phyitm in listPHYITM)
                            {
                                ParserDefItem item = new ParserDefItem
                                {
                                    Type = parser.PARSE_TYPE,
                                    PHYITM = phyitm,
                                    PHYPRS = listPHYPRS.Where(r => r.PHYPRS_SEQ == phyitm.PHYITM_SEQ).FirstOrDefault()
                                };
                                if (item.PHYPRS != null)
                                {
                                    item.LOGITM = listLOGITM.Where(r => r.LOGITM_SEQ == phyitm.PHYITM_SEQ).FirstOrDefault();
                                }
                                listItem.Add(item);
                            }
                            // 親子関係構築
                            ParserDefItem rootItem = buildParent(listItem);
                            // 繰返し回数の展開
                            parserDef.Item = expandItem(rootItem);
                            // 集団項目のサイズ計算
                            calcPhysicGroupSize(parserDef.Item);
                            calcLogicGroupSize(parserDef.Item);
                        }
                        else if (parser.PARSE_TYPE == "2")
                        {
                            ParserDefItem item = new ParserDefItem
                            {
                                Type = parser.PARSE_TYPE,
                                Size = (int)parser.PARSE_SIZE
                            };
                            parserDef.Item = item;
                        }
                        else
                        {
                            ParserDefItem item = new ParserDefItem
                            {
                                Type = parser.PARSE_TYPE
                            };
                            parserDef.Item = item;
                        }
                        listParserDef.Add(parserDef);
                    }
                }
            }
            catch (Exception ex)
            {
                this.logger.Error(ex, string.Format("ＤＢからの取得処理でエラーが発生しました。"));
                return null;
            }

            List<string> listHeader = new List<string>();   //ヘッダ部
            List<string> listCtrlOne = new List<string>();  //制御情報部１
            List<string> listCommon = new List<string>();   //共通部
            List<string> listEntry = new List<string>();    //エントリ部
            List<string> listCtrlTwo = new List<string>();  //制御情報部２
            List<string> listResult = new List<string>();

            //各バッファ（リスト）に情報を出力する
            try
            {
                // ヘッダ部
                listHeader.Add("CSV");
                listHeader.Add("TBL,4088");
                listHeader.Add("*-------------------------------------------------------------------------------");
                listHeader.Add("*  システム名      マルス７０１");
                listHeader.Add("*");
                listHeader.Add(string.Format("*  サブシステム名  {0}", Utils.ToZenkaku(Subsustem)));
                listHeader.Add("*");
                listHeader.Add(string.Format("*  テーブル名      {0}", DENSTRL.DENSTRL_PHDEFID));
                listHeader.Add("*");
                // エントリ部
                int LogicSize = 0;
                int LogicLOC = 0;
                foreach (ParserDef parserDef in listParserDef)
                {
                    if (parserDef.Item.Type == "1")
                    {
                        int lc = LogicLOC;
                        int PhysicLOC = parserDef.PhysicOffset;
                        listEntry.AddRange(buildEntryString(parserDef.Item, ref PhysicLOC, ref LogicLOC));
                        LogicSize += (LogicLOC - lc);
                    }
                    else if (parserDef.Item.Type == "2")
                    {
                        LogicLOC += parserDef.Item.Size;
                        LogicSize += parserDef.Item.Size;
                    }
                    else
                    {
                        listEntry.Add("****************************************");
                        listEntry.Add("* NEXTADDR");
                        listEntry.Add("****************************************");
                        listEntry.Add(",項目タグ,CHAR,12,NEXTADDR");
                        listEntry.Add(",FILLER,CHAR,4,");
                        listEntry.Add(",項目属性,CHAR,4,");
                        listEntry.Add(",項目ロケーション,BIN,4,");
                        listEntry.Add(",項目サイズ,BIN,4,");
                        listEntry.Add(",文字コード,CHAR,1,");
                        listEntry.Add(",FILLER,CHAR,3,");
                        listEntry.Add(",項目属性,CHAR,4,");
                        listEntry.Add(",項目ロケーション,BIN,4,");
                        listEntry.Add(",項目サイズ,BIN,4,");
                        listEntry.Add(",項目符号,CHAR,1,");
                        listEntry.Add(",文字コード,CHAR,1,");
                        listEntry.Add(",FILLER,CHAR,2,");
                        LogicLOC = 0;
                    }
                }
                listEntry.Add("****************************************");
                listEntry.Add("* END");
                listEntry.Add("****************************************");
                listEntry.Add(",項目タグ,CHAR,12,END");
                listEntry.Add(",FILLER,CHAR,4,");
                listEntry.Add(",項目属性,CHAR,4,");
                listEntry.Add(",項目ロケーション,BIN,4,");
                listEntry.Add(",項目サイズ,BIN,4,");
                listEntry.Add(",文字コード,CHAR,1,");
                listEntry.Add(",FILLER,CHAR,3,");
                listEntry.Add(",項目属性,CHAR,4,");
                listEntry.Add(",項目ロケーション,BIN,4,");
                listEntry.Add(string.Format(",項目サイズ,BIN,4,{0:D}", LogicSize));
                listEntry.Add(",項目符号,CHAR,1,");
                listEntry.Add(",文字コード,CHAR,1,");
                listEntry.Add(",FILLER,CHAR,2,");
                int EntryCount = listEntry.Count / 16;
                // 制御情報部１
                listCtrlOne.Add("*-------------------------------------------------------------------------------");
                listCtrlOne.Add("制御情報部１");
                listCtrlOne.Add(string.Format(",全体長,BIN,4,{0:D}", 8 + 32 + 48 * EntryCount + 8));
                listCtrlOne.Add(",チェックＩＤ１,BIN,4,1");
                // 共通部
                listCommon.Add("*-------------------------------------------------------------------------------");
                listCommon.Add("共通情報部");
                listCommon.Add(string.Format(",テーブルＩＤ,CHAR,8,{0}", DENSTRL.DENSTRL_PHDEFID));
                listCommon.Add(",共通情報長,BIN,4,32");
                listCommon.Add(string.Format(",最大エントリ数,BIN,4,{0}", EntryCount));
                listCommon.Add(string.Format(",エントリ数,BIN,4,{0}", EntryCount));
                listCommon.Add(",エントリ長,BIN,4,48");
                listCommon.Add(",テーブル種別,CHAR,4,TEXT");
                listCommon.Add(",可変長フラグ,CHAR,1,0");
                listCommon.Add(",インデックスフラグ,CHAR,1,0");
                listCommon.Add(",FILLER,HEX,2,0000");
                // 制御情報部２
                listCtrlTwo.Add("*-------------------------------------------------------------------------------");
                listCtrlTwo.Add("制御情報部２");
                listCtrlTwo.Add(",チェックＩＤ１,BIN,4,1");
                listCtrlTwo.Add(",予備,BIN,4,0");

                listResult.AddRange(listHeader);
                listResult.AddRange(listCtrlOne);
                listResult.AddRange(listCommon);
                listResult.Add("*-------------------------------------------------------------------------------");
                listResult.Add("エントリ部START");
                listResult.AddRange(listEntry);
                listResult.Add("エントリ部END");
                listResult.AddRange(listCtrlTwo);
            }
            catch (Exception ex)
            {
                this.logger.Error(ex, string.Format("パーサ変換定義の組み立て処理でエラーが発生しました。"));
                return null;
            }

            this.logger.Info(string.Format("【論理パターン管理機能】パーサ変換定義作成完了"));
            return listResult;
        }

        /// <summary>
        /// 親子関係構築
        /// </summary>
        /// <param name="listParserDef"></param>
        /// <returns></returns>
        private ParserDefItem buildParent(List<ParserDefItem> listParserDef)
        {
            for(int i = 1; i < listParserDef.Count; i++)
            {
                ParserDefItem parent = listParserDef[i - 1];
                while(parent != null)
                {
                    if (parent.PHYITM.PHYITM_LEVEL < listParserDef[i].PHYITM.PHYITM_LEVEL)
                    {
                        parent.ChildItems.Add(listParserDef[i]);
                        listParserDef[i].ParentItem = parent;
                        if(listParserDef[i].PHYITM.PHYITM_DTTYPE == "BIT")
                        {
                            parent.hasBit = true;
                        }
                        break;
                    }
                    else
                    {
                        parent = parent.ParentItem;
                    }
                }
            }
            return listParserDef[0];
        }

        /// <summary>
        /// 繰返し回数展開
        /// </summary>
        /// <param name="Item"></param>
        /// <returns></returns>
        private ParserDefItem expandItem(ParserDefItem Item)
        {
            for(int i = 0; i < Item.ChildItems.Count; i++)
            {
                if(Item.ChildItems[i].PHYITM.PHYITM_OCCURS != 0 && Item.ChildItems[i].PHYITM.PHYITM_OCCURS > 1)
                {
                    ParserDefItem[] Items = new ParserDefItem[(int)Item.ChildItems[i].PHYITM.PHYITM_OCCURS];
                    for(int j = 0; j < Items.Length; j ++)
                    {
                        Items[j] = Item.ChildItems[i].DeepClone();
                        Items[j].PHYITM.PHYITM_OCCURS = 0;
                        foreach(string word in new List<string>() { "nn", "mm", "ll" })
                        {
                            if(Items[j].PHYPRS != null)
                            {
                                if (Items[j].PHYPRS.PHYPRS_TAGNM.IndexOf(word) > -1)
                                {
                                    Items[j].PHYPRS.PHYPRS_TAGNM = Items[j].PHYPRS.PHYPRS_TAGNM.Replace(word, string.Format("{0:D2}", j + 1));
                                    // 子項目がある場合は、全ての子項目についても置換する
                                    for (int k = 0; k < Items[j].ChildItems.Count; k++)
                                    {
                                        if(Items[j].ChildItems[k].PHYPRS != null)
                                        {
                                            Items[j].ChildItems[k] = childItemExpand(Items[j].ChildItems[k], word, j + 1);
                                        }
                                    }
                                    break;
                                }
                            }
                        }
                    }
                    Item.ChildItems.RemoveAt(i);
                    Item.ChildItems.InsertRange(i, Items);
                }
            }
            // 孫項目のOCCURS展開
            for (int i = 0; i < Item.ChildItems.Count; i++)
            {
                Item.ChildItems[i] = expandItem(Item.ChildItems[i]);
            }

            return Item;
        }

        /// <summary>
        /// 集団項目サイズ算出（物理）
        /// </summary>
        /// <param name="Item"></param>
        /// <returns></returns>
        private int calcPhysicGroupSize(ParserDefItem Item)
        {
            int size = 0;
            int bitsize = 0;

            if(Item.PHYITM.PHYITM_DTTYPE == "GROUP")
            {
                for (int i = 0; i < Item.ChildItems.Count; i++)
                {
                    if (Item.ChildItems[i].PHYITM.PHYITM_DTTYPE == "GROUP")
                    {
                        if ((bitsize % 8) > 0) bitsize += (8 - bitsize % 8);
                        size += calcPhysicGroupSize(Item.ChildItems[i]);
                    }
                    else if (Item.ChildItems[i].PHYITM.PHYITM_DTTYPE == "BIT")
                    {
                        bitsize += (int)Item.ChildItems[i].PHYITM.PHYITM_DTLEN;
                    }
                    else
                    {
                        if ((bitsize % 8) > 0) bitsize += (8 - bitsize % 8);
                        size += (int)Item.ChildItems[i].PHYITM.PHYITM_DTLEN;
                    }
                }
            }
            else
            {
                return (int)Item.PHYITM.PHYITM_DTLEN;
            }
            if ((bitsize % 8) > 0) bitsize += (8 - bitsize % 8);
            size += bitsize / 8;
            Item.PHYITM.PHYITM_DTLEN = size;
            return size;
        }

        /// <summary>
        /// 集団項目サイズ算出（論理）
        /// </summary>
        /// <param name="Item"></param>
        /// <returns></returns>
        private int calcLogicGroupSize(ParserDefItem Item)
        {
            int size = 0;
            int bitsize = 0;

            if (Item.LOGITM == null) return 0;

            if (Item.PHYITM.PHYITM_DTTYPE == "GROUP")
            {
                for (int i = 0; i < Item.ChildItems.Count; i++)
                {
                    if(Item.ChildItems[i].LOGITM != null)
                    {
                        if (Item.ChildItems[i].PHYITM.PHYITM_DTTYPE == "GROUP")
                        {
                            if ((bitsize % 8) > 0) bitsize += (8 - bitsize % 8);
                            size += calcLogicGroupSize(Item.ChildItems[i]);
                        }
                        else if (Item.ChildItems[i].PHYITM.PHYITM_DTTYPE == "BIT")
                        {
                            bitsize += (int)Item.ChildItems[i].LOGITM.LOGITM_DATALEN;
                        }
                        else
                        {
                            if ((bitsize % 8) > 0) bitsize += (8 - bitsize % 8);
                            size += (int)Item.ChildItems[i].LOGITM.LOGITM_DATALEN;
                        }
                    }
                }
            }
            else
            {
                return (int)Item.LOGITM.LOGITM_DATALEN;
            }
            if ((bitsize % 8) > 0) bitsize += (8 - bitsize % 8);
            size += bitsize / 8;
            Item.LOGITM.LOGITM_DATALEN = size;
            return size;
        }

        /// <summary>
        /// 子項目展開
        /// </summary>
        /// <param name="Item"></param>
        /// <param name="word"></param>
        /// <param name="iNumber"></param>
        /// <returns></returns>
        private ParserDefItem childItemExpand(ParserDefItem Item, string word, int iNumber)
        {
            Item.PHYPRS.PHYPRS_TAGNM = Item.PHYPRS.PHYPRS_TAGNM.Replace(word, string.Format("{0:D2}", iNumber));
            // 子項目がある場合は子項目も置換する
            for (int i = 0; i < Item.ChildItems.Count; i++)
            {
                Item.ChildItems[i] = childItemExpand(Item.ChildItems[i], word, iNumber);
            }
            return Item;
        }

        /// <summary>
        /// パーサ変換定義．エントリ部組み立て
        /// </summary>
        /// <param name="Item"></param>
        /// <param name="Offset">開始位置</param>
        /// <param name="LogicLOC">論理位置</param>
        /// <returns></returns>
        private List<string> buildEntryString(ParserDefItem Item, ref int Offset, ref int LogicLOC)
        {
            List<string> list = new List<string>();
            foreach (ParserDefItem ChildItem in Item.ChildItems)
            {
                if (ChildItem.ChildItems.Count > 0)
                {
                    //子項目がビット持ちなので集団項目が出力対象
                    if (ChildItem.hasBit)
                    {
                        if(ChildItem.LOGITM != null)
                        {
                            list.Add("****************************************");
                            list.Add(string.Format("* {0}", ChildItem.PHYITM.PHYITM_ITEMNM));
                            list.Add("****************************************");
                            list.Add(string.Format(",項目タグ,CHAR,12,{0}", ChildItem.PHYPRS.PHYPRS_TAGNM));
                            list.Add(",FILLER,CHAR,4,");
                            list.Add(string.Format(",項目属性,CHAR,4,{0}", ChildItem.LOGITM.LOGITM_TYPE));
                            list.Add(string.Format(",項目ロケーション,BIN,4,{0:D}", LogicLOC));
                            list.Add(string.Format(",項目サイズ,BIN,4,{0}", ChildItem.LOGITM.LOGITM_DATALEN));
                            if (string.IsNullOrEmpty(ChildItem.LOGITM.LOGITM_MCODE))
                            {
                                list.Add(",文字コード,CHAR,1,");
                            }
                            else
                            {
                                list.Add(string.Format(",文字コード,CHAR,1,{0}", ChildItem.LOGITM.LOGITM_MCODE));
                            }
                            list.Add(",FILLER,CHAR,3,");
                            if(ChildItem.PHYPRS.PHYPRS_LTYPE != null && ChildItem.PHYPRS.PHYPRS_LTYPE == "INT")
                            {
                                list.Add(string.Format(",項目属性,CHAR,4,{0}", "BIN"));
                            }
                            else
                            {
                                list.Add(string.Format(",項目属性,CHAR,4,{0}", ChildItem.PHYPRS.PHYPRS_LTYPE));
                            }
                            list.Add(string.Format(",項目ロケーション,BIN,4,{0:D}", Offset));
                            list.Add(string.Format(",項目サイズ,BIN,4,{0}", ChildItem.PHYITM.PHYITM_DTLEN));
                            if (string.IsNullOrEmpty(ChildItem.PHYPRS.PHYPRS_FLG))
                            {
                                list.Add(",項目符号,CHAR,1,0");
                            }
                            else
                            {
                                list.Add(string.Format(",項目符号,CHAR,1,{0}", ChildItem.PHYPRS.PHYPRS_FLG));
                            }
                            if (string.IsNullOrEmpty(ChildItem.PHYPRS.PHYPRS_MCODE))
                            {
                                list.Add(",文字コード,CHAR,1,");
                            }
                            else
                            {
                                list.Add(string.Format(",文字コード,CHAR,1,{0}", ChildItem.PHYPRS.PHYPRS_MCODE));
                            }
                            list.Add(",FILLER,CHAR,2,");
                            LogicLOC += (int)ChildItem.LOGITM.LOGITM_DATALEN;
                        }

                        Offset += getSize(ChildItem);
                    }
                    else
                    {
                        //子項目の内容を格納
                        list.AddRange(buildEntryString(ChildItem, ref Offset, ref LogicLOC));
                    }
                }
                else
                {
                    //論理項目が存在する場合は出力対象とする
                    if(ChildItem.LOGITM != null)
                    {
                        list.Add("****************************************");
                        list.Add(string.Format("* {0}", ChildItem.PHYITM.PHYITM_ITEMNM));
                        list.Add("****************************************");
                        list.Add(string.Format(",項目タグ,CHAR,12,{0}", ChildItem.PHYPRS.PHYPRS_TAGNM));
                        list.Add(",FILLER,CHAR,4,");
                        list.Add(string.Format(",項目属性,CHAR,4,{0}", ChildItem.PHYPRS.PHYPRS_LTYPE));
                        list.Add(string.Format(",項目ロケーション,BIN,4,{0:D}", Offset));
                        list.Add(string.Format(",項目サイズ,BIN,4,{0}", ChildItem.PHYITM.PHYITM_DTLEN));
                        if (string.IsNullOrEmpty(ChildItem.PHYPRS.PHYPRS_MCODE))
                        {
                            list.Add(",文字コード,CHAR,1,");
                        }
                        else
                        {
                            list.Add(string.Format(",文字コード,CHAR,1,{0}", ChildItem.PHYPRS.PHYPRS_MCODE));
                        }
                        list.Add(",FILLER,CHAR,3,");
                        list.Add(string.Format(",項目属性,CHAR,4,{0}", ChildItem.LOGITM.LOGITM_TYPE));
                        list.Add(string.Format(",項目ロケーション,BIN,4,{0}", LogicLOC));
                        list.Add(string.Format(",項目サイズ,BIN,4,{0}", ChildItem.LOGITM.LOGITM_DATALEN));
                        if (string.IsNullOrEmpty(ChildItem.PHYPRS.PHYPRS_FLG))
                        {
                            list.Add(",項目符号,CHAR,1,0");
                        }
                        else
                        {
                            list.Add(string.Format(",項目符号,CHAR,1,{0}", ChildItem.PHYPRS.PHYPRS_FLG));
                        }
                        if (string.IsNullOrEmpty(ChildItem.LOGITM.LOGITM_MCODE))
                        {
                            list.Add(",文字コード,CHAR,1,");
                        }
                        else
                        {
                            list.Add(string.Format(",文字コード,CHAR,1,{0}", ChildItem.LOGITM.LOGITM_MCODE));
                        }
                        list.Add(",FILLER,CHAR,2,");
                        LogicLOC += (int)ChildItem.LOGITM.LOGITM_DATALEN;
                    }
                    Offset += (int)ChildItem.PHYITM.PHYITM_DTLEN;
                }
            }
            return list;
        }

        /// <summary>
        /// 項目サイズ取得
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        private int getSize(ParserDefItem item)
        {
            int size = 0;
            int bitSize = 0;
            foreach (ParserDefItem ChildItem in item.ChildItems)
            {
                //集団項目か？
                if (string.IsNullOrEmpty(ChildItem.PHYITM.PHYITM_CPYDTTYPE))
                {
                    if ((bitSize % 8) > 0) bitSize += 8 - (bitSize % 8);
                    bitSize = 0;
                    size += getSize(ChildItem);
                }
                else
                {
                    //ビット項目か？
                    if (ChildItem.PHYITM.PHYITM_CPYDTTYPE.IndexOf(" BIT") > 0)
                    {
                        bitSize += (int)ChildItem.PHYITM.PHYITM_DTLEN;
                    }
                    else
                    {
                        if ((bitSize % 8) > 0) bitSize += 8 - (bitSize % 8);
                        bitSize = 0;
                        size += (int)ChildItem.PHYITM.PHYITM_DTLEN;
                    }
                }
            }
            if ((bitSize % 8) > 0) bitSize += 8 - (bitSize % 8);
            size += bitSize / 8;
            return size;
        }

        /// <summary>
        /// 新規ボタン押下時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnNew_Click(object sender, EventArgs e)
        {
            if(isEditCheck())
            {
                //電文構成ダイアログを表示し、選択された内容をパターン編集に設定する
                DenstrbDialog denstrbDialog = new DenstrbDialog(this.version, this.subsystem);
                if (denstrbDialog.ShowDialog() == DialogResult.OK)
                {
                    setPattern(denstrbDialog.T_DENSTRB, null);
                    btnEdit.Enabled = false;
                    NewFlag = true;
                }
            }
        }

        /// <summary>
        /// パターン編集.セル編集開始
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvPattern_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            //編集対象以外のセルはキャンセルする
            if (e.ColumnIndex < 4) e.Cancel = true;
        }

        /// <summary>
        /// パターン編集.セルの内容が変更された時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvPattern_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1) return;
            bool status = false;

            //編集状態に応じてボタンの有効／無効を切り替える
            DataGridViewRow row = dgvPattern.Rows[e.RowIndex];
            if(string.IsNullOrEmpty(row.Cells[4].Value as string) == false &&
               string.IsNullOrEmpty(row.Cells[5].Value as string) == false &&
               string.IsNullOrEmpty(row.Cells[6].Value as string) == false)
            {
                status = true;
            }

            if(NewFlag)
            {
                btnListAdd.Enabled = status;
                btnEdit.Enabled = false;
                btnListDel.Enabled = false;
            }
            else
            {
                btnListAdd.Enabled = false;
                btnEdit.Enabled = status;
                btnListDel.Enabled = false;
            }
        }

        /// <summary>
        /// パターン編集の追加ボタン押下時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnListAdd_Click(object sender, EventArgs e)
        {
            if(isEditCheck())
            {
                if (checkPattern())     // 編集内容の検定
                {
                    RowItem rowItem = dgvPattern.Rows[0].Tag as RowItem;
                    string cmt = string.Empty;
                    if (rowItem.DENSTRB.DENSTRB_COMMENT != null) cmt = rowItem.DENSTRB.DENSTRB_COMMENT;
                    //ＤＢ上に同一パターンがないか検定する
                    if (getDENSTRL(rowItem.DENSTRB) == true)
                    {
                        MessageBox.Show("既に同一パターンが存在します", Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.DENSTRL = null;
                        return;
                    }
                    if (checkDouble((string)dgvPattern.Rows[0].Cells[6].Value, rowItem.DENSTRB) == false)
                    {
                        MessageBox.Show("該当パーサ変換定義ＩＤは既に使用されています。", Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    //一覧に追加
                    dgvList.Rows.Add(cmt,
                                     rowItem.DENSTRB.DENSTRB_TELSUBSYSID,
                                     rowItem.DENSTRB.DENSTRB_TELTYPE,
                                     rowItem.DENSTRB.DENSTRB_PATNO,
                                     dgvPattern.Rows[0].Cells[4].Value as string,
                                     dgvPattern.Rows[0].Cells[5].Value as string,
                                     dgvPattern.Rows[0].Cells[6].Value as string);
                    dgvList.Rows[dgvList.Rows.Count - 1].Tag = rowItem;
                    dgvList.Rows[dgvList.Rows.Count - 1].Selected = true;
                    dgvList.FirstDisplayedScrollingRowIndex = dgvList.Rows.Count - 1;

                    grpEdit.Enabled = true;
                    grpOutput.Enabled = false;
                    grpList.Enabled = false;
                    grpPattern.Enabled = false;
                    btnListAdd.Enabled = false;
                    btnUpdate.Enabled = true;
                    this.DENSTRB = rowItem.DENSTRB;
                    NewFlag = false;
                    //物理－論理パーサ変換定義編集に設定
                    setEdit();
                }
                else
                {
                    MessageBox.Show("パターン編集・論理情報の入力内容が誤っています。", Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// 物理－論理パーサ変換定義編集の追加ボタン押下時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            //メニューを表示
            mnuEdit.Show(btnAdd, new Point(btnAdd.Width / 2, btnAdd.Height/2));
        }

        /// <summary>
        /// メニュー.情報部を追加
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mnuAddID_Click(object sender, EventArgs e)
        {
            //物理構成ダイアログを表示し、選択した内容を追加する
            PhysicStrDialog physicStrDialog = new PhysicStrDialog(this.version, this.DENSTRB);
            if(physicStrDialog.ShowDialog() == DialogResult.OK)
            {
                ListViewItem ltvItem = resultItemToListViewItem(physicStrDialog.resultItem);
                ltvEdit.Items.Add(ltvItem);
                btnUpdate.Enabled = true;
                isEdit = true;
            }
        }

        /// <summary>
        /// 物理－論理パーサ変換定義編集の削除ボタン押下時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDel_Click(object sender, EventArgs e)
        {
            if(ltvEdit.SelectedItems.Count > 0)
            {
                ltvEdit.Items.Remove(ltvEdit.SelectedItems[0]);
                isEdit = true;
                //全ての項目を削除した場合は、更新ボタンを無効にする
                if (ltvEdit.Items.Count == 0)
                {
                    btnUpdate.Enabled = false;
                }
                else
                {
                    btnUpdate.Enabled = true;
                }
            }
        }

        /// <summary>
        /// 物理－論理パーサ変換定義編集のリスト選択時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ltvEdit_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            //何か選択されたら、削除ボタンを有効にする
            if(e.IsSelected)
            {
                btnDel.Enabled = true;
            }
            else
            {
                btnDel.Enabled = false;
            }
        }

        /// <summary>
        /// メニュー.予備を追加
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mnuAddYobi_Click(object sender, EventArgs e)
        {
            Common.Forms.InputDialog dialog = new InputDialog();
            dialog.Multiline = false;
            dialog.Check = this.checkSize;  //サイズ以外は入力不可とする
            if(dialog.ShowDialog(this, "入力", "予備サイズを入力してください。", string.Empty) == DialogResult.OK)
            {
                ListViewItem ltvItem = new ListViewItem();
                ltvItem.Text = "予備";
                ltvItem.SubItems.Add("-");
                ltvItem.SubItems.Add("-");
                ltvItem.SubItems.Add(dialog.Value);
                ltvItem.SubItems.Add("-");
                ltvItem.SubItems.Add("-");
                ltvEdit.Items.Add(ltvItem);
                btnUpdate.Enabled = true;
                isEdit = true;
            }
        }

        /// <summary>
        /// 入力ダイアログ.検定関数
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        private bool checkSize(string text)
        {
            //数値のみ許可
            return Common.Utils.IsNum(text);
        }

        /// <summary>
        /// メニュー.NEXTADDR
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mnuAddNextADDR_Click(object sender, EventArgs e)
        {
            ListViewItem ltvItem = new ListViewItem();
            ltvItem.Text = "NEXTADDR";
            ltvItem.SubItems.Add("-");
            ltvItem.SubItems.Add("-");
            ltvItem.SubItems.Add("-");
            ltvItem.SubItems.Add("-");
            ltvItem.SubItems.Add("-");
            ltvEdit.Items.Add(ltvItem);
            isEdit = true;
        }

        /// <summary>
        /// 更新ボタン押下時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (updateEdit())   //更新処理
            {
                isEdit = false;
                MessageBox.Show("更新が完了しました。", Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
                btnUpdate.Enabled = false;
                grpOutput.Enabled = true;
                grpEdit.Enabled = false;
                //一覧を再設定
                setList();
                NewFlag = false;
                //更新したパターンを一覧から検索し、選択状態にする
                int RowIndex = -1;
                if (dgvPattern.Rows.Count == 1)
                {
                    RowIndex = searchList(dgvPattern.Rows[0].Cells[4].Value as string, dgvPattern.Rows[0].Cells[5].Value as string);
                }
                if (RowIndex != -1)
                {
                    dgvList.Rows[RowIndex].Selected = true;
                    dgvPattern.Rows[0].Tag = getRowItemFromDataGridView(RowIndex);
                }
                else
                {
                    foreach(DataGridViewRow row in dgvList.SelectedRows)
                    {
                        row.Selected = false;
                        dgvPattern.Rows.Clear();
                        btnEdit.Enabled = false;
                    }
                }
            }
            else
            {
                MessageBox.Show("更新に失敗しました。ログファイルを確認してください。", Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        /// <summary>
        /// 一覧のセルがクリックされた時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                if (isEditCheck())
                {
                    //パターン編集に該当行のパターンを設定する
                    dgvPattern.Rows.Clear();

                    RowItem rowItem = dgvList.Rows[e.RowIndex].Tag as RowItem;
                    dgvPattern.Rows.Add(rowItem.DENSTRB.DENSTRB_COMMENT,
                                        rowItem.DENSTRB.DENSTRB_TELSUBSYSID,
                                        rowItem.DENSTRB.DENSTRB_TELTYPE,
                                        rowItem.DENSTRB.DENSTRB_PATNO,
                                        rowItem.DENSTRL.DENSTRL_STRNO,
                                        rowItem.DENSTRL.DENSTRL_INOUT,
                                        rowItem.DENSTRL.DENSTRL_PHDEFID);
                    dgvPattern.Rows[dgvPattern.Rows.Count - 1].Tag = rowItem;
                    btnEdit.Enabled = true;
                    btnListDel.Enabled = true;
                    btnListAdd.Enabled = false;
                    ltvEdit.Items.Clear();
                    grpEdit.Enabled = false;
                    NewFlag = false;
                    grpOutput.Enabled = true;
                }
            }
        }

        /// <summary>
        /// パターン編集の削除ボタン押下時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnListDel_Click(object sender, EventArgs e)
        {
            if(isEditCheck())
            {
                if (MessageBox.Show("選択したパターンを削除します。よろしいですか？",
                                    Resources.QUESTION,
                                    MessageBoxButtons.YesNo,
                                    MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    RowItem rowItem = dgvPattern.Rows[0].Tag as RowItem;

                    this.logger.Info(string.Format("【論理パターン管理機能】パターン削除開始（{0},{1},{2}）",
                                                                                        rowItem.DENSTRL.DENSTRL_STRNO,
                                                                                        rowItem.DENSTRL.DENSTRL_INOUT,
                                                                                        rowItem.DENSTRL.DENSTRL_PHDEFID));

                    //更新日付の検定
                    T_DENSTRL check = this.version.context.T_DENSTRL.AsNoTracking().Where(r =>
                                                                                    r.DENSTRL_SUBSYSID == rowItem.DENSTRL.DENSTRL_SUBSYSID &&
                                                                                    r.DENSTRL_TELSUBSYSID == rowItem.DENSTRL.DENSTRL_TELSUBSYSID &&
                                                                                    r.DENSTRL_TELTYPE == rowItem.DENSTRL.DENSTRL_TELTYPE &&
                                                                                    r.DENSTRL_PATNO == rowItem.DENSTRL.DENSTRL_PATNO &&
                                                                                    r.DENSTRL_ORDER == rowItem.DENSTRL.DENSTRL_ORDER).SingleOrDefault();
                    if (check == null ||
                       check.DENSTRL_USERID != rowItem.DENSTRL.DENSTRL_USERID ||
                       check.DENSTRL_UPDTIME != rowItem.DENSTRL.DENSTRL_UPDTIME)
                    {
                        this.logger.Error(string.Format("編集中に別ユーザによって更新されましたので、更新できません。"));
                        MessageBox.Show("他ユーザが変更しています");
                        return;
                    }

                    List<T_PARSER> listParser = new List<T_PARSER>();
                    int count = 0;
                    try
                    {
                        count = this.version.context.T_DENSTRL.AsNoTracking().Where(r =>
                                                                                    r.DENSTRL_PHDEFID == rowItem.DENSTRL.DENSTRL_PHDEFID).Count();
                    }
                    catch (Exception　ex)
                    {
                        this.logger.Error(ex, string.Format("エラーが発生しました。"));
                        MessageBox.Show("エラーが発生しました。ログファイルを参照してください。");
                        return;
                    }
                    if (count == 1)
                    {
                        //Ｍパーサ変換情報テーブル も 削除対象とする
                        listParser = this.version.context.T_PARSER.AsNoTracking().Where(r =>
                                                                                r.PARSE_PHDEFID == rowItem.DENSTRL.DENSTRL_PHDEFID).ToList();
                    }

                    string sql = "DELETE FROM t_denstrl" +
                                    $" WHERE DENSTRL_SUBSYSID='{rowItem.DENSTRL.DENSTRL_SUBSYSID}' AND" +
                                            $" DENSTRL_TELSUBSYSID='{rowItem.DENSTRL.DENSTRL_TELSUBSYSID}' AND" +
                                            $" DENSTRL_TELTYPE='{rowItem.DENSTRL.DENSTRL_TELTYPE}' AND" +
                                            $" DENSTRL_PATNO='{rowItem.DENSTRL.DENSTRL_PATNO}' AND" +
                                            $" DENSTRL_ORDER={rowItem.DENSTRL.DENSTRL_ORDER}";
                    try
                    {
                        using (var tran = this.version.context.Database.BeginTransaction())
                        {
                            this.version.context.Database.ExecuteSqlCommand(sql);
                            foreach (T_PARSER parser in listParser)
                            {
                                sql = "DELETE FROM t_parser" +
                                        $" WHERE PARSE_PHDEFID='{rowItem.DENSTRL.DENSTRL_PHDEFID}'";
                                this.version.context.Database.ExecuteSqlCommand(sql);
                            }
                            tran.Commit();
                        }
                        this.logger.Info(string.Format("【論理パターン管理機能】パターン削除終了"));
                        MessageBox.Show("削除が完了しました。", Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        this.logger.Error(ex, string.Format("ＤＢの更新に失敗しました。(SQL={0})", sql));
                        this.logger.Info(string.Format("【論理パターン管理機能】パターン削除終了"));
                        MessageBox.Show("削除に失敗しました。ログを確認してください。", Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    ltvEdit.Items.Clear();
                    dgvPattern.Rows.Clear();
                    setList();
                    btnListDel.Enabled = false;
                    btnListAdd.Enabled = false;
                    btnEdit.Enabled = false;
                    isEdit = false;
                }
            }
        }

        /// <summary>
        /// パターン編集の編集ボタン押下時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEdit_Click(object sender, EventArgs e)
        {
            if(isEditCheck())
            {
                if (checkPattern())
                {
                    RowItem rowItem = dgvPattern.Rows[0].Tag as RowItem;
                    //同一パターンが無いか検定する
                    int rowIndex = searchList(rowItem);
                    foreach (DataGridViewRow row in dgvList.Rows)
                    {
                        if (rowIndex != row.Index)
                        {
                            if ((string)dgvPattern.Rows[0].Cells[4].Value == (string)row.Cells[4].Value && (string)dgvPattern.Rows[0].Cells[5].Value == (string)row.Cells[5].Value)
                            {
                                MessageBox.Show(string.Format("既に同一パターン（論理構成番号={0}, 入出力区分={1}）が存在します", 
                                                            row.Cells[4].Value as string, row.Cells[5].Value as string), Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                return;
                            }
                            else if ((string)dgvPattern.Rows[0].Cells[6].Value == (string)row.Cells[6].Value)
                            {
                                MessageBox.Show(string.Format("既にパーサ変換定義ＩＤ（パーサ変換定義ＩＤ={0}）が存在します",
                                                            row.Cells[6].Value as string), Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                return;
                            }
                        }
                    }

                    if(checkDouble((string)dgvPattern.Rows[0].Cells[6].Value, rowItem.DENSTRB) == false)
                    {
                        MessageBox.Show("該当パーサ変換定義ＩＤは既に使用されています。", Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    //一覧の該当パターンの内容を更新する
                    dgvList.Rows[rowIndex].Cells[4].Value = dgvPattern.Rows[0].Cells[4].Value as string;
                    dgvList.Rows[rowIndex].Cells[5].Value = dgvPattern.Rows[0].Cells[5].Value as string;
                    dgvList.Rows[rowIndex].Cells[6].Value = dgvPattern.Rows[0].Cells[6].Value as string;
                    dgvList.Rows[rowIndex].Selected = true;

                    grpEdit.Enabled = true;
                    grpList.Enabled = false;
                    grpPattern.Enabled = false;
                    grpOutput.Enabled = false;
                    btnUpdate.Enabled = true;
                    this.DENSTRB = rowItem.DENSTRB;

                    //物理－論理パーサ変換定義編集に設定する
                    setEdit();
                }
                else
                {
                    MessageBox.Show("パターン編集・論理情報の入力内容が誤っています。", Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private bool checkDouble(string PHDEFID, T_DENSTRB denstrb)
        {
            int Count = this.version.context.T_DENSTRL.AsNoTracking().Where(r => r.DENSTRL_PHDEFID == PHDEFID &&
                                                                                 ( r.DENSTRL_SUBSYSID != this.subsystem ||
                                                                                   r.DENSTRL_TELSUBSYSID != denstrb.DENSTRB_TELSUBSYSID ||
                                                                                   r.DENSTRL_TELTYPE != denstrb.DENSTRB_TELTYPE ||
                                                                                   r.DENSTRL_PATNO != denstrb.DENSTRB_PATNO)).Count();
            if (Count > 0) return false;
            return true;
        }

        /// <summary>
        /// …ボタン押下時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btRef_Click(object sender, EventArgs e)
        {
            TextBox textbox;
            if (sender == btRef)
            {
                textbox = txtOutput;
            }
            else
            {
                textbox = txtOutputMany;
            }

            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "格納場所を指定してください。";
            if(textbox.Text.Length > 0)
            {
                dialog.SelectedPath = textbox.Text.Trim();
            }
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                textbox.Text = dialog.SelectedPath;
            }
        }

        /// <summary>
        /// 【編集】出力ボタン押下時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSave_Click(object sender, EventArgs e)
        {
            if(dgvPattern.Rows.Count == 0)
            {
                MessageBox.Show("出力対象物がありません。", Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string ID = dgvPattern.Rows[0].Cells[6].Value as string;
            string ext = "txt";
            if (rdbCSV.Checked) ext = "csv";
            string file = Path.GetFullPath(string.Format("{0}\\{1}.{2}", txtOutput.Text.Trim(), ID, ext));
            RowItem rowItem = dgvPattern.Rows[0].Tag as RowItem;
            List<string> listStr = makeParserDef(this.subsystem, rowItem.DENSTRB, rowItem.DENSTRL);

            string msg = string.Empty;
            MessageBoxIcon errLevel = MessageBoxIcon.None;
            this.logger.Info(string.Format("【論理パターン管理機能】パーサ変換定義出力開始（File={0}）", file));
            try
            {
                WaitDialog.Show(this);
                try
                {
                    using (StreamWriter sw = new StreamWriter(file, false, Encoding.GetEncoding(System.Configuration.ConfigurationManager.AppSettings["Encoding"])))
                    {
                        foreach (string str in listStr)
                        {
                            sw.WriteLine(str);
                        }
                    }
                    this.logger.Info("ファイル出力に成功しました。");
                    msg = string.Format("{0}.{1}を出力しました。", ID, ext);
                    errLevel = MessageBoxIcon.Information;
                }
                catch (Exception ex)
                {
                    msg = "出力に失敗しました。ログファイルを確認してください";
                    errLevel = MessageBoxIcon.Error;
                    this.logger.Error(ex, string.Format("ファイル出力に失敗しました。（File={0}）", file));
                }
            }
            finally
            {
                WaitDialog.Close();
            }
            this.logger.Info("【論理パターン管理機能】パーサ変換定義出力終了");
            if(errLevel == MessageBoxIcon.Information)
            {
                MessageBox.Show(msg, Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (errLevel == MessageBoxIcon.Error)
            {
                MessageBox.Show(msg, Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 【出力】サブシステム変更
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmboutSubsys_SelectedIndexChanged(object sender, EventArgs e)
        {
            //検索結果をクリア
            dgvSearch.Rows.Clear();
            chkAll.Checked = false;
        }

        /// <summary>
        /// 検索ボタン押下時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            WaitDialog.Show(this);
            try
            {
                string PhysicSubsys = cmbPhysicSubsys.Text;
                string DefID = txtParserDefID.Text.Trim();

                dgvSearch.Rows.Clear();

                //入力内容に応じて検索する
                List<T_DENSTRL> listDENSTRL = null;
                if (string.IsNullOrEmpty(PhysicSubsys) && string.IsNullOrEmpty(DefID))
                {
                    listDENSTRL = this.version.context.T_DENSTRL.AsNoTracking().Where(r => r.DENSTRL_SUBSYSID == cmboutSubsys.Text).ToList();
                }
                else if (string.IsNullOrEmpty(PhysicSubsys) && !string.IsNullOrEmpty(DefID))
                {
                    listDENSTRL = this.version.context.T_DENSTRL.AsNoTracking().Where(r =>
                                                                                r.DENSTRL_SUBSYSID == cmboutSubsys.Text &&
                                                                                r.DENSTRL_PHDEFID.Contains(DefID)).ToList();
                }
                else if (!string.IsNullOrEmpty(PhysicSubsys) && string.IsNullOrEmpty(DefID))
                {
                    listDENSTRL = this.version.context.T_DENSTRL.AsNoTracking().Where(r =>
                                                                                r.DENSTRL_SUBSYSID == cmboutSubsys.Text &&
                                                                                r.DENSTRL_TELSUBSYSID == PhysicSubsys).ToList();
                }
                else
                {
                    listDENSTRL = this.version.context.T_DENSTRL.AsNoTracking().Where(r =>
                                                                                r.DENSTRL_SUBSYSID == cmboutSubsys.Text &&
                                                                                r.DENSTRL_TELSUBSYSID == PhysicSubsys &&
                                                                                r.DENSTRL_PHDEFID.Contains(DefID)).ToList();
                }

                //検索結果を設定
                foreach (T_DENSTRL denstrl in listDENSTRL)
                {
                    T_DENSTRB denstrb = this.version.context.T_DENSTRB.AsNoTracking().Where(r =>
                                                                                r.DENSTRB_SUBSYSID == denstrl.DENSTRL_SUBSYSID &&
                                                                                r.DENSTRB_TELSUBSYSID == denstrl.DENSTRL_TELSUBSYSID &&
                                                                                r.DENSTRB_TELTYPE == denstrl.DENSTRL_TELTYPE &&
                                                                                r.DENSTRB_PATNO == denstrl.DENSTRL_PATNO).SingleOrDefault();
                    RowItem rowItem = new RowItem
                    {
                        DENSTRL = denstrl,
                        DENSTRB = denstrb
                    };

                    string cmt = string.Empty;
                    if (denstrb.DENSTRB_COMMENT != null) cmt = denstrb.DENSTRB_COMMENT;
                    //初期値はチェックＯＦＦ（0）
                    dgvSearch.Rows.Add("0", cmt, denstrl.DENSTRL_TELSUBSYSID, denstrl.DENSTRL_TELTYPE, denstrl.DENSTRL_PATNO, denstrl.DENSTRL_STRNO, denstrl.DENSTRL_INOUT, denstrl.DENSTRL_PHDEFID);
                    dgvSearch.Rows[dgvSearch.Rows.Count - 1].Tag = rowItem;
                }
            }
            finally
            {
                WaitDialog.Close();
            }
        }

        /// <summary>
        /// 格納場所の内容が変更された時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtOutput_TextChanged(object sender, EventArgs e)
        {
            TextBox textbox = null;
            Button button = null;

            if(sender == txtOutput)
            {
                textbox = txtOutput;
                button = btnSave;
            }
            else
            {
                textbox = txtOutputMany;
                button = btnSaveMany;
            }

            //存在するディレクトリの場合は出力ボタンを有効にする
            string dir = textbox.Text.Trim();
            if(Directory.Exists(dir))
            {
                if(sender == txtOutputMany)
                {
                    if(this.ManyOutCheck)
                    {
                        button.Enabled = true;
                    }
                    else
                    {
                        button.Enabled = false;
                    }
                }
                else
                {
                    button.Enabled = true;
                }
            }
            else
            {
                button.Enabled = false;
            }

        }

        /// <summary>
        /// 【出力】出力ボタン押下時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSaveMany_Click(object sender, EventArgs e)
        {
            string msg = string.Empty;
            WaitDialog.Show(this);
            try
            {
                string ext = "csv";
                List<string> listOutFile = new List<string>();
                List<string> listErrorFile = new List<string>();
                StringBuilder sb = new StringBuilder();
                string file = string.Empty;

                if (rdbTXTMany.Checked) ext = "txt";
                List<string> listStr = makeParserPattern(cmboutSubsys.Text);

                // パーサ変換パターン定義の出力を行う
                if (chkPatternDef.Checked)
                {
                    this.logger.Info("【論理パターン管理機能】パーサ変換パターン定義出力開始");
                    try
                    {
                        file = Path.GetFullPath(string.Format("{0}\\{1}.{2}",
                                                                        txtOutputMany.Text.Trim(),
                                                                        "DPCSMPPT",
                                                                        ext));
                        using (StreamWriter sw = new StreamWriter(file, false, Encoding.GetEncoding(System.Configuration.ConfigurationManager.AppSettings["Encoding"])))
                        {
                            foreach (string str in listStr)
                            {
                                sw.WriteLine(str);
                            }
                        }
                        this.logger.Info(string.Format("ファイル出力に成功しました。（File={0}）", file));
                        listOutFile.Add(string.Format("{0}.{1}", "DPCSMPPT", ext));
                    }
                    catch (Exception ex)
                    {
                        this.logger.Error(ex, string.Format("ファイル出力に失敗しました。（File={0}）", file));
                        listErrorFile.Add(string.Format("{0}.{1}", "DPCSMPPT", ext));
                    }
                }

                // チェックしてあるパーサ変換定義を出力する
                this.logger.Info("【論理パターン管理機能】パーサ変換定義出力開始");

                foreach (DataGridViewRow row in dgvSearch.Rows)
                {
                    if ((string)row.Cells[0].Value == "1")
                    {
                        string ID = (string)row.Cells[7].Value;
                        file = Path.GetFullPath(string.Format("{0}\\{1}.{2}",
                                                                    txtOutputMany.Text.Trim(),
                                                                    ID,
                                                                    ext));
                        RowItem rowItem = (RowItem)row.Tag;
                        listStr = makeParserDef(cmboutSubsys.Text, rowItem.DENSTRB, rowItem.DENSTRL);

                        try
                        {
                            using (StreamWriter sw = new StreamWriter(file, false, Encoding.GetEncoding(System.Configuration.ConfigurationManager.AppSettings["Encoding"])))
                            {
                                foreach (string str in listStr)
                                {
                                    sw.WriteLine(str);
                                }
                            }
                            this.logger.Info(string.Format("ファイル出力に成功しました。（File={0}）", file));
                            listOutFile.Add(string.Format("{0}.{1}", ID, ext));
                        }
                        catch (Exception ex)
                        {
                            this.logger.Error(ex, string.Format("ファイル出力に失敗しました。（File={0}）", file));
                            listErrorFile.Add(string.Format("{0}.{1}", ID, ext));
                        }
                    }
                }
                int count = 0;
                if (listOutFile.Count > 0)
                {
                    sb.Append("出力が完了しました\r\n--------\r\n");
                    foreach (string s in listOutFile)
                    {
                        if (count > 5)
                        {
                            sb.Append(" :\r\n");
                            break;
                        }
                        sb.Append(s);
                        sb.Append("\r\n");
                        count++;
                    }
                    sb.Append(string.Format("--------\r\n>> 全 {0}本\r\n\r\n", listOutFile.Count));
                }

                if (listErrorFile.Count > 0)
                {
                    sb.Append("出力に失敗しました\r\n--------\r\n");
                    foreach (string s in listErrorFile)
                    {
                        if (count > 5)
                        {
                            sb.Append(" :\r\n");
                            break;
                        }
                        sb.Append(s);
                        sb.Append("\r\n");
                        count++;
                    }
                    sb.Append(string.Format("--------\r\n>> 全 {0}本\r\n", listErrorFile.Count));
                }
                this.logger.Info("【論理パターン管理機能】パーサ変換定義出力終了（成功={0}本、失敗={1}本）", listOutFile.Count, listErrorFile.Count);
                msg = sb.ToString();
            }
            finally
            {
                WaitDialog.Close();
            }
            MessageBox.Show(msg, "出力結果", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /// <summary>
        /// 並び替え元
        /// </summary>
        int sourceIndex = -1;

        #region 順序の入れ替え
        private void dgvList_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            sourceIndex = e.RowIndex;   // マウスが押された行を移動対象とする
        }

        private void dgvList_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            int rowIndex;
            if (e.RowIndex == -1)
            {
                rowIndex = 0;
            }
            else
            {
                rowIndex = e.RowIndex;
            }
            if(this.sourceIndex >= 0)
            {
                // 移動
                if(this.sourceIndex != rowIndex)
                {
                    DataGridViewRow tmp = dgvList.Rows[this.sourceIndex];
                    dgvList.Rows.RemoveAt(this.sourceIndex);
                    dgvList.Rows.Insert(rowIndex, tmp);
                    dgvList.Rows[rowIndex].Selected = true;
                    btnUpdate.Enabled = true;
                }
            }
            this.sourceIndex = -1;
        }
        #endregion

        private void chkPatternDef_CheckedChanged(object sender, EventArgs e)
        {
            // 何れかがチェックされていたら、出力を有効にする
            bool check = false;
            foreach (DataGridViewRow row in dgvSearch.Rows)
            {
                if ((string)row.Cells[0].Value == "1")
                {
                    check = true;
                    break;
                }
            }

            ManyOutCheck = chkPatternDef.Checked || check;
            if (Directory.Exists(txtOutputMany.Text) && ManyOutCheck)
            {
                btnSaveMany.Enabled = true;
            }
            else
            {
                btnSaveMany.Enabled = false;
            }
        }
    }
}
