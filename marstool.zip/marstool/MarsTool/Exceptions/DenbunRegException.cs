﻿//------------------------------------------------------------------
// All Rights Reserved. Copyright (C) 2018, Hitachi Solutions, Ltd.
//------------------------------------------------------------------
using System;

namespace MarsTool.Exceptions
{
    /// <summary>
    /// DenbunRegException Class<br/>
    /// DenbunRegException　クラス<br/>
    /// </summary>
    /// <remarks>
    /// 2018/03/15 新規作成<br/>
    /// </remarks>
    class DenbunRegException : Exception
    {
        string ErrorMessage { get; set; }

        #region public method

        /// <summary>
        /// Initializes a new instance of the DenbunRegExceptions class<br/>
        /// 設定条件例外クラスの新インスタンスの初期化<br/>
        /// </summary>
        /// <param name="message">
        /// Exception message - 例外メッセージ<br/>
        /// </param>
        /// <remarks>
        /// 2018/03/15 新規作成<br/>
        /// </remarks>
        public DenbunRegException(string message)
            : base(message)
        {
            this.ErrorMessage = message;
        }

        /// <summary>
        /// Initializes a new instance of the DenbunRegExceptions class<br/>
        /// 設定条件例外クラスの新インスタンスの初期化<br/>
        /// </summary>
        /// <param name="message">
        /// Exception message <br/>
        /// 例外メッセージ<br/>
        /// </param>
        /// <param name="exp">
        /// Inner Exception<br/>
        /// 内部例外<br/>
        /// </param>
        /// <remarks>
        /// 2018/03/15 新規作成<br/>
        /// </remarks>
        public DenbunRegException(string message, Exception exp)
            : base(message, exp)
        {
            this.ErrorMessage = message;
        }

        /// <summary>
        /// To Get Error Code.<br/>
        /// エラーコードを取得<br/>
        /// </summary>
        /// <returns>
        /// Exception code<br/>
        /// 例外コード<br/>
        /// </returns>
        /// <remarks>
        /// 2018/03/15 新規作成<br/>
        /// </remarks>
        public int GetErrorCode()
        {
            return this.HResult;
        }

        /// <summary>
        /// To get error message.<br/>
        /// エラーメッセージを取得<br/>
        /// </summary>
        /// <returns>
        /// Exception message<br/>
        /// 例外メッセージ<br/>
        /// </returns>
        /// <remarks>
        /// 2018/03/15 新規作成<br/>
        /// </remarks>
        public string GetMessage()
        {
            return this.ErrorMessage;
        }
    }

    #endregion
}
