﻿using MarsTool.Properties;
using System;

namespace MarsTool.Exceptions
{
    class ExclusiveException : Exception
    {
        /// <summary>
        /// 排他例外クラス
        /// </summary>
        public ExclusiveException() : base(Resources.EXCLUSIVE) { }
    }
}
