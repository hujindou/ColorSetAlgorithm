﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsTool.Exceptions
{
    class PhysicalLogicalMappingException : Exception
    {
        string ErrorMessage { get; set; }

        /// <summary>
        /// Initializes a new instance of the PhysicalLogicalMappingException class<br/>
        /// 物理論理マッピング例外クラスの新インスタンスを初期化<br/>
        /// </summary>
        /// <param name="message">
        /// Exception message - 例外メッセージ<br/>
        /// </param>
        /// <remarks>
        /// 2018/03/05 新規作成<br/>
        /// </remarks>
        public PhysicalLogicalMappingException(string message)
            : base(message)
        {
            this.ErrorMessage = message;
        }

        /// <summary>
        /// Initializes a new instance of the PhysicalLogicalMappingException class<br/>
        /// 物理論理マッピング例外クラスの新インスタンスを初期化<br/>
        /// </summary>
        /// <param name="message">
        /// Exception message <br/>
        /// 例外メッセージ<br/>
        /// </param>
        /// <param name="exp">
        /// Inner Exception<br/>
        /// </param>
        /// <remarks>
        /// 2018/03/05 新規作成<br/>
        /// </remarks>
        public PhysicalLogicalMappingException(string message, Exception exp)
            : base(message, exp)
        {
            this.ErrorMessage = message;
        }

        /// <summary>
        /// To Get Error Code.<br/>
        /// エラーを取得<br/>
        /// </summary>
        /// <returns>
        /// Exception code<br/>
        /// 例外コード<br/>
        /// </returns>
        /// <remarks>
        /// 2018/03/05 新規作成<br/>
        /// </remarks>
        public int GetErrorCode()
        {
            return this.HResult;
        }

        /// <summary>
        /// To get error message.<br/>
        /// エラーメッセージを取得<br/>
        /// </summary>
        /// <returns>
        /// Exception message<br/>
        /// 例外メッセージ<br/>
        /// </returns>
        /// <remarks>
        /// 2018/03/05 新規作成<br/>
        /// </remarks>
        public string GetMessage()
        {
            return this.ErrorMessage;
        }
    }
}
