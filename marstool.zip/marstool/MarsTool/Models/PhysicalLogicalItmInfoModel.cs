﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsTool.Models
{
    class PhysicalLogicalItmInfoModel
    {
        private string phyitm_itemflag;
        private string phyitm_dtlen;

        public Int64 Phyitm_seq { get; set; }

        public string Phyitm_itemnm { get; set; }

        public string Phyitm_dttype { get; set; }

        public string Phyitm_dtlen
        {
            get { return phyitm_dtlen; }
            set
            {
                if (phyitm_itemflag.Equals("1"))
                {
                    phyitm_dtlen = "(" + value + ")";
                }
                else
                {
                    phyitm_dtlen = value;
                }
            }
        }

        public string Phyitm_occurs { get; set; }

        public string Phyitm_itemflag
        {
            get { return phyitm_itemflag; }
            set { phyitm_itemflag = value; }
        }

        public PhysicalLogicalOperationModel logicalOperation { get; set; }

        public List<string> logicalOperationIDList { get; set; }
    }
}
