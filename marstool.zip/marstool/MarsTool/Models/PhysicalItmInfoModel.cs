﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsTool.Models
{
    class PhysicalItmInfoModel
    {
        private string phyitm_level;
        public Int64 Phyitm_seq { get; set; }

        public string Phyitm_level
        {
            get { return phyitm_level; }
            set
            {
                phyitm_level = (!string.IsNullOrEmpty(value) && value.Length < 2) ? "0" + value : value;
            }
        }

        public string Phyitm_itemnm { get; set; }

        public LogicalOperationModel logicalOperation { get; set; }

        public List<LogicalOperationModel> logicalOperationList { get; set; }
    }
}
