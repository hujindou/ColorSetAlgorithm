namespace MarsTool.Models.DB
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class T_RDTITEM
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(4)]
        public string RDTITM_SUBSYSID { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(10)]
        public string RDTITM_TABLEID { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(1)]
        public string RDTITM_INFTYPE { get; set; }

        [Key]
        [Column(Order = 3)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int RDTITM_ENTNO { get; set; }

        [Key]
        [Column(Order = 4)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int RDTITM_ITEMNO { get; set; }

        [Required]
        [StringLength(100)]
        public string RDTITM_ITEMNM { get; set; }

        [Required]
        [StringLength(6)]
        public string RDTITM_DATATYPE { get; set; }

        public int RDTITM_SIZE { get; set; }

        [StringLength(100)]
        public string RDTITM_DATA { get; set; }

        [StringLength(10)]
        public string RDTITM_CHKTYPE { get; set; }

        [StringLength(100)]
        public string RDTITM_COMMENT { get; set; }
    }
}
