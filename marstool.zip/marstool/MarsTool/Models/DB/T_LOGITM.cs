﻿namespace MarsTool.Models.DB
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class T_LOGITM
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(4)]
        [Required]
        public string LOGITM_SUBSYSIDL { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(10)]
        [Required]
        public string LOGITM_LCPID { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(18)]
        [Required]
        public string LOGITM_SEQ { get; set; }

        [StringLength(6)]
        public string LOGITM_TYPE { get; set; }

        public int? LOGITM_DATALEN { get; set; }

        [StringLength(60)]
        public string LOGITM_PREFIX { get; set; }

        [StringLength(60)]
        public string LOGITM_DTTYPE { get; set; }

        [StringLength(1)]
        public string LOGITM_MCODE { get; set; }
    }
}
