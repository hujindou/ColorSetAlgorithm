﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsTool.Models.DB
{
    class T_ITEMCHG
    {

        public string TMITEMCHG_CPATTR { get; set; }

        public string TMITEMCHG_CPSIZE { get; set; }

        public string TMITEMCHG_ITEMATTR { get; set; }

        public int TMITEMCHG_ITEMSIZE { get; set; }

        public int TMITEMCHG_COMP { get; set; }
      
    }
}