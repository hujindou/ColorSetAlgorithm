namespace MarsTool.Models.DB
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class T_JNLPT
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [StringLength(18)]
        public string JNL_PATTERNID { get; set; }

        [StringLength(16)]
        public string JNL_PATTERNNO { get; set; }

        [StringLength(16)]
        public string JNL_CUPID { get; set; }

        [StringLength(6)]
        public string JNL_SUBORDER { get; set; }

        [StringLength(256)]
        public string JNL_TYPE { get; set; }

        [StringLength(2048)]
        public string JNL_OPTYPE { get; set; }

        [StringLength(16)]
        public string JNL_ANS { get; set; }

        [StringLength(2048)]
        public string JNL_COMMNENT { get; set; }

        public int JNL_ENABLEFLG { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public DateTime? JNL_UPDTIME { get; set; }

        [ForeignKey("JNL_PATTERNID")]
        public virtual ICollection<T_JNLSEGS> JNL_INFOBLOCKS { get; set; }

        public string JNL_USERID { get; set; }

        [Column("JNL_HASH")]
        public string JNL_KEY { get; set; }

        public static implicit operator T_JNLPT(Models.ViewPattern v)
        {
            T_JNLPT res = new T_JNLPT();
            res.JNL_ANS = v.JN_ANS;
            res.JNL_COMMNENT = v.JN_COMMNENT;
            res.JNL_CUPID = v.JN_CUPID;
            res.JNL_OPTYPE = v.JN_OPTYPE;
            res.JNL_PATTERNNO = v.JN_PATTERNNO;
            res.JNL_TYPE = v.JN_TYPE;
            res.JNL_PATTERNID = v.JN_PATTERNID;
            res.JNL_SUBORDER = v.JN_SUBORDER;
            res.JNL_ENABLEFLG = v.Enabled;
            res.JNL_INFOBLOCKS = new List<T_JNLSEGS>();
            res.JNL_USERID = v.USERID;
            int i = 0;
            string key = "";
            foreach (var xx in v.JN_INFOBLOCKS)
            {
                i++;
                //
                xx.JN_PATTERNID = v.JN_PATTERNID;
                T_JNLSEGS yy = xx;
                //���Ԃ�����
                yy.JNL_ORDER = i;
                res.JNL_INFOBLOCKS.Add(yy);
                key += xx.JN_INTERFACEID;
            }

            System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create();
            byte[] barr = System.Text.Encoding.UTF8.GetBytes(key);

            byte[] h = md5.ComputeHash(barr);

            for (int j = 0; j < h.Length; j++)
            {
                res.JNL_KEY += h[j].ToString("X2");
            }

            return res;
        }
    }
}
