namespace MarsTool.Models.DB
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class T_CPYPHY
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(4)]
        [Required]
        public string CPYPHY_SUBSYSID { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(20)]
        [Required]
        public string CPYPHY_INFOID { get; set; }

        [StringLength(60)]
        [Required]
        public string CPYPHY_BCPNM { get; set; }

        [StringLength(10)]
        public string CPYPHY_BCPID { get; set; }

        public int CPYPHY_SIZE { get; set; }
        public int? CPYPHY_LEVNO { get; set; }

        [StringLength(4096)]
        public string CPYPHY_COMMENT { get; set; }

        [StringLength(1)]
        public string CPYPHY_STATUS { get; set; }

        [StringLength(7)]
        public string CPYPHY_USERID { get; set; }


        public DateTime? CPYPHY_UPDTIME { get; set; }


    }
}
