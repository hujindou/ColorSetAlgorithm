﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MarsTool.Models.DB;

namespace MarsTool.Models.DB
{
    /// <summary>
    /// 
    /// </summary>
    class PhysicalCopyKuInfo
    {
        //サブシステムID
        [StringLength(4, ErrorMessage = "物理サブシステムIDが4桁以上になっています。")]
        public string CPYPHY_SubSysId { get; set; }

        //情報部ID
        [StringLength(20, ErrorMessage = "情報部IDが20桁以上になっています。")]
        public string CPYPHY_InfoId { get; set; }

        //コピー句ID
        [StringLength(10, ErrorMessage = "コピー句IDが10桁以上になっています。")]
        public string CPYPHY_BcpId { get; set; }

        //コピー句名
        [StringLength(60, ErrorMessage = "コピー句名が60桁以上になっています。")]
        public string CPYPHY_BcpNm { get; set; }

        //コピー句サイズ        
        public int CPYPHY_Size { get; set; }       

        //コピー句のコメント
        [StringLength(4096, ErrorMessage = "コピー句コメントが4096桁以上になっています。")]
        public string CPYPHY_Comment { get; set; }

        //更新ユーザID
        public string CPYPHY_UserId { get; set; }

        //更新時刻
        public string CPYPHY_UPDTIME { get; set; }

        //コピー句開始レベル番号
        public int CPYPHY_LEVNO { get; set; }

        //削除フラグ
        public string CPYPHY_STATUS { get; set; }

        //物理アイテム情報一覧
        [NotMapped]
        public List<PhysicalCopyKuItemInfo> phyCpyItemInfoList { get; set; }

        //設定条件情報一覧
        [NotMapped]
        public List<SettingConditionInfo> setCondList { get; set; }

        //論理コピー句情報一覧
        [NotMapped]
        public List<LogicalCopyKuInfo> logicalHeaderInfos { get; set; }

        //Mパーサ情報一覧
        [NotMapped]
        public List<T_PHYPRS> mParserInfoList { get; set; }

        public bool checkDatalengthData()
        {
            var validator = new ValidationContext(this, null, null);
            var valres = new List<ValidationResult>();
            bool isVal = Validator.TryValidateObject(this, validator, valres, true);

            return isVal;
        }
    }
}
