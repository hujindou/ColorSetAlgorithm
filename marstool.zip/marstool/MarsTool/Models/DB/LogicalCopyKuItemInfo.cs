﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsTool.Models.DB
{
    class LogicalCopyKuItemInfo
    {

        //サブシステムID        
        public string LOGITM_SUBSYSIDL { get; set; }

        //論理コピー句ID        
        public string LOGITM_LCPID { get; set; }

        public string LOGITM_SEQ { get; set; }

        //論理属性
        [StringLength(6, ErrorMessage = "論理属性が6桁以上になっています。")]
        public string LOGITM_TYPE { get; set; }

        //論理サイズ        
        public int LOGITM_DATALEN { get; set; }

        //コピー句Ｐｒｅｆｉｘ
        [StringLength(60, ErrorMessage = "コピー句Ｐｒｅｆｉｘが60桁以上になっています。")]
        public string LOGITM_PREFIX { get; set; }

        //コピー句データ形式
        [StringLength(60, ErrorMessage = "コピー句データ形式が60桁以上になっています。")]
        public string LOGITM_DTTYPE { get; set; }

        //文字コード
        public string LOGITM_MCODE { get; set; }

        //物理項目項番
        [NotMapped]
        public int PHYITM_ItemNo { get; set; }

        //物理項目パス
        [NotMapped]
        public string PHYITM_Path { get; set; }

        //物理項目
        [NotMapped]
        public string PHYITM_ItemName { get; set; }

        public bool checkDatalengthData()
        {
            var validator = new ValidationContext(this, null, null);
            var valres = new List<ValidationResult>();
            bool isVal = Validator.TryValidateObject(this, validator, valres, true);

            return isVal;
        }
    }
}