﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsTool.Models.DB
{
    class LogicalCopyKuInfo
    {
        //物理コピー句ID       
        public string CPYLGC_PHYSYSID { get; set; }

        //サブシステムID
        [StringLength(4, ErrorMessage = "論理サブシステムIDが4桁以上になっています。")]
        public string CPYLGC_SUBSYSID { get; set; }

        //情報部ID        
        public string CPYLGC_INFOID { get; set; }

        //論理コピー句ID
        [StringLength(10, ErrorMessage = "論理コピー句IDが10桁以上になっています。")]
        public string CPYLGC_LCPID { get; set; }

        //論理コピー句の出力順序
        public int CPYLGC_OUTPUTORDER { get; set; }

        //論理コピー句操作名
        [StringLength(10, ErrorMessage = "論理コピー句操作名が10桁以上になっています。")]
        public string CPYLGC_OPNM { get; set; }

        //論理コピー句開始レベル番号
        public int CPYLGC_LEVNO { get; set; }

        //コピー句コメント        
        public string CPYLGC_COMMENT { get; set; }

        //更新ユーザＩＤ
        public string CPYLGC_USERID { get; set; }

        //サブシステムID
        public string CPYLGC_UPDTIME { get; set; }

        //更新日時
        public int LOGITM_COL { get; set; }

        //論理アイテム情報一覧
        [NotMapped]
        public List<LogicalCopyKuItemInfo> logCpyItemInfoList { get; set; }

        public bool checkDatalengthData()
        {
            var validator = new ValidationContext(this, null, null);
            var valres = new List<ValidationResult>();
            bool isVal = Validator.TryValidateObject(this, validator, valres, true);

            return isVal;
        }
    }
}
