﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsTool.Models.DB
{
    class T_PHYPRS
    {

        // 物理サブシステムＩＤ
        public string PHYPRS_PHYSYSID { get; set; }

        // 情報部ＩＤ
        public string PHYPRS_INFOID { get; set; }

        // サブシステムＩＤ
        [StringLength(4, ErrorMessage = "論理サブシステム名が4桁以上になっています。")]
        public string PHYPRS_SUBSYSID { get; set; }

        // 物理ＩＤ
        [StringLength(15, ErrorMessage = "物理ＩＤが15桁以上になっています。")]
        public string PHYPRS_PHYID { get; set; }

        // レイアウト定義
        [StringLength(16, ErrorMessage = "レイアウト定義が16桁以上になっています。")]
        public string PHYPRS_LAYDEF { get; set; }

        // シーケンス
        public string PHYPRS_SEQ { get; set; }

        // 物理タグ名
        [StringLength(60, ErrorMessage = "物理タグ名が60桁以上になっています。")]
        public string PHYPRS_TAGNM { get; set; }

        // 物理属性
        [StringLength(6, ErrorMessage = "物理属性が6桁以上になっています。")]
        public string PHYPRS_LTYPE { get; set; }

        // コード変換要
        public string PHYPRS_CDCHG { get; set; }

        // 符号有無
        public string PHYPRS_FLG { get; set; }

        //文字コード
        public string PHYPRS_MCODE { get; set; }

        //PHYPRS_USERID
        public string PHYPRS_USERID { get; set; }

        //PHYPRS_UPDTIME
        public string PHYPRS_UPDTIME { get; set; }

        //物理アイテムのパス
        [NotMapped]
        public string PHYITM_PATH { get; set; }

        //物理項目項番
        [NotMapped]
        public int PHYITM_ITEMNO { get; set; }

        public bool checkDatalengthData()
        {
            var validator = new ValidationContext(this, null, null);
            var valres = new List<ValidationResult>();
            bool isVal = Validator.TryValidateObject(this, validator, valres, true);

            return isVal;
        }
    }
}