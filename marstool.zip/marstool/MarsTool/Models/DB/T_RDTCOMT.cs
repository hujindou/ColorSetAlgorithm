namespace MarsTool.Models.DB
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class T_RDTCOMT
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(4)]
        public string RDTCOMT_SUBSYSID { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(10)]
        public string RDTCOMT_TABLEID { get; set; }

        [Key]
        [Column(Order = 2)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int RDTCOMT_ENTNO { get; set; }

        [Key]
        [Column(Order = 3)]
        [StringLength(100)]
        public string RDTCOMT_COMT { get; set; }

        [Required]
        public int RDTCOMT_ORDER { get; set; }

        [StringLength(1)]
        public string RDTCOMT_COMTFLG { get; set; }
    }
}
