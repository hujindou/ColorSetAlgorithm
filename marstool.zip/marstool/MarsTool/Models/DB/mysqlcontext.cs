﻿using MySql.Data.EntityFramework;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsTool.Models.DB
{
    [DbConfigurationType(typeof(MySqlEFConfiguration))]
    public class mysqlcontext : DbContext
    {

        public mysqlcontext(string connectionstring)
            : base(connectionstring)
        {
            Database.SetInitializer<mysqlcontext>(null);
        }

        /// <summary>
        /// ジャーナルパターン
        /// </summary>
        public virtual DbSet<T_JNLPT> T_JNPT { get; set; }

        /// <summary>
        /// ジャーナル情報部
        /// </summary>
        public virtual DbSet<T_JNLSEGS> T_JNSEGS { get; set; }

        /// <summary>
        /// view
        /// </summary>
        public virtual DbSet<V_JNLSEGS> V_JNSEGS { get; set; }

        /// <summary>
        /// ユーザーテーブル
        /// </summary>
        public virtual DbSet<T_USER> T_USERS { get; set; }

        /// <summary>
        /// view
        /// </summary>
        public virtual DbSet<V_JNLPT> V_JNPT { get; set; }

        /// <summary>
        /// 候補値テーブル
        /// </summary>
        public virtual DbSet<T_KOHO> T_KOHO { get; set; }

        /// <summary>
        /// 物理アイテム情報テーブル
        /// </summary>
        public virtual DbSet<T_PHYITM> T_PHYITM { get; set; }

        /// <summary>
        /// 物理アイテム情報テーブル
        /// </summary>
        public virtual DbSet<T_CPYPHY> T_CPYPHY { get; set; }

        /// <summary>
        /// 論理設定条件情報
        /// </summary>
        public virtual DbSet<T_CONDITION> T_CONDITION { get; set; }

        /// <summary>
        /// 物理Ｍパーサ情報
        /// </summary>
        public virtual DbSet<T_PHYPRS_EF> T_PHYPRS { get; set; }

        /// <summary>
        /// 論理コピー句情報
        /// </summary>
        public virtual DbSet<T_CPYLOG> T_CPYLOG { get; set; }

        /// <summary>
        /// 論理アイテム情報
        /// </summary>
        public virtual DbSet<T_LOGITM> T_LOGITM { get; set; }

        /// <summary>
        /// ＲＤＡＴＡ共通情報テーブル
        /// </summary>
        public virtual DbSet<T_RDATA> T_RDATA { get; set; }

        /// <summary>
        /// ＲＤＡＴＡ情報部テーブル
        /// </summary>
        public virtual DbSet<T_RDTINF> T_RDTINF { get; set; }

        /// <summary>
        /// ＲＤＡＴＡ改修コメントテーブル
        /// </summary>
        public virtual DbSet<T_RDTCOMT> T_RDTCOMT { get; set; }

        /// <summary>
        /// ＲＤＡＴＡ項目情報テーブル
        /// </summary>
        public virtual DbSet<T_RDTITEM> T_RDTITEM { get; set; }

        /// <summary>
        /// 電文構成パターン物理情報テーブル
        /// </summary>
        public virtual DbSet<T_DENSTRB> T_DENSTRB { get; set; }   

        /// <summary>
        /// 電文構成パターン物理アイテム情報テーブル
        /// </summary>
        public virtual DbSet<T_DENSTRBITM> T_DENSTRBITM { get; set; }

        /// <summary>
        /// Ｍパーサ変換情報テーブル
        /// </summary>
        public virtual DbSet<T_PARSER> T_PARSER { get; set; }

        /// <summary>
        /// 電文構成パターン論理情報テーブル
        /// </summary>
        public virtual DbSet<T_DENSTRL> T_DENSTRL { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<V_JNLPT>().HasMany<V_JNLSEGS>(e => e.JNL_INFOBLOCKS);
            modelBuilder.Entity<T_JNLPT>().HasMany<T_JNLSEGS>(e => e.JNL_INFOBLOCKS);
        }
    }
}
