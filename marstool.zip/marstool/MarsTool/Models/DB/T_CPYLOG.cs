﻿namespace MarsTool.Models.DB
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class T_CPYLOG
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(4)]
        [Required]
        public string CPYLGC_PHYSYSID { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(20)]
        [Required]
        public string CPYLGC_INFOID { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(4)]
        [Required]
        public string CPYLGC_SUBSYSID { get; set; }

        [Key]
        [Column(Order = 3)]
        [StringLength(10)]
        [Required]
        public string CPYLGC_LCPID { get; set; }

        [StringLength(10)]
        public string CPYLGC_OPNM { get; set; }

        public int? CPYLGC_OUTPUTORDER { get; set; }

        public int? CPYLGC_LEVNO { get; set; }

        [StringLength(4096)]
        public string CPYLGC_COMMENT { get; set; }

        [StringLength(7)]
        public string CPYLGC_USERID { get; set; }

        public DateTime? CPYLGC_UPDTIME { get; set; }

    }
}
