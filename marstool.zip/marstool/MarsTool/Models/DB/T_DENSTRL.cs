﻿namespace MarsTool.Models.DB
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class T_DENSTRL
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(4)]
        public string DENSTRL_SUBSYSID { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(4)]
        public string DENSTRL_TELSUBSYSID { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(1)]
        public string DENSTRL_TELTYPE { get; set; }

        [Key]
        [Column(Order = 3)]
        [StringLength(10)]
        public string DENSTRL_PATNO { get; set; }

        [Key]
        [Column(Order = 4)]
        public int DENSTRL_ORDER { get; set; }

        [StringLength(4)]
        public string DENSTRL_STRNO { get; set; }

        [StringLength(1)]
        public string DENSTRL_INOUT { get; set; }

        [StringLength(8)]
        public string DENSTRL_PHDEFID { get; set; }

        [StringLength(7)]
        public string DENSTRL_USERID { get; set; }

        public DateTime? DENSTRL_UPDTIME { get; set; }
    }
}
