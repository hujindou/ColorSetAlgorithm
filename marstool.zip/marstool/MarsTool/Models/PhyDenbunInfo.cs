﻿namespace MarsTool.Models
{
    using System;
    using System.Collections.Generic;

    public partial class PhyDenbunInfo
    {
        public int order { get; set; }

        public string subSysID { get; set; }
        
        public string telSubSysID { get; set; }
        
        public string telType { get; set; }
        
        public string patNo { get; set; }
        
        public string groupID { get; set; }
        
        public string comment { get; set; }
        
        public string userID { get; set; }
        
        public DateTime updateTime { get; set; }

        public List<PhyDenbunItmInfo> itemInfos { get; set; }
    }
}
