﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MarsTool.Models.DB;

namespace MarsTool.Models
{
    public class VersionModel
    {
        /// <summary>
        /// 世代名称
        /// </summary>
        public string Vername { get; set; }

        /// <summary>
        /// DBサーバー名、或いはDBサーバーIP
        /// </summary>
        public string Hostname { get; set; }

        /// <summary>
        /// DB名
        /// </summary>
        public string DBName { get; set; }

        /// <summary>
        /// DBにアクセスするユーザー名
        /// </summary>
        public string DBUser { get; set; }

        /// <summary>
        /// DBにアクセスするユーザーのパスワード
        /// </summary>
        public string DBPassword { get; set; }

        /// <summary>
        /// サーバーのPort Number
        /// </summary>
        public string Port { get; set; }

        /// <summary>
        /// 現在世代の日付
        /// YYYYMMDD形
        /// </summary>
        public string VersionDate { get; set; }

        private DB.mysqlcontext ctx = null;
        private DB.T_USER user = null;

        //世代管理辞典
        private Dictionary<string, List<string>> pridic;

        public void setDBContext(DB.mysqlcontext p, DB.T_USER p2, Dictionary<string, List<string>> lst)
        {
            ctx = p;
            user = p2;
            pridic = lst;
        }

        /// <summary>
        /// 当サブシステムへの編集権限を持つかの判断
        /// </summary>
        /// <returns>
        /// 「false」読みだけ、「true」は読み、編集権限を持つ
        /// </returns>
        public bool hasSubsysModifyPrivilege(string subsysid)
        {
            if (user == null)
                return false;

            if (pridic != null && pridic.ContainsKey(user.GRP) && pridic[user.GRP].Any(r => r.Contains((subsysid + "").Trim().ToUpper())))
                return true;

            return false;
        }

        /// <summary>
        /// ＤＢの採番関数を使って、採番する
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public string genSequenceID(string keyWord)
        {
            if (String.IsNullOrWhiteSpace(keyWord) || keyWord.Length > 20)
                throw new Exception("Keyの長さは１～２０桁");
            string res = null;
            MySql.Data.MySqlClient.MySqlParameter p1 = new MySql.Data.MySqlClient.MySqlParameter("@p1", MySql.Data.MySqlClient.MySqlDbType.VarChar);
            p1.Value = keyWord;

            var res1 = context.Database.SqlQuery<int>("select TMSEQ_CURVAL from t_tmseque where TMSEQ_NAME = @p1", p1).FirstOrDefault();

            if (res1 == 0)
            {
                context.Database.ExecuteSqlCommand("insert into t_tmseque values (@p1,1,1)", p1);
                res1 = 1;
            }
            else
            {
                context.Database.ExecuteSqlCommand("update t_tmseque set TMSEQ_CURVAL = TMSEQ_CURVAL + 1 where TMSEQ_NAME = @p1", p1);
                res1 += 1;
            }

            res = this.VersionDate + res1.ToString("D10");
            return res;
        }

        public string genSequenceID2(string keyWord)
        {
            MySql.Data.MySqlClient.MySqlConnection connection = new MySql.Data.MySqlClient.MySqlConnection(this.ConnectString);
            string selectQuery = "select TMSEQ_CURVAL from t_tmseque where TMSEQ_NAME = @p1";

            connection.Open();
            MySql.Data.MySqlClient.MySqlCommand command = null;
            MySql.Data.MySqlClient.MySqlParameter p1 = new MySql.Data.MySqlClient.MySqlParameter("@p1", MySql.Data.MySqlClient.MySqlDbType.VarChar);
            p1.Value = keyWord;

            command = new MySql.Data.MySqlClient.MySqlCommand(selectQuery, connection);
            command.Parameters.Add(p1);

            var res = command.ExecuteScalar();

            if (res == null)
            {
                res = 1;

                command = new MySql.Data.MySqlClient.MySqlCommand("insert into t_tmseque values (@p1,1,1)", connection);
                command.Parameters.Add(p1);
                command.ExecuteNonQuery();
            }
            else
            {

                res = (int)res + 1;

                command = new MySql.Data.MySqlClient.MySqlCommand("update t_tmseque set TMSEQ_CURVAL = TMSEQ_CURVAL + 1 where TMSEQ_NAME = @p1", connection);
                command.Parameters.Add(p1);
                command.ExecuteNonQuery();
            }


            connection.Close();

            var res2 = this.VersionDate + ((int)res).ToString("D10");

            return res2;
        }

        /// <summary>
        /// 現在のユーザーが編集できるサブシステムリストを取得
        /// </summary>
        /// <returns></returns>
        public List<string> getModifiableSubsysList()
        {
            List<string> res = new List<string>();

            if (pridic != null && pridic.ContainsKey(user.GRP))
                res.AddRange(pridic[user.GRP]);

            return res.Distinct().Where(r => r != "JM").ToList();
        }

        /// <summary>
        /// すべてのサブシステムリストを取得
        /// </summary>
        /// <returns></returns>
        public List<string> getAllSubsysList()
        {
            List<string> res = new List<string>();

            if (pridic != null)
                foreach (var xx in pridic)
                    res.AddRange(xx.Value);

            return res.Distinct().Where(r => r != "JM").ToList();
        }



        public DB.mysqlcontext context
        {
            get
            {
                return ctx;
            }
        }

        public DB.T_USER User
        {
            get
            {
                return user;
            }
        }



        /// <summary>
        /// DB連続用文字列
        /// </summary>
        public string ConnectString
        {
            get
            {
                return $"server={this.Hostname};port={this.Port};database={this.DBName};uid={this.DBUser};password={this.DBPassword};CharSet=utf8;SslMode=None";
            }
        }
    }
}
