﻿//-----------------------------------------------------------
// All Rights Reserved , Copyright (C) 2018 , Hitachi , Ltd.
//-----------------------------------------------------------
using System.Collections.Generic;

namespace MarsTool.Models
{
    /// <summary>
    /// CodeCandidateModel Class<br/>
    /// CodeCandidateModel　クラス<br/>
    /// Create properties of code candidate value.<br/>
    /// コード候補値のプロパティーを作成<br/>
    /// </summary>
    /// <remarks>
    /// 2018/03/15 新規作成<br/>
    /// </remarks>
    class CodeCandidateModel
    {
        public string Koho_group { get; set; }

        public List<int> Koho_outputOrder { get; set; }

        public List<string> Koho_code { get; set; }

        public List<string> Koho_content { get; set; }
    }
}
