﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsTool.Models
{
    class PhysicalLogicalOperationModel
    {
        public string Cpylgc_lcpid { get; set; }

        public string Cpylgc_opnm { get; set; }

        public int Cpylgc_outputorder { get; set; }
    }
}
