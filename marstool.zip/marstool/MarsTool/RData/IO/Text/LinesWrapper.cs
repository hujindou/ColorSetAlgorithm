﻿using System.Collections.Generic;

namespace MarsTool.RData.IO.Text
{
    /// <summary>
    /// ファイル行ラッパークラス
    /// </summary>
    public class LinesWrapper
    {
        /// <summary>
        /// ファイル行情報
        /// </summary>
        private List<string> _lines = new List<string>();
        public string[] Contents
        {
            get
            {
                return this._lines.ToArray();
            }
        }

        private int _idx;
        public int LineNo
        {
            get
            {
                return this._idx + 1;
            }
        }
        public string Current
        {
            get
            {
                if (this._lines == null || this._lines.Count <= this._idx) return null;
                if (this._idx == -1)
                {
                    this._idx++;
                }

                return this._lines[_idx];
            }
        }

        public string Next()
        {
            if (this._lines == null) return null;

            this._idx++;
            return this.Current;
        }

        public void Init()
        {
            this._idx = -1;
        }

        public void Goback()
        {
            this._idx--;
        }

        public void Add(string line)
        {
            this._lines.Add(string.IsNullOrEmpty(line) ? string.Empty : line);
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public LinesWrapper() : this(null) { }
        public LinesWrapper(string[] lines)
        {
            this._idx = -1;
            if (lines == null) return;
            
            this._lines.AddRange(lines);
        }
    }
}
