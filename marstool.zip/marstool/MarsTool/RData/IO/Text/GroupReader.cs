﻿using MarsTool.RData.Info;
using System;
using System.Collections.Generic;
using System.Linq;
using Regular = System.Text.RegularExpressions;

namespace MarsTool.RData.IO.Text
{
    /// <summary>
    /// ＲＤＡＴＡ情報部読込ベースクラス
    /// </summary>
    public abstract class GroupReaderBase : TextReaderBase
    {
        /// <summary>
        /// ＲＤＡＴＡ情報部
        /// </summary>
        private Group _group = null;
        public Group Group
        {
            get
            {
                return this._group;
            }
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public GroupReaderBase(Group group)
        {
            this._group = group;
        }

        /// <summary>
        /// クリア
        /// </summary>
        public override void Clear()
        {
            if (this._group == null) return;
            this._group.FieldDefList.Clear();
            this._group.RecordList.Clear();
        }

        /// <summary>
        /// 情報部のヘッダ部判定
        /// </summary>
        /// <returns></returns>
        protected virtual bool HitHeader()
        {
            var line = this.Next();
            if (string.IsNullOrWhiteSpace(line)) return false;

            // 判定失敗場合
            if (!line.TrimEnd().EndsWith(this.Group.Name))
            {
                this.Goback();
                return false;
            }

            return true;
        }

        /// <summary>
        /// エントリレコード読込
        /// </summary>
        public virtual void ReadRecord()
        {
            // レコード情報リーダー
            new RecordReader(this._group, this.Lines).Read();
        }

        /// <summary>
        /// 読込処理
        /// </summary>
        public override void Read()
        {
            // 該当情報部のヘッダ部定義が存在しない場合
            if (!this.HitHeader())
            {
                throw new Exception(string.Format("{0}が存在しない。", this.Group.Name));
            }

            // レコード読込
            this.ReadRecord();
        }
    }

    /// <summary>
    /// ローダインタフェース情報部読込クラス
    /// </summary>
    public class GroupInterfaceReader : GroupReaderBase
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public GroupInterfaceReader(GroupInterface groupInterface) : base(groupInterface) { }

        /// <summary>
        /// 読込処理
        /// </summary>
        public override void Read()
        {
            // 該当情報部のヘッダ部定義が存在する場合
            if (this.HitHeader())
            {
                this.Group.HeaderInfo.Expand = "要";

                // レコード読込
                this.ReadRecord();
            }
        }
    }

    /// <summary>
    /// 制御情報部１読込クラス
    /// </summary>
    public class GroupCtrl1Reader : GroupReaderBase
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public GroupCtrl1Reader(GroupCtrl1 groupCtrl1) : base(groupCtrl1) { }
    }

    /// <summary>
    /// 共通情報部読込クラス
    /// </summary>
    public class GroupCommonReader : GroupReaderBase
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public GroupCommonReader(GroupCommon groupCommon) : base(groupCommon) { }

        /// <summary>
        /// エントリレコード読込
        /// </summary>
        public override void ReadRecord()
        {
            // レコード情報リーダー
            base.ReadRecord();

            if (this.Group.FieldDefList.Count > 9)
            {
                var fieldDefList = new List<FieldDefine>(this.Group.FieldDefList);
                this.Group.FieldDefList.Clear();
                this.Group.FieldDefList.AddRange(fieldDefList.Take(9));
            }
        }
    }

    /// <summary>
    /// 共通情報部・ユーザ任意情報読込クラス
    /// </summary>
    public class GroupUserReader : GroupReaderBase
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public GroupUserReader(GroupUser groupUser) : base(groupUser) { }

        /// <summary>
        /// 読込処理
        /// </summary>
        public override void Read()
        {
            // 該当情報部のヘッダ部定義が存在する場合
            if (this.HitHeader())
            {
                // レコード読込
                this.ReadRecord();
            }
        }
    }

    /// <summary>
    /// エントリ部読込クラス
    /// </summary>
    public class GroupEntryReader : GroupReaderBase
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public GroupEntryReader(GroupEntry groupEntry) : base(groupEntry) { }

        /// <summary>
        /// エントリレコード読込
        /// </summary>
        public override void ReadRecord()
        {
            // レコード情報リーダー
            new EntryRecordReader(this.Group, this.Lines).Read();
        }
        
        protected override bool IsSkipLine(string line)
        {
            return string.IsNullOrWhiteSpace(line);
        }

        private const string HEADER_LINE_REG = @"^[*][*]+$";

        /// <summary>
        /// 情報部のヘッダ部判定
        /// </summary>
        /// <returns></returns>
        protected override bool HitHeader()
        {
            var line = this.Next();
            if (string.IsNullOrWhiteSpace(line)) return false;

            // ＭＢ管理テーブルの場合
            if (this.Group.HeaderInfo.IsMBTable)
            {
                do
                {
                    // エントリヘッダ部の上囲いレコード「************　......」を判定する
                    if (Regular.Regex.IsMatch(line, HEADER_LINE_REG)) break;

                    line = this.Next();
                    if (string.IsNullOrWhiteSpace(line)) return false;
                } while (true);

                line = this.Next();
                if (string.IsNullOrWhiteSpace(line)) return false;

                if (line.TrimEnd().EndsWith(this.Group.Name))
                {
                    return Regular.Regex.IsMatch(this.Next(), HEADER_LINE_REG);
                }

                return false;
            }
            else
            {
                // 判定失敗場合
                if (!line.TrimEnd().EndsWith(this.Group.Name + "START"))
                {
                    this.Goback();
                    return false;
                }

                return true;
            }
        }

        /// <summary>
        /// 情報部のフッター部判定
        /// </summary>
        /// <returns></returns>
        private bool HitFooter()
        {
            // ＭＢ管理テーブル以外の場合
            if (!this.Group.HeaderInfo.IsMBTable)
            {
                var line = this.Next();
                if (!line.TrimEnd().EndsWith(this.Group.Name + "END"))
                {
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 読込処理
        /// </summary>
        public override void Read()
        {
            // 該当情報部のヘッダ部定義が存在しない場合
            if (!this.HitHeader())
            {
                throw new Exception(string.Format("{0}が存在しない。", this.Group.Name));
            }

            // レコード読込
            this.ReadRecord();

            // 該当情報部のフッター部判定
            if (!this.HitFooter())
            {
                throw new Exception(string.Format("エントリ部終了文言「{0}」が漏れる",
                    this.Group.Name + "END"));
            }
        }
    }

    /// <summary>
    /// 制御情報部２読込クラス
    /// </summary>
    public class GroupCtrl2Reader : GroupReaderBase
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public GroupCtrl2Reader(GroupCtrl2 groupCtrl2) : base(groupCtrl2) { }

        /// <summary>
        /// 読込処理
        /// </summary>
        public override void Read()
        {
            // 該当情報部のヘッダ部定義が存在しない場合
            if (!this.HitHeader())
            {
                throw new Exception(string.Format("{0}が存在しない。", this.Group.Name));
            }

            // レコード読込
            this.ReadRecord();
        }
    }
}
