﻿using System.Text.RegularExpressions;

namespace MarsTool.RData.IO.Text
{
    /// <summary>
    /// テキスト読込ベースクラス
    /// </summary>
    public abstract class TextReaderBase
    {
        public const string SKIP_LINE_REG = @"^[*]([-]+|[*]*)$";
        public const string FIELDS_LINE_REG = @"^[*],項目名,データ型,サイズ,データ内容,チェック種別,コメント\s*$";

        /// <summary>
        /// ファイル行情報
        /// </summary>
        private LinesWrapper _linesWrapper = null;
        public LinesWrapper Lines
        {
            set
            {
                this._linesWrapper = value;
            }
            get
            {
                return this._linesWrapper;
            }
        }

        public string Next()
        {
            if (this._linesWrapper == null) return null;

            var line = this._linesWrapper.Next();
            if (line == null) return null;

            while (line != null)
            {
                if (this.IsSkipLine(line))
                {
                    line = this._linesWrapper.Next();
                    continue;
                }
                break;
            }

            return line;
        }

        protected virtual bool IsSkipLine(string line)
        {
            return string.IsNullOrWhiteSpace(line) ||
                Regex.IsMatch(line, SKIP_LINE_REG) ||
                Regex.IsMatch(line, FIELDS_LINE_REG);
        }

        public int LineNo
        {
            get
            {
                if (this._linesWrapper == null) return 0;
                return this._linesWrapper.LineNo;
            }
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public TextReaderBase() { }

        /// <summary>
        /// クリア
        /// </summary>
        public virtual void Clear() { }

        /// <summary>
        /// 読込処理
        /// </summary>
        public abstract void Read();

        public void Goback()
        {
            if (this._linesWrapper != null)
            {
                this._linesWrapper.Goback();
            }
        }
    }
}
