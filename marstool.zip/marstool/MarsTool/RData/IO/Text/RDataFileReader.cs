﻿using MarsTool.RData.Info;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace MarsTool.RData.IO.Text
{
    /// <summary>
    /// ＲＤＡＴＡ情報リーダーベースクラス
    /// </summary>
    public class RDataFileReader
    {
        /// <summary>
        /// ＲＤＡＴＡ情報
        /// </summary>
        private RDataInfo _rDataInfo = new RDataInfo();

        /// <summary>
        /// リーダーリスト
        /// </summary>
        private List<TextReaderBase> _readers = new List<TextReaderBase>();

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public RDataFileReader()
        {
            // ヘッダ部共通情報リーダー
            this._readers.Add(new HeaderInfoReader(this._rDataInfo.HeaderInfo));
            // ローダインタフェース情報部リーダー
            this._readers.Add(new GroupInterfaceReader(this._rDataInfo.Interface));
            // 制御情報部１リーダー
            this._readers.Add(new GroupCtrl1Reader(this._rDataInfo.GroupCtrl1));
            // 共通情報部リーダー
            this._readers.Add(new GroupCommonReader(this._rDataInfo.GroupCommon));
            // 共通情報部・ユーザ任意情報リーダー
            this._readers.Add(new GroupUserReader(this._rDataInfo.GroupUser));
            // エントリ部リーダー
            this._readers.Add(new GroupEntryReader(this._rDataInfo.GroupEntry));
            // 制御情報部２リーダー
            this._readers.Add(new GroupCtrl2Reader(this._rDataInfo.GroupCtrl2));
        }

        /// <summary>
        /// 読込処理
        /// </summary>
        public RDataInfo Read(string folder, string filename, string ext, Encoding encoding)
        {
            if (!string.IsNullOrWhiteSpace(ext) && ext.StartsWith("."))
            {
                ext = ext.Substring(1);
            }

            var fullname = string.Format("{0}.{1}", filename, ext);
            var filepath = Path.Combine(folder, fullname);
            if (!File.Exists(filepath))
            {
                throw new Exception(string.Format("ファイルが存在しません。「{0}」", filepath));
            }

            this._rDataInfo.HeaderInfo.Filename = filename;
            this._rDataInfo.HeaderInfo.Extension = ext;

            var lines = new LinesWrapper(File.ReadAllLines(filepath, encoding));
            this._readers.ForEach(
                reader =>
                {
                    reader.Clear();
                    reader.Lines = lines;
                });

            try
            {
                foreach (var reader in this._readers)
                {
                    reader.Read();
                }
            }
            catch (Exception e)
            {
                throw new Exception($"{fullname} {e.Message}");
            }

            return this._rDataInfo;
        }
    }
}
