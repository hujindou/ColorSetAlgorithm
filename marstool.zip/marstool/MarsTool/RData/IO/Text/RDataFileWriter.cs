﻿using MarsTool.RData.Info;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace MarsTool.RData.IO.Text
{
    /// <summary>
    /// ＲＤＡＴＡ情報ライターベースクラス
    /// </summary>
    public class RDataFileWriter
    {
        /// <summary>
        /// ＲＤＡＴＡ情報
        /// </summary>
        private RDataInfo _rDataInfo = null;

        /// <summary>
        /// ライターリスト
        /// </summary>
        private List<TextWriterBase> _writers = new List<TextWriterBase>();

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public RDataFileWriter(RDataInfo rDataInfo)
        {
            if (rDataInfo == null) return;

            this._rDataInfo = rDataInfo;

            // ヘッダ部共通情報ライター
            this._writers.Add(new HeaderInfoWriter(this._rDataInfo.HeaderInfo));
            // ローダインタフェース情報部ライター
            this._writers.Add(new GroupInterfaceWriter(this._rDataInfo.Interface));
            // 制御情報部１ライター
            this._writers.Add(new GroupCtrl1Writer(this._rDataInfo.GroupCtrl1));
            // 共通情報部ライター
            this._writers.Add(new GroupCommonWriter(this._rDataInfo.GroupCommon));
            // 共通情報部・ユーザ任意情報ライター
            this._writers.Add(new GroupUserWriter(this._rDataInfo.GroupUser));
            // エントリ部ライター
            this._writers.Add(new GroupEntryWriter(this._rDataInfo.GroupEntry));
            // 制御情報部２ライター
            this._writers.Add(new GroupCtrl2Writer(this._rDataInfo.GroupCtrl2));
        }

        /// <summary>
        /// 書込処理
        /// </summary>
        public void Write(string filepath, Encoding encoding)
        {
            var folder = Path.GetDirectoryName(filepath);
            if (!Directory.Exists(folder))
            {
                throw new Exception(string.Format("「{0}」フォルダが存在しない。", folder));
            }

            var lines = new LinesWrapper();
            this._writers.ForEach(writer => writer.Lines = lines);

            try
            {
                foreach (var writer in this._writers)
                {
                    writer.Write();
                }

                File.WriteAllLines(filepath, lines.Contents, encoding);
            }
            catch (Exception e)
            {
                throw new Exception($"{filepath} [{e.Message}]");
            }
        }
    }
}
