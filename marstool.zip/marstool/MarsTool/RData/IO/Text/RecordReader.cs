﻿using MarsTool.Common;
using MarsTool.RData.Info;
using MarsTool.RData.Text;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Regular = System.Text.RegularExpressions;

namespace MarsTool.RData.IO.Text
{
    /// <summary>
    /// レコード情報読込クラス
    /// </summary>
    public class RecordReader : TextReaderBase
    {
        private const int FIELD_MAX_LEN = 50;

        /// <summary>
        /// ＲＤＡＴＡ情報部
        /// </summary>
        private Group _group = null;
        public Group Group
        {
            get
            {
                return this._group;
            }
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public RecordReader(Group group, LinesWrapper lines)
        {
            this._group = group;
            this.Lines = lines;
        }

        /// <summary>
        /// 読込処理
        /// </summary>
        public override void Read()
        {
            var record = new RecordInfo();
            this._group.RecordList.Add(record);

            uint fieldIdx = 0;
            do
            {
                var line = this.Next();
                if (string.IsNullOrWhiteSpace(line)) return;

                // フィールドではない場合
                if (!line.StartsWith(","))
                {
                    this.Goback();
                    return;
                }

                record.Add(this.ReadFieldInfo(line, this.LineNo, true, fieldIdx++));
            } while (true);
        }

        /// <summary>
        /// 項目情報を読込
        /// </summary>
        /// <param name="line"></param>
        /// <param name="lineNo"></param>
        /// <param name="isFirstEntry"></param>
        /// <param name="fieldIdx"></param>
        /// <returns></returns>
        protected FieldInfo ReadFieldInfo(string line, int lineNo, bool isFirstEntry, uint fieldIdx)
        {
            if (string.IsNullOrWhiteSpace(line)) return null;

            try
            {
                var infos = line.Split(',');

                // 項目名
                var itemName = infos[1];
                // データ属性
                var dataAttr = infos[2];
                // サイズ
                var strSize = infos[3];

                if (!int.TryParse(strSize, out int size))
                {
                    throw new Exception("サイズは数値を入力してください。");
                }
                if (!"YOBI".Equals(dataAttr) && size > FIELD_MAX_LEN)
                {
                    throw new Exception($"サイズが{FIELD_MAX_LEN}以下入力してください。");
                }

                FieldDefine fieldDef = null;

                if (isFirstEntry)
                {
                    fieldDef = new FieldDefine
                    {
                        // 項目名
                        ItemName = itemName,
                        // データ属性
                        DataAttr = dataAttr,
                        // サイズ
                        Size = strSize
                    };

                    this.Group.FieldDefList.Add(fieldDef);
                }
                else
                {
                    if (fieldIdx >= this.Group.FieldDefList.Count)
                    {
                        if (Utils.IsFiller(itemName))
                        {
                            return new FieldInfo();
                        }
                        throw new Exception("項目定義が先頭エントリと異なります。");
                    }
                    else
                    {
                        fieldDef = this.Group.FieldDefList[(int)fieldIdx];

                        if (!fieldDef.ItemName.Equals(itemName) || // 項目名
                            !fieldDef.DataAttr.Equals(dataAttr) || // データ属性
                            !fieldDef.Size.Equals(strSize))        // サイズ
                        {
                            throw new Exception("項目定義が先頭エントリと異なります。");
                        }
                    }
                }

                // フィールド情報
                var fieldInfo = new FieldInfo(fieldDef.Key);
                var len = infos.Length;
                if (len > 4)
                {
                    // データ内容
                    var value = infos[4];
                    fieldInfo.Value = value;
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        var jisEncode = Encoding.GetEncoding("Shift_JIS");

                        switch (fieldDef.DataAttr)
                        {
                            case "HEX":
                                {
                                    var bytes = jisEncode.GetBytes(value).Length / 2;
                                    if (bytes > size)
                                    {
                                        throw new Exception($"データが{size}バイトを超過する。");
                                    }
                                }
                                break;

                            case "CHAR":
                                {
                                    var bytes = jisEncode.GetBytes(value).Length;
                                    if (bytes > size)
                                    {
                                        throw new Exception($"データが{size}バイトを超過する。");
                                    }
                                }
                                break;

                            default:
                                break;
                        }
                    }
                }
                if (len > 5)
                {
                    // チェック種別
                    fieldInfo.CheckType = infos[5];
                }
                if (len > 6)
                {
                    // コメント
                    fieldInfo.Comment = infos[6];
                }

                return fieldInfo;
            }
            catch (Exception e)
            {
                throw new Exception($"{lineNo}行目が内容不正。({e.Message})");
            }
        }
    }

    /// <summary>
    /// エントリレコード情報読込クラス
    /// </summary>
    public class EntryRecordReader : RecordReader
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public EntryRecordReader(Group group, LinesWrapper lines) : base(group, lines) { }

        /// <summary>
        /// 読込処理
        /// </summary>
        public override void Read()
        {
            RecordInfo record = null;
            var entryNo = 1;
            while (true)
            {
                // 開始コメント読込
                var startComments = this.ReadComments(EditComment.CommentFlg.Start);

                // ヘッダ部読込
                record = this.ReadHeader();
                if (record == null)
                {
                    break;
                }

                record.AddEditComments(startComments);

                this.Group.RecordList.Add(record);

                // ＭＢ管理テーブル または 削除されない場合
                if (this.Group.HeaderInfo.IsMBTable || string.IsNullOrWhiteSpace(record.DelComment))
                {
                    uint fieldIdx = 0;
                    do
                    {
                        var line = this.Next();
                        if (string.IsNullOrWhiteSpace(line)) break;

                        // フィールドではない場合
                        if (!line.StartsWith(","))
                        {
                            this.Goback();
                            break;
                        }

                        record.Add(this.ReadFieldInfo(line, this.LineNo, entryNo == 1, fieldIdx++));
                    } while (true);
                }

                // 終了コメント読込
                var endComments = this.ReadComments(EditComment.CommentFlg.End);
                record.AddEditComments(endComments);

                var order = 1;
                record.EditCommentList.ForEach(c => c.Order = order++);

                record.EntryNo = entryNo++;
            }
        }

        /// <summary>
        /// レコードのコメント読込
        /// </summary>
        /// <returns></returns>
        private List<EditComment> ReadComments(EditComment.CommentFlg flg)
        {
            var line = string.Empty;
            EditComment editComment = null;
            var commentList = new List<EditComment>();
            while (true)
            {
                line = this.Next();
                if ((editComment = EditComment.Parse(line, flg)) == null)
                {
                    this.Goback();
                    break;
                }
                commentList.Add(editComment);
            }

            return commentList;
        }

        protected override bool IsSkipLine(string line)
        {
            return string.IsNullOrWhiteSpace(line);
        }

        private const string HEADER_LINE_REG = @"^[*][*]+$";

        /// <summary>
        /// レコードのヘッダ部読込
        /// </summary>
        /// <returns></returns>
        private RecordInfo ReadHeader()
        {
            var line = this.Next();
            if (line == null) return null;

            // 削除されたエントリ
            var match = Regular.Regex.Match(line, @"^削除・(.+エントリ)・([^\s].*[^\s])\s*$");
            if (match.Success)
            {
                return new RecordInfo
                {
                    Comment = match.Groups[1].Value,
                    DelComment = match.Groups[2].Value
                };
            }

            // エントリヘッダ部の上囲いレコード「************　......」を判定する
            if (!Regular.Regex.IsMatch(line, HEADER_LINE_REG))
            {
                this.Goback();
                return null;
            }

            var lineNo = -1;
            var lineCnt = 0;
            // エントリヘッダ部内容
            var headerContent = string.Empty;
            do
            {
                line = this.Next();
                if (line == null) return null;

                if (lineNo == -1) lineNo = this.LineNo;
                lineCnt++;

                // エントリヘッダ部の下囲いレコード「************　......」を判定する
                if (Regular.Regex.IsMatch(line, HEADER_LINE_REG)) break;

                headerContent += line + "\r\n";
            } while (true);

            // エントリコメント
            var comment = string.Empty;
            // 削除エントリコメント
            var delComment = string.Empty;

            // ＭＢ管理テーブルの場合
            if (this.Group.HeaderInfo.IsMBTable)
            {
                match = Regular.Regex.Match(
                    headerContent,
                    @"^[*][,](ＤＳＭＢ管理Ｔエントリ[（].*[）])\s*(削除・([^\s](.|\r|\n)*[^\s]))?\s*$");
                if (!match.Success)
                {
                    for (var i = 0; i < lineCnt; i++) this.Goback();
                    return null;
                }

                comment = match.Groups[1].Value;
                if (match.Groups.Count > 3)
                {
                    delComment = match.Groups[3].Value;
                }

                return new RecordInfo
                {
                    Comment = comment,
                    DelComment = delComment
                };
            }
            else
            {
                match = Regular.Regex.Match(headerContent, @"^[*][\s]+([^\s](.|\r|\n)*[^\s])?\s*?$");
                if (match.Success)
                {
                    if (match.Groups.Count > 1)
                    {
                        comment = match.Groups[1].Value;
                    }

                    return new RecordInfo()
                    {
                        Comment = comment
                    };
                }

                throw new Exception($"{lineNo}行目が内容不正。(エントリコメントが誤っている。)");
            }
        }
    }
}
