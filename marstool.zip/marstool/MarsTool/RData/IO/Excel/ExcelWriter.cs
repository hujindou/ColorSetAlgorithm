﻿using MarsTool.RData.Info;
using System;
using System.ComponentModel;

namespace MarsTool.RData.IO.Excel
{
    /// <summary>
    /// Excelライタークラス
    /// </summary>
    public class ExcelWriter
    {
        /// <summary>
        /// ＲＤＡＴＡ情報
        /// </summary>
        private RDataInfo _rDataInfo = null;

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public ExcelWriter(RDataInfo rDataInfo)
        {
            if (rDataInfo == null) return;

            this._rDataInfo = rDataInfo;
        }

        /// <summary>
        /// 書込処理
        /// </summary>
        public void Write(BackgroundWorker worker, string filepath)
        {
            try
            {
                var headerInfo = this._rDataInfo.HeaderInfo;
                var groupEntry = this._rDataInfo.GroupEntry;
                var isMbTable = headerInfo.IsMBTable;

                worker.ReportProgress(5);
                using (var excel = new ExcelWrapper(true))
                {
                    var wb = excel.Open(filepath);
                    var ws = wb.Sheets[0];

                    worker.ReportProgress(15);

                    // ＲＤＡＴＡファイル名
                    ws.SetCellValue(3, 3, headerInfo.Filename);

                    // 項目定義
                    // 名称行
                    var nameRow = 5;
                    // データ型行
                    var typeRow = 6;
                    // サイズ行
                    var sizeRow = 7;
                    // 開始列
                    var startCol = 3;
                    // 開始行
                    var startRow = 8;
                    // 終了列
                    var endCol = startCol + (groupEntry.FieldDefList.Count - 1);
                    // 名称
                    ws.CopyStyle(nameRow, startCol, nameRow, startCol + 1, nameRow, endCol);
                    // データ型
                    ws.CopyStyle(typeRow, startCol, typeRow, startCol + 1, typeRow, endCol);
                    // サイズ
                    ws.CopyStyle(sizeRow, startCol, sizeRow, startCol + 1, sizeRow, endCol);

                    var recordCnt = groupEntry.RecordList.Count;
                    // 終了行
                    var endRow = startRow + recordCnt - 1;
                    // エントリ番号
                    ws.CopyStyle(8, 1, startRow, 1, endRow, 1);
                    // エントリコメント
                    ws.CopyStyle(8, 2, startRow, 2, endRow, 2);
                    // 項目値
                    ws.CopyStyle(8, 2, startRow, startCol, endRow, endCol);

                    foreach (var fieldDef in groupEntry.FieldDefList)
                    {
                        // 名称
                        ws.SetCellValue(nameRow, startCol, fieldDef.ItemName);
                        // データ型
                        ws.SetCellValue(typeRow, startCol, fieldDef.DataAttr);
                        // サイズ
                        ws.SetCellValue(sizeRow, startCol, fieldDef.Size);
                        startCol++;
                    }

                    worker.ReportProgress(20);

                    var progress = 0;
                    for (var i = 0; i < recordCnt; i++)
                    {
                        var record = groupEntry.RecordList[i];
                        if (progress < ((i * 80) / recordCnt))
                        {
                            progress = (i * 80) / recordCnt;
                            worker.ReportProgress(progress + 20);
                        }

                        // ＭＢ管理テーブル以外の場合、削除されたエントリが出力対象外
                        if (!isMbTable && !string.IsNullOrWhiteSpace(record.DelComment)) continue;

                        startCol = 1;

                        // エントリ番号
                        ws.SetCellValue(startRow, startCol, record.EntryNo.ToString());
                        startCol++;

                        // エントリコメント
                        ws.SetCellValue(startRow, startCol, record.Comment.ToString());
                        startCol++;

                        foreach (var fieldDef in groupEntry.FieldDefList)
                        {
                            // 項目値
                            var field = record[fieldDef.Key];
                            var value = (field != null) ? field.Value : string.Empty;
                            ws.SetCellValue(startRow, startCol, value);

                            startCol++;
                        }

                        startRow++;
                    }
                }
            }
            catch (Exception e)
            {
                throw new Exception(string.Format("ＲＤＡＴＡ帳票が書込失敗する。{0}", e.Message));
            }
        }
    }
}
