﻿using System.Collections.Generic;
using ComExcel = Microsoft.Office.Interop.Excel;

namespace MarsTool.RData.IO.Excel
{
    /// <summary>
    /// WorkSheetクラス
    /// </summary>
    public class WorkSheet
    {
        /// <summary>
        /// COM Worksheetオブジェクト
        /// </summary>
        private ComExcel.Worksheet _ws;
        /// <summary>
        /// Worksheet名前
        /// </summary>
        private string _name;
        /// <summary>
        /// COM　Rangeオブジェクト
        /// </summary>
        private ComExcel.Range _range = null;
        private int _maxRow = 1;
        private int _maxCol = 1;
        private object[,] _values = null;

        /// <summary>
        /// コンストラクタ
        /// </summary>
        internal WorkSheet(ComExcel.Worksheet ws)
        {
            this._ws = ws;
            if (this._ws == null) return;

            this._name = ws.Name;
            try
            {
                this.LoadUsedRange();
            }
            catch
            {
                // 各項目がデフォルトにする、何もしない
            }
        }

        /// <summary>
        /// シートのすべてデータをロードする。
        /// </summary>
        private void LoadUsedRange()
        {
            if (this._ws == null) return;
            this._range = this._ws.UsedRange;
            this._values = this._range.Value;

            if (this._values == null) return;
            this._maxRow = this._values.GetLength(0);
            this._maxCol = this._values.GetLength(1);
        }

        /// <summary>
        /// カラム名的なアルファベット文字列を数値へ変換する。
        /// </summary>
        /// <param name="strCol"></param>
        /// <returns></returns>
        public static int ColumnString2Int(string strCol)
        {
            if (strCol == null) return 1;

            int col = 0;
            strCol = strCol.ToUpper();
            for (int i = 0; i < strCol.Length; i++)
            {
                char ch = strCol[i];
                if (ch < 'A' || ch > 'Z') return 1;
                col = col * 26 + (ch - 'A' + 1);
            }

            return col;
        }

        /// <summary>
        /// 数値をカラム名的なアルファベット文字列へ変換する。
        /// </summary>
        /// <param name="nCol"></param>
        /// <returns></returns>
        public static string ColumnInt2String(int nCol)
        {
            if (nCol < 1) return string.Empty;

            string strCol = string.Empty;
            do
            {
                strCol = (char)((nCol - 1) % 26 + 'A') + strCol;
                nCol = (nCol - 1) / 26;
            } while (nCol > 0);

            return strCol;
        }

        /// <summary>
        /// 行とカラム応じるセルのデータを取得する。
        /// </summary>
        /// <param name="nRow"></param>
        /// <param name="nCol"></param>
        /// <returns></returns>
        public string GetCellValue(int nRow, int nCol)
        {
            if (this._values == null) return string.Empty;

            nRow -= this._range.Row - 1;
            nCol -= this._range.Column - 1;
            if (nRow < 1 || nRow > this._maxRow
                || nCol < 1 || nCol > this._maxCol) return string.Empty;

            if (this._values[nRow, nCol] == null) return string.Empty;
            return this._values[nRow, nCol].ToString().Trim();
        }

        /// <summary>
        /// 行とカラム応じるセルのデータを取得する。
        /// </summary>
        /// <param name="nRow"></param>
        /// <param name="strCol"></param>
        /// <returns></returns>
        public string GetCellValue(int nRow, string strCol)
        {
            return this.GetCellValue(nRow, ColumnString2Int(strCol));
        }

        public void SetCellValue(int nRow, int nCol, string value)
        {
            if (value == null) value = string.Empty;
            this._ws.Cells[nRow, nCol].Value = value;
        }

        /// <summary>
        /// 行とカラム応じるセルにデータを設定する。
        /// </summary>
        /// <param name="nRow"></param>
        /// <param name="strCol"></param>
        /// <param name="value"></param>
        public void SetCellValue(int nRow, string strCol, string value)
        {
            this.SetCellValue(nRow, ColumnString2Int(strCol), value);
        }

        /// <summary>
        /// セルのスタイルをコピーする。
        /// </summary>
        /// <param name="fromRow"></param>
        /// <param name="fromCol"></param>
        /// <param name="toRow1"></param>
        /// <param name="toCol1"></param>
        /// <param name="toRow2"></param>
        /// <param name="toCol2"></param>
        public void CopyStyle(int fromRow, int fromCol, int toRow1, int toCol1, int toRow2, int toCol2)
        {
            var from = this._ws.Cells[fromRow, fromCol];
            var to = this._ws.Range[this._ws.Cells[toRow1, toCol1], this._ws.Cells[toRow2, toCol2]];

            from.Copy(to);
        }

        /// <summary>
        /// データを探す。
        /// </summary>
        /// <param name="val"></param>
        /// <param name="nRow"></param>
        /// <param name="nCol"></param>
        /// <returns></returns>
        public int FindValue(string val, ref int nRow, ref int nCol)
        {
            if (this._values == null || val == null) return -1;

            for (int row = 1; row <= this._maxRow; row++)
            {
                for (int col = 1; col <= this._maxCol; col++)
                {
                    if (!val.Equals(this._values[row, col])) continue;

                    nRow = row + this._range.Row - 1;
                    nCol = col + this._range.Column - 1;
                    return 0;
                }
            }

            return -1;
        }

        /// <summary>
        /// データを探す。
        /// </summary>
        /// <param name="val"></param>
        /// <param name="nRow"></param>
        /// <param name="strCol"></param>
        /// <returns></returns>
        public int FindValue(string val, ref int nRow, ref string strCol)
        {
            int nCol = 0;
            int rtn = FindValue(val, ref nRow, ref nCol);
            strCol = ColumnInt2String(nCol);

            return rtn;
        }

        /// <summary>
        /// 行データを取得する。
        /// </summary>
        /// <param name="nRow"></param>
        /// <returns></returns>
        public string[] GetRow(int nRow)
        {
            return GetRow(nRow, 0);
        }

        /// <summary>
        /// 行データを取得する。
        /// </summary>
        /// <param name="nRow"></param>
        /// <param name="offset"></param>
        /// <returns></returns>
        public string[] GetRow(int nRow, int offset)
        {
            if (this._values == null) return null;

            nRow -= this._range.Row - 1;
            if (nRow < 1 || nRow > this._maxRow) return null;

            var valueList = new List<string>();
            object val;
            for (int col = offset + 1; col <= this._maxCol; col++)
            {
                val = this._values[nRow, col];
                valueList.Add(val == null ? string.Empty : val.ToString());
            }

            return valueList.ToArray();
        }

        public int GetColOffset(string strCol)
        {
            return ColumnString2Int(strCol) - this._range.Column;
        }

        /// <summary>
        /// Worksheet名
        /// </summary>
        public string Name
        {
            get
            {
                return this._name;
            }
        }

        /// <summary>
        /// COM Worksheetオブジェクトを破棄
        /// </summary>
        public void Release()
        {
            ExcelWrapper.ReleaseObj(this._range);
            ExcelWrapper.ReleaseObj(this._ws);
        }
    }
}
