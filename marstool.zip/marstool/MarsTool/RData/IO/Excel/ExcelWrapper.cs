﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using ComExcel = Microsoft.Office.Interop.Excel;

namespace MarsTool.RData.IO.Excel
{
    /// <summary>
    /// Excelラッパークラス
    /// </summary>
    public class ExcelWrapper : IDisposable
    {
        /// <summary>
        /// Dispose済みフラグ
        /// </summary>
        private bool _disposed = false;
        /// <summary>
        /// 保存
        /// </summary>
        private bool _save = false;
        /// <summary>
        /// COM Excelアプリケーションオブジェクト
        /// </summary>
        private ComExcel.Application _app;
        /// <summary>
        /// WorkBookオブジェクトリスト
        /// </summary>
        private List<MarsTool.RData.IO.Excel.WorkBook> _wbList
            = new List<MarsTool.RData.IO.Excel.WorkBook>();

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public ExcelWrapper(bool save)
        {
            _app = new ComExcel.Application();
            _app.Visible = false;
            _save = save;
        }
        public ExcelWrapper() : this(false) { }

        /// <summary>
        /// ファイナライザ
        /// </summary>
        ~ExcelWrapper()
        {
            Dispose(false);
        }

        /// <summary>
        /// Dispose
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (!this._disposed)
            {
                this._disposed = true;
                if (disposing)
                {
                    // managed リソースの解放
                }

                this.Close(this._save);
                _app.Quit();
                ReleaseObj(_app);
            }
        }

        /// <summary>
        /// Dispose
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Excelファイルを開く
        /// </summary>
        /// <returns></returns>
        public MarsTool.RData.IO.Excel.WorkBook Open(string filename)
        {
            if (!File.Exists(filename))
            {
                throw new FileNotFoundException(
                    string.Format("「{0}」が存在しません。", Path.GetFileName(filename)));
            }

            var wb = new MarsTool.RData.IO.Excel.WorkBook(_app.Workbooks.Open(filename), filename);
            if (!this._wbList.Contains(wb))
            {
                this._wbList.Add(wb);
            }
            
            return wb;
        }

        /// <summary>
        /// Excelファイルを閉じる
        /// </summary>
        public void Close()
        {
            this.Close(false);
        }
        public void Close(bool save)
        {
            foreach (var wb in _wbList)
            {
                wb.Close(save);
            }
        }

        /// <summary>
        /// COMオブジェクトを破棄
        /// </summary>
        public static void ReleaseObj(object COMObj)
        {
            try
            {
                if (COMObj != null)
                {
                    Marshal.ReleaseComObject(COMObj);
                }
            }
            finally
            {
                COMObj = null;
            }
        }
    }
}
