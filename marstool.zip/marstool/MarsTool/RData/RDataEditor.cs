﻿using MarsTool.Common;
using MarsTool.Common.Forms;
using MarsTool.Properties;
using MarsTool.RData.Info;
using MarsTool.RData.Text;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using static MarsTool.RData.Info.EditComment;

namespace MarsTool.RData
{
    /// <summary>
    /// ＲＤＡＴＡ情報編集コントロールクラス
    /// </summary>
    public partial class RDataEditor : UserControl
    {
        /// <summary>
        /// 制御情報部１タブ
        /// </summary>
        private const int TAB_IDX_CTRL1 = 1;

        /// <summary>
        /// ユーザ任意情報タブ
        /// </summary>
        private const int TAB_IDX_USER = 3;

        /// <summary>
        /// エントリ部タブ
        /// </summary>
        private const int TAB_IDX_ENTRY = 4;

        public ContextMenuStrip DgvAddDelMenu { set; get; }
        private int EntryRowIndex { set; get; }

        /// <summary>
        /// 項目名
        /// </summary>
        public const int ITEMCOL_ITEMNM = 0;
        /// <summary>
        /// データ型
        /// </summary>
        public const int ITEMCOL_DATATYPE = 1;
        /// <summary>
        /// サイズ
        /// </summary>
        public const int ITEMCOL_SIZE = 2;
        /// <summary>
        /// データ内容
        /// </summary>
        public const int ITEMCOL_DATA = 3;
        /// <summary>
        /// チェック種別
        /// </summary>
        public const int ITEMCOL_CHKTYPE = 4;
        /// <summary>
        /// コメント
        /// </summary>
        public const int ITEMCOL_COMMENT = 5;
        /// <summary>
        /// エントリ番号
        /// </summary>
        public const int ENTRYCOL_NO = 0;
        /// <summary>
        /// エントリコメント
        /// </summary>
        public const int ENTRYCOL_COMMENT = 1;
        /// <summary>
        /// 削除コメント
        /// </summary>
        public const int ENTRYCOL_DELCOMMENT = 2;
        /// <summary>
        /// コメントフラグ
        /// </summary>
        public const int COMMCOL_FLG = 0;
        /// <summary>
        /// コメント内容
        /// </summary>
        public const int COMMCOL_CONTEXT = 1;

        private RDataInfo RDataInfo { set; get; }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public RDataEditor()
        {
            InitializeComponent();

            #region ヘッダ部

            // 拡張子
            this.cbExt.Items.AddRange(new object[]
            {
                new KeyValuePair<string, string>("csv", "1"),
                new KeyValuePair<string, string>("txt", "2")
            });
            this.cbExt.DisplayMember = "Key";
            this.cbExt.ValueMember = "Value";

            // ローダ時のソート
            this.cbSort.Items.AddRange(new object[]
            {
                new KeyValuePair<string, string>("不要", "0"),
                new KeyValuePair<string, string>("要", "1")
            });
            this.cbSort.DisplayMember = "Key";
            this.cbSort.ValueMember = "Value";

            // 展開
            this.cbExpand.Items.AddRange(new object[]
            {
                new KeyValuePair<string, string>("不要", "0"),
                new KeyValuePair<string, string>("要", "1")
            });
            this.cbExpand.DisplayMember = "Key";
            this.cbExpand.ValueMember = "Value";
            #endregion

            #region 情報部
            this.tabGroups.SelectedIndex = TAB_IDX_CTRL1;

            // コメントフラグ
            var column = this.dgvEntryComment.Columns["COMTFLG"];
            if (column is DataGridViewComboBoxColumn)
            {
                var cbColumn = column as DataGridViewComboBoxColumn;
                cbColumn.Items.AddRange(new object[]
                {
                new KeyValuePair<string, string>("前後に表示 ** S **、** E **", "1"),
                new KeyValuePair<string, string>("頭部に表示 ** S **", "2"),
                new KeyValuePair<string, string>("後部に表示 ** E **", "3")
                });
                cbColumn.DisplayMember = "Key";
                cbColumn.ValueMember = "Value";
            }
            #endregion
        }

        /// <summary>
        /// サブシステムＩＤ
        /// </summary>
        public void SetSubSysId(string [] subSysIds)
        {
            this.cbSubSysId.Items.AddRange(subSysIds);
        }

        #region ヘッダ部

        /// <summary>
        /// 新規、編集モード
        /// true:   編集
        /// false:  新規
        /// </summary>
        private bool _editMode = false;
        public bool EditMode
        {
            set
            {
                this._editMode = value;
                // サブシステムＩＤ
                this.cbSubSysId.Enabled = !value;
                // テーブルＩＤ
                this.txtTableId.ReadOnly = value;
                // システム名
                this.txtSysNm.ReadOnly = value;
                // サブシステム名
                this.txtSubSysNm.ReadOnly = value;
                // テーブル名
                this.txtTableNm.ReadOnly = value;

                // 新規モード場合
                if (!value) this.InitNewInsert();
            }
            get
            {
                return this._editMode;
            }
        }

        /// <summary>
        /// ＭＢ管理テーブルフラグ
        /// </summary>
        private bool _isMBTable = false;
        public bool IsMBTable
        {
            set
            {
                this._isMBTable = value;
            }

            get
            {
                // 新規の場合
                if (!this._editMode)
                {
                    return this._isMBTable;
                }

                return this.RDataInfo.HeaderInfo.IsMBTable;
            }
        }

        /// <summary>
        /// 画面で入力したデータを取得
        /// </summary>
        /// <param name="headerInfo"></param>
        public void GetHeader(HeaderInfo headerInfo)
        {
            // 展開
            headerInfo.Expand = this.cbExpand.Text;
            // システム名
            headerInfo.SystemNm = this.txtSysNm.Text;
            // サブシステム名
            headerInfo.SubSystemNm = this.txtSubSysNm.Text;
            // テーブル名
            headerInfo.TableNm = this.txtTableNm.Text;
            // ブロック長
            headerInfo.BlockLen = this.txtBlkLen.Text;
            // サブシステムＩＤ
            headerInfo.SubSystemId = this.cbSubSysId.Text;
            // テーブルＩＤ
            headerInfo.TableId = this.txtTableId.Text;
            // RDATAファイル名
            headerInfo.Filename = this.txtFilename.Text;
            // 拡張子
            headerInfo.Extension = this.cbExt.Text;
            // コピー句ＩＤ
            headerInfo.CopyId = this.txtCopyId.Text;
            // ファイルグループ
            headerInfo.FileGroup = this.txtFileGroup.Text;
            // 構成タイプ
            headerInfo.StructType = this.cbStructType.Text;
            // ローダ時のソート
            headerInfo.Sort = this.cbSort.Text;
            // キー相対位置
            headerInfo.KeyLoc = this.txtKeyLoc.Text;
            // キー長
            headerInfo.KeyLen = this.txtKeyLen.Text;
            // キー
            headerInfo.Key = this.txtKey.Text;
            // 最大エントリ数
            var maxEntryCnt = headerInfo.MaxEntryCnt = 0;
            if (int.TryParse(this.txtMaxEntryCnt.Text, out maxEntryCnt))
            {
                headerInfo.MaxEntryCnt = maxEntryCnt;
            }
        }

        /// <summary>
        /// 画面へデータを設定
        /// </summary>
        /// <param name="headerInfo"></param>
        private void SetHeader(HeaderInfo headerInfo)
        {
            // 展開
            this.cbExpand.Text = headerInfo.Expand;
            // システム名
            this.txtSysNm.Text = headerInfo.SystemNm;
            // サブシステム名
            this.txtSubSysNm.Text = headerInfo.SubSystemNm;
            // テーブル名
            this.txtTableNm.Text = headerInfo.TableNm;
            // ブロック長
            this.txtBlkLen.Text = headerInfo.BlockLen;
            // サブシステムＩＤ
            this.cbSubSysId.Text = headerInfo.SubSystemId;
            // テーブルＩＤ
            this.txtTableId.Text = headerInfo.TableId;
            // RDATAファイル名
            this.txtFilename.Text = headerInfo.Filename;
            // 拡張子
            this.cbExt.Text = headerInfo.Extension;
            // コピー句ＩＤ
            this.txtCopyId.Text = headerInfo.CopyId;
            // ファイルグループ
            this.txtFileGroup.Text = headerInfo.FileGroup;
            // 構成タイプ
            this.cbStructType.Text = headerInfo.StructType;
            // ローダ時のソート
            this.cbSort.Text = headerInfo.Sort;
            // キー相対位置
            this.txtKeyLoc.Text = headerInfo.KeyLoc;
            // キー長
            this.txtKeyLen.Text = headerInfo.KeyLen;
            // キー
            this.txtKey.Text = headerInfo.Key;
            // 最大エントリ数
            this.txtMaxEntryCnt.Text = headerInfo.MaxEntryCnt.ToString();

            this.cbExpand.SelectedIndexChanged += this.SelectedIndexChanged;
            this.cbStructType.SelectedIndexChanged += this.SelectedIndexChanged;
        }

        /// <summary>
        /// 入力データ検証
        /// </summary>
        /// <returns></returns>
        public bool IsValidate()
        {
            var header = this.RDataInfo.HeaderInfo;
            this.GetHeader(header);

            // 新規の場合
            if (!this.EditMode)
            {
                // サブシステムＩＤ
                var subSysId = this.cbSubSysId.Text;
                if (string.IsNullOrWhiteSpace(subSysId))
                {
                    MessageBox.Show("サブシステムＩＤは必須入力項目です。",
                        Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

                // テーブルＩＤ
                var tableId = this.txtTableId.Text;
                if (string.IsNullOrWhiteSpace(tableId))
                {
                    MessageBox.Show("テーブルＩＤは必須入力項目です。",
                        Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

                // システム名
                var sysNm = this.txtSysNm.Text;
                if (string.IsNullOrWhiteSpace(sysNm))
                {
                    MessageBox.Show("システム名は必須入力項目です。", 
                        Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

                // サブシステム名
                var subSysNm = this.txtSubSysNm.Text;
                if (string.IsNullOrWhiteSpace(subSysNm))
                {
                    MessageBox.Show("サブシステム名は必須入力項目です。",
                        Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

                // テーブル名
                var tableNm = this.txtTableNm.Text;
                if (string.IsNullOrWhiteSpace(tableNm))
                {
                    MessageBox.Show("テーブル名は必須入力項目です。",
                        Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
            }

            // ブロック長
            var blkLen = this.txtBlkLen.Text;
            if (string.IsNullOrWhiteSpace(blkLen))
            {
                MessageBox.Show("ブロック長は必須入力項目です。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            int.TryParse(this.txtBlkLen.Text, out int blockLen);
            if ((blockLen + 8) % 512 != 0)
            {
                MessageBox.Show("ブロック長の値が不正です。[ブロック長 =（512*整数 - 8）]",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            // ＲＤＡＴＡファイル名
            var filename = this.txtFilename.Text;
            if (string.IsNullOrWhiteSpace(filename))
            {
                MessageBox.Show("ＲＤＡＴＡファイル名は必須入力項目です。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            else
            {
                // ＭＢ管理テーブルの場合
                if (this.IsMBTable)
                {
                    if (!Utils.IsMBTable(filename))
                    {
                        MessageBox.Show("ＭＢ管理テーブルはＲＤＡＴＡファイル名に「DSTDMB」文字列を含める必要があります。",
                            Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }
                }
                else
                {
                    if (Utils.IsMBTable(filename))
                    {
                        MessageBox.Show("ＭＢ管理テーブルではない時、ＲＤＡＴＡファイル名は「DSTDMB」文字列を含めてはいけません。",
                            Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }
                }
            }

            // ローダ時のソートが"要"の場合
            if ("要".Equals(this.cbSort.Text))
            {
                if (!"要".Equals(this.cbExpand.Text))
                {
                    MessageBox.Show("ローダソート指定時はローダインタフェースが必須です。",
                        Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

                if (!"5".Equals(this.cbStructType.Text))
                {
                    MessageBox.Show("ローダソート指定時は構成タイプ５が必須です。",
                        Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

                if (string.IsNullOrWhiteSpace(this.txtKeyLoc.Text) ||
                    string.IsNullOrWhiteSpace(this.txtKeyLen.Text))
                {
                    MessageBox.Show("ソートが「要」の場合、キー相対位置とキー長は必須入力項目です。",
                        Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
            }

            //４：共通情報部・ユーザ任意情報
            if (!this.IsFieldDefDgvValidate(this.dgvUser, TAB_IDX_USER)) return false;

            //５：エントリ部
            if (!this.IsFieldDefDgvValidate(this.dgvEntryItem, TAB_IDX_ENTRY)) return false;

            // 各長リセット
            this.ResetSize();

            // ユーザ任意情報長
            if (header.UserInfoLen % 4 != 0)
            {
                this.tabGroups.SelectedIndex = TAB_IDX_USER;
                MessageBox.Show("ユーザ任意情報長が４の倍数ではない。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            // エントリ長
            if (header.EntryLen % 4 != 0)
            {
                this.tabGroups.SelectedIndex = TAB_IDX_ENTRY;
                MessageBox.Show("エントリ長が４の倍数ではない。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            // 編集コメント
            if (!this.IsCommentDgvValidate()) return false;

            // ローダ時のソートが"要"の場合
            if ("要".Equals(this.cbSort.Text))
            {
                // ソート要なら入力必須。
                if (int.TryParse(this.txtKeyLoc.Text, out int keyLoc))
                {
                    if (keyLoc < 0 || keyLoc >= header.EntryLen)
                    {
                        MessageBox.Show("キー相対位置の値が不正です。",
                            Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }
                }

                if (int.TryParse(this.txtKeyLen.Text, out int keyLen))
                {
                    if (keyLen <= 0 || keyLoc + keyLen > header.EntryLen)
                    {
                        MessageBox.Show("キー長の値が不正です。",
                            Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }
                }
            }

            return true;
        }

        private void NumbericTextbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) &&
                !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void AlpahNumbericTextbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) &&
                !char.IsLetter(e.KeyChar) &&
                !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void SelectedIndexChanged(object sender, EventArgs e)
        {
            this.ResetSize();
        }
        #endregion

        #region 情報部

        #region データグリッドイベント
        private void CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex < 0) return;

            if (!(sender is DataGridView)) return;

            var dgv = sender as DataGridView;
            var curRow = dgv.Rows[e.RowIndex];

            if (e.Button == MouseButtons.Left)
            {
                ReadOnly.Set(this.GetDataGridViewType(dgv), curRow, e.ColumnIndex);
                return;
            }

            // メニュー表示
            if (!this.CheckMouseClick(dgv)) return;

            this.SetMenuVisible(curRow);
            var cellRect = dgv.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, false);
            this.DgvAddDelMenu.Tag = curRow;
            this.DgvAddDelMenu.Show(dgv, new Point(cellRect.X + e.X, cellRect.Y + e.Y));
        }

        private void DgvMouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Right) return;

            if (!(sender is DataGridView)) return;

            // メニュー表示
            var dgv = sender as DataGridView;
            if (!this.CheckMouseClick(dgv)) return;

            this.SetMenuVisible(null);
            var dgvRect = dgv.DisplayRectangle;
            this.DgvAddDelMenu.Tag = dgv;
            this.DgvAddDelMenu.Show(dgv, new Point(dgvRect.X + e.X, dgvRect.Y + e.Y));
        }

        /// <summary>
        /// 上へ追加メニュー処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void AddBeforeMenuItem_Click(object sender, EventArgs e)
        {
            if (this.DgvAddDelMenu.Tag is DataGridViewRow)
            {
                var row = this.DgvAddDelMenu.Tag as DataGridViewRow;
                this.AddNewItem(row.DataGridView, row.Index);
            }
        }

        /// <summary>
        /// 下へ追加メニュー処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void AddAfterMenuItem_Click(object sender, EventArgs e)
        {
            if (this.DgvAddDelMenu.Tag is DataGridViewRow)
            {
                var row = this.DgvAddDelMenu.Tag as DataGridViewRow;
                this.AddNewItem(row.DataGridView, row.Index + 1);
            }
        }

        /// <summary>
        /// 追加メニュー処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void AddMenuItem_Click(object sender, EventArgs e)
        {
            if (this.DgvAddDelMenu.Tag is DataGridViewRow)
            {
                var row = this.DgvAddDelMenu.Tag as DataGridViewRow;
                var dgv = row.DataGridView;
                this.AddNewItem(dgv, dgv.Rows.Count);

                dgv.FirstDisplayedScrollingRowIndex = dgv.Rows.Count - 1;
            }
            else if (this.DgvAddDelMenu.Tag is DataGridView)
            {
                var dgv = this.DgvAddDelMenu.Tag as DataGridView;
                this.AddNewItem(dgv, dgv.Rows.Count);

                dgv.FirstDisplayedScrollingRowIndex = dgv.Rows.Count - 1;
            }
        }

        /// <summary>
        /// 削除メニュー処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void DelMenuItem_Click(object sender, EventArgs e)
        {
            if (this.DgvAddDelMenu.Tag is DataGridViewRow)
            {
                var dgv = (this.DgvAddDelMenu.Tag as DataGridViewRow).DataGridView;

                var row = this.DgvAddDelMenu.Tag as DataGridViewRow;
                // エントリ一覧の場合
                if (dgv == this.dgvEntry)
                {
                    // ＭＢ管理テーブル場合、１６行単位で削除する
                    if (this.IsMBTable)
                    {
                        var startIdx = (row.Index / 16) * 16;
                        var endIdx = startIdx + 16;

                        var rows = this.dgvEntry.Rows.Cast<DataGridViewRow>()
                            .Where(r => r.Index >= startIdx && r.Index < endIdx);
                        rows.ToList().ForEach(r => RowUtils.SetDelete(r));
                    }
                    else
                    {
                        RowUtils.SetDelete(row);
                    }

                    this.ResetEntryNo(dgv);
                    if (row.Index == this.EntryRowIndex)
                    {
                        this.dgvEntryComment.Rows.Clear();
                        this.dgvEntryItem.Rows.Clear();
                    }
                }
                else
                {
                    RowUtils.SetDelete(row);
                }

                this.ResetSize();
            }
        }

        /// <summary>
        /// 回復メニュー処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void UnDelMenuItem_Click(object sender, EventArgs e)
        {
            if (this.DgvAddDelMenu.Tag is DataGridViewRow)
            {
                var dgv = (this.DgvAddDelMenu.Tag as DataGridViewRow).DataGridView;
                if (dgv != this.dgvEntry) return;

                var row = this.DgvAddDelMenu.Tag as DataGridViewRow;

                // ＭＢ管理テーブル場合、１６行単位で削除する
                if (this.IsMBTable)
                {
                    var startIdx = (row.Index / 16) * 16;
                    var endIdx = startIdx + 16;

                    var rows = this.dgvEntry.Rows.Cast<DataGridViewRow>()
                        .Where(r => r.Index >= startIdx && r.Index < endIdx);
                    rows.ToList().ForEach(r => RowUtils.UnDelete(r));
                }
                else
                {
                    RowUtils.UnDelete(row);
                }

                this.ResetEntryNo(dgv);
                this.ResetSize();

                if (row.Index == this.EntryRowIndex)
                {
                    // 選択されたエントリ情報が画面に表示する
                    this.ShowEntryInfo(row);
                }
            }
        }

        private void DgvEntry_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            this.DgvEntry_CellEnter(sender, e);
        }

        private void DgvEntry_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            //５：エントリ部
            if (this.EntryRowIndex != e.RowIndex && !this.IsFieldDefDgvValidate(this.dgvEntryItem, TAB_IDX_ENTRY))
            {
                this.dgvEntry.Rows[e.RowIndex].Selected = false;
                this.dgvEntry.Rows[this.EntryRowIndex].Cells[0].Selected = true;

                return;
            }

            // 一覧からエントリ情報取得
            this.GetEntryInfo(false);
            this.ResetSize();

            this.EntryRowIndex = e.RowIndex;

            // 選択されたエントリ情報が画面に表示する
            this.ShowEntryInfo(this.dgvEntry.CurrentRow);
        }

        private void Item_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.Value == null) return;
            switch (e.ColumnIndex)
            {
                // 項目名
                case ITEMCOL_ITEMNM:
                    if (Utils.IsFiller(e.Value.ToString()))
                    {
                        e.Value = Utils.FILLER;
                        if (sender is DataGridView)
                        {
                            var row = (sender as DataGridView).Rows[e.RowIndex];
                            // データ内容
                            row.Cells[ITEMCOL_DATA].Value = string.Empty;
                            // チェック種別
                            row.Cells[ITEMCOL_CHKTYPE].Value = string.Empty;
                            // コメント
                            row.Cells[ITEMCOL_COMMENT].Value = string.Empty;
                        }
                    }
                    break;

                // データ型
                case ITEMCOL_DATATYPE:
                    e.Value = e.Value.ToString().ToUpper();
                    break;

                default:
                    break;
            }
        }

        private void Item_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            var value = e.FormattedValue.ToString();
            if (string.IsNullOrWhiteSpace(value)) return;

            switch(e.ColumnIndex)
            {
                // データ型
                case ITEMCOL_DATATYPE:
                    if (!Utils.IsAlpahNum(value))
                    {
                        MessageBox.Show("データ型は英数字を入力してください。",
                            Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        e.Cancel = true;
                    }
                    break;

                // サイズ
                case ITEMCOL_SIZE:
                    if (!Utils.IsNum(value))
                    {
                        MessageBox.Show("サイズは数値を入力してください。",
                            Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        e.Cancel = true;
                    }
                    break;

                default:
                    break;
            }
        }
        #endregion

        private void SetMenuVisible(DataGridViewRow row)
        {
            var showMenus = new List<string>();
            if (row == null)
            {
                // 追加
                showMenus.Add("Add");
            }
            else
            {
                var dgv = row.DataGridView;
                if (dgv == this.dgvEntry)
                {
                    var showDelOrUnDel = false;
                    // ＭＢ管理テーブルの場合、新規行編集できる
                    if (this.IsMBTable)
                    {
                        // 追加
                        showMenus.Add("Add");
                        showDelOrUnDel = (RowUtils.IsDelete(row) || RowUtils.IsNew(row));
                    }
                    else
                    {
                        // 上へ追加
                        showMenus.Add("AddBefore");
                        // 下へ追加
                        showMenus.Add("AddAfter");
                        showDelOrUnDel = true;
                    }

                    if (showDelOrUnDel)
                    {
                        // 削除
                        if (!RowUtils.IsDelete(row))
                        {
                            showMenus.Add("Delete");
                        }
                        // 回復
                        else
                        {
                            showMenus.Add("UnDelete");
                        }
                    }
                }
                else
                {
                    // 上へ追加
                    showMenus.Add("AddBefore");
                    // 下へ追加
                    showMenus.Add("AddAfter");
                    // 削除
                    if (!RowUtils.IsDelete(row))
                    {
                        showMenus.Add("Delete");
                    }
                }
            }

            var menuItems = this.DgvAddDelMenu.Items.Cast<ToolStripMenuItem>();
            menuItems.ToList().ForEach(r => r.Visible = showMenus.Contains(r.Tag));
        }

        /// <summary>
        /// データグリッド種類を取得
        /// </summary>
        /// <param name="dgv"></param>
        /// <returns></returns>
        private int GetDataGridViewType(DataGridView dgv)
        {
            if (dgv == this.dgvEntry)
            {
                return this.IsMBTable ? ReadOnly.MBENTRY : ReadOnly.ENTRY;
            }

            if (dgv == this.dgvEntryItem) return ReadOnly.ENTRY_ITEM;

            if (dgv == this.dgvEntryComment) return ReadOnly.ENTRY_COMMENT;

            if (dgv == this.dgvUser) return ReadOnly.USER_ITEM;

            return -1;
        }

        /// <summary>
        /// 選択されたエントリ情報が画面に表示する
        /// </summary>
        /// <param name="row"></param>
        private void ShowEntryInfo(DataGridViewRow row)
        {
            if (RowUtils.IsDelete(row))
            {
                this.dgvEntryItem.Rows.Clear();
                this.dgvEntryComment.Rows.Clear();
                return;
            }

            var record = RowUtils.GetData<RecordInfo>(row);
            if (record == null)
            {
                record = new RecordInfo();
                RowUtils.SetData<RecordInfo>(row, record);
            }

            this.SetEditComment(record.EditCommentList);

            var delComment = RowUtils.GetValue(row, ENTRYCOL_DELCOMMENT);
            // ＭＢ管理テーブル場合 または 該当するエントリが削除されない場合
            if (this.IsMBTable || string.IsNullOrWhiteSpace(delComment))
            {
                this.SetItems(this.dgvEntryItem, record);
            }
            else
            {
                this.dgvEntryItem.Rows.Clear();
            }
        }

        /// <summary>
        /// エントリ一覧の空白判定
        /// </summary>
        /// <param name="dgv"></param>
        /// <returns></returns>
        private bool CheckMouseClick(DataGridView dgv)
        {
            if (dgv != this.dgvEntryItem && dgv != this.dgvEntryComment) return true;

            if (this.dgvEntry.Rows.Count == 0)
            {
                MessageBox.Show("エントリ一覧にエントリレコードを追加してください。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (this.EntryRowIndex < 0 || this.EntryRowIndex >= this.dgvEntry.Rows.Count) return true;
            var row = this.dgvEntry.Rows[this.EntryRowIndex];

            var deletedMsg = "エントリ一覧で選択したエントリは削除されているため操作できません。";
            if (RowUtils.IsDelete(row))
            {
                MessageBox.Show(deletedMsg, Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (dgv == this.dgvEntryItem)
            {
                var record = RowUtils.GetData<RecordInfo>(row);
                if (!this.IsMBTable &&
                    record != null &&
                    !string.IsNullOrWhiteSpace(record.DelComment))
                {
                    MessageBox.Show(deletedMsg, Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 一覧に新しい行を追加する
        /// </summary>
        /// <param name="dgv"></param>
        /// <param name="index"></param>
        private void AddNewItem(DataGridView dgv, int index)
        {
            var fields = new List<string>();

            if (dgv == this.dgvEntry)
            {
                // 一覧からエントリ情報取得
                this.GetEntryInfo(false);

                var count = 1;
                // ＭＢ管理テーブル場合、１６行追加する
                if (this.IsMBTable) count = 16;

                for (var i = 0; i < count; i++)
                {
                    // エントリ番号
                    fields.Add(string.Empty);
                    // エントリコメント
                    fields.Add(string.Empty);
                    // 削除コメント
                    fields.Add(string.Empty);

                    dgv.Rows.Insert(index, fields.ToArray());
                    RowUtils.SetNew(dgv.Rows[index]);
                }

                this.ResetEntryNo(dgv);
                this.ResetSize();
            }
            else if (dgv == this.dgvEntryComment)
            {
                // コメントフラグ
                fields.Add(string.Empty);
                // コメント内容
                fields.Add(string.Empty);

                dgv.Rows.Insert(index, fields.ToArray());
                RowUtils.SetNew(dgv.Rows[index]);
            }
            else
            {
                // 項目名
                fields.Add(string.Empty);
                // データ型
                fields.Add(string.Empty);
                // サイズ
                fields.Add(string.Empty);
                // データ内容
                fields.Add(string.Empty);
                // チェック種別
                fields.Add(string.Empty);
                // コメント
                fields.Add(string.Empty);

                dgv.Rows.Insert(index, fields.ToArray());
                RowUtils.SetNew(dgv.Rows[index]);
            }
        }

        /// <summary>
        /// 各データ長再計算
        /// </summary>
        private void ResetSize()
        {
            var header = this.RDataInfo.HeaderInfo;

            // 一覧からエントリ項目情報取得
            this.GetEntryItemInfo();
            // エントリ長計算
            var fieldDefList = this.RDataInfo.GroupEntry.FieldDefList;
            header.EntryLen = fieldDefList.Sum(r => r.IntSize);

            // エントリ数計算
            var entryRows = this.dgvEntry.Rows.Cast<DataGridViewRow>().Where(r => !RowUtils.IsDelete(r));
            // ＭＢ管理テーブルの場合
            if (this.IsMBTable)
            {
                header.EntryCnt = 0;

                var records = entryRows.Select(r =>
                {
                    var record = RowUtils.GetData<RecordInfo>(r);
                    if (record != null) record.DelComment = RowUtils.GetValue(r, ENTRYCOL_DELCOMMENT);
                    return record;
                }).ToList();

                var count = records.Count();
                for (var i = 0; i < count; i++)
                {
                    var record = records[i];

                    if (record != null && 
                        string.IsNullOrEmpty(record.DelComment) &&
                        !record.IsEmpty(fieldDefList))
                    {
                        header.EntryCnt = i + 1;
                    }
                }
            }
            else
            {
                header.EntryCnt = entryRows.Where(
                    r => string.IsNullOrEmpty(RowUtils.GetValue(r, ENTRYCOL_DELCOMMENT))).Count();
            }

            // 任意情報長
            header.UserInfoLen = this.dgvUser.Rows.Cast<DataGridViewRow>()
                .Where(r => !RowUtils.IsDelete(r))
                .Sum(r => RowUtils.GetIntValue(r, ITEMCOL_SIZE));

            // 共通情報長
            header.CommonInfoLen = 32 + header.UserInfoLen;

            // 最大エントリ数
            if (int.TryParse(this.txtMaxEntryCnt.Text, out int maxEntryCnt))
            {
                header.MaxEntryCnt = maxEntryCnt;
            }
            if (header.MaxEntryCnt < header.EntryCnt)
            {
                header.MaxEntryCnt = header.EntryCnt;
                this.txtMaxEntryCnt.Text = header.EntryCnt.ToString();
            }

            // 構成タイプが5の場合
            if ("5".Equals(this.cbStructType.Text))
            {
                header.TableAllLen = 8 + header.CommonInfoLen + header.MaxEntryCnt * header.EntryLen + 8;
            }
            else
            {
                header.TableAllLen = header.CommonInfoLen + header.MaxEntryCnt * header.EntryLen;
            }

            // ローダインタフェース
            this.ResetInterfaceDgv();

            // 制御情報部１
            this.ResetCtrl1Dgv();

            // 共通情報部
            this.ResetCommonDgv();
        }

        /// <summary>
        /// ローダインタフェースリセット
        /// </summary>
        private void ResetInterfaceDgv()
        {
            // ローダインタフェース
            this.dgvInterface.Rows.Clear();

            if ("要".Equals(this.cbExpand.Text))
            {
                var fields = new List<string> { "レコード数", "BIN", "4", "1",
                    string.Empty, string.Empty };
                var index = this.dgvInterface.Rows.Add(fields.ToArray());
                RowUtils.SetNew(this.dgvInterface.Rows[index]);

                var header = this.RDataInfo.HeaderInfo;
                fields = new List<string> { "データ長", "BIN", "4", header.TableAllLen.ToString(),
                    string.Empty, string.Empty };
                index = this.dgvInterface.Rows.Add(fields.ToArray());
                RowUtils.SetNew(this.dgvInterface.Rows[index]);
            }
        }

        /// <summary>
        /// 新規モード初期化処理
        /// </summary>
        private void InitNewInsert()
        {
            // 制御情報部１
            var fields = new List<string> { "ブロック長", "BIN", "4", string.Empty,
                string.Empty, string.Empty };
            var index = this.dgvCtrl1.Rows.Add(fields.ToArray());
            RowUtils.SetNew(this.dgvCtrl1.Rows[index]);

            fields = new List<string> { "チェックＩＤ１", "BIN", "4", "1",
                string.Empty, string.Empty };
            index = this.dgvCtrl1.Rows.Add(fields.ToArray());
            RowUtils.SetNew(this.dgvCtrl1.Rows[index]);

            // 共通情報部
            fields = new List<string> { "テーブルＩＤ", "CHAR", "8", string.Empty,
                string.Empty, string.Empty };
            index = this.dgvCommon.Rows.Add(fields.ToArray());
            RowUtils.SetNew(this.dgvCommon.Rows[index]);

            fields = new List<string> { "共通情報長", "BIN", "4", string.Empty,
                string.Empty, string.Empty };
            index = this.dgvCommon.Rows.Add(fields.ToArray());
            RowUtils.SetNew(this.dgvCommon.Rows[index]);

            fields = new List<string> { "最大エントリ数", "BIN", "4", string.Empty,
                string.Empty, string.Empty };
            index = this.dgvCommon.Rows.Add(fields.ToArray());
            RowUtils.SetNew(this.dgvCommon.Rows[index]);

            fields = new List<string> { "エントリ数", "BIN", "4", string.Empty,
                string.Empty, string.Empty };
            index = this.dgvCommon.Rows.Add(fields.ToArray());
            RowUtils.SetNew(this.dgvCommon.Rows[index]);

            fields = new List<string> { "エントリ長", "BIN", "4", string.Empty,
                string.Empty, string.Empty };
            index = this.dgvCommon.Rows.Add(fields.ToArray());
            RowUtils.SetNew(this.dgvCommon.Rows[index]);

            fields = new List<string> { "テーブル種別", "CHAR", "4", "TEXT",
                string.Empty, string.Empty };
            index = this.dgvCommon.Rows.Add(fields.ToArray());
            RowUtils.SetNew(this.dgvCommon.Rows[index]);

            fields = new List<string> { "可変長フラグ", "CHAR", "1", "0",
                string.Empty, string.Empty };
            index = this.dgvCommon.Rows.Add(fields.ToArray());
            RowUtils.SetNew(this.dgvCommon.Rows[index]);

            fields = new List<string> { "インデックスフラグ", "CHAR", "1", "0",
                string.Empty, string.Empty };
            index = this.dgvCommon.Rows.Add(fields.ToArray());
            RowUtils.SetNew(this.dgvCommon.Rows[index]);

            fields = new List<string> { "FILLER", "HEX", "2", "0000",
                string.Empty, string.Empty };
            index = this.dgvCommon.Rows.Add(fields.ToArray());
            RowUtils.SetNew(this.dgvCommon.Rows[index]);

            // 制御情報部２
            fields = new List<string> { "チェックＩＤ２", "BIN", "4", "1",
                string.Empty, string.Empty };
            index = this.dgvCtrl2.Rows.Add(fields.ToArray());
            RowUtils.SetNew(this.dgvCtrl2.Rows[index]);

            fields = new List<string> { "FILLER", "BIN", "4", string.Empty,
                string.Empty, string.Empty };
            index = this.dgvCtrl2.Rows.Add(fields.ToArray());
            RowUtils.SetNew(this.dgvCtrl2.Rows[index]);
        }

        /// <summary>
        /// 制御情報部１リセット
        /// </summary>
        private void ResetCtrl1Dgv()
        {
            if (this.dgvCtrl1.Rows.Count <= 0) return;
            var lenRow = this.dgvCtrl1.Rows[0];
            if (lenRow == null) return;

            lenRow.Cells[ITEMCOL_ITEMNM].Value = this.IsMBTable ? "ブロック長" : "全体長";
            lenRow.Cells[ITEMCOL_DATA].Value = this.RDataInfo.HeaderInfo.TableAllLen;
        }

        /// <summary>
        /// 共通情報部リセット
        /// </summary>
        private void ResetCommonDgv()
        {
            var header = this.RDataInfo.HeaderInfo;
            this.dgvCommon.Rows.Cast<DataGridViewRow>().ToList()
                .ForEach(
                r=>
                {
                    switch(RowUtils.GetValue(r, ITEMCOL_ITEMNM))
                    {
                        case "テーブルＩＤ":
                            r.Cells[ITEMCOL_DATA].Value = header.TableId;
                            break;

                        case "共通情報長":
                            r.Cells[ITEMCOL_DATA].Value = header.CommonInfoLen;
                            break;

                        case "最大エントリ数":
                            r.Cells[ITEMCOL_DATA].Value = header.MaxEntryCnt;
                            break;

                        case "エントリ数":
                            r.Cells[ITEMCOL_DATA].Value = header.EntryCnt;
                            break;

                        case "エントリ長":
                            r.Cells[ITEMCOL_DATA].Value = header.EntryLen;
                            break;

                        default:
                            break;
                    }
                });
        }

        /// <summary>
        /// エントリレコードの番号を揃え
        /// </summary>
        /// <param name="dgv"></param>
        private void ResetEntryNo(DataGridView dgv)
        {
            if (dgv != this.dgvEntry) return;

            // 削除された行対象外
            var rows = dgv.Rows.Cast<DataGridViewRow>();

            var entryNo = 1;
            rows.Where(r => !RowUtils.IsDelete(r)).ToList().ForEach(
                r =>
                {
                    // ＭＢ管理テーブルの場合
                    if (this.IsMBTable)
                    {
                        var strEntryNo = Utils.ToZenkaku(entryNo.ToString());
                        var newRow = RowUtils.IsNew(r) ? "(追)" : string.Empty;
                        r.Cells[ENTRYCOL_COMMENT].Value = $"ＤＳＭＢ管理Ｔエントリ（{strEntryNo}）{newRow}";
                    }

                    r.Cells[ENTRYCOL_NO].Value = entryNo++;
                });

            var rowCnt = dgv.Rows.Count;
            if (rowCnt == 0)
            {
                this.EntryRowIndex = -1;
            }
            else if (this.EntryRowIndex == -1)
            {
                var selectedRow = rows.Where(r => r.Cells[0].Selected).Take(1);
                if (selectedRow.Count() == 0)
                {
                    this.EntryRowIndex = 0;
                    rows.ToList()[0].Cells[0].Selected = true;
                }
                else
                {
                    this.EntryRowIndex = selectedRow.ElementAt(0).Index;
                }
            }
        }

        /// <summary>
        /// 画面で入力した項目定義を検証する
        /// </summary>
        /// <param name="dgv"></param>
        /// <param name="tabIndex"></param>
        /// <returns></returns>
        private bool IsFieldDefDgvValidate(DataGridView dgv, int tabIndex)
        {
            var rows = dgv.Rows.Cast<DataGridViewRow>().Where(r => !RowUtils.IsDelete(r));

            // 項目名
            if (rows.Any(r => string.IsNullOrEmpty(RowUtils.GetValue(r, ITEMCOL_ITEMNM))))
            {
                this.tabGroups.SelectedIndex = tabIndex;
                MessageBox.Show("項目名は必須入力項目です。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            // データ型
            if (rows.Any(r => string.IsNullOrEmpty(RowUtils.GetValue(r, ITEMCOL_DATATYPE))))
            {
                this.tabGroups.SelectedIndex = tabIndex;
                MessageBox.Show("データ型は必須入力項目です。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            // サイズ
            if (rows.Any(r => string.IsNullOrEmpty(RowUtils.GetValue(r, ITEMCOL_SIZE))))
            {
                this.tabGroups.SelectedIndex = tabIndex;
                MessageBox.Show("サイズは必須入力項目です。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            var jisEncode = Encoding.GetEncoding("Shift_JIS");
            foreach (var row in rows)
            {
                var value = RowUtils.GetValue(row, ITEMCOL_DATA);
                if (string.IsNullOrEmpty(value)) continue;

                var itemName = RowUtils.GetValue(row, ITEMCOL_ITEMNM);
                var dataType = RowUtils.GetValue(row, ITEMCOL_DATATYPE).ToUpper();
                var size = RowUtils.GetIntValue(row, ITEMCOL_SIZE);

                switch (dataType)
                {
                    case "HEX":
                        {
                            var bytes = jisEncode.GetBytes(value).Length / 2;
                            if (bytes > size)
                            {
                                this.tabGroups.SelectedIndex = tabIndex;
                                MessageBox.Show($"{itemName}はデータ内容が{size}バイトを超過する。",
                                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return false;
                            }
                        }
                        break;

                    case "CHAR":
                        {
                            var bytes = jisEncode.GetBytes(value).Length;
                            if (bytes > size)
                            {
                                this.tabGroups.SelectedIndex = tabIndex;
                                MessageBox.Show($"{itemName}はデータ内容が{size}バイトを超過する。",
                                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return false;
                            }
                        }
                        break;

                    default:
                        break;
                }
            }

            return true;
        }

        /// <summary>
        /// 画面で入力した改修コメントを検証する
        /// </summary>
        /// <returns></returns>
        private bool IsCommentDgvValidate()
        {
            var rows = this.dgvEntryComment.Rows.Cast<DataGridViewRow>()
                .Where(r => !RowUtils.IsDelete(r));

            // コメントフラグ
            if (rows.Any(r => string.IsNullOrEmpty(RowUtils.GetValue(r, COMMCOL_FLG))))
            {
                this.tabGroups.SelectedIndex = TAB_IDX_ENTRY;
                MessageBox.Show("改修コメントフラグは必須入力項目です。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            // コメント内容
            if (rows.Any(r => string.IsNullOrEmpty(RowUtils.GetValue(r, COMMCOL_CONTEXT))))
            {
                this.tabGroups.SelectedIndex = TAB_IDX_ENTRY;
                MessageBox.Show("改修コメント内容は必須入力項目です。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        /// <summary>
        /// 画面からＲＤＡＴＡ情報を取得
        /// </summary>
        /// <param name="rdataInfo"></param>
        /// <returns></returns>
        public RDataInfo GetForm(RDataInfo rdataInfo)
        {
            this.GetHeader(rdataInfo.HeaderInfo);

            // ローダインタフェース情報部
            Group group = rdataInfo.Interface;
            this.dgvInterface.Tag = group;
            group.RecordList.Clear();
            var record = new RecordInfo();
            if (this.GetItems(this.dgvInterface, record))
            {
                group.RecordList.Add(record);
            }

            // 制御情報部１
            group = rdataInfo.GroupCtrl1;
            this.dgvCtrl1.Tag = group;
            group.RecordList.Clear();
            record = new RecordInfo();
            if (this.GetItems(this.dgvCtrl1, record))
            {
                group.RecordList.Add(record);
            }

            // 共通情報部
            group = rdataInfo.GroupCommon;
            this.dgvCommon.Tag = group;
            group.RecordList.Clear();
            record = new RecordInfo();
            this.GetItems(this.dgvCommon, record);
            group.RecordList.Add(record);

            // ユーザ任意情報
            group = rdataInfo.GroupUser;
            this.dgvUser.Tag = group;
            group.RecordList.Clear();
            record = new RecordInfo();
            if (this.GetItems(this.dgvUser, record))
            {
                group.RecordList.Add(record);
            }

            // エントリ
            group = rdataInfo.GroupEntry;
            this.dgvEntryItem.Tag = group;
            this.GetEntryInfo(true);

            // 制御情報部２
            group = rdataInfo.GroupCtrl2;
            this.dgvCtrl2.Tag = group;
            group.RecordList.Clear();
            record = new RecordInfo();
            this.GetItems(this.dgvCtrl2, record);
            group.RecordList.Add(record);

            return rdataInfo;
        }

        /// <summary>
        /// 画面から項目情報を取得
        /// </summary>
        /// <param name="dgv"></param>
        /// <param name="record"></param>
        /// <returns></returns>
        private bool GetItems(DataGridView dgv, RecordInfo record)
        {
            if (dgv == null || !(dgv.Tag is Group) || record == null) return false;

            var group = dgv.Tag as Group;
            var recordList = group.RecordList;
            recordList.Clear();
            var fieldDefList = group.FieldDefList;
            fieldDefList.Clear();

            // 削除された行対象外
            var rows = dgv.Rows.Cast<DataGridViewRow>().Where(r => !RowUtils.IsDelete(r));
            foreach (DataGridViewRow row in rows)
            {
                var fieldDef = RowUtils.GetData<FieldDefine>(row);
                if (fieldDef == null)
                {
                    fieldDef = new FieldDefine();
                }
                // 項目名
                fieldDef.ItemName = RowUtils.GetValue(row, ITEMCOL_ITEMNM);
                // データ型
                fieldDef.DataAttr = RowUtils.GetValue(row, ITEMCOL_DATATYPE);
                // サイズ
                fieldDef.Size = RowUtils.GetValue(row, ITEMCOL_SIZE);
                fieldDefList.Add(fieldDef);

                var field = new FieldInfo(fieldDef.Key)
                {
                    // データ内容
                    Value = RowUtils.GetValue(row, ITEMCOL_DATA),
                    // チェック種別
                    CheckType = RowUtils.GetValue(row, ITEMCOL_CHKTYPE),
                    // コメント
                    Comment = RowUtils.GetValue(row, ITEMCOL_COMMENT)
                };
                record.Add(field);
            }

            return fieldDefList.Count > 0;
        }

        /// <summary>
        /// 画面からエントリ項目情報を取得
        /// </summary>
        /// <param name="dgv"></param>
        /// <param name="record"></param>
        /// <returns></returns>
        private bool GetEntryItems(RecordInfo record)
        {
            var dgv = this.dgvEntryItem;
            if (dgv == null || !(dgv.Tag is Group) || record == null) return false;

            var rows = dgv.Rows.Cast<DataGridViewRow>();
            if (rows.Count() == 0 || rows.All(r => RowUtils.IsDelete(r))) return false;

            var group = dgv.Tag as Group;
            var recordList = group.RecordList;
            var fieldDefList = group.FieldDefList;
            fieldDefList.Clear();

            var delRows = rows.Where(r => RowUtils.IsDelete(r) && RowUtils.HasData(r));
            foreach (DataGridViewRow row in delRows)
            {
                var fieldDef = RowUtils.GetData<FieldDefine>(row);
                foreach (var entryRecord in recordList)
                {
                    entryRecord.Remove(fieldDef.Key);
                }
            }

            // 削除された行対象外
            rows = rows.Where(r => !RowUtils.IsDelete(r));
            foreach (DataGridViewRow row in rows)
            {
                // 項目名
                var itemName = RowUtils.GetValue(row, ITEMCOL_ITEMNM);
                // データ型
                var dataAttr = RowUtils.GetValue(row, ITEMCOL_DATATYPE);
                // サイズ
                var size = RowUtils.GetValue(row, ITEMCOL_SIZE);
                // データ内容
                var value = RowUtils.GetValue(row, ITEMCOL_DATA);
                // チェック種別
                var chkType = RowUtils.GetValue(row, ITEMCOL_CHKTYPE);
                // コメント
                var comment = RowUtils.GetValue(row, ITEMCOL_COMMENT);

                var fieldDef = RowUtils.GetData<FieldDefine>(row);
                if (fieldDef == null)
                {
                    fieldDef = new FieldDefine
                    {
                        ItemName = itemName,
                        DataAttr = dataAttr,
                        Size = size
                    };

                    var field = new FieldInfo(fieldDef.Key)
                    {
                        Value = value,
                        CheckType = chkType,
                        Comment = comment
                    };
                    record.Add(field);
                }
                else
                {
                    fieldDef.ItemName = itemName;
                    fieldDef.DataAttr = dataAttr;
                    fieldDef.Size = size;

                    var field = record[fieldDef.Key];
                    if (field == null)
                    {
                        field = new FieldInfo(fieldDef.Key);
                        record.Add(field);
                    }

                    field.Value = value;
                    field.CheckType = chkType;
                    field.Comment = comment;
                }

                fieldDefList.Add(fieldDef);
            }

            return fieldDefList.Count > 0;
        }

        /// <summary>
        /// 一覧からエントリ項目情報取得
        /// </summary>
        private void GetEntryItemInfo()
        {
            if (this.EntryRowIndex < 0) return;

            var curRow = this.dgvEntry.Rows[this.EntryRowIndex];
            if (RowUtils.IsDelete(curRow)) return;
            var delComment = RowUtils.GetValue(curRow, ENTRYCOL_DELCOMMENT);
            if (!this.IsMBTable && !string.IsNullOrWhiteSpace(delComment)) return;

            var curRecord = RowUtils.GetData<RecordInfo>(curRow);
            if (curRecord == null)
            {
                curRecord = new RecordInfo();
                RowUtils.SetData<RecordInfo>(curRow, curRecord);
            }
            this.GetEditComment(curRecord.EditCommentList);

            // ＭＢ管理テーブル場合 または 該当するエントリが削除されない場合
            if (this.IsMBTable || string.IsNullOrWhiteSpace(delComment))
            {
                this.GetEntryItems(curRecord);
            }
        }

        /// <summary>
        /// 一覧からエントリ情報取得
        /// </summary>
        private void GetEntryInfo(bool clearDeleted)
        {
            if (this.EntryRowIndex < 0 || this.EntryRowIndex >= this.dgvEntry.Rows.Count) return;

            // エントリレコードリスト
            var recordList = (this.dgvEntryItem.Tag as Group).RecordList;
            recordList.Clear();

            var rows = this.dgvEntry.Rows.Cast<DataGridViewRow>().Where(r => !RowUtils.IsDelete(r));
            foreach (DataGridViewRow row in rows)
            {
                var record = RowUtils.GetData<RecordInfo>(row);
                if (record == null)
                {
                    record = new RecordInfo();
                }

                // エントリ番号
                record.EntryNo = RowUtils.GetIntValue(row, ENTRYCOL_NO);
                // エントリコメント
                // ＭＢ管理テーブルの場合
                if (this.IsMBTable)
                {
                    var strEntryNo = Utils.ToZenkaku(record.EntryNo.ToString());
                    record.Comment = $"ＤＳＭＢ管理Ｔエントリ（{strEntryNo}）";
                }
                else
                {
                    record.Comment = RowUtils.GetValue(row, ENTRYCOL_COMMENT);
                }
                // 削除コメント
                record.DelComment = RowUtils.GetValue(row, ENTRYCOL_DELCOMMENT);

                if (clearDeleted && !string.IsNullOrWhiteSpace(record.DelComment))
                {
                    record.Clear();
                }

                recordList.Add(record);
            }

            // 一覧からエントリ項目情報取得
            this.GetEntryItemInfo();
        }

        /// <summary>
        /// 画面から改修コメントを取得
        /// </summary>
        /// <param name="editComments"></param>
        private void GetEditComment(List<EditComment> editComments)
        {
            if (editComments == null) return;

            var dgv = this.dgvEntryComment;

            var rows = dgv.Rows.Cast<DataGridViewRow>().Where(r => !RowUtils.IsDelete(r));

            editComments.Clear();
            var order = 1;
            foreach (DataGridViewRow row in rows)
            {
                var comment = RowUtils.GetData<EditComment>(row);
                if (comment == null)
                {
                    comment = new EditComment();
                }

                // コメントフラグ
                switch (RowUtils.GetValue(row, COMMCOL_FLG))
                {
                    case "1":
                        comment.Flag = CommentFlg.StartEnd;
                        break;

                    case "2":
                        comment.Flag = CommentFlg.Start;
                        break;

                    case "3":
                        comment.Flag = CommentFlg.End;
                        break;

                    default:
                        continue;
                }

                // コメント内容
                var value = RowUtils.GetValue(row, COMMCOL_CONTEXT);
                if (string.IsNullOrEmpty(value)) continue;
                comment.Content = value;

                comment.Order = order++;
                editComments.Add(comment);
            }
        }

        /// <summary>
        /// ＲＤＡＴＡ情報が画面に設定する
        /// </summary>
        /// <param name="rdataInfo"></param>
        public void SetForm(RDataInfo rdataInfo)
        {
            if (rdataInfo == null) return;

            FieldDefine.InitKey();

            this.RDataInfo = rdataInfo;
            this.EntryRowIndex = -1;

            this.lblMbTable.Visible = this.IsMBTable;

            // ローダインタフェース情報部
            Group group = rdataInfo.Interface;
            this.dgvInterface.Tag = group;
            var recordList = group.RecordList;
            if (recordList.Count > 0)
            {
                this.SetItems(this.dgvInterface, recordList.First());
                rdataInfo.HeaderInfo.ExpandFlg = "1";
            }
            else
            {
                rdataInfo.HeaderInfo.ExpandFlg = "0";
            }
            this.SetHeader(rdataInfo.HeaderInfo);

            // 制御情報部１
            group = rdataInfo.GroupCtrl1;
            this.dgvCtrl1.Tag = group;
            recordList = group.RecordList;
            if (recordList.Count > 0)
            {
                this.SetItems(this.dgvCtrl1, recordList.First());
            }
            // 共通情報部
            group = rdataInfo.GroupCommon;
            this.dgvCommon.Tag = group;
            recordList = group.RecordList;
            if (recordList.Count > 0)
            {
                this.SetItems(this.dgvCommon, recordList.First());
            }
            // ユーザ任意情報
            group = rdataInfo.GroupUser;
            this.dgvUser.Tag = group;
            recordList = group.RecordList;
            if (recordList.Count > 0)
            {
                this.SetItems(this.dgvUser, recordList.First());
            }
            // エントリ
            group = rdataInfo.GroupEntry;
            this.SetGroups(this.dgvEntry, group.RecordList);
            this.dgvEntryItem.Tag = group;
            recordList = group.RecordList;
            if (recordList.Count > 0)
            {
                var record = recordList.First();
                // 改修コメント
                this.SetEditComment(record.EditCommentList);
                // エントリ項目情報
                this.SetItems(this.dgvEntryItem, record);
            }
            // 制御情報部２
            group = rdataInfo.GroupCtrl2;
            this.dgvCtrl2.Tag = group;
            recordList = group.RecordList;
            if (recordList.Count > 0)
            {
                this.SetItems(this.dgvCtrl2, recordList.First());
            }

            this.ResetSize();
        }

        /// <summary>
        /// ＲＤＡＴＡの情報部が画面に設定する
        /// </summary>
        /// <param name="dgv"></param>
        /// <param name="records"></param>
        private void SetGroups(DataGridView dgv, List<RecordInfo> records)
        {
            if (dgv == null || records == null) return;

            var fields = new List<string>();
            dgv.Rows.Clear();
            foreach (var record in records)
            {
                fields.Clear();
                // エントリ番号
                fields.Add(record.EntryNo.ToString());
                // エントリコメント
                fields.Add(record.Comment);
                // 削除コメント
                fields.Add(record.DelComment);

                var index = dgv.Rows.Add(fields.ToArray());
                RowUtils.SetData<RecordInfo>(dgv.Rows[index], record);
            }

            this.EntryRowIndex = records.Count > 0 ? 0 : -1;
        }

        /// <summary>
        /// ＲＤＡＴＡの改修コメントが画面に設定する
        /// </summary>
        /// <param name="editComments"></param>
        private void SetEditComment(List<EditComment> editComments)
        {
            if (editComments == null) return;

            var dgv = this.dgvEntryComment;

            var fields = new List<string>();
            dgv.Rows.Clear();
            foreach (var comment in editComments)
            {
                fields.Clear();

                // コメントフラグ
                var flag = "1";
                switch (comment.Flag)
                {
                    case CommentFlg.Start:
                        flag = "2";
                        break;
                    case CommentFlg.End:
                        flag = "3";
                        break;
                    default:
                        break;
                }
                fields.Add(flag);

                // コメント内容
                fields.Add(comment.Content);

                var index = dgv.Rows.Add(fields.ToArray());
                RowUtils.SetData<EditComment>(dgv.Rows[index], comment);
            }
        }

        /// <summary>
        /// ＲＤＡＴＡの項目情報が画面に設定する
        /// </summary>
        /// <param name="dgv"></param>
        /// <param name="record"></param>
        private void SetItems(DataGridView dgv, RecordInfo record)
        {
            if (dgv == null || !(dgv.Tag is Group) || record == null) return;

            dgv.Rows.Clear();

            var group = dgv.Tag as Group;
            var fields = new List<string>();
            foreach (var fieldDef in group.FieldDefList)
            {
                // データ内容
                var value = string.Empty;
                // チェック種別
                var chkType = string.Empty;
                // コメント
                var comment = string.Empty;

                var field = record[fieldDef.Key];
                if (field != null)
                {
                    // データ内容
                    value = field.Value;
                    // チェック種別
                    chkType = field.CheckType;
                    // コメント
                    comment = field.Comment;
                }

                fields.Clear();
                // 項目名
                fields.Add(fieldDef.ItemName);
                // データ型
                fields.Add(fieldDef.DataAttr);
                // サイズ
                fields.Add(fieldDef.Size);
                // データ内容
                fields.Add(value);
                // チェック種別
                fields.Add(chkType);
                // コメント
                fields.Add(comment);

                var index = dgv.Rows.Add(fields.ToArray());
                RowUtils.SetData<FieldDefine>(dgv.Rows[index], fieldDef);
            }
        }
        #endregion
    }

    /// <summary>
    /// 読込専用設定クラス
    /// </summary>
    class ReadOnly
    {
        public const int ENTRY = 1;
        public const int MBENTRY = 2;
        public const int ENTRY_ITEM = 3;
        public const int ENTRY_COMMENT = 4;
        public const int USER_ITEM = 5;

        protected DataGridViewCell Cell { set; get; }

        public ReadOnly(DataGridViewRow row, int colIdx)
        {
            if (row == null || colIdx < 0 || colIdx >= row.Cells.Count) return;

            this.Cell = row.Cells[colIdx];
        }

        public static void Set(int gdvType, DataGridViewRow row, int colIdx)
        {
            if (row == null || colIdx < 0 || colIdx >= row.Cells.Count) return;
            
            switch(gdvType)
            {
                case ENTRY:
                    new EntryReadOnly(row, colIdx).Set();
                    break;

                case MBENTRY:
                    new MBEntryReadOnly(row, colIdx).Set();
                    break;

                case ENTRY_COMMENT:
                    new ReadOnly(row, colIdx).Set();
                    break;

                case ENTRY_ITEM:
                case USER_ITEM:
                    new ItemReadOnly(row, colIdx).Set();
                    break;
                    
                default:
                    break;
            }
        }

        public void Set()
        {
            if (this.Cell == null) return;

            if (RowUtils.IsDelete(this.Cell.OwningRow))
            {
                this.Cell.ReadOnly = true;
            }
            else
            {
                this.Cell.ReadOnly = false;
                this.SetReadOnly();
            }
        }

        protected virtual void SetReadOnly() { }
    }

    /// <summary>
    /// エントリ読込専用設定クラス
    /// </summary>
    class EntryReadOnly : ReadOnly
    {
        public EntryReadOnly(DataGridViewRow row, int colIdx) : base(row, colIdx) { }

        protected override void SetReadOnly()
        {
            switch (this.Cell.ColumnIndex)
            {
                // エントリ番号
                case RDataEditor.ENTRYCOL_NO:
                    this.Cell.ReadOnly = true;
                    break;

                // エントリコメント
                case RDataEditor.ENTRYCOL_COMMENT:
                    // 該当する行が削除された場合、編集することができない
                    var delComment = RowUtils.GetValue(this.Cell.OwningRow, RDataEditor.ENTRYCOL_DELCOMMENT);
                    this.Cell.ReadOnly = !string.IsNullOrWhiteSpace(delComment);
                    break;

                default:
                    break;
            }
        }
    }

    /// <summary>
    /// ＭＢ管理テーブルのエントリ読込専用設定クラス
    /// </summary>
    class MBEntryReadOnly : EntryReadOnly
    {
        public MBEntryReadOnly(DataGridViewRow row, int colIdx) : base(row, colIdx) { }

        protected override void SetReadOnly()
        {
            switch(this.Cell.ColumnIndex)
            {
                // エントリ番号
                case RDataEditor.ENTRYCOL_NO:
                // エントリコメント
                case RDataEditor.ENTRYCOL_COMMENT:
                    this.Cell.ReadOnly = true;
                    break;

                default:
                    break;
            }
        }
    }

    /// <summary>
    /// 項目読込専用設定クラス
    /// </summary>
    class ItemReadOnly : ReadOnly
    {
        public ItemReadOnly(DataGridViewRow row, int colIdx) : base(row, colIdx) { }

        protected override void SetReadOnly()
        {
            switch (this.Cell.ColumnIndex)
            {
                // データ内容
                case RDataEditor.ITEMCOL_DATA:
                // チェック種別
                case RDataEditor.ITEMCOL_CHKTYPE:
                // コメント
                case RDataEditor.ITEMCOL_COMMENT:
                    // 予備の場合、編集することができない
                    var itemNm = RowUtils.GetValue(this.Cell.OwningRow, RDataEditor.ITEMCOL_ITEMNM);
                    this.Cell.ReadOnly = Utils.IsFiller(itemNm);
                    break;

                default:
                    break;
            }
        }
    }
}
