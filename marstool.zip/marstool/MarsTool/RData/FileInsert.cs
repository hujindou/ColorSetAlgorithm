﻿using MarsTool.Common;
using MarsTool.Common.Forms;
using MarsTool.Models;
using MarsTool.Models.DB;
using MarsTool.Properties;
using MarsTool.RData.IO.DB;
using MarsTool.RData.IO.Text;
using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using NLog;

namespace MarsTool.RData
{
    /// <summary>
    /// ファイル登録タブクラス
    /// </summary>
    public class FileInsert
    {
        private Logger Logger = NLog.LogManager.GetCurrentClassLogger();

        /// <summary>
        /// データ一覧コントロール
        /// </summary>
        private DataGridView Dgv { get; set; }
        private CheckDataGridView InsertCheckDgv { get; set; }

        /// <summary>
        /// バージョンモデル
        /// </summary>
        public VersionModel Version { get; private set; }

        /// <summary>
        /// バージョンモデル
        /// </summary>
        protected mysqlcontext Context
        {
            get
            {
                return Version.context;
            }
        }

        /// <summary>
        /// ＲＤＡＴＡファイル格納フォルダ
        /// </summary>
        public string RDataFolder { set; get; }

        private Button BtnInsert { set; get; }
        
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public FileInsert(
            DataGridView dgv,
            CheckBox chkAll,
            Button btnInsert,
            VersionModel version)
        {
            // 登録
            this.Dgv = dgv;
            this.InsertCheckDgv = new CheckDataGridView(dgv, chkAll);
            this.InsertCheckDgv.ChangeStatus += ChangeStatus;
            this.BtnInsert = btnInsert;
            this.Version = version;
        }

        protected void ChangeStatus(bool nodata)
        {
            this.BtnInsert.Enabled = !nodata;
        }

        /// <summary>
        /// 指定フォルダ直下ＲＤＡＴＡファイル名一覧情報をロード
        /// </summary>
        /// <param name="rdataFolder"></param>
        public void Load(string rdataFolder)
        {
            var fields = new List<string>();
            var ext = string.Empty;
            this.InsertCheckDgv.ChkAll.Checked = false;
            this.InsertCheckDgv.ChkAll.Enabled = false;
            this.Dgv.Rows.Clear();
            foreach (var filename in Directory.GetFiles(rdataFolder))
            {
                ext = Path.GetExtension(filename).ToLower();
                switch (ext)
                {
                    case ".csv":
                    case ".txt":
                        break;
                    default:
                        continue;
                }

                fields.Clear();
                // 選択
                fields.Add("0");
                // ＲＤＡＴＡファイル名
                fields.Add(Path.GetFileNameWithoutExtension(filename));
                // ＲＤＡＴＡファイル名
                fields.Add(ext.Substring(1));

                this.Dgv.Rows.Add(fields.ToArray());
            }
            this.RDataFolder = rdataFolder;

            if (this.Dgv.Rows.Count > 0)
            {
                this.InsertCheckDgv.ChkAll.Enabled = true;
            }
            else
            {
                MessageBox.Show("ＲＤＡＴＡファイルが存在しません。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }            
        }

        public bool PreInsert()
        {
            if (!Directory.Exists(this.RDataFolder))
            {
                MessageBox.Show("ＲＤＡＴＡフォルダは必須入力項目です。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        /// <summary>
        /// ＲＤＡＴＡファイルの情報がＤＢに登録
        /// </summary>
        /// <param name="worker"></param>
        /// <param name="e"></param>
        public void Insert(BackgroundWorker worker, DoWorkEventArgs e)
        {
            using (var context = new mysqlcontext(this.Version.ConnectString))
            {
                var dbAccess = new RDataDBAccess(worker, this.Version, context);
                var filename = string.Empty;
                var ext = string.Empty;
                var encoding = Encoding.GetEncoding("Shift_JIS");
                var rows = this.Dgv.Rows.Cast<DataGridViewRow>().Where(r => "1".Equals(r.Cells[0].Value));
                foreach (DataGridViewRow row in rows)
                {
                    row.Cells[0].Value = "0";

                    filename = row.Cells["Filename"].Value.ToString();
                    ext = row.Cells["Extension"].Value.ToString();

                    var statusCell = row.Cells["InsertStatus"];
                    try
                    {
                        statusCell.Style.ForeColor = Color.Blue;
                        statusCell.Value = "処理中。。。";

                        var reader = new RDataFileReader();
                        if (!Utils.IsAlpahNum(filename))
                        {
                            statusCell.Style.ForeColor = Color.Red;
                            statusCell.Value = "ＲＤＡＴＡファイル名が英数字以外。";
                            continue;
                        }
                        if (filename.Length > 16)
                        {
                            statusCell.Style.ForeColor = Color.Red;
                            statusCell.Value = "ＲＤＡＴＡファイル名の長さが16桁を超過する。";
                            continue;
                        }
                        var rdataInfo = reader.Read(this.RDataFolder, filename, ext, encoding);

                        var subSysId = rdataInfo.HeaderInfo.SubSystemId;
                        var tableId = rdataInfo.HeaderInfo.TableId;
                        if (dbAccess.Exists(subSysId, tableId))
                        {
                            statusCell.Style.ForeColor = Color.Red;
                            statusCell.Value = "ＤＢに該当するＲＤＡＴＡ情報が既に存在する。";
                            continue;
                        }

                        dbAccess.Insert(rdataInfo);

                        statusCell.Value = "ＲＤＡＴＡ情報が正常に登録されました。" +
                            "該当するＲＤＡＴＡファイルを出力タブより出力して下さい。";
                    }
                    catch (Exception ex)
                    {
                        statusCell.Style.ForeColor = Color.Red;
                        statusCell.Value = ex.Message;
                        this.Logger.Error(ex.Message);
                    }
                    finally
                    {
                        Application.DoEvents();
                    }
                }
            }

            e.Result = "ファイル登録処理が完了しました。";
        }

        public void AfterInsert()
        {
            var rows = this.Dgv.Rows.Cast<DataGridViewRow>();
            var hasSelectedRow = rows.Any(r => "1".Equals(r.Cells[0].Value));
            this.ChangeStatus(!hasSelectedRow);
            this.InsertCheckDgv.ChkAll.Checked = hasSelectedRow;
        }
    }
}
