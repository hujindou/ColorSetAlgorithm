﻿using MarsTool.Exceptions;
using MarsTool.Models;
using MarsTool.Models.DB;
using MarsTool.Properties;
using MarsTool.RData.Info;
using MarsTool.RData.IO.DB;
using MarsTool.RData.IO.Excel;
using MarsTool.RData.IO.Text;
using System;
using System.ComponentModel;
using System.Configuration;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace MarsTool.RData
{
    /// <summary>
    /// ＲＤＡＴＡ編集タブクラス
    /// </summary>
    public class RDataEdit : EditorBase
    {
        /// <summary>
        /// テンプレートファイル
        /// </summary>
        private string TempFile { set; get; }

        /// <summary>
        /// 出力エリア
        /// </summary>
        private RDataOutput RDataOutput { set; get; }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public RDataEdit(
            RDataEditor rdataEditor,
            RDataOutput rdataOutput,
            VersionModel version) : base(rdataEditor, version)
        {
            this.TempFile = ConfigurationManager.AppSettings["rdataFileTemplateLocation"];
            this.RDataEditor.EditMode = true;
            this.RDataOutput = rdataOutput;
        }

        public bool PreUpdate(RDataInfo rdataInfo)
        {
            if (!this.RDataEditor.IsValidate()) return false;
            this.RDataEditor.GetForm(this.RDataInfo);

            var dbAccess = new RDataDBAccess(this.Version);
            if (!dbAccess.IsRDataChanged(rdataInfo, this.RDataInfo))
            {
                MessageBox.Show("何も編集していないため、更新されませんでした。",
                    Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }

            return true;
        }

        /// <summary>
        /// 更新処理
        /// </summary>
        /// <param name="rdataInfo"></param>
        public void Update(BackgroundWorker worker, DoWorkEventArgs e, RDataInfo rdataInfo)
        {
            try
            {
                using (var context = new mysqlcontext(this.Version.ConnectString))
                {
                    var dbAccess = new RDataDBAccess(worker, this.Version, context);

                    worker.ReportProgress(0);

                    dbAccess.Update(rdataInfo, this.RDataInfo);

                    worker.ReportProgress(100);

                    e.Result = "更新処理が完了しました。\n該当するＲＤＡＴＡファイルを出力タブより出力して下さい。";
                }
            }
            catch (ExclusiveException ee)
            {
                this.Logger.Error(ee.Message);
                e.Result = $"W{ee.Message}";
            }
            catch (Exception ex)
            {
                this.Logger.Error(ex.Message);
                e.Result = $"E{MessageId.TSR00012_E}\n{ex.Message}";
            }
        }

        public bool PreOutput(RDataInfo rdataInfo)
        {
            if (!this.RDataOutput.IsValidate()) return false;
            if (!this.RDataEditor.IsValidate()) return false;

            this.RDataEditor.GetForm(this.RDataInfo);

            var dbAccess = new RDataDBAccess(this.Version);
            if (dbAccess.IsRDataChanged(rdataInfo, this.RDataInfo))
            {
                MessageBox.Show("ＲＤＡＴＡ情報が編集されました、更新してください。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        /// <summary>
        /// ファイル出力
        /// </summary>
        /// <param name="rdataInfo"></param>
        public void Output(BackgroundWorker worker, DoWorkEventArgs e)
        {
            try
            {
                worker.ReportProgress(0);

                if (this.RDataOutput.IsOutputFile) this.OutputFile(this.RDataInfo);
                if (this.RDataOutput.IsOutputExcel) this.OutputExcel(worker, this.RDataInfo);

                worker.ReportProgress(100);

                e.Result = "出力処理が完了しました。";
            }
            catch (Exception ex)
            {
                this.Logger.Error(ex.Message);
                e.Result = $"E{MessageId.TSR00012_E}\n{ex.Message}";
            }
        }

        /// <summary>
        /// ＲＤＡＴＡファイル出力
        /// </summary>
        /// <param name="rdataInfo"></param>
        private void OutputFile(RDataInfo rdataInfo)
        {
            var folder = this.RDataOutput.SelectedPath;
            var headerInfo = rdataInfo.HeaderInfo;
            var filename = $"{headerInfo.Filename}.{headerInfo.Extension}";

            var writer = new RDataFileWriter(rdataInfo);
            writer.Write(Path.Combine(folder, filename), Encoding.GetEncoding("Shift_JIS"));
        }

        /// <summary>
        /// ＲＤＡＴＡ帳票出力
        /// </summary>
        /// <param name="rdataInfo"></param>
        private void OutputExcel(BackgroundWorker worker, RDataInfo rdataInfo)
        {
            var folder = this.RDataOutput.SelectedPath;
            var headerInfo = rdataInfo.HeaderInfo;
            var filename = $"{headerInfo.Filename}.xlsx";
            var fullname = Path.Combine(folder, filename);

            File.Copy(this.TempFile, fullname);

            var writer = new ExcelWriter(rdataInfo);
            writer.Write(worker, fullname);
        }
    }
}
