﻿using MarsTool.Common;

namespace MarsTool.RData.Info
{
    /// <summary>
    /// フィールド定義
    /// </summary>
    public class FieldDefine
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public FieldDefine()
        {
            this._key = NextKey();
        }

        public FieldDefine(FieldDefine fieldDefine)
        {
            // フィールド定義のキー
            this._key = fieldDefine.Key;
            // 項目名
            this.ItemName = fieldDefine.ItemName;
            // データ型
            this.DataAttr = fieldDefine.DataAttr;
            // サイズ
            this.Size = fieldDefine.Size;
        }

        /// <summary>
        /// 採番用キー
        /// </summary>
        private static int nextKey = 0;

        /// <summary>
        /// 採番用キーを初期化
        /// </summary>
        public static void InitKey()
        {
            FieldDefine.nextKey = 0;
        }

        /// <summary>
        /// キーを採番する
        /// </summary>
        /// <returns></returns>
        public static int NextKey()
        {
            return FieldDefine.nextKey++;
        }

        /// <summary>
        /// 項目名
        /// </summary>
        private string _itemName;
        public string ItemName
        {
            set
            {
                this._itemName = Utils.IsFiller(value) ? Utils.FILLER : value;
            }
            get
            {
                return Utils.TrimString(this._itemName);
            }
        }

        /// <summary>
        /// データ属性
        /// </summary>
        private string _dataAttr;
        public string DataAttr
        {
            set
            {
                this._dataAttr = value;
            }
            get
            {
                return Utils.TrimString(this._dataAttr).ToUpper();
            }
        }

        /// <summary>
        /// サイズ
        /// </summary>
        private string _size;
        public string Size
        {
            set
            {
                this._size = value;
            }
            get
            {
                return Utils.TrimString(this._size);
            }
        }
        public int IntSize
        {
            get
            {
                return int.TryParse(this.Size, out int size) ? size : 0;
            }
        }

        /// <summary>
        /// フィールド定義のキー
        /// </summary>
        private int _key = 0;
        public int Key
        {
            get
            {
                return this._key;
            }
        }
    }
}
