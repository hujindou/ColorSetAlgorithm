﻿namespace MarsTool.RData.Info
{
    /// <summary>
    /// ＲＤＡＴＡ情報クラス
    /// </summary>
    public class RDataInfo
    {
        /// <summary>
        /// ＲＤＡＴＡファイルヘッダ部共通情報
        /// </summary>
        private HeaderInfo _headerInfo = new HeaderInfo();
        public HeaderInfo HeaderInfo
        {
            get
            {
                return this._headerInfo;
            }
        }

        /// <summary>
        /// ローダインタフェース情報部
        /// </summary>
        private GroupInterface _groupInterface = null;
        public GroupInterface Interface
        {
            get
            {
                return this._groupInterface;
            }
        }

        /// <summary>
        /// 制御情報部１
        /// </summary>
        private GroupCtrl1 _groupCtrl1 = null;
        public GroupCtrl1 GroupCtrl1
        {
            get
            {
                return this._groupCtrl1;
            }
        }

        /// <summary>
        /// 共通情報部
        /// </summary>
        private GroupCommon _groupCommon = null;
        public GroupCommon GroupCommon
        {
            get
            {
                return this._groupCommon;
            }
        }

        /// <summary>
        /// 共通情報部・ユーザ任意情報
        /// </summary>
        private GroupUser _groupUser = null;
        public GroupUser GroupUser
        {
            get
            {
                return this._groupUser;
            }
        }

        /// <summary>
        /// エントリ部
        /// </summary>
        private GroupEntry _groupEntry = null;
        public GroupEntry GroupEntry
        {
            get
            {
                return this._groupEntry;
            }
        }

        /// <summary>
        /// 制御情報部２
        /// </summary>
        private GroupCtrl2 _groupCtrl2 = null;
        public GroupCtrl2 GroupCtrl2
        {
            get
            {
                return this._groupCtrl2;
            }
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public RDataInfo()
        {
            // ローダインタフェース情報部
            this._groupInterface = new GroupInterface(this._headerInfo);
            // 制御情報部１
            this._groupCtrl1 = new GroupCtrl1(this._headerInfo);
            // 共通情報部
            this._groupCommon = new GroupCommon(this._headerInfo);
            // 共通情報部・ユーザ任意情報
            this._groupUser = new GroupUser(this._headerInfo);
            // エントリ部
            this._groupEntry = new GroupEntry(this._headerInfo);
            // 制御情報部２
            this._groupCtrl2 = new GroupCtrl2(this._headerInfo);
        }
    }
}
