﻿using MarsTool.Common;

namespace MarsTool.RData.Text
{
    /// <summary>
    /// フィールド読込クラス
    /// </summary>
    public class FieldInfo
    {
        /// <summary>
        /// フィールド定義キー
        /// </summary>
        public int Key { get; set; }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public FieldInfo() : this(-1) { }
        public FieldInfo(int key)
        {
            this.Key = key;
        }
        public FieldInfo(FieldInfo fieldInfo)
        {
            // フィールド定義キー
            this.Key = fieldInfo.Key;
            // データ内容
            this.Value = fieldInfo.Value;
            // チェック種別
            this.CheckType = fieldInfo.CheckType;
            // コメント
            this.Comment = fieldInfo.Comment;
        }

        /// <summary>
        /// データ内容
        /// </summary>
        private string _value = null;
        public string Value
        {
            set
            {
                this._value = value;
            }
            get
            {
                return Utils.TrimString(this._value);
            }
        }

        /// <summary>
        /// チェック種別
        /// </summary>
        private string _checkType = null;
        public string CheckType
        {
            set
            {
                this._checkType = value;
            }
            get
            {
                return Utils.TrimString(this._checkType);
            }
        }

        /// <summary>
        /// コメント
        /// </summary>
        private string _comment = null;
        public string Comment
        {
            set
            {
                this._comment = value;
            }
            get
            {
                return Utils.TrimString(this._comment);
            }
        }
    }
}
