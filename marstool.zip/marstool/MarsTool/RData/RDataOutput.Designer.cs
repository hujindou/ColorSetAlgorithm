﻿namespace MarsTool.RData
{
    partial class RDataOutput
    {
        /// <summary> 
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region コンポーネント デザイナーで生成されたコード

        /// <summary> 
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を 
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupOutput = new System.Windows.Forms.GroupBox();
            this.chkExcel = new System.Windows.Forms.CheckBox();
            this.chkFile = new System.Windows.Forms.CheckBox();
            this.btnOutput = new System.Windows.Forms.Button();
            this.btnSelectFolder = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.txtFolder = new System.Windows.Forms.TextBox();
            this.groupOutput.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupOutput
            // 
            this.groupOutput.Controls.Add(this.chkExcel);
            this.groupOutput.Controls.Add(this.chkFile);
            this.groupOutput.Controls.Add(this.btnOutput);
            this.groupOutput.Controls.Add(this.btnSelectFolder);
            this.groupOutput.Controls.Add(this.txtFolder);
            this.groupOutput.Controls.Add(this.label16);
            this.groupOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupOutput.Location = new System.Drawing.Point(0, 0);
            this.groupOutput.Name = "groupOutput";
            this.groupOutput.Size = new System.Drawing.Size(1078, 45);
            this.groupOutput.TabIndex = 34;
            this.groupOutput.TabStop = false;
            // 
            // chkExcel
            // 
            this.chkExcel.AutoSize = true;
            this.chkExcel.Location = new System.Drawing.Point(915, 16);
            this.chkExcel.Name = "chkExcel";
            this.chkExcel.Size = new System.Drawing.Size(87, 16);
            this.chkExcel.TabIndex = 4;
            this.chkExcel.Text = "RDATA帳票";
            this.chkExcel.UseVisualStyleBackColor = true;
            this.chkExcel.CheckedChanged += new System.EventHandler(this.StatusChanged);
            // 
            // chkFile
            // 
            this.chkFile.AutoSize = true;
            this.chkFile.Location = new System.Drawing.Point(816, 16);
            this.chkFile.Name = "chkFile";
            this.chkFile.Size = new System.Drawing.Size(97, 16);
            this.chkFile.TabIndex = 3;
            this.chkFile.Text = "RDATAファイル";
            this.chkFile.UseVisualStyleBackColor = true;
            this.chkFile.CheckedChanged += new System.EventHandler(this.StatusChanged);
            // 
            // btnOutput
            // 
            this.btnOutput.Enabled = false;
            this.btnOutput.Location = new System.Drawing.Point(1018, 11);
            this.btnOutput.Name = "btnOutput";
            this.btnOutput.Size = new System.Drawing.Size(54, 23);
            this.btnOutput.TabIndex = 5;
            this.btnOutput.Text = "出力";
            this.btnOutput.UseVisualStyleBackColor = true;
            // 
            // btnSelectFolder
            // 
            this.btnSelectFolder.Location = new System.Drawing.Point(762, 11);
            this.btnSelectFolder.Name = "btnSelectFolder";
            this.btnSelectFolder.Size = new System.Drawing.Size(30, 23);
            this.btnSelectFolder.TabIndex = 2;
            this.btnSelectFolder.Text = "…";
            this.btnSelectFolder.UseVisualStyleBackColor = true;
            this.btnSelectFolder.Click += new System.EventHandler(this.BtnSelectFolder_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 16);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(59, 12);
            this.label16.TabIndex = 8;
            this.label16.Text = "格納場所：";
            // 
            // txtFolder
            // 
            this.txtFolder.Location = new System.Drawing.Point(65, 13);
            this.txtFolder.Name = "txtFolder";
            this.txtFolder.Size = new System.Drawing.Size(693, 19);
            this.txtFolder.TabIndex = 1;
            this.txtFolder.TextChanged += new System.EventHandler(this.StatusChanged);
            // 
            // RDataOutput
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupOutput);
            this.Name = "RDataOutput";
            this.Size = new System.Drawing.Size(1078, 45);
            this.groupOutput.ResumeLayout(false);
            this.groupOutput.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupOutput;
        private System.Windows.Forms.CheckBox chkExcel;
        private System.Windows.Forms.CheckBox chkFile;
        private System.Windows.Forms.Button btnOutput;
        private System.Windows.Forms.Button btnSelectFolder;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtFolder;
    }
}
