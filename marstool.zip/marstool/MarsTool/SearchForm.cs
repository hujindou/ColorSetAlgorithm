﻿using MarsTool.Common.Forms;
using MarsTool.Models;
using MarsTool.Search;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace MarsTool
{
    /// <summary>
    /// 検索機能クラス
    /// </summary>
    public partial class SearchForm : MarsForm
    {
        private CheckDataGridView jnlChkDgv = null;

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public SearchForm(VersionModel version) : base(version)
        {
            InitializeComponent();

            // インタフェース
            this.rdoInitInfoId.Tag = this.txtInitInfoId;
            this.rdoInitKey.Tag = this.txtInitKey;
            this.tabInit.Tag = new InitSearch(
                this.combInitSubSysID,
                this.rdoInitInfoId,
                this.rdoInitKey,
                this.dgvInit,
                this.rtxtItemInfo,
                this.Version);

            // 電文構成
            this.tabTel.Tag = new TelSearch(
                this.combTelSubSysID,
                this.rdoTelEde,
                this.rdoTelEdr,
                this.txtTelSubSysId,
                this.txtTelPatternNo,
                this.dgvTel,
                this.Version);

            // RDATA
            this.dgvRData.Tag = this.chkRDataAll;
            this.rdoRDataTbId.Tag = this.txtRDataTbId;
            this.rdoRDataTbNm.Tag = this.txtRDataTbNm;
            this.btnRDataDel.Tag = this.delRDataProgressBar;
            this.tabRData.Tag = new RDataSearch(
                this.combRDataSubSysID,
                this.rdoRDataTbId,
                this.rdoRDataTbNm,
                this.dgvRData,
                this.btnRDataDel,
                this.Version);

            // JNL
            this.jnlChkDgv = new CheckDataGridView(this.jndatagridview, this.jnlchkall);
            this.jnlChkDgv.ChangeStatus += ChangeStatus;
        }

        /// <summary>
        /// タグ選択イベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tabCtlSearch_SelectedIndexChanged(object sender, EventArgs e)
        {
            var tabControl = (sender as TabControl);
            if (tabControl == null) return;

            var tabPage = tabControl.TabPages[tabControl.SelectedIndex] as TabPage;
            if (tabPage == null) return;

            // ＲＤＡＴＡタグ場合、進行状況表示する
            this.delRDataProgressBar.Visible = (tabPage == tabRData);

            var search = tabPage.Tag as ISubSysId;
            if (search == null) return;

            // サブシステムＩＤ設定
            search.SetSysIds();
        }

        #region インタフェース
        private void rdoInit_CheckedChanged(object sender, EventArgs e)
        {
            this.txtInitInfoId.Enabled = this.rdoInitInfoId.Checked;
            this.txtInitKey.Enabled = this.rdoInitKey.Checked;
        }

        private void btnInitSearch_Click(object sender, EventArgs e)
        {
            var initSearch = this.tabInit.Tag as InitSearch;
            if (initSearch != null) initSearch.Search();
        }
        #endregion

        #region 物理電文構成
        private void btnTelSearch_Click(object sender, EventArgs e)
        {
            var telSearch = this.tabTel.Tag as TelSearch;
            if (telSearch != null) telSearch.Search();
        }
        #endregion

        #region RDATA
        private void rdoRData_CheckedChanged(object sender, EventArgs e)
        {
            this.txtRDataTbId.Enabled = this.rdoRDataTbId.Checked;
            this.txtRDataTbNm.Enabled = this.rdoRDataTbNm.Checked;
        }

        private void btnRDataSearch_Click(object sender, EventArgs e)
        {
            var rDataSearch = this.tabRData.Tag as RDataSearch;
            if (rDataSearch != null) rDataSearch.Search();
        }

        private void btnRDataDel_Click(object sender, EventArgs e)
        {
            var rDataSearch = this.tabRData.Tag as RDataSearch;
            if (rDataSearch != null)
            {
                if (rDataSearch.Delete())
                {
                    rDataSearch.Search(false);
                }
                this.delRDataProgressBar.Value = 0;
            }
        }
        #endregion

        protected virtual void ChangeStatus(bool nodata)
        {
            this.jnldel.Enabled = !nodata;
        }

        /// <summary>
        /// 検索
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button7_Click(object sender, EventArgs e)
        {
            jnlchkall.Checked = false;

            this.jndatagridview.Rows.Clear();
            this.jndatagridview.Refresh();

            string patterno = this.ptno.Text.Trim();
            string cupid = this.cupid.Text.Trim();
            string kentype = this.tktype.Text.Trim();
            string segid = this.segid.Text.Trim();
            if (this.chksegid.Checked == false) segid = "";
            string segname = this.segname.Text.Trim();
            if (this.chksegname.Checked == false) segname = "";
            string msg = "";

            try
            {
                List<object> lst = new List<object>();

                using (var context = new Models.DB.mysqlcontext(this.Version.ConnectString))
                {
                    var res1 = context.V_JNPT.AsNoTracking().Where(r => r.JNL_PATTERNNO.Contains(patterno) && r.JNL_CUPID.Contains(cupid) && r.JNL_TYPE.Contains(kentype));

                    if (this.chksegid.Checked)
                    {
                        res1 = res1.Where(r => r.JNL_INFOBLOCKS.Any(o => o.JNL_INFOID.Contains(segid)));
                    }
                    else
                    {
                        res1 = res1.Where(r => r.JNL_INFOBLOCKS.Any(o => o.JNL_NAME.Contains(segname)));
                    }

                    int cnt = res1.Count();
                    if (cnt == 0)
                    {
                        msg = "検索データが存在しませんでした。";
                    }
                    else
                    {
                        if (cnt > 50)
                        {
                            res1 = res1.Take(50);
                            msg = $"{cnt}件を検索しましたが、50件のみを表示します。";
                        }

                        var res = res1.ToList();
                        if (res != null)
                        {
                            foreach (var tmp in res)
                            {
                                lst.Clear();
                                lst.Add("0");
                                lst.Add(tmp.JNL_PATTERNID);

                                if (tmp.JNL_ENABLEFLG != 2)
                                {
                                    lst.Add(tmp.JNL_PATTERNNO);
                                }
                                else
                                {
                                    lst.Add("欠番");
                                }

                                lst.Add(tmp.JNL_CUPID);
                                lst.Add(tmp.JNL_TYPE);
                                lst.Add(tmp.JNL_ANS);

                                foreach (var tmp2 in tmp.JNL_INFOBLOCKS.OrderBy(r => r.JNL_ORDER))
                                {
                                    if (lst.Count < 16)
                                    {
                                        lst.Add(tmp2.JNL_INFOID);
                                    }
                                }
                                int insertedrow = this.jndatagridview.Rows.Add(lst.ToArray());
                            }
                            this.jndatagridview.ClearSelection();
                        }

                        this.jnlchkall.Enabled = true;
                    }
                }

                if (sender != null && msg != "")
                {
                    MessageBox.Show(msg, Properties.Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception exp)
            {
                this.Logger.Error(exp, "ジャーナル検索エラー");
                MessageBox.Show("ジャーナルを検索する時、エラーが発生しました", Properties.Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void chksegid_CheckedChanged(object sender, EventArgs e)
        {
            this.segname.Enabled = false;
            this.segid.Enabled = true;
        }

        private void chksegname_CheckedChanged(object sender, EventArgs e)
        {
            this.segname.Enabled = true;
            this.segid.Enabled = false;
        }

        private void dbc(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            var f = new MForm(this.jndatagridview.Rows[e.RowIndex].Cells[1].Value.ToString(), this.Version);
            f.ShowDialog();
        }

        private void SelectForm_Load(object sender, EventArgs e)
        {
            this.jndatagridview.CellDoubleClick += dbc;
            this.jndatagridview.AutoScrollOffset = new System.Drawing.Point(20, 0);
            var initSearch = this.tabInit.Tag as InitSearch;
            if (initSearch != null && !initSearch.SetSysIds()) this.Close();
        }

        /// <summary>
        /// 削除
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button9_Click(object sender, EventArgs e)
        {
            List<string> todel = new List<string>();
            for (int i = 0; i < this.jndatagridview.Rows.Count; i++)
            {
                if ("1".Equals(this.jndatagridview.Rows[i].Cells[0].Value))
                {
                    todel.Add(this.jndatagridview.Rows[i].Cells[1].Value.ToString());
                }
            }
            string todelstr = String.Join("','", todel);

            if (todel.Count > 0)
            {
                if (!this.Version.hasSubsysModifyPrivilege("JM"))
                {
                    MessageBox.Show($"ジャーナルの削除権限がありません", Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Question);
                    return;
                }

                if (MessageBox.Show($"選択した{todel.Count}件を削除しますか？", "削除確認", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
                {
                    this.Context.Database.ExecuteSqlCommand($"delete from t_jnlpt where JNL_PATTERNID in ('{todelstr}') ;delete from t_jnlsegs where JNL_PATTERNID in ('{todelstr}')");
                    button7_Click(null, null);
                }
            }
            else
                return;
        }

    }

}
