﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MarsTool.Common;
using MarsTool.Models.DB;
using MarsTool.Properties;
using MarsTool.Models;

namespace MarsTool
{
    public partial class DenstrbDialog : Form
    {
        private VersionModel version;

        public T_DENSTRB T_DENSTRB { get; private set; }   

        private DenstrbDialog()
        {
            InitializeComponent();
        }

        public DenstrbDialog(VersionModel version, string subsystem) : this()
        {
            this.version = version;
            List<T_DENSTRB> listDENSTRB = this.version.context.T_DENSTRB.AsNoTracking().Where(r =>
                                                                                              r.DENSTRB_SUBSYSID == subsystem).OrderBy(r =>
                                                                                                                                       r.DENSTRB_ORDER).ToList();
            foreach(T_DENSTRB denstrb in listDENSTRB)
            {
                string cmt = string.Empty;
                if (denstrb.DENSTRB_COMMENT != null) cmt = denstrb.DENSTRB_COMMENT;
                ListViewItem item = new ListViewItem();
                item.Text = cmt;
                item.SubItems.Add(denstrb.DENSTRB_TELSUBSYSID);
                item.SubItems.Add(denstrb.DENSTRB_TELTYPE);
                item.SubItems.Add(denstrb.DENSTRB_PATNO);
                item.Tag = denstrb;
                ltvList.Items.Add(item);
            }
        }

        private void ltvList_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ltvList.SelectedIndices.Count == 0)
            {
                btnOK.Enabled = false;
            }
            else
            {
                btnOK.Enabled = true;
                this.T_DENSTRB = ltvList.SelectedItems[0].Tag as T_DENSTRB;
            }
        }
    }
}
