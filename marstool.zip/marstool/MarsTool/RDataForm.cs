﻿using MarsTool.Common.Forms;
using MarsTool.Models;
using MarsTool.Models.DB;
using MarsTool.Properties;
using MarsTool.RData;
using MarsTool.RData.Info;
using MarsTool.RData.IO.DB;
using MarsTool.RData.IO.Text;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace MarsTool
{
    /// <summary>
    /// ＲＤＡＴＡ管理機能クラス
    /// </summary>
    public partial class RDataForm : MarsForm
    {
        #region 登録・出力タブ
        private List<ToolStripProgressBar> ProgressBars { set; get; }
        private NewInsert NewInsert { set; get; }
        private FileInsert FileInsert { set; get; }
        private FileOutput RDataOutput { set; get; }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public RDataForm(VersionModel version) : base(version)
        {
            InitializeComponent();
            this.tabRData.TabPages.Remove(this.tpEdit);
            this.ProgressBars = new List<ToolStripProgressBar>
            {
                this.progressBarFileInsert,
                this.progressBarNewInsert,
                this.progressBarOutput,
                this.progressBarEdit
            };
            this.ProgressBars.ForEach(p => p.Visible = false);

            // ファイル登録
            this.FileInsert = new FileInsert(
                this.dgvRDataFile,
                this.chkAllInsert,
                this.btnFileInsert,
                version);
            this.progressBarFileInsert.Visible = true;

            // 新規登録
            this.rdtNewInsert.DgvAddDelMenu = this.addDelMenu;
            this.AddBeforeMenuItem.Click += this.rdtNewInsert.AddBeforeMenuItem_Click;
            this.AddAfterMenuItem.Click += this.rdtNewInsert.AddAfterMenuItem_Click;
            this.AddMenuItem.Click += this.rdtNewInsert.AddMenuItem_Click;
            this.DelMenuItem.Click += this.rdtNewInsert.DelMenuItem_Click;
            this.UnDelMenuItem.Click += this.rdtNewInsert.UnDelMenuItem_Click;
            this.NewInsert = new NewInsert(
                this.rdtNewInsert,
                version);

            // 出力
            this.dgvRDataOutput.Tag = this.chkRDataAll;
            this.rdoRDataTbId.Tag = this.txtRDataTbId;
            this.rdoRDataTbNm.Tag = this.txtRDataTbNm;
            this.RDataOutput = new FileOutput(
                this.combSubSysID,
                this.rdoRDataTbId,
                this.rdoRDataTbNm,
                this.dgvRDataOutput,
                this.ucOutput,
                this.Version);
            this.ucOutput.BtnOutput.Click += UcOutput_Click;
        }

        private void TabRData_SelectedIndexChanged(object sender, EventArgs e)
        {
            var tabControl = (sender as TabControl);
            if (tabControl == null) return;

            var tabPage = tabControl.TabPages[tabControl.SelectedIndex];
            // 出力タブ
            if (tabPage == this.tpOutput)
            {
                // サブシステムＩＤ設定
                this.RDataOutput.SetSysIds();
            }

            this.ShowProgressBar();
        }

        private void TabInsert_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.ShowProgressBar();
        }

        private void ShowProgressBar()
        {
            this.ProgressBars.ForEach(p => p.Visible = false);

            var tabPage = this.tabRData.TabPages[this.tabRData.SelectedIndex];

            // 登録タブ
            if (tabPage == this.tpInsert)
            {
                var subTabPage = this.tabInsert.TabPages[this.tabInsert.SelectedIndex];
                // ファイルから登録
                if (subTabPage == this.tpFileInsert)
                {
                    this.progressBarFileInsert.Visible = true;
                    return;
                }

                // 新規作成
                this.progressBarNewInsert.Visible = true;
                if (this.tpNewInsert.Tag == null)
                {
                    var f = new SelectTable();
                    if (f.ShowDialog(this) == DialogResult.OK)
                    {
                        this.rdtNewInsert.IsMBTable = f.IsMBTable;
                        this.NewInsert.Init();
                        this.tpNewInsert.Tag = true;
                    }
                    else
                    {
                        this.tabInsert.SelectedIndex = 0;
                    }
                }

                return;
            }

            // 出力タブ
            if (tabPage == this.tpOutput)
            {
                this.progressBarOutput.Visible = true;
            }
        }

        private void RdoRData_CheckedChanged(object sender, EventArgs e)
        {
            this.txtRDataTbId.Enabled = this.rdoRDataTbId.Checked;
            this.txtRDataTbNm.Enabled = this.rdoRDataTbNm.Checked;
        }

        /// <summary>
        /// 出力画面の検索処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnSelecct_Click(object sender, EventArgs e)
        {
            this.RDataOutput.Search();
        }

        /// <summary>
        /// ＲＤＡＴＡフォルダを選択
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnSelectFolder_Click(object sender, EventArgs e)
        {
            if (this.folderBrowserDlg.ShowDialog() == DialogResult.OK)
            {
                this.txtRDataFolder.Text = this.folderBrowserDlg.SelectedPath;
            }
        }

        /// <summary>
        /// ＲＤＡＴＡファイル一覧を取得
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnLoadRData_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(this.txtRDataFolder.Text))
            {
                MessageBox.Show("ＲＤＡＴＡフォルダを入力してください。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!Directory.Exists(this.txtRDataFolder.Text))
            {
                MessageBox.Show("入力されたフォルダが存在しません。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            this.FileInsert.Load(this.txtRDataFolder.Text);
        }

        /// <summary>
        /// 新規登録処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnNewInsert_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("新規登録処理を行いますか?",
                Resources.QUESTION, MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (result == DialogResult.Cancel) return;

            this.RunWorkerAsync(this.NewInsert.PreInsert, this.NewInsert);
        }

        /// <summary>
        /// ファイル登録処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnFileInsert_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("ファイル登録処理を行いますか?",
                Resources.QUESTION, MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (result == DialogResult.Cancel) return;

            this.RunWorkerAsync(this.FileInsert.PreInsert, this.FileInsert);
        }

        /// <summary>
        /// 出力処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UcOutput_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("出力処理を行いますか?",
                Resources.QUESTION, MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (result == DialogResult.Cancel) return;

            this.RunWorkerAsync(this.RDataOutput.PreOutput, this.RDataOutput);
        }

        #endregion

        #region 編集タグ
        private RDataEdit RDataEdit { set; get; }

        /// <summary>
        /// RDATA情報
        /// </summary>
        private RDataInfo RDataInfo { set; get; }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public RDataForm(T_RDATA rdataInfo, VersionModel version) : base(version)
        {
            InitializeComponent();
            this.tabRData.TabPages.Remove(this.tpInsert);
            this.tabRData.TabPages.Remove(this.tpOutput);
            this.progressBarEdit.Visible = true;

            this.rdtUpdate.DgvAddDelMenu = this.addDelMenu;
            this.AddBeforeMenuItem.Click += this.rdtUpdate.AddBeforeMenuItem_Click;
            this.AddAfterMenuItem.Click += this.rdtUpdate.AddAfterMenuItem_Click;
            this.AddMenuItem.Click += this.rdtUpdate.AddMenuItem_Click;
            this.DelMenuItem.Click += this.rdtUpdate.DelMenuItem_Click;
            this.UnDelMenuItem.Click += this.rdtUpdate.UnDelMenuItem_Click;

            this.RDataEdit = new RDataEdit(
                this.rdtUpdate,
                this.ucEditOutput,
                version);
            this.ucEditOutput.BtnOutput.Click += UcEditOutput_Click;

            using (var context = new mysqlcontext(this.Version.ConnectString))
            {
                var dbAccess = new RDataDBAccess(this.Version, context);
                var rdataInfos = dbAccess.Select(rdataInfo.RDATA_SUBSYSID, rdataInfo.RDATA_TABLEID);
                if (rdataInfos == null)
                {
                    MessageBox.Show("ＤＢにデータ存在しません。");
                }
                else
                {
                    this.RDataInfo = rdataInfos[0];
                    this.RDataEdit.RDataInfo = rdataInfos[1];
                }
            }
        }

        /// <summary>
        /// ファイル選択
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnSelectRData_Click(object sender, EventArgs e)
        {
            if (this.openFileDlg.ShowDialog() == DialogResult.OK)
            {
                this.txtRDataFile.Text = this.openFileDlg.FileName;
            }
        }

        /// <summary>
        /// ファイル比較
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnDbFileComp_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(this.txtRDataFile.Text))
            {
                MessageBox.Show("ＲＤＡＴＡファイルは入力してください。", Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!File.Exists(this.txtRDataFile.Text))
            {
                MessageBox.Show("入力したＲＤＡＴＡファイルは存在しません。", Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // ＲＤＡＴＡファイルの行情報
            var rdataLines = File.ReadAllLines(this.txtRDataFile.Text);

            // 比較用ファイル名
            var compFilename = $"{this.txtRDataFile.Text}.comp";
            var writer = new RDataFileWriter(this.RDataInfo);
            writer.Write(compFilename, Encoding.GetEncoding("Shift_JIS"));

            // 比較用ＲＤＡＴＡファイルの行情報
            var compRDataLines = File.ReadAllLines(compFilename);

            if (rdataLines.Length != compRDataLines.Length)
            {
                this.Logger.Warn($"入力したＲＤＡＴＡファイルの内容とＤＢの内容が不一致。\n{this.txtRDataFile.Text}\n{this.txtRDataFile.Text}.comp");
                MessageBox.Show("入力したＲＤＡＴＡファイルの内容とＤＢの内容が不一致。", Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            for (var i = 0; i < rdataLines.Length; i++)
            {
                var strLine = rdataLines[i].Trim();
                var strCompLine = compRDataLines[i].Trim();

                if (!string.Equals(strLine, strCompLine))
                {
                    this.Logger.Warn($"入力したＲＤＡＴＡファイルの内容とＤＢの内容が不一致。\n{this.txtRDataFile.Text}\n{this.txtRDataFile.Text}.comp");
                    MessageBox.Show("入力したＲＤＡＴＡファイルの内容とＤＢの内容が不一致。", Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            this.rdtUpdate.Enabled = true;
            this.ucEditOutput.Enabled = true;
            this.btnUpdate.Enabled = true;
        }

        /// <summary>
        /// 更新処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("更新処理を行いますか?",
                Resources.QUESTION, MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (result == DialogResult.Cancel) return;

            this.RunWorkerAsync(() => this.RDataEdit.PreUpdate(this.RDataInfo), this.RDataEdit);
        }

        /// <summary>
        /// 出力処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UcEditOutput_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("出力処理を行いますか?",
                Resources.QUESTION, MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (result == DialogResult.Cancel) return;

            this.RunWorkerAsync(() =>
            {
                if (this.RDataEdit.PreOutput(this.RDataInfo))
                {
                    this.grpComp.Enabled = false;
                    this.rdtUpdate.Enabled = false;
                    this.ucEditOutput.Enabled = false;
                    this.btnUpdate.Enabled = false;

                    return true;
                }

                return false;
            }, this.ucEditOutput);
        }

        #endregion

        #region 進行状況処理
        private object workerArg = null;

        private string GetWorkerMsg()
        {
            var msg = string.Empty;
            // 新規登録処理
            if (this.workerArg == this.NewInsert)
            {
                msg = "新規登録";
            }
            // ファイル登録処理
            else if (this.workerArg == this.FileInsert)
            {
                msg = "ファイル登録";
            }
            // 更新処理
            else if (this.workerArg == this.RDataEdit)
            {
                msg = "更新";
            }
            else if (this.workerArg == this.ucEditOutput || this.workerArg == this.RDataOutput)
            {
                msg = "出力";
            }

            return msg;
        }

        private void RunWorkerAsync(Func<bool> preFunc, object arg)
        {
            if (this.backgroundWorker.IsBusy)
            {
                var msg = this.GetWorkerMsg();
                if (!string.IsNullOrEmpty(msg))
                {
                    MessageBox.Show($"{msg}処理中なので、少々待ちください。",
                        Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else if(preFunc())
            {
                this.workerArg = arg;
                this.backgroundWorker.RunWorkerAsync();
            }
        }

        private void BackgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            // 新規登録処理
            if (this.workerArg == this.NewInsert)
            {
                this.NewInsert.Insert(this.backgroundWorker, e);
                return;
            }

            // ファイル登録処理
            if (this.workerArg == this.FileInsert)
            {
                this.FileInsert.Insert(this.backgroundWorker, e);
                return;
            }

            // 更新処理
            if (this.workerArg == this.RDataEdit)
            {
                this.RDataEdit.Update(this.backgroundWorker, e, this.RDataInfo);
                return;
            }

            // 編集画面の出力処理
            if (this.workerArg == this.ucEditOutput)
            {
                this.RDataEdit.Output(this.backgroundWorker, e);
                return;
            }

            // 出力処理
            if (this.workerArg == this.RDataOutput)
            {
                this.RDataOutput.Output(this.backgroundWorker, e);
                return;
            }
        }

        private void BackgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // ファイル登録処理
            if (this.workerArg == this.FileInsert)
            {
                this.FileInsert.AfterInsert();
            }
            // 更新処理
            else if (this.workerArg == this.RDataEdit)
            {
                using (var context = new mysqlcontext(this.Version.ConnectString))
                {
                    var dbAccess = new RDataDBAccess(this.Version, context);

                    var subSysId = this.RDataInfo.HeaderInfo.SubSystemId;
                    var tableId = this.RDataInfo.HeaderInfo.TableId;
                    var rdataInfos = dbAccess.Select(subSysId, tableId);
                    if (rdataInfos != null)
                    {
                        this.RDataInfo = rdataInfos[0];
                        this.RDataEdit.RDataInfo = rdataInfos[1];
                    }
                }
            }
            // 編集画面の出力処理
            else if (this.workerArg == this.ucEditOutput)
            {
                this.grpComp.Enabled = true;
                this.rdtUpdate.Enabled = true;
                this.ucEditOutput.Enabled = true;
                this.btnUpdate.Enabled = true;
            }
            // 出力処理
            else if (this.workerArg == this.RDataOutput)
            {
                this.RDataOutput.AfterOutput();
            }

            if (e.Result != null)
            {
                var msg = e.Result.ToString();
                if (!string.IsNullOrEmpty(msg))
                {
                    var msgType = msg.Substring(0, 1);
                    switch (msgType.ToUpper())
                    {
                        case "W":
                            MessageBox.Show(msg.Substring(1), Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            break;

                        case "E":
                            MessageBox.Show(msg.Substring(1), Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            break;

                        default:
                            MessageBox.Show(msg, Resources.INFORMATION, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            break;
                    }
                }
            }

            this.progressBarFileInsert.Value = 0;
            this.progressBarNewInsert.Value = 0;
            this.progressBarEdit.Value = 0;
            this.progressBarOutput.Value = 0;
        }

        private void BackgroundWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            // 新規登録処理
            if (this.workerArg == this.NewInsert)
            {
                this.progressBarNewInsert.Value = e.ProgressPercentage;
                return;
            }

            // ファイル登録処理
            if (this.workerArg == this.FileInsert)
            {
                this.progressBarFileInsert.Value = e.ProgressPercentage;
                return;
            }

            // 編集画面
            if (this.workerArg == this.RDataEdit || this.workerArg == this.ucEditOutput)
            {
                this.progressBarEdit.Value = e.ProgressPercentage;
                return;
            }

            // 出力処理
            if (this.workerArg == this.RDataOutput)
            {
                this.progressBarOutput.Value = e.ProgressPercentage;
                return;
            }
        }

        private void RDataForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.backgroundWorker.IsBusy)
            {                
                MessageBox.Show($"{this.GetWorkerMsg()}処理中なので、閉じることはできません。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                e.Cancel = true;
                return;
            }
        }
        #endregion
    }
}
