﻿//-----------------------------------------------------------
// All Rights Reserved , Copyright (C) 2018 , Hitachi , Ltd.
//-----------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using MySql.Data.MySqlClient;
using MarsTool.Models;
using MarsTool.Common;
using MarsTool.Properties;
using MarsTool.Exceptions;
using System.Text;

namespace MarsTool.Daos
{
    /// <summary>
    /// KohoDBConnectivity Class<br/>
    /// KohoDBConnectivity　クラス<br/>
    /// To Connect DataBase.To get data from database<br/>
    /// データベースからデータを取得するため、データベースを接続<br/>
    /// </summary>
    /// <remarks>
    /// 2018/03/28 新規作成<br/>
    /// </remarks>
    class KohoDBConnectivity
    {
        #region variable

        //Specify instance of KohoDBConnectivity
        //KohoDBConnectivityのインスタンスを指定
        private static KohoDBConnectivity instance;

        //To connect to database
        //データベースを接続
        private static MySqlConnection connection;

        private VersionModel version;

        #endregion

        #region private method

        /// <summary>
        /// データベース接続を取得<br/>
        /// Get Connection to database<br/>
        /// </summary>
        /// <remarks>
        /// 2018/03/15 新規作成<br/>
        /// </remarks>
        private KohoDBConnectivity(VersionModel v)
        {
            connection = new MySqlConnection(v.ConnectString);
            version = v;
        }

        #endregion

        #region public method

        /// <summary>
        /// Get Connection to database<br/>
        /// データベース接続を取得<br/>
        /// </summary>
        /// <returns>
        /// Return KohoDBConnectivity instance.<br/>
        /// KohoDBConnectivityインスタンスを返却<br/>
        /// </returns>
        /// <remarks>
        /// 2018/03/15 新規作成<br/>
        /// </remarks>
        public static KohoDBConnectivity getInstance(VersionModel v)
        {
            if (instance == null)
            {
                instance = new KohoDBConnectivity(v);
            }
            return instance;
        }

        /// <summary>
        /// To Register code candidate value to "T_KOHO" Table.<br/>
        /// コード候補値を「T_KOHO」テーブルに登録<br/>
        /// </summary>
        /// <param name="codeCandidateValueList">
        /// codeCandidateValueList is used to register code candidate value.<br/>
        /// コード候補値を登録する際に使用する　codeCandidateValueList<br/>
        /// </param>
        /// <param name="userID">
        /// userId is used to register UserID column.<br/>
        /// UserID列に登録するためuserIdを使用<br/>
        /// </param>
        /// <returns>
        /// Return success count of code candidate value　registration.<br/>
        /// 登録したコード候補値の成功件数を返却<br/>
        /// </returns>
        /// <exception cref="CodeCadidateRegException">
        /// Throw exception if exception occurs.<br/>
        /// 例外が発生する場合、例外をスロー<br/>
        /// </exception>
        /// <remarks>
        /// 2018/05/24 新規作成<br/>
        /// </remarks>
        public int InsertCodeCandidateList(List<CodeCandidateModel> codeCandidateValueList)
        {
            MySqlTransaction transaction = null;

            int executeCnt = 0;
            try
            {
                string insertQuery = "INSERT INTO T_KOHO ( KOHO_GROUP, KOHO_CODE, KOHO_CONTENT , KOHO_ORDER , KOHO_USERID , KOHO_UPDTIME)"
                                    + " VALUES ";

                StringBuilder sCommand = new StringBuilder(insertQuery);

                connection.Open();
                transaction = connection.BeginTransaction();

                List<string> rows = new List<string>();

                for (int i = 0; i < codeCandidateValueList.Count; i++)
                {
                    for (int j = 0; j < codeCandidateValueList[i].Koho_code.Count; j++)
                    {
                        rows.Add(string.Format("('{0}','{1}','{2}','{3}','{4}','{5}')",
                            MySqlHelper.EscapeString(codeCandidateValueList[i].Koho_group),
                            MySqlHelper.EscapeString(codeCandidateValueList[i].Koho_code[j]),
                            MySqlHelper.EscapeString(codeCandidateValueList[i].Koho_content[j]),
                            MySqlHelper.EscapeString(codeCandidateValueList[i].Koho_outputOrder[j].ToString()),
                            MySqlHelper.EscapeString(version.User.USERID),
                            MySqlHelper.EscapeString(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"))));

                        if (rows.Count == 30000 ||
                            (i == codeCandidateValueList.Count - 1 && j == codeCandidateValueList[i].Koho_code.Count - 1))
                        {
                            sCommand.Append(string.Join(",", rows));
                            sCommand.Append(";");

                            MySqlCommand myCmd = new MySqlCommand(sCommand.ToString(), connection);

                            executeCnt += myCmd.ExecuteNonQuery();
                            rows.Clear();
                            sCommand = new StringBuilder(insertQuery);
                        }
                    }
                }
                transaction.Commit();

                this.CloseConnection();
            }
            catch (Exception e)
            {
                //if (connection.State == ConnectionState.Open)
                if (connection != null)
                {
                    //log for Database error
                    //データベースにエラーが発生する場合、ログに記録
                    LogUtils.WriteLogInfo(version.User.USERID, LogUtils.GetMsgInfo(Resources.CVR00011_E, e.Message), LogUtils.GetMsgType(ConstantUtils.CVR00011_E), e);
                    if(executeCnt != 0)
                    {
                        transaction.Rollback();
                    }
                    connection.Close();

                    //Throw Error CVR00011_E
                    //CVR00011_E　エラーをスロー
                    throw new CodeCadidateRegException(LogUtils.GetMsgInfo(Resources.CVR00011_E, e.Message), e);
                }
                else
                {
                    //log for Database error
                    //データベースにエラーが発生する場合、ログに記録
                    LogUtils.WriteLogInfo(version.User.USERID, LogUtils.GetMsgInfo(Resources.CVR00009_E, e.Message), LogUtils.GetMsgType(ConstantUtils.CVR00009_E), e);
                    this.CloseConnection();

                    //Throw Error CVR00009-E
                    //CVR00009-E　エラーをスロー
                    throw new CodeCadidateRegException(LogUtils.GetMsgInfo(Resources.CVR00009_E, e.Message), e);
                }
            }
            return executeCnt;
        }

        /// <summary>
        /// To check copy clause id exists or not in "T_TMCOPYK" table.<br/>
        /// 「T_TMCOPYK」テーブルにコピー句IDは存在しているかチェック<br/>
        /// </summary>
        /// <param name="groupName">
        /// groupName is used to find in "T_KOHO" table.<br/>
        /// 「T_KOHO」テーブルに検索するため、groupNameを使用<br/>
        /// </param>
        /// <returns>
        /// Return Boolean "TRUE" if copyCluaseID is exists in "T_TMCOPYK" table or "FALSE" if not exist .<br/>
        /// 「T_TMCOPYK」にcopyCluaseIDが存在する場合、ブーリアン「TRUE」に返却し、存在しない場合、「FALSE」に返却<br/>
        /// </returns>
        /// <exception cref="CodeCadidateRegException">
        /// Throw exception if exception occurs.<br/>
        /// 例外が発生する場合、例外をスロー<br/>
        /// </exception>
        /// <remarks>
        /// 2018/05/24 新規作成<br/>
        /// </remarks>
        public bool CheckGroupName(string groupName)
        {
            bool result = false;
            try
            {
                string selectCopyClauseID = "SELECT EXISTS (SELECT 1 FROM T_KOHO k WHERE k.KOHO_GROUP =@KOHO_GROUP);";

                connection.Open();

                MySqlCommand command = null;

                command = new MySqlCommand(selectCopyClauseID, connection);
                command.Parameters.AddWithValue("@KOHO_GROUP", groupName);

                result = Convert.ToBoolean(command.ExecuteScalar());

                this.CloseConnection();
            }
            catch (Exception e)
            {
                //log for Database error
                //データベースにエラーが発生する場合、ログに記録
                LogUtils.WriteLogInfo(version.User.USERID, LogUtils.GetMsgInfo(Resources.CVR00009_E, e.Message), LogUtils.GetMsgType(ConstantUtils.CVR00009_E), e);
                this.CloseConnection();

                //Throw Error CVR00009-E
                //CVR00009-E　エラーをスロー
                throw new CodeCadidateRegException(LogUtils.GetMsgInfo(Resources.CVR00009_E, e.Message), e);
            }
            return result;
        }

        /// <summary>
        /// To get all columns of maximum size in "T_KOHO" Table.<br/>
        /// 「T_KOHO」テーブルに全ての列の最大サイズを取得<br/>
        /// </summary>
        /// <returns>
        /// Return column name and maximum size of "T_KOHO" Table.<br/>
        ///「T_KOHO」テーブルの列名と最大サイズを返却<br/>
        /// </returns>
        /// <exception cref="CodeCadidateRegException">
        /// Throw exception if exception occurs.<br/>
        /// 例外が発生する場合、例外をスロー<br/>
        /// </exception>
        /// <remarks>
        /// 2018/05/24 新規作成<br/>
        /// </remarks>
        public Dictionary<string, int> SelectMaxColLen()
        {
            Dictionary<string, int> maxColLength = new Dictionary<string, int>();
            try
            {
                string selectMaxColLen = "SELECT character_maximum_length FROM information_schema.columns WHERE " +
                                          "table_schema = @table_schema AND table_name = @table_name " +
                                          "AND column_name = @column_name;";

                connection.Open();

                MySqlCommand command = null;
                command = new MySqlCommand(selectMaxColLen, connection);

                for (int i = 0; i < ConstantUtils.COLLIST.Length; i++)
                {
                    command.Parameters.Clear();
                    command.Parameters.AddWithValue("@table_schema", connection.Database);
                    command.Parameters.AddWithValue("@table_name", ConstantUtils.TABLENAME);
                    command.Parameters.AddWithValue("@column_name", ConstantUtils.COLLIST[i]);

                    IDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        maxColLength.Add(ConstantUtils.COLLIST[i], int.Parse(reader["character_maximum_length"].ToString()));
                    }
                    reader.Close();
                }
                this.CloseConnection();
            }
            catch (Exception e)
            {
                //log for Database error
                //データベースにエラーが発生する場合、ログに記録
                LogUtils.WriteLogInfo(version.User.USERID, LogUtils.GetMsgInfo(Resources.CVR00009_E, e.Message), LogUtils.GetMsgType(ConstantUtils.CVR00009_E), e);
                this.CloseConnection();

                //Throw Error CVR00009-E
                //CVR00009-E　エラーをスロー
                throw new CodeCadidateRegException(LogUtils.GetMsgInfo(Resources.CVR00009_E, e.Message), e);
            }
            return maxColLength;
        }

        // <summary>
        /// To close database connection.<br/>
        /// データベース接続を閉じる<br/>
        /// </summary>
        /// <remarks>
        /// 2018/03/15 新規作成<br/>
        /// </remarks>
        public void CloseConnection()
        {
            if (connection.State == ConnectionState.Open)
            {
                connection.Close();
            }
        }

        #endregion
    }
}
