﻿//-----------------------------------------------------------
// All Rights Reserved , Copyright (C) 2018 , Hitachi , Ltd.
//-----------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Data;
using System.Configuration;
using MySql.Data.MySqlClient;
using MarsTool.Models.DB;
using MarsTool.Properties;
using MarsTool.Exceptions;
using MarsTool.Common;
using MarsTool.Models;

namespace MarsTool.Daos
{
    /// <summary>
    /// CopyKuDBConnectivity Class<br/>
    /// CopyKuDBConnectivity　クラス<br/>
    /// To Connect DataBase.To get data from database<br/>
    /// データベースからデータを取得するため、データベースを接続<br/>
    /// </summary>
    /// <remarks>
    /// 2018/03/07 新規作成<br/>
    /// </remarks>
    class CopyKuDBConnectivity
    {
        #region variable

        private NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        //Specify instance of CopyKuDBConnectivity
        //DBConnectivityのインスタンスを指定
        private static CopyKuDBConnectivity instance;

        //To connect to database
        //データベースを接続
        private VersionModel version;
        #endregion


        #region public method

        /// <summary>
        /// Get Connection to database<br/>
        /// データベース接続を取得<br/>
        /// </summary>
        /// <returns>
        /// Return CopyKuDBConnectivity instance.<br/>
        /// DBConnectivityインスタンスを返却<br/>
        /// </returns>
        /// <remarks>
        /// 2018/03/07 新規作成<br/>
        /// </remarks>
        public CopyKuDBConnectivity(VersionModel v)
        {
            version = v;
        }

        /// <summary>
        /// 物理コピー句情報を取得する
        /// </summary>
        /// <param name="subSysId"></param>
        /// <param name="infoId"></param>
        /// <returns></returns>
        public PhysicalCopyKuInfo SelectPhysicalCopyKuInfo(string subSysId, string infoId)
        {
            PhysicalCopyKuInfo physicalCopyKu = null;
            MySqlConnection connection = new MySqlConnection(this.version.ConnectString);
            try
            {
                string selectQuery = "SELECT CPYPHY_SIZE, CPYPHY_STATUS FROM T_CPYPHY WHERE CPYPHY_SUBSYSID ='" + subSysId
                    + "' AND CPYPHY_INFOID ='" + infoId + "';";

                connection.Open();

                MySqlCommand command = null;

                if (subSysId != string.Empty && infoId != string.Empty)
                {
                    physicalCopyKu = new PhysicalCopyKuInfo();
                    command = new MySqlCommand(selectQuery, connection);
                    command.Parameters.Add(new MySqlParameter("@subSysId", subSysId));
                    command.Parameters.Add(new MySqlParameter("@infoId", infoId));
                }

                IDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    physicalCopyKu.CPYPHY_Size = reader["CPYPHY_SIZE"]as int? ?? default(int); ;
                    physicalCopyKu.CPYPHY_STATUS = reader["CPYPHY_STATUS"].ToString();
                }
            }
            catch (Exception e)
            {
                logger.Error(e, $"{version.User.USERID}" + string.Format(Resources.CKR00002_E, "物理コピー句情報"));
                //Throw Error CKR00002-E
                //CKR00002-E　エラーをスロー
                throw new CopyKuInfoReadProcessException(string.Format(Resources.CKR00002_E, "物理コピー句情報"), e);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return physicalCopyKu;
        }

        /// <summary>
        /// 物理コピー句情報を取得する
        /// </summary>
        /// <param name="subSysId"></param>
        /// <param name="infoId"></param>
        /// <returns></returns>
        public Int32 SelectPhysicalCopyKuID(string copyKuId)
        {
            Int32 count = 0;
            MySqlConnection connection = new MySqlConnection(this.version.ConnectString);
            try
            {
                string selectQuery = "SELECT COUNT(*) FROM T_CPYPHY WHERE CPYPHY_BCPID ='" + copyKuId + "';";

                connection.Open();

                MySqlCommand command = null;

                if (copyKuId != string.Empty)
                {                    
                    command = new MySqlCommand(selectQuery, connection);
                    command.Parameters.Add(new MySqlParameter("@CPYPHY_BCPID", copyKuId));
                }

                count = Convert.ToInt32(command.ExecuteScalar());


            }
            catch (Exception e)
            {
                logger.Error(e, $"{version.User.USERID}" + string.Format(Resources.CKR00002_E, "物理コピー句情報"));
                //Throw Error CKR00002-E
                //CKR00002-E　エラーをスロー
                throw new CopyKuInfoReadProcessException(string.Format(Resources.CKR00002_E, "物理コピー句情報"), e);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return count;
        }


        /// <summary>
        /// 物理コピー句情報を取得する
        /// </summary>
        /// <param name="subSysId"></param>
        /// <param name="infoId"></param>
        /// <returns></returns>
        public PhysicalCopyKuInfo SelectLastUpdateUser(string subSysId, string infoId)
        {
            PhysicalCopyKuInfo updateUser = null;
            MySqlConnection connection = new MySqlConnection(this.version.ConnectString);
            try
            {
                string selectQuery = "SELECT CPYPHY_USERID, CPYPHY_UPDTIME FROM T_CPYPHY WHERE CPYPHY_SUBSYSID ='" + subSysId
                    + "' AND CPYPHY_INFOID ='" + infoId + "' AND (CPYPHY_STATUS IS NULL OR CPYPHY_STATUS <> '1')";

                connection.Open();

                MySqlCommand command = null;

                if (subSysId != string.Empty && infoId != string.Empty)
                {
                    updateUser = new PhysicalCopyKuInfo();
                    command = new MySqlCommand(selectQuery, connection);
                    command.Parameters.Add(new MySqlParameter("@subSysId", subSysId));
                    command.Parameters.Add(new MySqlParameter("@infoId", infoId));
                }

                IDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    updateUser.CPYPHY_UserId = reader["CPYPHY_USERID"].ToString();
                    updateUser.CPYPHY_UPDTIME = reader["CPYPHY_UPDTIME"].ToString();
                }
            }
            catch (Exception e)
            {
                logger.Error(e, $"{version.User.USERID}" + string.Format(Resources.CKR00002_E, "物理コピー句情報"));
                //Throw Error CKR00002-E
                //CKR00002-E　エラーをスロー
                throw new CopyKuInfoReadProcessException(string.Format(Resources.CKR00002_E, "物理コピー句情報"), e);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return updateUser;
        }


        /// <summary>
        /// 物理アイテム情報一覧を取得する
        /// </summary>
        /// <param name="subSysId"></param>
        /// <param name="infoId"></param>
        /// <returns></returns>
        public List<PhysicalCopyKuItemInfo> SelectPhysicalCopyKuItemInfos(string subSysId, string infoId)
        {
            List<PhysicalCopyKuItemInfo> phyCopyKuItemInfos = null;
            //MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["myDatabaseConnection"].ConnectionString);
            MySqlConnection connection = new MySqlConnection(this.version.ConnectString);
            try
            {
                string selectQuery = "SELECT PHYITM_SUBSYSID, PHYITM_INFOID, PHYITM_PATH, PHYITM_ITEMNO, PHYITM_SEQ, PHYITM_LEVEL, PHYITM_ITEMNM, PHYITM_ITEMID, PHYITM_DTLEN, PHYITM_DTTYPE,PHYITM_CPYDTTYPE, PHYITM_ITEMFLG, PHYITM_OCCURS, PHYITM_COMMENT, PHYITM_NOTE FROM T_PHYITM WHERE PHYITM_SUBSYSID ='" + subSysId +"' AND PHYITM_INFOID ='" + infoId + "' ORDER BY PHYITM_ITEMNO;";

                connection.Open();

                MySqlCommand command = new MySqlCommand(selectQuery, connection);


                if (subSysId != string.Empty && infoId != string.Empty)
                {
                    command = new MySqlCommand(selectQuery, connection);
                    command.Parameters.Add(new MySqlParameter("@subSysId", subSysId));
                    command.Parameters.Add(new MySqlParameter("@infoId", infoId));
                }

                IDataReader reader = command.ExecuteReader();

                phyCopyKuItemInfos = new List<PhysicalCopyKuItemInfo>();

                while (reader.Read())
                {
                    PhysicalCopyKuItemInfo itemInfo = new PhysicalCopyKuItemInfo();
                    itemInfo.PHYITM_SubSysId = reader["PHYITM_SUBSYSID"].ToString();
                    itemInfo.PHYITM_InfoId = reader["PHYITM_INFOID"].ToString();
                    itemInfo.PHYITM_Path = reader["PHYITM_PATH"].ToString();
                    itemInfo.PHYITM_ItemNo = reader["PHYITM_ITEMNO"] as int? ?? default(int);
                    itemInfo.PHYITM_Seq = reader["PHYITM_SEQ"].ToString();
                    itemInfo.PHYITM_Level = reader["PHYITM_LEVEL"] as int? ?? default(int);
                    itemInfo.PHYITM_ItemName = reader["PHYITM_ITEMNM"].ToString();
                    itemInfo.PHYITM_ItemId = reader["PHYITM_ITEMID"].ToString();
                    itemInfo.PHYITM_DTLEN = reader["PHYITM_DTLEN"] as int? ?? default(int);
                    itemInfo.PHYITM_DTTYPE = reader["PHYITM_DTTYPE"].ToString();
                    itemInfo.PHYITM_CPYDTTYPE = reader["PHYITM_CPYDTTYPE"].ToString();
                    itemInfo.PHYITM_ItemFlg = reader["PHYITM_ITEMFLG"].ToString();
                    itemInfo.PHYITM_Occurs = reader["PHYITM_OCCURS"] as int? ?? default(int);
                    itemInfo.PHYITM_Comment = reader["PHYITM_COMMENT"].ToString();
                    itemInfo.PHYITM_Note = reader["PHYITM_NOTE"].ToString();
                    phyCopyKuItemInfos.Add(itemInfo);
                }
            }
            catch (Exception e)
            {
                logger.Error(e, $"{version.User.USERID}" + string.Format(Resources.CKR00002_E, "物理アイテム情報"));
                throw new CopyKuInfoReadProcessException(string.Format(Resources.CKR00002_E, "物理アイテム情報"), e);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return phyCopyKuItemInfos;
        }

        /// <summary>
        /// 物理アイテム情報を取得する
        /// </summary>
        /// <param name="subSysId"></param>
        /// <param name="infoId"></param>
        /// <param name="path"></param>
        /// <param name="itemNo"></param>
        /// <returns></returns>
        public PhysicalCopyKuItemInfo SelectPhysicalCopyKuItemInfo(string subSysId, string infoId, string path, int itemNo)
        {
            PhysicalCopyKuItemInfo phyCopyKuItemInfo = null;
            //MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["myDatabaseConnection"].ConnectionString);
            MySqlConnection connection = new MySqlConnection(this.version.ConnectString);
            try
            {
                string selectQuery = "SELECT PHYITM_SEQ, PHYITM_LEVEL, PHYITM_ITEMNM, PHYITM_CPYDTTYPE, PHYITM_ITEMFLG, PHYITM_COMMENT, " +
                                        "PHYITM_NOTE FROM T_PHYITM WHERE PHYITM_SUBSYSID ='" + subSysId +
                                        "' AND PHYITM_INFOID ='" + infoId + "' AND PHYITM_PATH ='" + path + "';";

                connection.Open();

                MySqlCommand command = new MySqlCommand(selectQuery, connection);


                if (subSysId != string.Empty && infoId != string.Empty)
                {
                    phyCopyKuItemInfo = new PhysicalCopyKuItemInfo();
                    command = new MySqlCommand(selectQuery, connection);
                    command.Parameters.Add(new MySqlParameter("@subSysId", subSysId));
                    command.Parameters.Add(new MySqlParameter("@infoId", infoId));
                    command.Parameters.Add(new MySqlParameter("@path", path));
                    //command.Parameters.Add(new MySqlParameter("@itemNo", itemNo));
                }

                IDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    phyCopyKuItemInfo.PHYITM_Seq = reader["PHYITM_SEQ"].ToString();
                    phyCopyKuItemInfo.PHYITM_Level = reader["PHYITM_LEVEL"] as int? ?? default(int);
                    phyCopyKuItemInfo.PHYITM_ItemName = reader["PHYITM_ITEMNM"].ToString();
                    phyCopyKuItemInfo.PHYITM_CPYDTTYPE = reader["PHYITM_CPYDTTYPE"].ToString();
                    phyCopyKuItemInfo.PHYITM_ItemFlg = reader["PHYITM_ITEMFLG"].ToString();
                    phyCopyKuItemInfo.PHYITM_Comment = reader["PHYITM_COMMENT"].ToString();
                    phyCopyKuItemInfo.PHYITM_Note = reader["PHYITM_NOTE"].ToString();
                }
            }
            catch (Exception e)
            {
                logger.Error(e, $"{version.User.USERID}" + string.Format(Resources.CKR00002_E, "物理アイテム情報"));
                //Throw Error CKR00002-E
                //CKR00002-E　エラーをスロー
                throw new CopyKuInfoReadProcessException(string.Format(Resources.CKR00002_E, "物理アイテム情報"), e);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return phyCopyKuItemInfo;
        }


        //public T_ITEMCHG SelectItemDataTypeAndDataLen(string bDataType, string bDataLen, string dataType)
        //{
        //    T_ITEMCHG itemInfo = null;
        //    MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["myDatabaseConnection"].ConnectionString);
        //    try
        //    {
        //        MySqlCommand command = null;

        //        string selectQuery = "SELECT TMITEMCHG_ITEMATTR, TMITEMCHG_ITEMSIZE FROM t_tmitemchg WHERE " +
        //            "TMITEMCHG_CPATTR = '" + bDataType + "' AND TMITEMCHG_CPSIZE = '" + bDataLen + "';";

        //        //if(bDataType != string.Empty && bDataLen != string.Empty)
        //        //{
        //        //    itemInfo = new T_ITEMCHG();
        //        //    builder.Append(" TMITEMCHG_CPATTR ='"+ bDataType + "' AND TMITEMCHG_CPSIZE ='" + bDataLen + "'");                    
        //        //}
        //        command = new MySqlCommand(selectQuery, connection);
        //        if (bDataType != string.Empty)
        //        {
        //            itemInfo = new T_ITEMCHG();                    
        //            command.Parameters.Add(new MySqlParameter("@bDataType", bDataType));
        //            command.Parameters.Add(new MySqlParameter("@bDataLen", bDataLen));
        //        }

        //        connection.Open();


        //        IDataReader reader = command.ExecuteReader();

        //        if (itemInfo != null)
        //        {                    
        //            while(reader.Read())
        //            {
        //                itemInfo.TMITEMCHG_ITEMATTR = reader["TMITEMCHG_ITEMATTR"].ToString();
        //                itemInfo.TMITEMCHG_ITEMSIZE = reader["TMITEMCHG_ITEMSIZE"] as int? ?? default(int);
        //            }                    
        //        }                
        //    }
        //    catch (Exception e)
        //    {
        //        //Throw Error CKR00002-E
        //        //CKR00002-E　エラーをスロー
        //        throw new CopyKuInfoReadProcessException(string.Format(Resources.CKR00002_E, "物理コピー句情報"), e);
        //    }
        //    finally
        //    {
        //        if (connection != null)
        //        {
        //            connection.Close();
        //        }
        //    }
        //    return itemInfo;
        //}

        /// <summary>
        /// 論理コピー句情報一覧を取得する
        /// </summary>
        /// <param name="subSysIdL"></param>
        /// <param name="logicalId"></param>
        /// <returns></returns>
        public List<LogicalCopyKuItemInfo> SelectLogicalCopyKuItemInfos(string subSysIdL, string logicalId)
        {
            List<LogicalCopyKuItemInfo> LogCopyKuItemInfos = null;
            //MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["myDatabaseConnection"].ConnectionString);
            MySqlConnection connection = new MySqlConnection(this.version.ConnectString);
            try
            {
                string selectQuery = "SELECT T1.LOGITM_SEQ, T1.LOGITM_TYPE, T1.LOGITM_DATALEN, T1.LOGITM_PREFIX, T1.LOGITM_DTTYPE" +
                                        " FROM T_LOGITM T1 INNER JOIN T_PHYITM T2 ON T1.LOGITM_SEQ = T2.PHYITM_SEQ WHERE T1.LOGITM_SUBSYSIDL ='" + subSysIdL +
                                         "' AND T1.LOGITM_LCPID = '" + logicalId + "'; ";

                connection.Open();

                MySqlCommand command = new MySqlCommand(selectQuery, connection);


                if (subSysIdL != string.Empty && logicalId != string.Empty)
                {
                    LogCopyKuItemInfos = new List<LogicalCopyKuItemInfo>();
                    command.Parameters.Add(new MySqlParameter("@subSysIdL", subSysIdL));
                    command.Parameters.Add(new MySqlParameter("@logicalId", logicalId));
                }

                IDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    LogicalCopyKuItemInfo itemInfo = new LogicalCopyKuItemInfo();
                    itemInfo.LOGITM_SEQ = reader["LOGITM_SEQ"].ToString();
                    itemInfo.LOGITM_TYPE = reader["LOGITM_TYPE"].ToString();
                    itemInfo.LOGITM_DATALEN = reader["LOGITM_DATALEN"] as int? ?? default(int);
                    itemInfo.LOGITM_PREFIX = reader["LOGITM_PREFIX"].ToString();
                    itemInfo.LOGITM_DTTYPE = reader["LOGITM_DTTYPE"].ToString();
                    LogCopyKuItemInfos.Add(itemInfo);
                }
            }
            catch (Exception e)
            {
                logger.Error(e, $"{version.User.USERID}" + string.Format(Resources.CKR00002_E, "論理アイテム情報"));
                //Throw Error CKR00002-E
                //CKR00002-E　エラーをスロー
                throw new CopyKuInfoReadProcessException(string.Format(Resources.CKR00002_E, "論理アイテム情報"), e);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return LogCopyKuItemInfos;
        }

        /// <summary>
        /// 設定条件情報一覧を取得する
        /// </summary>
        /// <param name="subSysId"></param>
        /// <param name="infoId"></param>
        /// <param name="opName"></param>
        /// <returns></returns>
        public List<SettingConditionInfo> SelectSettingConditionInfos(string subSysId, string infoId, string opName)
        {
            List<SettingConditionInfo> settingConditionInfos = null;
            //MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["myDatabaseConnection"].ConnectionString);
            MySqlConnection connection = new MySqlConnection(this.version.ConnectString);
            try
            {
                string selectQuery = "SELECT T1.COND_SETCOND FROM T_CONDITION T1 INNER JOIN T_PHYITM T2 ON T1.COND_SEQ = T2.PHYITM_SEQ " +
                    "WHERE T1.COND_SUBSYSID ='" + subSysId + "' AND T1.COND_INFOID ='" + infoId + "' AND T1.COND_OPNM ='" + opName + "'; ";

                connection.Open();

                MySqlCommand command = new MySqlCommand(selectQuery, connection);


                if (subSysId != string.Empty && infoId != string.Empty)
                {
                    settingConditionInfos = new List<SettingConditionInfo>();
                    command = new MySqlCommand(selectQuery, connection);
                    command.Parameters.Add(new MySqlParameter("@subSysId", subSysId));
                    command.Parameters.Add(new MySqlParameter("@infoId", infoId));
                    command.Parameters.Add(new MySqlParameter("@opName", opName));
                }

                IDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    SettingConditionInfo itemInfo = new SettingConditionInfo();
                    itemInfo.COND_OPNM = reader["COND_SETCOND"].ToString();
                    settingConditionInfos.Add(itemInfo);
                }
            }
            catch (Exception e)
            {
                //log for Database error
                //データベースにエラーが発生する場合、ログに記録
                logger.Error(e, $"{version.User.USERID}" + string.Format(Resources.CKR00002_E, "論理設定条件情報"));

                throw new CopyKuInfoReadProcessException(string.Format(Resources.CKR00002_E, "論理設定条件情報"));
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return settingConditionInfos;
        }

        /// <summary>
        /// Ｍパーサ物理情報を取得する
        /// </summary>
        /// <param name="phySubSysId"></param>
        /// <param name="subSysId"></param>
        /// <param name="infoId"></param>
        /// <param name="layDef"></param>
        /// <returns></returns>
        public List<T_PHYPRS> SelectPhysicalMParserInfos(string phySubSysId, string subSysId, string infoId, string layDef)
        {
            List<T_PHYPRS> mParserInfos = null;
            //MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["myDatabaseConnection"].ConnectionString);
            MySqlConnection connection = new MySqlConnection(this.version.ConnectString);
            try
            {
                string selectQuery = "SELECT PHYPRS_PHYID, PHYPRS_TAGNM, PHYPRS_LTYPE FROM T_PHYPRS WHERE PHYPRS_PHYSYSID ='" + phySubSysId
                   + "' AND PHYPRS_INFOID ='" + infoId + "' AND PHYPRS_SUBSYSID = '" + subSysId + "' AND PHYPRS_LAYDEF = '" + layDef + "';";

                connection.Open();

                MySqlCommand command = new MySqlCommand(selectQuery, connection);


                if (phySubSysId != string.Empty && subSysId != string.Empty && infoId != string.Empty && layDef != string.Empty)
                {
                    mParserInfos = new List<T_PHYPRS>();
                    command = new MySqlCommand(selectQuery, connection);
                    command.Parameters.Add(new MySqlParameter("@phySubSysId", phySubSysId));
                    command.Parameters.Add(new MySqlParameter("@infoId", infoId));
                    command.Parameters.Add(new MySqlParameter("@subSysId", subSysId));
                    command.Parameters.Add(new MySqlParameter("@layDef", layDef));
                }

                IDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    T_PHYPRS itemInfo = new T_PHYPRS();
                    itemInfo.PHYPRS_PHYID = reader["PHYPRS_PHYID"].ToString();
                    itemInfo.PHYPRS_TAGNM = reader["PHYPRS_TAGNM"].ToString();
                    itemInfo.PHYPRS_LTYPE = reader["PHYPRS_LTYPE"].ToString();
                    mParserInfos.Add(itemInfo);
                }
            }
            catch (Exception e)
            {
                //log for Database error
                //データベースにエラーが発生する場合、ログに記録
                logger.Error(e, $"{version.User.USERID}" + string.Format(Resources.CKR00002_E, "物理Ｍパーサ情報"));

                //Throw Error CKR00002-E
                //CKR00002-E　エラーをスロー
                throw new CopyKuInfoReadProcessException(string.Format(Resources.CKR00002_E, "物理Ｍパーサ情報"), e);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return mParserInfos;
        }

        /// <summary>
        /// 物理コピー句情報を取得する
        /// </summary>
        /// <param name="subSysId"></param>
        /// <param name="infoId"></param>
        /// <returns></returns>
        public Int32 SelectCopyKuDataTypeCount(string subSysId, string infoId)
        {
            Int32 count = 0;
            MySqlConnection connection = new MySqlConnection(this.version.ConnectString);
            try
            {
                string selectQuery = "SELECT COUNT(PHYITM_CPYDTTYPE) FROM T_PHYITM WHERE PHYITM_SUBSYSID ='" + subSysId
                    + "' AND PHYITM_INFOID ='" + infoId + "';";

                connection.Open();

                MySqlCommand command = null;

                if (subSysId != string.Empty && infoId != string.Empty)
                {
                    command = new MySqlCommand(selectQuery, connection);
                    command.Parameters.Add(new MySqlParameter("@subSysId", subSysId));
                    command.Parameters.Add(new MySqlParameter("@infoId", infoId));
                }

                count = Convert.ToInt32(command.ExecuteScalar());

            }
            catch (Exception e)
            {
                //Throw Error CKR00002-E
                //CKR00002-E　エラーをスロー
                logger.Error(e, $"{version.User.USERID}" + string.Format(Resources.CKR00002_E, "物理アイテム情報"));
                throw new CopyKuInfoReadProcessException(string.Format(Resources.CKR00002_E, "物理アイテム情報"), e);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return count;
        }

        /// <summary>
        /// 物理コピー句情報を取得する
        /// </summary>
        /// <param name="subSysId"></param>
        /// <param name="infoId"></param>
        /// <returns></returns>
        public Int32 SelectLastOutputOrderNoOfSettingInfo(string subSysId, string infoId)
        {
            Int32 count = 0;
            MySqlConnection connection = new MySqlConnection(this.version.ConnectString);
            try
            {
                string selectQuery = "SELECT MAX(COND_OUTPUTORDER) FROM T_CONDITION WHERE COND_SUBSYSID ='" + subSysId
                    + "' AND COND_INFOID ='" + infoId + "';";

                connection.Open();

                MySqlCommand command = null;

                if (subSysId != string.Empty && infoId != string.Empty)
                {
                    command = new MySqlCommand(selectQuery, connection);
                    command.Parameters.Add(new MySqlParameter("@subSysId", subSysId));
                    command.Parameters.Add(new MySqlParameter("@infoId", infoId));
                }

                if (command.ExecuteScalar() != DBNull.Value)
                {
                    count = Convert.ToInt32(command.ExecuteScalar());
                }

            }
            catch (Exception e)
            {
                //Throw Error CKR00002-E
                //CKR00002-E　エラーをスロー
                logger.Error(e, $"{version.User.USERID}" + string.Format(Resources.CKR00002_E, "物理アイテム情報"));
                throw new CopyKuInfoReadProcessException(string.Format(Resources.CKR00002_E, "物理アイテム情報"), e);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return count;
        }

        /// <summary>
        /// 物理コピー句情報を取得する
        /// </summary>
        /// <param name="subSysId"></param>
        /// <param name="infoId"></param>
        /// <returns></returns>
        public Int32 SelectLastOutputOrderNoOfLogicalInfo(string subSysId, string infoId, string logicSubSysId)
        {
            Int32 count = 0;
            MySqlConnection connection = new MySqlConnection(this.version.ConnectString);
            try
            {
                string selectQuery = "SELECT MAX(CPYLGC_OUTPUTORDER) FROM T_CPYLOG WHERE CPYLGC_PHYSYSID ='" + subSysId
                    + "' AND CPYLGC_INFOID ='" + infoId + "' AND CPYLGC_SUBSYSID ='" + logicSubSysId + "';";

                connection.Open();

                MySqlCommand command = null;

                if (subSysId != string.Empty && infoId != string.Empty && logicSubSysId != string.Empty)
                {
                    command = new MySqlCommand(selectQuery, connection);
                    command.Parameters.Add(new MySqlParameter("@subSysId", subSysId));
                    command.Parameters.Add(new MySqlParameter("@infoId", infoId));
                    command.Parameters.Add(new MySqlParameter("@logicSubSysId", logicSubSysId));
                }
                if (command.ExecuteScalar() != DBNull.Value)
                {
                    count = Convert.ToInt32(command.ExecuteScalar());
                }
            }
            catch (Exception e)
            {
                //Throw Error CKR00002-E
                //CKR00002-E　エラーをスロー
                logger.Error(e, $"{version.User.USERID}" + string.Format(Resources.CKR00002_E, "論理コピー句情報"));
                throw new CopyKuInfoReadProcessException(string.Format(Resources.CKR00002_E, "論理コピー句情報"), e);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return count;
        }

        /// <summary>
        /// 物理コピー句情報をＤＢに登録する
        /// </summary>
        /// <param name="phyCopyInfo"></param>
        /// <returns></returns>
        public int insertPhyCopyKuInfo(PhysicalCopyKuInfo phyCopyInfo)
        {
            int result = 0;
            //MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["myDatabaseConnection"].ConnectionString);
            MySqlConnection connection = new MySqlConnection(this.version.ConnectString);
            try
            {
                string insertQuery = "INSERT INTO T_CPYPHY(CPYPHY_SUBSYSID, CPYPHY_INFOID, CPYPHY_BCPID, CPYPHY_BCPNM, CPYPHY_SIZE, CPYPHY_LEVNO," +
                    "CPYPHY_COMMENT, CPYPHY_USERID, CPYPHY_UPDTIME) "
                    + "VALUES(@CPYPHY_SUBSYSID, @CPYPHY_INFOID, @CPYPHY_BCPID, @CPYPHY_BCPNM, @CPYPHY_Size, @CPYPHY_LEVNO, @CPYPHY_COMMENT," +
                    " @CPYPHY_USERID, @CPYPHY_UPDTIME)";

                connection.Open();

                MySqlCommand command = new MySqlCommand(insertQuery, connection);

                command.Parameters.AddWithValue("@CPYPHY_SUBSYSID", phyCopyInfo.CPYPHY_SubSysId);
                command.Parameters.AddWithValue("@CPYPHY_INFOID", phyCopyInfo.CPYPHY_InfoId);
                command.Parameters.AddWithValue("@CPYPHY_BCPID", phyCopyInfo.CPYPHY_BcpId);
                command.Parameters.AddWithValue("@CPYPHY_BCPNM", phyCopyInfo.CPYPHY_BcpNm);
                command.Parameters.AddWithValue("@CPYPHY_SIZE", phyCopyInfo.CPYPHY_Size);
                command.Parameters.AddWithValue("@CPYPHY_LEVNO", phyCopyInfo.CPYPHY_LEVNO);
                command.Parameters.AddWithValue("@CPYPHY_COMMENT", phyCopyInfo.CPYPHY_Comment);
                command.Parameters.AddWithValue("@CPYPHY_USERID", phyCopyInfo.CPYPHY_UserId);
                command.Parameters.AddWithValue("@CPYPHY_UPDTIME", DateTime.Now);

                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                //log for Database error
                //データベースにエラーが発生する場合、ログに記録
                logger.Error(e, $"{version.User.USERID}" + string.Format(Resources.TSR00003_E, "物理コピー句情報"));

                throw new CopyKuInfoReadProcessException(string.Format(Resources.TSR00003_E, "物理コピー句情報"), e);

            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return result;
        }

        /// <summary>
        /// 物理アイテム情報をＤＢに登録する
        /// </summary>
        /// <param name="phyCopyItemInfo"></param>
        /// <returns></returns>
        public int insertPhyCopyKuItemInfo(PhysicalCopyKuItemInfo phyCopyItemInfo)
        {
            int result = 0;
            //MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["myDatabaseConnection"].ConnectionString);
            MySqlConnection connection = new MySqlConnection(this.version.ConnectString);
            try
            {
                //string insertQuery = "INSERT INTO T_PHYITM(PHYITM_SUBSYSID, PHYITM_INFOID, PHYITM_PATH, PHYITM_ITEMNO, PHYITM_SEQ, PHYITM_LEVEL, PHYITM_ITEMID, PHYITM_ITEMNM, PHYITM_DTTYPE," +
                //    "PHYITM_CPYDTTYPE, PHYITM_DTLEN, PHYITM_COMMENT, PHYITM_NOTE, PHYITM_TAG, PHYITM_ITEMFLG, PHYITM_OCCURS)"
                //    + "VALUES(@PHYITM_SUBSYSID, @PHYITM_INFOID, @PHYITM_PATH, @PHYITM_ITEMNO, (SELECT nextval('T_PHYITM') as next_sequence), @PHYITM_LEVEL, @PHYITM_ITEMID, @PHYITM_ITEMNM, @PHYITM_DTTYPE, @PHYITM_CPYDTTYPE, @PHYITM_DTLEN," +
                //    "@PHYITM_COMMENT, @PHYITM_NOTE, @PHYITM_TAG, @PHYITM_ITEMFLG, @PHYITM_OCCURS)";
                string insertQuery = "INSERT INTO T_PHYITM(PHYITM_SUBSYSID, PHYITM_INFOID, PHYITM_PATH, PHYITM_ITEMNO, PHYITM_SEQ, PHYITM_LEVEL, PHYITM_ITEMID, PHYITM_ITEMNM, PHYITM_DTTYPE," +
                    "PHYITM_CPYDTTYPE, PHYITM_DTLEN, PHYITM_COMMENT, PHYITM_NOTE, PHYITM_ITEMFLG, PHYITM_OCCURS)"
                    + "VALUES(@PHYITM_SUBSYSID, @PHYITM_INFOID, @PHYITM_PATH, @PHYITM_ITEMNO, @PHYITM_SEQ, @PHYITM_LEVEL, @PHYITM_ITEMID, @PHYITM_ITEMNM, @PHYITM_DTTYPE, @PHYITM_CPYDTTYPE, @PHYITM_DTLEN," +
                    "@PHYITM_COMMENT, @PHYITM_NOTE, @PHYITM_ITEMFLG, @PHYITM_OCCURS)";
                connection.Open();

                MySqlCommand command = new MySqlCommand(insertQuery, connection);

                command.Parameters.AddWithValue("@PHYITM_SUBSYSID", phyCopyItemInfo.PHYITM_SubSysId);
                command.Parameters.AddWithValue("@PHYITM_INFOID", phyCopyItemInfo.PHYITM_InfoId);
                command.Parameters.AddWithValue("@PHYITM_PATH", phyCopyItemInfo.PHYITM_Path);
                command.Parameters.AddWithValue("@PHYITM_ITEMNO", phyCopyItemInfo.PHYITM_ItemNo);
                command.Parameters.AddWithValue("@PHYITM_SEQ", phyCopyItemInfo.PHYITM_Seq);
                command.Parameters.AddWithValue("@PHYITM_LEVEL", phyCopyItemInfo.PHYITM_Level);
                command.Parameters.AddWithValue("@PHYITM_ITEMID", phyCopyItemInfo.PHYITM_ItemId);
                command.Parameters.AddWithValue("@PHYITM_ITEMNM", phyCopyItemInfo.PHYITM_ItemName);
                command.Parameters.AddWithValue("@PHYITM_DTTYPE", phyCopyItemInfo.PHYITM_DTTYPE);
                command.Parameters.AddWithValue("@PHYITM_CPYDTTYPE", phyCopyItemInfo.PHYITM_CPYDTTYPE);
                command.Parameters.AddWithValue("@PHYITM_DTLEN", phyCopyItemInfo.PHYITM_DTLEN);
                command.Parameters.AddWithValue("@PHYITM_COMMENT", phyCopyItemInfo.PHYITM_Comment);
                command.Parameters.AddWithValue("@PHYITM_NOTE", phyCopyItemInfo.PHYITM_Note);
                command.Parameters.AddWithValue("@PHYITM_ITEMFLG", phyCopyItemInfo.PHYITM_ItemFlg);
                command.Parameters.AddWithValue("@PHYITM_OCCURS", phyCopyItemInfo.PHYITM_Occurs);

                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                //データベースにエラーが発生する場合、ログに記録
                logger.Error(e, $"{version.User.USERID}" + string.Format(Resources.TSR00003_E, "物理コピー句アイテム情報"));

                throw new CopyKuInfoReadProcessException(string.Format(Resources.TSR00003_E, "物理コピー句アイテム情報"), e);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return result;
        }

        /// <summary>
        /// 論理コピー句情報をＤＢに登録する
        /// </summary>
        /// <param name="logicalCopyKuInfo"></param>
        /// <returns></returns>
        public int insertLogicalCopyKuInfo(LogicalCopyKuInfo logicalCopyKuInfo)
        {
            int result = 0;
            //MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["myDatabaseConnection"].ConnectionString);
            MySqlConnection connection = new MySqlConnection(this.version.ConnectString);
            try
            {
                string insertQuery = "INSERT INTO T_CPYLOG(CPYLGC_PHYSYSID, CPYLGC_INFOID, CPYLGC_SUBSYSID, " +
                    "CPYLGC_LCPID, CPYLGC_OPNM, CPYLGC_OUTPUTORDER, CPYLGC_LEVNO, CPYLGC_COMMENT, CPYLGC_USERID, CPYLGC_UPDTIME) VALUES "
                    + "(@CPYLGC_PHYSYSID, @CPYLGC_INFOID, @CPYLGC_SUBSYSID, @CPYLGC_LCPID, @CPYLGC_OPNM, " +
                    "@CPYLGC_OUTPUTORDER, @CPYLGC_LEVNO, @CPYLGC_COMMENT, @CPYLGC_USERID, @CPYLGC_UPDTIME)";

                connection.Open();

                MySqlCommand command = new MySqlCommand(insertQuery, connection);

                command.Parameters.AddWithValue("@CPYLGC_PHYSYSID", logicalCopyKuInfo.CPYLGC_PHYSYSID);
                command.Parameters.AddWithValue("@CPYLGC_INFOID", logicalCopyKuInfo.CPYLGC_INFOID);
                command.Parameters.AddWithValue("@CPYLGC_SUBSYSID", logicalCopyKuInfo.CPYLGC_SUBSYSID);
                command.Parameters.AddWithValue("@CPYLGC_LCPID", logicalCopyKuInfo.CPYLGC_LCPID);
                command.Parameters.AddWithValue("@CPYLGC_OPNM", logicalCopyKuInfo.CPYLGC_OPNM);
                command.Parameters.AddWithValue("@CPYLGC_OUTPUTORDER", logicalCopyKuInfo.CPYLGC_OUTPUTORDER);
                command.Parameters.AddWithValue("@CPYLGC_LEVNO", logicalCopyKuInfo.CPYLGC_LEVNO);
                command.Parameters.AddWithValue("@CPYLGC_COMMENT", logicalCopyKuInfo.CPYLGC_COMMENT);
                command.Parameters.AddWithValue("@CPYLGC_USERID", logicalCopyKuInfo.CPYLGC_USERID);
                command.Parameters.AddWithValue("@CPYLGC_UPDTIME", DateTime.Now);

                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                //データベースにエラーが発生する場合、ログに記録
                logger.Error(e, $"{version.User.USERID}" + string.Format(Resources.TSR00003_E, "論理コピー句情報"));

                throw new CopyKuInfoReadProcessException(string.Format(Resources.TSR00003_E, "論理コピー句情報"), e);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return result;
        }

        /// <summary>
        /// 論理アイテム情報をＤＢに登録する
        /// </summary>
        /// <param name="logicalCopyItemInfo"></param>
        /// <returns></returns>
        public int insertLogicalCopyKuItemInfo(LogicalCopyKuItemInfo logicalCopyItemInfo)
        {
            int result = 0;
            //MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["myDatabaseConnection"].ConnectionString);
            MySqlConnection connection = new MySqlConnection(this.version.ConnectString);
            try
            {
                string insertQuery = "INSERT INTO T_LOGITM(LOGITM_SUBSYSIDL, LOGITM_LCPID, LOGITM_SEQ, " +
                    "LOGITM_TYPE, LOGITM_DATALEN, LOGITM_PREFIX, LOGITM_DTTYPE, LOGITM_MCODE) "
                    + "VALUES(@LOGITM_SUBSYSIDL, @LOGITM_LCPID, @LOGITM_SEQ, @LOGITM_TYPE, " +
                    "@LOGITM_DATALEN, @LOGITM_PREFIX, @LOGITM_DTTYPE, @LOGITM_MCODE)";

                connection.Open();

                MySqlCommand command = new MySqlCommand(insertQuery, connection);

                command.Parameters.AddWithValue("@LOGITM_SUBSYSIDL", logicalCopyItemInfo.LOGITM_SUBSYSIDL);
                command.Parameters.AddWithValue("@LOGITM_LCPID", logicalCopyItemInfo.LOGITM_LCPID);
                command.Parameters.AddWithValue("@LOGITM_SEQ", logicalCopyItemInfo.LOGITM_SEQ);
                command.Parameters.AddWithValue("@LOGITM_TYPE", logicalCopyItemInfo.LOGITM_TYPE);
                command.Parameters.AddWithValue("@LOGITM_DATALEN", logicalCopyItemInfo.LOGITM_DATALEN);
                command.Parameters.AddWithValue("@LOGITM_PREFIX", logicalCopyItemInfo.LOGITM_PREFIX);
                command.Parameters.AddWithValue("@LOGITM_DTTYPE", logicalCopyItemInfo.LOGITM_DTTYPE);
                command.Parameters.AddWithValue("@LOGITM_MCODE", logicalCopyItemInfo.LOGITM_MCODE);

                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                //データベースにエラーが発生する場合、ログに記録
                logger.Error(e, $"{version.User.USERID}" + string.Format(Resources.TSR00003_E, "論理アイテム情報"));

                throw new CopyKuInfoReadProcessException(string.Format(Resources.TSR00003_E, "論理アイテム情報"), e);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return result;
        }

        /// <summary>
        /// Ｍパーサ物理情報をＤＢに登録する
        /// </summary>
        /// <param name="mParserInfo"></param>
        /// <returns></returns>
        public int insertPhysicalMParserInfo(T_PHYPRS mParserInfo)
        {
            int result = 0;
            //MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["myDatabaseConnection"].ConnectionString);
            MySqlConnection connection = new MySqlConnection(this.version.ConnectString);
            try
            {
                string insertQuery = "INSERT INTO T_PHYPRS(PHYPRS_PHYSYSID, PHYPRS_INFOID, PHYPRS_SUBSYSID, " +
                    "PHYPRS_PHYID, PHYPRS_LAYDEF, PHYPRS_SEQ, PHYPRS_TAGNM, PHYPRS_LTYPE, PHYPRS_CDCHG, PHYPRS_FLG, PHYPRS_MCODE, PHYPRS_USERID, PHYPRS_UPDTIME)"
                    + "VALUES(@PHYPRS_PHYSYSID, @PHYPRS_INFOID, @PHYPRS_SUBSYSID, @PHYPRS_PHYID, @PHYPRS_LAYDEF, " +
                    "@PHYPRS_SEQ, @PHYPRS_TAGNM, @PHYPRS_LTYPE, @PHYPRS_CDCHG, @PHYPRS_FLG, @PHYPRS_MCODE, @PHYPRS_USERID, @PHYPRS_UPDTIME)";

                connection.Open();

                MySqlCommand command = new MySqlCommand(insertQuery, connection);

                command.Parameters.AddWithValue("@PHYPRS_PHYSYSID", mParserInfo.PHYPRS_PHYSYSID);
                command.Parameters.AddWithValue("@PHYPRS_INFOID", mParserInfo.PHYPRS_INFOID);
                command.Parameters.AddWithValue("@PHYPRS_SUBSYSID", mParserInfo.PHYPRS_SUBSYSID);
                command.Parameters.AddWithValue("@PHYPRS_PHYID", mParserInfo.PHYPRS_PHYID);
                command.Parameters.AddWithValue("@PHYPRS_LAYDEF", mParserInfo.PHYPRS_LAYDEF);
                command.Parameters.AddWithValue("@PHYPRS_SEQ", mParserInfo.PHYPRS_SEQ);
                command.Parameters.AddWithValue("@PHYPRS_TAGNM", mParserInfo.PHYPRS_TAGNM);
                command.Parameters.AddWithValue("@PHYPRS_LTYPE", mParserInfo.PHYPRS_LTYPE);
                command.Parameters.AddWithValue("@PHYPRS_CDCHG", mParserInfo.PHYPRS_CDCHG);
                command.Parameters.AddWithValue("@PHYPRS_FLG", mParserInfo.PHYPRS_FLG);
                command.Parameters.AddWithValue("@PHYPRS_MCODE", mParserInfo.PHYPRS_MCODE);
                command.Parameters.AddWithValue("@PHYPRS_USERID", mParserInfo.PHYPRS_USERID);
                command.Parameters.AddWithValue("@PHYPRS_UPDTIME", DateTime.Now);

                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                //データベースにエラーが発生する場合、ログに記録
                logger.Error(e, $"{version.User.USERID}" + string.Format(Resources.TSR00003_E, "物理Ｍパーサ情報"));

                throw new CopyKuInfoReadProcessException(string.Format(Resources.TSR00003_E, "物理Ｍパーサ情報"), e);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return result;
        }

        /// <summary>
        /// 設定条件情報をＤＢに登録する
        /// </summary>
        /// <param name="settInfo"></param>
        /// <returns></returns>
        public int insertLogicalSettingCondtionInfo(SettingConditionInfo settInfo)
        {
            int result = 0;
            //MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["myDatabaseConnection"].ConnectionString);
            MySqlConnection connection = new MySqlConnection(this.version.ConnectString);
            try
            {
                string insertQuery = "INSERT INTO T_CONDITION(COND_SUBSYSID, COND_INFOID, COND_OPNM, COND_SEQ, COND_OUTPUTORDER, COND_SETCOND) "
                    + "VALUES(@COND_SUBSYSID, @COND_INFOID, @COND_OPNM, @COND_SEQ, @COND_OUTPUTORDER, @COND_SETCOND)";

                connection.Open();

                MySqlCommand command = new MySqlCommand(insertQuery, connection);

                command.Parameters.AddWithValue("@COND_SUBSYSID", settInfo.COND_SUBSYSID);
                command.Parameters.AddWithValue("@COND_INFOID", settInfo.COND_INFOID);
                command.Parameters.AddWithValue("@COND_OPNM", settInfo.COND_OPNM);
                command.Parameters.AddWithValue("@COND_SEQ", settInfo.COND_SEQ);
                command.Parameters.AddWithValue("@COND_OUTPUTORDER", settInfo.COND_OUTPUTORDER);
                command.Parameters.AddWithValue("@COND_SETCOND", settInfo.COND_SETCOND);

                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                //データベースにエラーが発生する場合、ログに記録
                logger.Error(e, $"{version.User.USERID}" + string.Format(Resources.TSR00003_E, "論理設定条件情報"));

                throw new CopyKuInfoReadProcessException(string.Format(Resources.TSR00003_E, "論理設定条件情報"), e);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return result;
        }

        /// <summary>
        /// 物理アイテム情報をＤＢに更新する
        /// </summary>
        /// <param name="itemInfo"></param>
        /// <returns></returns>
        public int updatePhyCopyKuItemInfoCommentAndNOTE(PhysicalCopyKuItemInfo itemInfo)
        {
            int result = 0;
            //MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["myDatabaseConnection"].ConnectionString);
            MySqlConnection connection = new MySqlConnection(this.version.ConnectString);
            try
            {
                string updatequery = "UPDATE T_PHYITM SET PHYITM_NOTE =@PHYITM_NOTE, PHYITM_COMMENT = @PHYITM_COMMENT where PHYITM_SUBSYSID ='" + itemInfo.PHYITM_SubSysId +
                                        "' and PHYITM_INFOID ='" + itemInfo.PHYITM_InfoId + "' and PHYITM_SEQ = '" + itemInfo.PHYITM_Seq + "';";

                connection.Open();

                MySqlCommand command = new MySqlCommand(updatequery, connection);


                if (itemInfo.PHYITM_Note != string.Empty)
                {
                    command.Parameters.AddWithValue("@PHYITM_NOTE", itemInfo.PHYITM_Note);
                }
                else
                {
                    command.Parameters.AddWithValue("@PHYITM_NOTE", null);
                }
                if (itemInfo.PHYITM_Comment != string.Empty)
                {
                    command.Parameters.AddWithValue("@PHYITM_COMMENT", itemInfo.PHYITM_Comment);
                }
                else
                {
                    command.Parameters.AddWithValue("@PHYITM_COMMENT", null);
                }
                command.Parameters.AddWithValue("@PHYITM_subsysid", itemInfo.PHYITM_SubSysId);
                command.Parameters.AddWithValue("@PHYITM_infoid", itemInfo.PHYITM_InfoId);
                command.Parameters.AddWithValue("@PHYITM_SEQ", itemInfo.PHYITM_Seq);

                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                //データベースにエラーが発生する場合、ログに記録
                logger.Error(e, $"{version.User.USERID}" + string.Format(Resources.TSR00003_E, "物理コピー句アイテム情報"));

                throw new CopyKuInfoReadProcessException(string.Format(Resources.TSR00003_E, "物理コピー句アイテム情報"), e);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return result;
        }

        /// <summary>
        /// 物理アイテム情報をＤＢに更新する
        /// </summary>
        /// <param name="itemInfo"></param>
        /// <returns></returns>
        public int updatePhyCopyKuItemInfo(PhysicalCopyKuItemInfo itemInfo)
        {
            int result = 0;
            //MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["myDatabaseConnection"].ConnectionString);
            MySqlConnection connection = new MySqlConnection(this.version.ConnectString);
            try
            {
                string updatequery = "UPDATE T_PHYITM SET PHYITM_ITEMID =@PHYITM_ITEMID, PHYITM_DTTYPE = @PHYITM_DTTYPE, PHYITM_DTLEN =@PHYITM_DTLEN, PHYITM_OCCURS = @PHYITM_OCCURS, " +
                    "PHYITM_NOTE =@PHYITM_NOTE, PHYITM_COMMENT = @PHYITM_COMMENT where PHYITM_SUBSYSID ='" + itemInfo.PHYITM_SubSysId +
                                        "' and PHYITM_INFOID ='" + itemInfo.PHYITM_InfoId + "' and PHYITM_SEQ = '" + itemInfo.PHYITM_Seq + "';";

                connection.Open();

                MySqlCommand command = new MySqlCommand(updatequery, connection);

                command.Parameters.AddWithValue("@PHYITM_ITEMID", itemInfo.PHYITM_ItemId);
                command.Parameters.AddWithValue("@PHYITM_DTTYPE", itemInfo.PHYITM_DTTYPE);
                command.Parameters.AddWithValue("@PHYITM_DTLEN", itemInfo.PHYITM_DTLEN);
                command.Parameters.AddWithValue("@PHYITM_OCCURS", itemInfo.PHYITM_Occurs);
                command.Parameters.AddWithValue("@PHYITM_NOTE", itemInfo.PHYITM_Note);
                command.Parameters.AddWithValue("@PHYITM_COMMENT", itemInfo.PHYITM_Comment);
                command.Parameters.AddWithValue("@PHYITM_subsysid", itemInfo.PHYITM_SubSysId);
                command.Parameters.AddWithValue("@PHYITM_infoid", itemInfo.PHYITM_InfoId);
                command.Parameters.AddWithValue("@PHYITM_SEQ", itemInfo.PHYITM_Seq);

                result = command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                //データベースにエラーが発生する場合、ログに記録
                logger.Error(e, $"{version.User.USERID}" + string.Format(Resources.TSR00003_E, "物理コピー句アイテム情報"));

                throw new CopyKuInfoReadProcessException(string.Format(Resources.TSR00003_E, "物理コピー句アイテム情報"), e);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return result;
        }
        #endregion
    }
}
