﻿using MarsTool.Models;
using MarsTool.Models.DB;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarsTool
{
    public partial class PasswordChange : Form
    {
        private VersionModel version;

        public PasswordChange()
        {
            InitializeComponent();
        }

        public PasswordChange(VersionModel p2) : this()
        {
            version = p2;
        }

        private NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.textBox3.Text.Length >= 6 && this.textBox3.Text.Length <= 12)
            {
                if (this.textBox3.Text != this.textBox4.Text)
                {
                    MessageBox.Show(Properties.Resources.LGN_OLDNEW_NOEQUAL, Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (String.IsNullOrEmpty(this.textBox2.Text))
                {
                    MessageBox.Show(Properties.Resources.LGN_OLD_NOINPUT, Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (this.textBox2.Text == this.textBox3.Text)
                {
                    MessageBox.Show("新パスワードは旧パスワードと異なるパスワードを設定してください。", Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    using (var context = new Models.DB.commondbcontext())
                    {
                        string uid = this.textBox1.Text;
                        string pwd = this.textBox2.Text;
                        T_USER u = context.T_USERS.FirstOrDefault(r => r.USERID == uid && r.PASSWORD == pwd);

                        if (u != null)
                        {
                            u.PASSWORD = this.textBox3.Text;
                            context.SaveChanges();
                            logger.Info($"{uid} パスワード変更 成功");
                            MessageBox.Show(Properties.Resources.LGN_CHANGE_PWD, Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            this.Dispose();
                        }
                        else
                        {
                            logger.Info($"{uid} パスワード変更 失敗");
                            MessageBox.Show(Properties.Resources.LGN_OLDPWD_WRONG, Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }

            }
            else
            {
                MessageBox.Show(Properties.Resources.LGN_NEWPWD_RULE, Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void PasswordChange_Load(object sender, EventArgs e)
        {
            this.textBox1.Text = version.User.USERID;
            this.label1.Select();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}
