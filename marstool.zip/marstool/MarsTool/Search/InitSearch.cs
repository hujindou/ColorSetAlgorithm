﻿using MarsTool.Models;
using MarsTool.Models.DB;
using MarsTool.Properties;
using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Windows.Forms;

namespace MarsTool.Search
{
    /// <summary>
    /// インタフェース情報検索タブクラス
    /// </summary>
    class InitSearch : SearchBase<T_PHYITM>
    {
        /// <summary>
        /// 情報部ＩＤ
        /// </summary>
        private RadioButton RdoInitInfoId { set; get; }

        /// <summary>
        /// パスキーワード
        /// </summary>
        private RadioButton RdoInitKey { set; get; }

        /// <summary>
        /// 項目情報
        /// </summary>
        private RichTextBox RTxtItemInfo { set; get; }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public InitSearch(
            ComboBox subSysIdsCtl,
            RadioButton rdoInitInfoId,
            RadioButton rdoInitKey,
            DataGridView dgv,
            RichTextBox itemInfo,
            VersionModel version)
            : base(subSysIdsCtl, dgv, version)
        {
            this.RdoInitInfoId = rdoInitInfoId;
            this.RdoInitKey = rdoInitKey;
            this.RTxtItemInfo = itemInfo;
            this.Dgv.CellClick += CellClick;
        }

        /// <summary>
        /// サブシステム設定
        /// </summary>
        protected override string[] SearchSysIds()
        {
            return this.Context.T_PHYITM.AsNoTracking().Select(r => r.PHYITM_SUBSYSID).Distinct().OrderBy(id => id).ToArray();
        }

        /// <summary>
        /// 入力検証
        /// </summary>
        /// <returns></returns>
        protected override bool Validate()
        {
            if (this.RdoInitInfoId.Checked)
            {
                // 情報部ＩＤ
                var infoId = (this.RdoInitInfoId.Tag as TextBox).Text;
                if (string.IsNullOrWhiteSpace(infoId))
                {
                    MessageBox.Show("情報部ＩＤは必須入力項目です。",
                        Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
            }
            else
            {
                // パスキーワード
                var keyword = (this.RdoInitKey.Tag as TextBox).Text;
                if (string.IsNullOrWhiteSpace(keyword))
                {
                    MessageBox.Show("キーワードは必須入力項目です。",
                        Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 検索
        /// </summary>
        /// <param name="dgv"></param>
        protected override List<T_PHYITM> SearchData(out int count)
        {
            count = 0;

            var selectItems = " SELECT T_PHYITM.*";
            var selectCnt = " SELECT COUNT(PHYITM_PATH)";
            var from = " FROM T_CPYPHY INNER JOIN T_PHYITM ON CPYPHY_SUBSYSID = PHYITM_SUBSYSID AND CPYPHY_INFOID = PHYITM_INFOID";
            var where = $" WHERE (CPYPHY_STATUS is NULL OR CPYPHY_STATUS <> '1')";
            if (!string.IsNullOrEmpty(this.SubSysId))
            {
                where += $" AND PHYITM_SUBSYSID = '{this.SubSysId}'";
            }

            DbRawSqlQuery<T_PHYITM> phyitm = null;
            if (this.RdoInitInfoId.Checked)
            {
                // 情報部ＩＤ
                var infoId = (this.RdoInitInfoId.Tag as TextBox).Text;
                where = $" {where} AND PHYITM_INFOID LIKE '%{infoId}%'";
            }
            else
            {
                // パスキーワード
                var keyword = (this.RdoInitKey.Tag as TextBox).Text;
                var keys = keyword.Split();
                var keyWheres = new List<string>();
                foreach (var key in keys)
                {
                    keyWheres.Add($" PHYITM_PATH LIKE '%{key}%' ");
                }
                if (keyWheres.Count == 1)
                {
                    where = $" {where} AND {keyWheres[0]}";
                }
                else
                {
                    where = $" {where} AND {string.Join(" AND ", keyWheres)}";
                }
            }

            count = this.Context.Database.SqlQuery<int>($"{selectCnt} {from} {where}").Single();

            phyitm = this.Context.Database.SqlQuery<T_PHYITM>($"{selectItems} {from} {where} LIMIT {MAX_COUNT}");

            return phyitm.ToList();
        }

        /// <summary>
        /// 画面クリア
        /// </summary>
        protected override void Clear()
        {
            base.Clear();
            this.RTxtItemInfo.Text = string.Empty;
        }

        /// <summary>
        /// 検索されたデータが一覧に表示する
        /// </summary>
        /// <param name="queryDatas"></param>
        protected override void SetDgv(List<T_PHYITM> queryDatas)
        {
            var fields = new List<string>();
            foreach (var record in queryDatas)
            {
                fields.Clear();
                // サブシステムＩＤ
                fields.Add(record.PHYITM_SUBSYSID);
                // 情報部ＩＤ
                fields.Add(record.PHYITM_INFOID);
                // 項目名
                fields.Add(record.PHYITM_ITEMNM);
                // 項目パス
                fields.Add(record.PHYITM_PATH);

                var index = this.Dgv.Rows.Add(fields.ToArray());
                this.Dgv.Rows[index].Tag = record;
            }

            this.SetItemInfo(this.Dgv.Rows[0].Tag as T_PHYITM);
        }

        /// <summary>
        /// 選択した項目の情報を表示する
        /// </summary>
        /// <param name="phyitm"></param>
        private void SetItemInfo(T_PHYITM phyitm)
        {
            if (phyitm == null) return;
            this.RTxtItemInfo.Text = $"レベル：  {phyitm.PHYITM_LEVEL}\n" +
                $"アイテム記号名称：  {phyitm.PHYITM_ITEMID}\n" +
                $"アイテム名称：  {phyitm.PHYITM_ITEMNM}\n" +
                $"データ形式：  {phyitm.PHYITM_DTTYPE}\n" +
                $"データサイズ：  {phyitm.PHYITM_DTLEN}\n" +
                $"繰返し回数：  {phyitm.PHYITM_OCCURS}\n" +
                $"アイテム内容：  {phyitm.PHYITM_COMMENT}\n" +
                $"記事：  {phyitm.PHYITM_NOTE}\n" +
                $"コピー句データ形式：  {phyitm.PHYITM_CPYDTTYPE}\n" +
                $"アイテムフラグ：  {phyitm.PHYITM_ITEMFLG}\n" +
                $"候補値グループ名：  {phyitm.PHYITM_GROUP}\n" +
                $"イメージ名：  {phyitm.PHYITM_IMAGENM}";
        }

        /// <summary>
        /// 項目パスを選択する
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            this.SetItemInfo(this.Dgv.Rows[e.RowIndex].Tag as T_PHYITM);
        }

        /// <summary>
        /// インタフェース編集画面遷移
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected override void CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            try
            {
                var f = new Interface(this.Dgv.Rows[e.RowIndex].Tag as T_PHYITM, this.Version);
                f.ShowDialog();
            }
            catch (Exception ex)
            {
                this.Logger.Error(ex.Message);
                var msg = $"{MessageId.TSR00012_E}\n{ex.Message}";
                MessageBox.Show(msg, Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
