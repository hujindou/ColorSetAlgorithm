﻿using MarsTool.Models;
using MarsTool.Models.DB;
using MarsTool.Properties;
using MarsTool.RData.IO.DB;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MarsTool.Search
{
    /// <summary>
    /// ＲＤＡＴＡ情報検索タブクラス
    /// </summary>
    class RDataSearch : SearchBase<T_RDATA>
    {
        /// <summary>
        /// テーブルＩＤ
        /// </summary>
        private RadioButton RdoRDataTbId { set; get; }

        /// <summary>
        /// テーブル名
        /// </summary>
        private RadioButton RdoRDataTbNm { set; get; }

        /// <summary>
        /// 削除ボタン
        /// </summary>
        private Button BtnDel { set; get; }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public RDataSearch(
            ComboBox subSysIdsCtl,
            RadioButton rdoRDataTbId,
            RadioButton rdoRDataTbNm,
            DataGridView dgv,
            Button btnDel,
            VersionModel version)
            : base(subSysIdsCtl, dgv, version)
        {
            this.RdoRDataTbId = rdoRDataTbId;
            this.RdoRDataTbNm = rdoRDataTbNm;
            this.BtnDel = btnDel;
        }

        /// <summary>
        /// サブシステム設定
        /// </summary>
        protected override string[] SearchSysIds()
        {
            return this.Context.T_RDATA.AsNoTracking().Select(r => r.RDATA_SUBSYSID).Distinct().OrderBy(id => id).ToArray();
        }

        /// <summary>
        /// 検索
        /// </summary>
        /// <param name="dgv"></param>
        protected override List<T_RDATA> SearchData(out int count)
        {
            count = 0;
            List<T_RDATA> rdata = null;

            if (this.RdoRDataTbId.Checked)
            {
                // テーブルＩＤ
                var tableId = (this.RdoRDataTbId.Tag as TextBox).Text;
                tableId = string.IsNullOrWhiteSpace(tableId) ? string.Empty : tableId;
                rdata = this.Context.T_RDATA.AsNoTracking().Where(
                    r => r.RDATA_TABLEID.Contains(tableId) &&
                    (r.RDATA_SUBSYSID == this.SubSysId || string.Empty.Equals(this.SubSysId))
                    ).Take(MAX_COUNT + 1).ToList();

                count = rdata.Count();
                if (count > MAX_COUNT)
                {
                    count = this.Context.T_RDATA.AsNoTracking().Count(
                        r => r.RDATA_TABLEID.Contains(tableId) &&
                        (r.RDATA_SUBSYSID == this.SubSysId || string.Empty.Equals(this.SubSysId)));
                }
            }
            else
            {
                // テーブル名
                var tableNm = (this.RdoRDataTbNm.Tag as TextBox).Text;
                tableNm = string.IsNullOrWhiteSpace(tableNm) ? string.Empty : tableNm;
                rdata = this.Context.T_RDATA.AsNoTracking().Where(
                    r => r.RDATA_TABLENM.Contains(tableNm) &&
                    (r.RDATA_SUBSYSID == this.SubSysId || string.Empty.Equals(this.SubSysId))
                    ).Take(MAX_COUNT + 1).ToList();

                count = rdata.Count();
                if (count > MAX_COUNT)
                {
                    count = this.Context.T_RDATA.AsNoTracking().Count(
                        r => r.RDATA_TABLENM.Contains(tableNm) &&
                        (r.RDATA_SUBSYSID == this.SubSysId || string.Empty.Equals(this.SubSysId)));
                }
            }

            return rdata.Take(MAX_COUNT).ToList();
        }

        /// <summary>
        /// 検索されたデータが一覧に表示する
        /// </summary>
        /// <param name="queryDatas"></param>
        protected override void SetDgv(List<T_RDATA> queryDatas)
        {
            var privilegeDic = new Dictionary<string, bool>();
            var fields = new List<string>();
            foreach (var record in queryDatas.ToList())
            {
                fields.Clear();
                // 選択列
                fields.Add("0");
                // サブシステムＩＤ
                fields.Add(record.RDATA_SUBSYSID);
                // テーブルＩＤ
                fields.Add(record.RDATA_TABLEID);
                // テーブル名
                fields.Add(record.RDATA_TABLENM);
                // コピー句ＩＤ
                fields.Add(record.RDATA_COPYID);
                // ＲＤＡＴＡファイル名
                fields.Add(record.RDATA_RDATAFNM);
                // 権限
                if (privilegeDic.ContainsKey(record.RDATA_SUBSYSID))
                {
                    fields.Add(privilegeDic[record.RDATA_SUBSYSID] ? "1" : "0");
                }
                else
                {
                    // 当サブシステムへの編集権限を持つかの判断
                    var privilege = this.Version.hasSubsysModifyPrivilege(record.RDATA_SUBSYSID);
                    privilegeDic[record.RDATA_SUBSYSID] = privilege;
                    fields.Add(privilege ? "1" : "0");
                }

                var index = this.Dgv.Rows.Add(fields.ToArray());
                var row = this.Dgv.Rows[index].Tag = record;
            }
        }

        /// <summary>
        /// 一覧に行のチェック状態変更
        /// </summary>
        /// <param name="nodata"></param>
        protected override void ChangeStatus(bool nodata)
        {
            this.BtnDel.Enabled = !nodata;
        }

        /// <summary>
        /// 進行状況設定
        /// </summary>
        /// <param name="progress"></param>
        private void ReportProgress(int progress)
        {
            if (this.BtnDel == null) return;
            var delRDataProgressBar = this.BtnDel.Tag as ToolStripProgressBar;
            if (delRDataProgressBar == null) return;

            delRDataProgressBar.Value = progress;
        }

        /// <summary>
        /// 削除処理
        /// </summary>
        public bool Delete()
        {
            var result = MessageBox.Show("削除処理を行いますか?",
                Resources.QUESTION, MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (result == DialogResult.Cancel) return false;

            try
            {
                using (var context = new mysqlcontext(this.Version.ConnectString))
                {
                    var dbAccess = new RDataDBAccess(this.Version, context);

                    var rows = this.Dgv.Rows.Cast<DataGridViewRow>();
                    var noPrivilegeRow = rows.Where(r => "1".Equals(r.Cells[0].Value) && "0".Equals(r.Cells["Privilege"].Value));
                    if (noPrivilegeRow.Count() > 0)
                    {
                        MessageBox.Show("更新権限のないサブシステムＩＤが選択されています。",
                            Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }

                    this.ReportProgress(0);

                    var delRowList = rows.Where(r => "1".Equals(r.Cells[0].Value)).ToList();
                    var count = delRowList.Count();
                    var progress = 0;
                    for (var i = 0; i < count; i++)
                    {
                        if (progress < ((i * 100) / count))
                        {
                            progress = (i * 100) / count;
                            this.ReportProgress(progress);
                        }

                        var delRow = delRowList[i];
                        delRow.Cells[0].Value = "0";
                        delRow.DefaultCellStyle.BackColor = Color.Gray;

                        var firstDisplayRowIndex = this.Dgv.FirstDisplayedScrollingRowIndex;
                        if (delRow.Index < firstDisplayRowIndex || delRow.Index > firstDisplayRowIndex + 20)
                        {
                            this.Dgv.FirstDisplayedScrollingRowIndex = delRow.Index;
                        }
                        Application.DoEvents();

                        var rdata = delRow.Tag as T_RDATA;
                        dbAccess.Delete(rdata.RDATA_SUBSYSID, rdata.RDATA_TABLEID);
                    }
                }

                this.ReportProgress(100);

                return true;
            }
            catch (Exception ex)
            {
                this.Logger.Error(ex.Message);
                var msg = $"{MessageId.TSR00012_E}\n{ex.Message}";
                MessageBox.Show(msg, Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);

                return false;
            }
        }

        /// <summary>
        /// ＲＤＡＴＡ編集画面遷移
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected override void CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            var rdata = this.Dgv.Rows[e.RowIndex].Tag as T_RDATA;

            // 当サブシステムへの編集権限を持つかの判断
            if (!this.Version.hasSubsysModifyPrivilege(rdata.RDATA_SUBSYSID))
            {
                MessageBox.Show("該当するサブシステムへの更新権限がありません。",
                    Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                var f = new RDataForm(rdata, this.Version);
                f.ShowDialog();
            }
            catch (Exception ex)
            {
                this.Logger.Error(ex.Message);
                var msg = $"{MessageId.TSR00012_E}\n{ex.Message}";
                MessageBox.Show(msg, Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
