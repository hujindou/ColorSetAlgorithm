﻿using MarsTool.Common;
using MarsTool.Models;
using MarsTool.Models.DB;
using MarsTool.Properties;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace MarsTool.Search
{
    /// <summary>
    /// 電文情報検索タブクラス
    /// </summary>
    class TelSearch : SearchBase<T_DENSTRB>
    {
        /// <summary>
        /// 要求応答区分:E
        /// </summary>
        private RadioButton RdoTelEde { set; get; }

        /// <summary>
        /// 要求応答区分:R
        /// </summary>
        private RadioButton RdoTelEdr { set; get; }

        /// <summary>
        /// 相手サブシステムＩＤ
        /// </summary>
        private TextBox TxtTelSubSysId { set; get; }

        /// <summary>
        /// パターン番号
        /// </summary>
        private TextBox TxtTelPatternNo { set; get; }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public TelSearch(
            ComboBox subSysIdsCtl,
            RadioButton rdoTelEde,
            RadioButton rdoTelEdr,
            TextBox txtTelSubSysId,
            TextBox txtTelPatternNo,
            DataGridView dgv,
            VersionModel version)
            : base(subSysIdsCtl, dgv, version)
        {
            this.RdoTelEde = rdoTelEde;
            this.RdoTelEdr = rdoTelEdr;
            this.TxtTelSubSysId = txtTelSubSysId;
            this.TxtTelPatternNo = txtTelPatternNo;
        }

        /// <summary>
        /// サブシステム設定
        /// </summary>
        protected override string[] SearchSysIds()
        {
            return this.Context.T_DENSTRB.AsNoTracking().Select(r => r.DENSTRB_SUBSYSID).Distinct().OrderBy(id => id).ToArray();
        }

        /// <summary>
        /// 検索
        /// </summary>
        /// <param name="dgv"></param>
        protected override List<T_DENSTRB> SearchData(out int count)
        {
            count = 0;

            // 相手サブシステムＩＤ
            var telSubSysId = this.TxtTelSubSysId.Text;
            telSubSysId = string.IsNullOrWhiteSpace(telSubSysId) ? string.Empty : telSubSysId;

            // 要求応答区分
            var telType = string.Empty;
            if (this.RdoTelEde.Checked)
            {
                telType = "E";
            }
            else if (this.RdoTelEdr.Checked)
            {
                telType = "R";
            }

            // パターン番号
            var patternNo = TxtTelPatternNo.Text;
            patternNo = string.IsNullOrWhiteSpace(patternNo) ? string.Empty : patternNo;

            // 電文構成パターン物理情報テーブル
            var denstrbs = this.Context.T_DENSTRB.AsNoTracking().Where(
                r => r.DENSTRB_TELSUBSYSID.Contains(telSubSysId) &&
                r.DENSTRB_PATNO.Contains(patternNo) &&
                (r.DENSTRB_TELTYPE == telType || string.Empty.Equals(telType)) &&
                (r.DENSTRB_SUBSYSID == this.SubSysId || string.Empty.Equals(this.SubSysId))
                ).Take(MAX_COUNT + 1).ToList();

            count = denstrbs.Count();
            if (count > MAX_COUNT)
            {
                count = this.Context.T_DENSTRB.AsNoTracking().Count(
                    r => r.DENSTRB_TELSUBSYSID.Contains(telSubSysId) &&
                    r.DENSTRB_PATNO.Contains(patternNo) &&
                    (r.DENSTRB_TELTYPE == telType || string.Empty.Equals(telType)) &&
                    (r.DENSTRB_SUBSYSID == this.SubSysId || string.Empty.Equals(this.SubSysId)));
            }

            var list = denstrbs.Take(MAX_COUNT).ToList();
            foreach (var denstrb in list)
            {
                // 電文構成パターン物理アイテム情報テーブル
                denstrb.itemInfos = this.Context.T_DENSTRBITM.AsNoTracking().Where(
                    r => r.DENSTRBITM_SUBSYSID == denstrb.DENSTRB_SUBSYSID &&
                    r.DENSTRBITM_TELSUBSYSID == denstrb.DENSTRB_TELSUBSYSID &&
                    r.DENSTRBITM_TELTYPE == denstrb.DENSTRB_TELTYPE &&
                    r.DENSTRBITM_PATNO == denstrb.DENSTRB_PATNO
                    ).OrderBy(r => r.DENSTRBITM_ORDER).Take(10).ToList();
            }

            return list;
        }

        /// <summary>
        /// 検索されたデータが一覧に表示する
        /// </summary>
        /// <param name="queryDatas"></param>
        protected override void SetDgv(List<T_DENSTRB> queryDatas)
        {
            var fields = new List<string>();
            foreach (var record in queryDatas.ToList())
            {
                fields.Clear();
                // コメント
                fields.Add(record.DENSTRB_COMMENT);
                // サブシステムＩＤ
                fields.Add(record.DENSTRB_SUBSYSID);
                // 相手サブシステムＩＤ
                fields.Add(record.DENSTRB_TELSUBSYSID);
                // 要求応答区分
                fields.Add(record.DENSTRB_TELTYPE);
                // パターン番号
                fields.Add(record.DENSTRB_PATNO);
                // 情報部グループＩＤ
                fields.Add(record.DENSTRB_GROUPID);

                // 物理ID
                foreach (var itemInfo  in record.itemInfos)
                {
                    // 項目種別
                    switch (itemInfo.DENSTRBITM_TYPE)
                    {
                        case CommonConstant.ID:
                            if (itemInfo.DENSTRBITM_TURN > 1)
                            {
                                fields.Add($"{{{itemInfo.DENSTRBITM_PHYID}}}*{itemInfo.DENSTRBITM_TURN}");
                            }
                            else
                            {
                                fields.Add(itemInfo.DENSTRBITM_PHYID);
                            }
                            break;

                        case CommonConstant.YB:
                            fields.Add($"YOBI({itemInfo.DENSTRBITM_YOBISIZE})");
                            break;

                        default:
                            break;
                    }
                }

                var index = this.Dgv.Rows.Add(fields.ToArray());
                this.Dgv.Rows[index].Tag = record;
            }
        }

        protected override void CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            var denstrb = this.Dgv.Rows[e.RowIndex].Tag as T_DENSTRB;

            // 当サブシステムへの編集権限を持つかの判断
            if (!this.Version.hasSubsysModifyPrivilege(denstrb.DENSTRB_SUBSYSID))
            {
                MessageBox.Show("当サブシステムへの編集権限がありません。", Resources.WARNING, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                var f = new TelForm(denstrb, this.Version);
                f.ShowDialog();
            }
            catch (Exception ex)
            {
                this.Logger.Error(ex.Message);
                var msg = $"{MessageId.TSR00012_E}\n{ex.Message}";
                MessageBox.Show(msg, Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
