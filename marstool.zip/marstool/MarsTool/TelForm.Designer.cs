﻿namespace MarsTool
{
    partial class TelForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.dgvPhyId = new System.Windows.Forms.DataGridView();
            this.TYPE = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.PHYID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TURN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.YOBISIZE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ORDER = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtGroupId = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.rTxtComment = new System.Windows.Forms.RichTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTelSubSysId = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtTelType = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.txtSubSysId = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPatternNo = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tabCtrlTel = new System.Windows.Forms.TabControl();
            this.tabInsert = new System.Windows.Forms.TabPage();
            this.label7 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tabPattern = new System.Windows.Forms.TabPage();
            this.btnTelUpdate = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.combTelSubSysID = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnTelSearch = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dgvTel = new System.Windows.Forms.DataGridView();
            this.tabEdit = new System.Windows.Forms.TabPage();
            this.dgvMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.AddBeforeMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AddAfterMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DelMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dgvTelMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.MoveBeforeMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.MoveAfterMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.AddBeforeMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.AddAfterMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.DelMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.dgvTelAddMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.AddMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.NO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COMMENT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SUBSYSID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TELSUBSYSID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TELTYPE = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.PATNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GROUPID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhyId)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.tabCtrlTel.SuspendLayout();
            this.tabInsert.SuspendLayout();
            this.tabPattern.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTel)).BeginInit();
            this.tabEdit.SuspendLayout();
            this.dgvMenu.SuspendLayout();
            this.dgvTelMenu.SuspendLayout();
            this.dgvTelAddMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.dgvPhyId);
            this.groupBox7.Location = new System.Drawing.Point(210, 6);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(432, 365);
            this.groupBox7.TabIndex = 17;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "パターンの物理ＩＤ一覧";
            // 
            // dgvPhyId
            // 
            this.dgvPhyId.AllowUserToAddRows = false;
            this.dgvPhyId.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPhyId.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TYPE,
            this.PHYID,
            this.TURN,
            this.YOBISIZE,
            this.ORDER});
            this.dgvPhyId.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvPhyId.Location = new System.Drawing.Point(3, 15);
            this.dgvPhyId.MultiSelect = false;
            this.dgvPhyId.Name = "dgvPhyId";
            this.dgvPhyId.RowHeadersWidth = 25;
            this.dgvPhyId.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvPhyId.RowTemplate.Height = 21;
            this.dgvPhyId.Size = new System.Drawing.Size(426, 347);
            this.dgvPhyId.TabIndex = 3;
            this.dgvPhyId.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvPhyId_CellMouseClick);
            this.dgvPhyId.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvPhyId_CellMouseDoubleClick);
            this.dgvPhyId.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.dgvPhyId_CellValidating);
            this.dgvPhyId.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dgvPhyId_MouseClick);
            // 
            // TYPE
            // 
            this.TYPE.HeaderText = "項目種別";
            this.TYPE.Name = "TYPE";
            // 
            // PHYID
            // 
            this.PHYID.HeaderText = "物理ＩＤ";
            this.PHYID.MaxInputLength = 15;
            this.PHYID.Name = "PHYID";
            this.PHYID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PHYID.Width = 80;
            // 
            // TURN
            // 
            this.TURN.HeaderText = "繰返し回数";
            this.TURN.MaxInputLength = 9;
            this.TURN.Name = "TURN";
            this.TURN.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.TURN.Width = 90;
            // 
            // YOBISIZE
            // 
            this.YOBISIZE.HeaderText = "予備サイズ";
            this.YOBISIZE.MaxInputLength = 9;
            this.YOBISIZE.Name = "YOBISIZE";
            this.YOBISIZE.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.YOBISIZE.Width = 90;
            // 
            // ORDER
            // 
            this.ORDER.HeaderText = "順序";
            this.ORDER.Name = "ORDER";
            this.ORDER.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ORDER.Visible = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtGroupId);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.rTxtComment);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.txtTelSubSysId);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.txtTelType);
            this.groupBox3.Controls.Add(this.btnUpdate);
            this.groupBox3.Controls.Add(this.txtSubSysId);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.txtPatternNo);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Location = new System.Drawing.Point(8, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(199, 365);
            this.groupBox3.TabIndex = 16;
            this.groupBox3.TabStop = false;
            // 
            // txtGroupId
            // 
            this.txtGroupId.Location = new System.Drawing.Point(115, 151);
            this.txtGroupId.MaxLength = 8;
            this.txtGroupId.Name = "txtGroupId";
            this.txtGroupId.Size = new System.Drawing.Size(78, 19);
            this.txtGroupId.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 154);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 12);
            this.label6.TabIndex = 26;
            this.label6.Text = "情報部グループＩＤ：";
            // 
            // rTxtComment
            // 
            this.rTxtComment.Location = new System.Drawing.Point(11, 199);
            this.rTxtComment.MaxLength = 60;
            this.rTxtComment.Name = "rTxtComment";
            this.rTxtComment.Size = new System.Drawing.Size(182, 128);
            this.rTxtComment.TabIndex = 2;
            this.rTxtComment.Text = "";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 184);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 12);
            this.label4.TabIndex = 25;
            this.label4.Text = "コメント：";
            // 
            // txtTelSubSysId
            // 
            this.txtTelSubSysId.Location = new System.Drawing.Point(115, 52);
            this.txtTelSubSysId.Name = "txtTelSubSysId";
            this.txtTelSubSysId.ReadOnly = true;
            this.txtTelSubSysId.Size = new System.Drawing.Size(78, 19);
            this.txtTelSubSysId.TabIndex = 24;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(9, 55);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(104, 12);
            this.label9.TabIndex = 23;
            this.label9.Text = "相手サブシステムＩＤ：";
            // 
            // txtTelType
            // 
            this.txtTelType.Location = new System.Drawing.Point(115, 85);
            this.txtTelType.Name = "txtTelType";
            this.txtTelType.ReadOnly = true;
            this.txtTelType.Size = new System.Drawing.Size(78, 19);
            this.txtTelType.TabIndex = 21;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(135, 335);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(58, 23);
            this.btnUpdate.TabIndex = 4;
            this.btnUpdate.Text = "更新";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // txtSubSysId
            // 
            this.txtSubSysId.Location = new System.Drawing.Point(115, 19);
            this.txtSubSysId.Name = "txtSubSysId";
            this.txtSubSysId.ReadOnly = true;
            this.txtSubSysId.Size = new System.Drawing.Size(78, 19);
            this.txtSubSysId.TabIndex = 20;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 12);
            this.label3.TabIndex = 18;
            this.label3.Text = "要求応答区分：";
            // 
            // txtPatternNo
            // 
            this.txtPatternNo.Location = new System.Drawing.Point(115, 118);
            this.txtPatternNo.Name = "txtPatternNo";
            this.txtPatternNo.ReadOnly = true;
            this.txtPatternNo.Size = new System.Drawing.Size(78, 19);
            this.txtPatternNo.TabIndex = 17;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 12);
            this.label1.TabIndex = 14;
            this.label1.Text = "サブシステムＩＤ：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 121);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 12);
            this.label2.TabIndex = 15;
            this.label2.Text = "パターン番号：";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 403);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(656, 22);
            this.statusStrip1.TabIndex = 11;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tabCtrlTel
            // 
            this.tabCtrlTel.Controls.Add(this.tabInsert);
            this.tabCtrlTel.Controls.Add(this.tabPattern);
            this.tabCtrlTel.Controls.Add(this.tabEdit);
            this.tabCtrlTel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabCtrlTel.Location = new System.Drawing.Point(0, 0);
            this.tabCtrlTel.Name = "tabCtrlTel";
            this.tabCtrlTel.SelectedIndex = 0;
            this.tabCtrlTel.Size = new System.Drawing.Size(656, 403);
            this.tabCtrlTel.TabIndex = 12;
            // 
            // tabInsert
            // 
            this.tabInsert.BackColor = System.Drawing.SystemColors.Control;
            this.tabInsert.Controls.Add(this.label7);
            this.tabInsert.Controls.Add(this.button7);
            this.tabInsert.Controls.Add(this.button5);
            this.tabInsert.Controls.Add(this.button6);
            this.tabInsert.Controls.Add(this.textBox17);
            this.tabInsert.Controls.Add(this.label5);
            this.tabInsert.Location = new System.Drawing.Point(4, 22);
            this.tabInsert.Name = "tabInsert";
            this.tabInsert.Padding = new System.Windows.Forms.Padding(3);
            this.tabInsert.Size = new System.Drawing.Size(648, 377);
            this.tabInsert.TabIndex = 0;
            this.tabInsert.Text = "登録";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(19, 78);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(243, 12);
            this.label7.TabIndex = 24;
            this.label7.Text = "※ツール専用入力シート（物理電文構成パターン）";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(581, 111);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(58, 23);
            this.button7.TabIndex = 20;
            this.button7.Text = "クリア";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click_1);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(497, 111);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(58, 23);
            this.button5.TabIndex = 19;
            this.button5.Text = "登録";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(605, 52);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(32, 19);
            this.button6.TabIndex = 18;
            this.button6.Text = "…";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(89, 52);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(511, 19);
            this.textBox17.TabIndex = 17;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 55);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 12);
            this.label5.TabIndex = 16;
            this.label5.Text = "入力ファイル";
            // 
            // tabPattern
            // 
            this.tabPattern.BackColor = System.Drawing.SystemColors.Control;
            this.tabPattern.Controls.Add(this.btnTelUpdate);
            this.tabPattern.Controls.Add(this.groupBox2);
            this.tabPattern.Controls.Add(this.groupBox1);
            this.tabPattern.Location = new System.Drawing.Point(4, 22);
            this.tabPattern.Name = "tabPattern";
            this.tabPattern.Padding = new System.Windows.Forms.Padding(3);
            this.tabPattern.Size = new System.Drawing.Size(648, 377);
            this.tabPattern.TabIndex = 2;
            this.tabPattern.Text = "編集";
            // 
            // btnTelUpdate
            // 
            this.btnTelUpdate.Enabled = false;
            this.btnTelUpdate.Location = new System.Drawing.Point(588, 21);
            this.btnTelUpdate.Name = "btnTelUpdate";
            this.btnTelUpdate.Size = new System.Drawing.Size(54, 23);
            this.btnTelUpdate.TabIndex = 4;
            this.btnTelUpdate.Text = "更新";
            this.btnTelUpdate.UseVisualStyleBackColor = true;
            this.btnTelUpdate.Click += new System.EventHandler(this.btnTelUpdate_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.combTelSubSysID);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.btnTelSearch);
            this.groupBox2.Location = new System.Drawing.Point(6, 1);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(253, 38);
            this.groupBox2.TabIndex = 26;
            this.groupBox2.TabStop = false;
            // 
            // combTelSubSysID
            // 
            this.combTelSubSysID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combTelSubSysID.FormattingEnabled = true;
            this.combTelSubSysID.Location = new System.Drawing.Point(96, 12);
            this.combTelSubSysID.Name = "combTelSubSysID";
            this.combTelSubSysID.Size = new System.Drawing.Size(65, 20);
            this.combTelSubSysID.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(10, 16);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(80, 12);
            this.label8.TabIndex = 22;
            this.label8.Text = "サブシステムＩＤ：";
            // 
            // btnTelSearch
            // 
            this.btnTelSearch.Location = new System.Drawing.Point(188, 10);
            this.btnTelSearch.Name = "btnTelSearch";
            this.btnTelSearch.Size = new System.Drawing.Size(54, 23);
            this.btnTelSearch.TabIndex = 2;
            this.btnTelSearch.Text = "検索";
            this.btnTelSearch.UseVisualStyleBackColor = true;
            this.btnTelSearch.Click += new System.EventHandler(this.btnTelSearch_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dgvTel);
            this.groupBox1.Location = new System.Drawing.Point(6, 50);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(636, 324);
            this.groupBox1.TabIndex = 25;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "電文構成パターン物理情報一覧";
            // 
            // dgvTel
            // 
            this.dgvTel.AllowUserToAddRows = false;
            this.dgvTel.AllowUserToResizeRows = false;
            this.dgvTel.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTel.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.NO,
            this.COMMENT,
            this.SUBSYSID,
            this.TELSUBSYSID,
            this.TELTYPE,
            this.PATNO,
            this.GROUPID,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn1,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column15,
            this.Column16});
            this.dgvTel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTel.Location = new System.Drawing.Point(3, 15);
            this.dgvTel.Name = "dgvTel";
            this.dgvTel.RowHeadersWidth = 25;
            this.dgvTel.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvTel.RowTemplate.Height = 21;
            this.dgvTel.Size = new System.Drawing.Size(630, 306);
            this.dgvTel.TabIndex = 3;
            this.dgvTel.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTel_CellDoubleClick);
            this.dgvTel.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvTel_CellMouseClick);
            this.dgvTel.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.dgvTel_CellValidating);
            // 
            // tabEdit
            // 
            this.tabEdit.BackColor = System.Drawing.SystemColors.Control;
            this.tabEdit.Controls.Add(this.groupBox7);
            this.tabEdit.Controls.Add(this.groupBox3);
            this.tabEdit.Location = new System.Drawing.Point(4, 22);
            this.tabEdit.Name = "tabEdit";
            this.tabEdit.Padding = new System.Windows.Forms.Padding(3);
            this.tabEdit.Size = new System.Drawing.Size(648, 377);
            this.tabEdit.TabIndex = 1;
            this.tabEdit.Text = "編集";
            // 
            // dgvMenu
            // 
            this.dgvMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddBeforeMenuItem,
            this.AddAfterMenuItem,
            this.DelMenuItem});
            this.dgvMenu.Name = "dgvMenu";
            this.dgvMenu.Size = new System.Drawing.Size(125, 70);
            // 
            // AddBeforeMenuItem
            // 
            this.AddBeforeMenuItem.Name = "AddBeforeMenuItem";
            this.AddBeforeMenuItem.Size = new System.Drawing.Size(124, 22);
            this.AddBeforeMenuItem.Text = "上へ追加";
            this.AddBeforeMenuItem.Click += new System.EventHandler(this.AddMenuItem_Click);
            // 
            // AddAfterMenuItem
            // 
            this.AddAfterMenuItem.Name = "AddAfterMenuItem";
            this.AddAfterMenuItem.Size = new System.Drawing.Size(124, 22);
            this.AddAfterMenuItem.Text = "下へ追加";
            this.AddAfterMenuItem.Click += new System.EventHandler(this.AddMenuItem_Click);
            // 
            // DelMenuItem
            // 
            this.DelMenuItem.Name = "DelMenuItem";
            this.DelMenuItem.Size = new System.Drawing.Size(124, 22);
            this.DelMenuItem.Text = "削除";
            this.DelMenuItem.Click += new System.EventHandler(this.DelMenuItem_Click);
            // 
            // dgvTelMenu
            // 
            this.dgvTelMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MoveBeforeMenu,
            this.MoveAfterMenu,
            this.AddBeforeMenu,
            this.AddAfterMenu,
            this.DelMenu});
            this.dgvTelMenu.Name = "dgvMenu";
            this.dgvTelMenu.Size = new System.Drawing.Size(125, 114);
            // 
            // MoveBeforeMenu
            // 
            this.MoveBeforeMenu.Name = "MoveBeforeMenu";
            this.MoveBeforeMenu.Size = new System.Drawing.Size(124, 22);
            this.MoveBeforeMenu.Text = "上へ移動";
            this.MoveBeforeMenu.Click += new System.EventHandler(this.MoveMenu_Click);
            // 
            // MoveAfterMenu
            // 
            this.MoveAfterMenu.Name = "MoveAfterMenu";
            this.MoveAfterMenu.Size = new System.Drawing.Size(124, 22);
            this.MoveAfterMenu.Text = "下へ移動";
            this.MoveAfterMenu.Click += new System.EventHandler(this.MoveMenu_Click);
            // 
            // AddBeforeMenu
            // 
            this.AddBeforeMenu.Name = "AddBeforeMenu";
            this.AddBeforeMenu.Size = new System.Drawing.Size(124, 22);
            this.AddBeforeMenu.Text = "上へ追加";
            this.AddBeforeMenu.Click += new System.EventHandler(this.AddMenu_Click);
            // 
            // AddAfterMenu
            // 
            this.AddAfterMenu.Name = "AddAfterMenu";
            this.AddAfterMenu.Size = new System.Drawing.Size(124, 22);
            this.AddAfterMenu.Text = "下へ追加";
            this.AddAfterMenu.Click += new System.EventHandler(this.AddMenu_Click);
            // 
            // DelMenu
            // 
            this.DelMenu.Name = "DelMenu";
            this.DelMenu.Size = new System.Drawing.Size(124, 22);
            this.DelMenu.Text = "削除";
            this.DelMenu.Click += new System.EventHandler(this.DelMenu_Click);
            // 
            // dgvTelAddMenu
            // 
            this.dgvTelAddMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddMenu});
            this.dgvTelAddMenu.Name = "dgvMenu";
            this.dgvTelAddMenu.Size = new System.Drawing.Size(101, 26);
            // 
            // AddMenu
            // 
            this.AddMenu.Name = "AddMenu";
            this.AddMenu.Size = new System.Drawing.Size(100, 22);
            this.AddMenu.Text = "追加";
            this.AddMenu.Click += new System.EventHandler(this.AddMenu_Click_1);
            // 
            // NO
            // 
            this.NO.HeaderText = "No.";
            this.NO.Name = "NO";
            this.NO.ReadOnly = true;
            this.NO.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.NO.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.NO.Width = 40;
            // 
            // COMMENT
            // 
            this.COMMENT.HeaderText = "コメント";
            this.COMMENT.MaxInputLength = 60;
            this.COMMENT.Name = "COMMENT";
            this.COMMENT.Width = 150;
            // 
            // SUBSYSID
            // 
            this.SUBSYSID.HeaderText = "サブシステムID";
            this.SUBSYSID.MaxInputLength = 4;
            this.SUBSYSID.Name = "SUBSYSID";
            this.SUBSYSID.ReadOnly = true;
            // 
            // TELSUBSYSID
            // 
            this.TELSUBSYSID.HeaderText = "相手サブシステムＩＤ";
            this.TELSUBSYSID.MaxInputLength = 4;
            this.TELSUBSYSID.Name = "TELSUBSYSID";
            this.TELSUBSYSID.Width = 125;
            // 
            // TELTYPE
            // 
            this.TELTYPE.HeaderText = "要求応答区分";
            this.TELTYPE.Items.AddRange(new object[] {
            "E",
            "R"});
            this.TELTYPE.Name = "TELTYPE";
            this.TELTYPE.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.TELTYPE.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // PATNO
            // 
            this.PATNO.HeaderText = "パターン番号";
            this.PATNO.MaxInputLength = 10;
            this.PATNO.Name = "PATNO";
            this.PATNO.Width = 90;
            // 
            // GROUPID
            // 
            this.GROUPID.HeaderText = "情報部グループＩＤ";
            this.GROUPID.MaxInputLength = 15;
            this.GROUPID.Name = "GROUPID";
            this.GROUPID.Width = 120;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.HeaderText = "物理ID1";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.Width = 80;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "物理ID2";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 80;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "物理ID3";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 80;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "物理ID4";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 80;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "物理ID5";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 80;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "物理ID6";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.Width = 80;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "物理ID7";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            this.Column7.Width = 80;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "物理ID8";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            this.Column8.Width = 80;
            // 
            // Column15
            // 
            this.Column15.HeaderText = "物理ID9";
            this.Column15.Name = "Column15";
            this.Column15.ReadOnly = true;
            this.Column15.Width = 80;
            // 
            // Column16
            // 
            this.Column16.HeaderText = "物理ID10";
            this.Column16.Name = "Column16";
            this.Column16.ReadOnly = true;
            this.Column16.Width = 80;
            // 
            // TelForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(656, 425);
            this.Controls.Add(this.tabCtrlTel);
            this.Controls.Add(this.statusStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "TelForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "物理パターン管理機能";
            this.Load += new System.EventHandler(this.TelForm_Load);
            this.groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhyId)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabCtrlTel.ResumeLayout(false);
            this.tabInsert.ResumeLayout(false);
            this.tabInsert.PerformLayout();
            this.tabPattern.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTel)).EndInit();
            this.tabEdit.ResumeLayout(false);
            this.dgvMenu.ResumeLayout(false);
            this.dgvTelMenu.ResumeLayout(false);
            this.dgvTelAddMenu.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.TabControl tabCtrlTel;
        private System.Windows.Forms.TabPage tabInsert;
        private System.Windows.Forms.TabPage tabPattern;
        private System.Windows.Forms.TabPage tabEdit;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtTelType;
        private System.Windows.Forms.TextBox txtSubSysId;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPatternNo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.DataGridView dgvPhyId;
        private System.Windows.Forms.TextBox txtTelSubSysId;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RichTextBox rTxtComment;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ContextMenuStrip dgvMenu;
        private System.Windows.Forms.ToolStripMenuItem AddBeforeMenuItem;
        private System.Windows.Forms.ToolStripMenuItem DelMenuItem;
        private System.Windows.Forms.TextBox txtGroupId;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ToolStripMenuItem AddAfterMenuItem;
        private System.Windows.Forms.ComboBox combTelSubSysID;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnTelSearch;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dgvTel;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnTelUpdate;
        private System.Windows.Forms.ContextMenuStrip dgvTelMenu;
        private System.Windows.Forms.ToolStripMenuItem AddBeforeMenu;
        private System.Windows.Forms.ToolStripMenuItem AddAfterMenu;
        private System.Windows.Forms.ToolStripMenuItem DelMenu;
        private System.Windows.Forms.ToolStripMenuItem MoveBeforeMenu;
        private System.Windows.Forms.ToolStripMenuItem MoveAfterMenu;
        private System.Windows.Forms.ContextMenuStrip dgvTelAddMenu;
        private System.Windows.Forms.ToolStripMenuItem AddMenu;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridViewComboBoxColumn TYPE;
        private System.Windows.Forms.DataGridViewTextBoxColumn PHYID;
        private System.Windows.Forms.DataGridViewTextBoxColumn TURN;
        private System.Windows.Forms.DataGridViewTextBoxColumn YOBISIZE;
        private System.Windows.Forms.DataGridViewTextBoxColumn ORDER;
        private System.Windows.Forms.DataGridViewTextBoxColumn NO;
        private System.Windows.Forms.DataGridViewTextBoxColumn COMMENT;
        private System.Windows.Forms.DataGridViewTextBoxColumn SUBSYSID;
        private System.Windows.Forms.DataGridViewTextBoxColumn TELSUBSYSID;
        private System.Windows.Forms.DataGridViewComboBoxColumn TELTYPE;
        private System.Windows.Forms.DataGridViewTextBoxColumn PATNO;
        private System.Windows.Forms.DataGridViewTextBoxColumn GROUPID;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
    }
}