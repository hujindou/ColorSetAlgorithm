﻿using MarsTool.LGC;
using MarsTool.Models;
using MarsTool.Models.DB;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Core.Objects;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace MarsTool
{
    public partial class FileLoadForm : Form
    {
        public FileLoadForm()
        {
            InitializeComponent();
        }

        public FileLoadForm(VersionModel p) : this()
        {
            version = p;
        }

        private VersionModel version;

        /// <summary>
        /// 1 - 5はヘッダ
        /// 6行以降は入力内容
        /// </summary>
        private const int startRow = 6;

        /// <summary>
        /// ジャーナル情報部の開始列
        /// </summary>
        private const int startCol = 8;

        private NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        private void button2_Click(object sender, EventArgs e)
        {
            if (!version.hasSubsysModifyPrivilege("JM"))
            {
                MessageBox.Show($"ジャーナルの登録権限がありません", Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (String.IsNullOrWhiteSpace(this.textBox1.Text))
            {
                MessageBox.Show(Properties.Resources.JNL_UPLOAD_FILEEMPTY, Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            this.button2.Enabled = false;

            //read xlsx
            List<ViewPattern> alldata = null;

            logger.Info($"{version.User.USERID} ジャーナル読込開始");

            this.richTextBox1.AppendText("ジャーナルパターン読込開始！完了するまで、画面操作しないでください\n");
            this.richTextBox1.ScrollToCaret();
            this.richTextBox1.AppendText($"読込対象ファイル：{this.textBox1.Text}\n");
            this.richTextBox1.ScrollToCaret();

            try
            {
                alldata = readExcel(this.textBox1.Text);
            }
            catch (Exception exp)
            {
                //
                logger.Error(exp, "ファイル読込できません");
                printerror(richTextBox1, $"エラー：対象ファイルを読込時、エラーが発生しました、詳細はログをご参考\n\n");
                this.button2.Enabled = true;
                return;
            }

            //check excel data
            if (alldata.Count > 0)
            {
                //欠番以外の重複チェック
                var dup1 = from tmp in alldata
                           where tmp.Enabled != 2
                           select new { tmp.JN_PATTERNNO, tmp.JN_ANS, tmp.JN_OPTYPE, tmp.Enabled, tmp.JNSEGKEY };
                if (dup1.Count() != dup1.Distinct().Count())
                {
                    printerror(richTextBox1, $"エラー：対象ファイルに重複データがある\n\n");
                    this.button2.Enabled = true;
                    return;
                }

                //欠番の場合の重複チェック
                var dup2 = from tmp in alldata
                           where tmp.Enabled == 2
                           select new { tmp.JN_CUPID, tmp.JN_TYPE, tmp.JN_SUBORDER };
                if (dup2.Count() != dup2.Distinct().Count())
                {
                    printerror(richTextBox1, $"エラー：対象ファイルに重複データがある\n\n");
                    this.button2.Enabled = true;
                    return;
                }

                //Excel Data Check

                Regex reg = new Regex(@"^MAX\([1-9][0-9]*\)$", RegexOptions.IgnoreCase);
                Regex reg2 = new Regex(@"^([0-9]+[-][0-9]+[-][0-9]+|[0-9]+[-][0-9]|[0-9]+)$");

                bool isDataOk = true;

                for (int i = 0; i < alldata.Count; i++)
                {
                    alldata[i].USERID = version.User.USERID;

                    //Excel入力データチェック
                    if (String.IsNullOrWhiteSpace(alldata[i].JN_CUPID))
                    {
                        printerror(richTextBox1, $"{i * 3 + startRow}行目のCUP-IDは空白\n");
                        isDataOk = false;
                        break;
                    }

                    if (!reg2.IsMatch(alldata[i].JN_SUBORDER))
                    {
                        printerror(richTextBox1, $"{i * 3 + startRow}行目の仕様書項番は「1」、「1-1」、「1-1-1」のように設定する必要\n");
                        isDataOk = false;
                        break;
                    }

                    //欠番のデータはチェックしないこと
                    if (alldata[i].Enabled == 2)
                        continue;


                    if (String.IsNullOrWhiteSpace(alldata[i].JN_OPTYPE))
                    {
                        printerror(richTextBox1, $"{i * 3 + startRow}行目の操作種別は空白\n");
                        isDataOk = false;
                        break;
                    }
                    if (String.IsNullOrWhiteSpace(alldata[i].JN_ANS))
                    {
                        printerror(richTextBox1, $"{i * 3 + startRow}行目のANSは空白\n");
                        isDataOk = false;
                        break;
                    }
                    if (String.IsNullOrWhiteSpace(alldata[i].JN_PATTERNNO))
                    {
                        printerror(richTextBox1, $"{i * 3 + startRow}行目のパターン番号は空白\n");
                        isDataOk = false;
                        break;
                    }

                    if (alldata[i].JN_INFOBLOCKS.Count == 0)
                    {
                        printerror(richTextBox1, $"{i * 3 + startRow}行目のジャーナル情報部は少なくとも１個が必要\n");
                        isDataOk = false;
                        break;
                    }

                    foreach (var tmp in alldata[i].JN_INFOBLOCKS)
                    {
                        //要求回答チェック
                        if (tmp.JN_PROPERTY3 != "要求" && tmp.JN_PROPERTY3 != "回答" && tmp.JN_PROPERTY3 != "")
                        {
                            printerror(richTextBox1, $"レベル１属性は「要求」、「回答」、空白しか設定できない\n");
                            isDataOk = false;
                            break;
                        }

                        var m1 = reg.Match(tmp.JN_PROPERTY5);

                        if (!String.IsNullOrEmpty(tmp.JN_PROPERTY5) && !m1.Success)
                        {
                            printerror(richTextBox1, $"レベル５属性は「MAX(N)」のように設定しかできない\n");
                            isDataOk = false;
                            break;
                        }

                    }
                    //情報部
                    if (isDataOk == false) break;
                }

                if (isDataOk && alldata.Any(r => r.checkData() == false) == false)
                {
                    try
                    {
                        using (var context = new mysqlcontext(version.ConnectString))
                        {
                            List<ViewPattern> tmplst = new List<ViewPattern>();
                            for (int i = 0; i < alldata.Count; i++)
                            {

                                string a = alldata[i].JN_PATTERNNO;
                                string b = alldata[i].JN_ANS;
                                string c = alldata[i].JN_OPTYPE;
                                string ee = alldata[i].JN_CUPID;
                                string ff = alldata[i].JN_TYPE;
                                string odr = alldata[i].JN_SUBORDER;
                                string key = alldata[i].JNSEGKEY;
                                int d = alldata[i].Enabled;
                                //欠番で、DBに同じパターンが存在する場合、無視すること
                                if (alldata[i].Enabled == 2)
                                {
                                    if (context.T_JNPT.AsNoTracking().Any(r => r.JNL_CUPID == ee && r.JNL_TYPE == ff && r.JNL_SUBORDER == odr && r.JNL_ENABLEFLG == d))
                                    {
                                        tmplst.Add(alldata[i]);
                                    }
                                }
                                else
                                {
                                    //欠番以外で、DBに同じパターンが存在する場合、無視すること
                                    //context.Database.Log = x => System.Diagnostics.Debug.WriteLine(x);
                                    if (context.T_JNPT.AsNoTracking().Any(r => r.JNL_PATTERNNO == a && r.JNL_ANS == b && r.JNL_OPTYPE == c && r.JNL_ENABLEFLG == d && r.JNL_KEY == key))
                                    {
                                        tmplst.Add(alldata[i]);
                                    }
                                }
                            }
                            foreach (var tmp in tmplst)
                            {
                                alldata.Remove(tmp);
                            }

                            if (alldata.Count == 0)
                            {
                                //do nothing
                            }
                            else
                            {
                                foreach (var jnPattern in alldata)
                                {
                                    //採番
                                    jnPattern.JN_PATTERNID = version.genSequenceID("T_JNLPT");
                                    T_JNLPT jp = jnPattern;
                                    context.T_JNPT.Add(jp);
                                }
                                context.SaveChanges();
                                logger.Info($"{version.User.USERID} ジャーナル読込正常終了");
                            }
                        }

                        richTextBox1.AppendText($"対象ファイルの  {alldata.Count}件  が読込必要と判断して処理しました\n\n");
                        richTextBox1.ScrollToCaret();
                    }
                    catch (Exception exp)
                    {
                        logger.Error(exp, Properties.Resources.DBERROR);
                        printerror(richTextBox1, $"DBエラーが発生しました、詳細はログをご参考\n\n");
                        this.button2.Enabled = true;
                        return;
                    }
                }
                else
                {
                    printerror(richTextBox1, $"不正なデータ、或いはデータの長さが多すぎる原因で、処理を中止した\n\n");
                    richTextBox1.ScrollToCaret();
                }
            }
            else
            {
                printerror(richTextBox1, $"対象ファイルにジャーナルパターンのデータがありません\n\n");
                richTextBox1.ScrollToCaret();
            }

            this.button2.Enabled = true;
        }

        /// <summary>
        /// 赤字でエラー情報を出力
        /// </summary>
        /// <param name="tb"></param>
        /// <param name="ms"></param>
        private void printerror(RichTextBox tb, string ms)
        {
            int texbox = tb.TextLength;
            tb.AppendText(ms);
            tb.SelectionStart = texbox;
            tb.SelectionLength = ms.Length;
            tb.SelectionColor = System.Drawing.Color.Red;
            tb.ScrollToCaret();
        }

        /// <summary>
        /// Read Excel to memory
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        private List<ViewPattern> readExcel(string text)
        {
            List<ViewPattern> res = new List<ViewPattern>();
            if (String.IsNullOrWhiteSpace(text))
                return res;

            var fi = new FileInfo(text);
            using (var package = new ExcelPackage(fi))
            {
                var workbook = package.Workbook;
                var s = workbook.Worksheets.FirstOrDefault(r => r.Name.Trim().Equals("ALLDATA", StringComparison.OrdinalIgnoreCase));
                int i = startRow;
                while (true)
                {
                    if (i > s.Dimension.End.Row)
                        break;

                    ViewPattern jnp = new ViewPattern();
                    jnp.Enabled = c((s.Cells[i, 1].Text + "").Trim().Replace("\n", ""));
                    jnp.JN_SUBORDER = (s.Cells[i, 4].Text + "").Trim().Replace("\n", "");

                    if (jnp.Enabled == 2)
                    {
                        jnp.JN_CUPID = (s.Cells[i, 2].Text + "").Trim().Replace("\n", "");
                        jnp.JN_TYPE = (s.Cells[i, 3].Text + "").Trim().Replace("\n", "");
                        jnp.JN_OPTYPE = " ";
                        jnp.JN_ANS = " ";
                        jnp.JN_PATTERNNO = " ";
                        jnp.JN_COMMNENT = " ";
                        jnp.JN_INFOBLOCKS = new List<ViewInfoBlock>();
                    }
                    else
                    {
                        jnp.JN_CUPID = (s.Cells[i, 2].Text + "").Trim().Replace("\n", "");
                        jnp.JN_TYPE = (s.Cells[i, 3].Text + "").Trim().Replace("\n", "");
                        jnp.JN_OPTYPE = (s.Cells[i, 5].Text + "").Replace("\n", Environment.NewLine);
                        jnp.JN_ANS = (s.Cells[i, 6].Text + "").Trim().Replace("\n", Environment.NewLine);
                        jnp.JN_PATTERNNO = (s.Cells[i, 7].Text + "").Trim().Replace("\n", Environment.NewLine);
                        jnp.JN_COMMNENT = (s.Cells[i, 8].Text + "").Replace("\n", Environment.NewLine);

                        //入力終了の判断はCUP-IDとパターン番号と操作種別が空白
                        if (String.IsNullOrEmpty(jnp.JN_CUPID) && String.IsNullOrEmpty(jnp.JN_PATTERNNO) && String.IsNullOrEmpty(jnp.JN_OPTYPE))
                        {
                            i += 7;
                            continue;
                        }

                        jnp.JN_INFOBLOCKS = new List<ViewInfoBlock>();

                        //情報部リスト設定
                        for (int j = 1; j <= 44; j++)
                        {
                            //空白の情報部があると、終了と判断する
                            if (String.IsNullOrWhiteSpace(s.Cells[i, j + startCol].Text))
                            {
                                break;
                            }
                            ViewInfoBlock block = new ViewInfoBlock();
                            block.JN_ORDER = j;

                            //情報部名入力より、情報部ID入力へ変更
                            block.JN_NAME = (s.Cells[i, j + startCol].Text + "").Trim().Replace("\n", "");
                            block.JN_INTERFACEID = block.JN_NAME;

                            block.JN_SIZE = null;
                            block.JN_PROPERTY3 = (s.Cells[i + 1, j + startCol].Text + "").Trim().Replace("\n", "");
                            block.JN_PROPERTY4 = (s.Cells[i + 2, j + startCol].Text + "").Trim().Replace("\n", "");
                            block.JN_REQRESFLG = (s.Cells[i + 3, j + startCol].Text + "").Trim().Replace("\n", "");
                            block.JN_PROPERTY2 = (s.Cells[i + 4, j + startCol].Text + "").Trim().Replace("\n", "");
                            block.JN_PROPERTY5 = (s.Cells[i + 5, j + startCol].Text + "").ToUpper().Trim().Replace("\n", "");
                            block.INHERENTPROPERTY = (s.Cells[i + 6, j + startCol].Text + "").Trim().Replace("\n", "");

                            jnp.JN_INFOBLOCKS.Add(block);
                        }
                    }

                    res.Add(jnp);
                    i += 7;
                }
            }
            return res;
        }

        /// <summary>
        /// 未使用/使用中/欠番 -> 0/1/2
        /// </summary>
        /// <param name="v"></param>
        /// <returns></returns>
        private int c(string v)
        {
            if (v.Contains(Properties.Resources.JNL_NOTUSER))
                return 0;
            else if (v.Contains("欠番"))
                return 2;
            else
                return 1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Title = Properties.Resources.JNL_POPTITLE1;
            openFileDialog.Filter = "Excel Files | *.xlsx";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                this.textBox1.Text = openFileDialog.FileName;
            }
        }

        private void FileLoadForm_Load(object sender, EventArgs e)
        {
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            this.richTextBox1.ReadOnly = true;
            this.richTextBox2.ReadOnly = true;

        }

        /// <summary>
        /// パス選択ダイアログ
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {
            using (var fbd = new FolderBrowserDialog())
            {
                DialogResult result = fbd.ShowDialog();

                if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(fbd.SelectedPath))
                {
                    this.textBox2.Text = fbd.SelectedPath;
                }
            }
        }

        /// <summary>
        /// 出力
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button4_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrWhiteSpace(this.textBox2.Text))
            {
                MessageBox.Show(Properties.Resources.JNL_MSG1, Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (String.IsNullOrWhiteSpace(this.comboBox1.SelectedItem.ToString()))
            {
                MessageBox.Show(Properties.Resources.JNL_MSG2, Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (!Directory.Exists(this.textBox2.Text))
            {
                MessageBox.Show("出力先は存在しない", Properties.Resources.ATTENTION, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string condition = this.comboBox1.SelectedItem.ToString();
            List<ViewPattern> lst = new List<ViewPattern>();

            FileOutputOfficeCom fop = new FileOutputOfficeCom();
            fop.readJNLData(condition, lst, version, this.richTextBox2);
            fop.writeDataToExcel(lst, this.textBox2.Text, this.richTextBox2);
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.tabControl1.SelectedTab == this.tabPage2)
            {
                try
                {
                    using (var context = new mysqlcontext(version.ConnectString))
                    {
                        List<string> lst = context.T_JNPT.AsNoTracking().Select(r => r.JNL_CUPID).Distinct().ToList();
                        lst.Add(Properties.Resources.JNL_LIST_ALL);
                        lst.Insert(0, "");
                        this.comboBox1.DataSource = lst;
                    }
                }
                catch (Exception exp)
                {
                    this.comboBox1.DataSource = new List<string>();
                    logger.Error(exp, Properties.Resources.DBERROR);
                    MessageBox.Show(Properties.Resources.DBERROR, Properties.Resources.ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }
    }

}
