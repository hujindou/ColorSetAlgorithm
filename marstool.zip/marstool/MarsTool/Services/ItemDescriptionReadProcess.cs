﻿using MarsTool.Common;
using MarsTool.Daos;
using MarsTool.Exceptions;
using MarsTool.Models;
using MarsTool.Models.DB;
using MarsTool.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Transactions;
using Excel = Microsoft.Office.Interop.Excel;

namespace MarsTool.Services
{
    class ItemDescriptionReadProcess
    {

        private NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        private VersionModel version;

        private CopyKuDBConnectivity dBConnectivity;

        public ItemDescriptionReadProcess(VersionModel v)
        {
            version = v;
            dBConnectivity = new CopyKuDBConnectivity(v);
        }

        /// <summary>
        ///アイテム説明書読み込み処理とアイテム内容と記事更新処理
        /// </summary>
        /// <param name="inputPath"></param>
        /// <param name="subSysId"></param>
        /// <param name="infoId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public Boolean ItemDescriptionReadAndUpdateProcess(string inputPath, string subSysId, string infoId, string userId)
        {
            bool result = false;

            try
            {
                // ディレクトリを取得する。
                string copyKuId = Path.GetFileNameWithoutExtension(inputPath);

                PhysicalCopyKuInfo copyKu = dBConnectivity.SelectPhysicalCopyKuInfo(subSysId, infoId);

                if (copyKu.CPYPHY_STATUS == ConstantUtils.STATUS_DELELTE)
                {
                    logger.Error($"{version.User.USERID}" + Resources.IDR00012_E);
                    throw new CopyKuInfoReadProcessException(Resources.IDR00012_E);
                }

                //一ファイルずつ読み込む。            

                PhysicalCopyKuInfo phyCopyKuInfo = CreatePhysicalCopyKuInfo(inputPath, subSysId, infoId);

                var list = phyCopyKuInfo.phyCpyItemInfoList;
                // 読み込んだデータ一覧から各グループ構成形にする。
                var firstItem = list.First();
                this.setLevel(firstItem, list, 1);

                // 各アイテムのパスを作成する。
                firstItem.PHYITM_Path = firstItem.PHYITM_ItemName;
                this.createPath(firstItem);

                // 各アイテムの項番を順序する。
                List<PhysicalCopyKuItemInfo> itemInfos = new List<PhysicalCopyKuItemInfo>();
                itemInfos.Add(list[0]);
                for (int i = 1; i < list.Count; i++)
                {
                    PhysicalCopyKuItemInfo info = reorderItem(list[i].PHYITM_ItemNo, firstItem.childList);
                    if (info != null)
                    {
                        list[i].PHYITM_Path = info.PHYITM_Path;
                        itemInfos.Add(list[i]);
                    }
                }
                phyCopyKuInfo.phyCpyItemInfoList = itemInfos;

                result = this.CheckAndUpdatePhysicalCopyKuInfo(phyCopyKuInfo);                
            }
            catch (Exception e)
            {
                //Log for unexpected error
                //想定外エラーが発生する場合、ログに記録
                logger.Error(e, e.Message);                

                //Throw Error CKR00099-E
                //CKR00099-E　エラーをスロー
                throw new CopyKuInfoReadProcessException(e.Message, e);
            }
            return result;
        }

        /// <summary>
        ///項目レベルを作成処理
        /// </summary>
        /// <param name="group"></param>
        /// <param name="list"></param>
        /// <param name="level"></param>       
        /// <returns></returns>
        private int setLevel(PhysicalCopyKuItemInfo group, List<PhysicalCopyKuItemInfo> list, int level)
        {
            var lastLen = group.PHYITM_DTLEN;
            group.PHYITM_Level = level;
            int bitLen = 0;
            var index = list.IndexOf(group);
            list = list.Skip(index + 1).ToList();

            var listCnt = list.Count();
            for (var i = 0; i < listCnt && lastLen > 0; i++)
            {
                var item = list[i];

                // グループ
                if ("0".Equals(item.PHYITM_ItemFlg))
                {
                    var cnt = this.setLevel(item, list, level++);
                    i += cnt;

                    if (item.PHYITM_Occurs == 0) item.PHYITM_Occurs = 1;

                    lastLen -= item.PHYITM_DTLEN * item.PHYITM_Occurs;
                }
                else
                {
                    if (item.PHYITM_DTTYPE == "BIT")
                    {
                        bitLen += item.PHYITM_DTLEN;
                    }
                    else
                    {
                        lastLen -= item.PHYITM_DTLEN;
                    }
                }
                int div = bitLen / 8;
                if (div == lastLen)
                {
                    lastLen -= div;
                    bitLen = 0;
                }
                group.childList.Add(item);
            }
            return group.childList.Count();
        }


        /// <summary>
        ///項目パス作成処理
        /// </summary>
        /// <param name="group"></param>            
        /// <returns></returns>
        private void createPath(PhysicalCopyKuItemInfo group)
        {
            foreach (var item in group.childList)
            {
                item.PHYITM_Path = group.PHYITM_Path + "_" + item.PHYITM_ItemName;

                // グループ
                if ("0".Equals(item.PHYITM_ItemFlg))
                {
                    this.createPath(item);
                }
            }
        }

        /// <summary>
        ///項目項番によって一覧の項目を順序する。
        /// </summary>
        /// <param name="itemNo"></param>
        /// <param name="physicalCopyKuItems"></param>       
        /// <returns></returns>
        private PhysicalCopyKuItemInfo reorderItem(int itemNo, List<PhysicalCopyKuItemInfo> physicalCopyKuItems)
        {
            PhysicalCopyKuItemInfo itemInfo = null;
            for (int i = 0; i < physicalCopyKuItems.Count; i++)
            {
                if (itemNo == physicalCopyKuItems[i].PHYITM_ItemNo)
                {
                    itemInfo = physicalCopyKuItems[i];
                    break;
                }
                else
                {
                    PhysicalCopyKuItemInfo itm = reorderItem(itemNo, physicalCopyKuItems[i].childList);
                    if (itm != null)
                    {
                        itemInfo = itm;
                        break;
                    }
                }
            }
            return itemInfo;
        }

        /// <summary>
        ///読み込んだデータとDBのデータを比較し、データを更新する。
        /// </summary>
        /// <param name="phyCopyKuInfo"></param>    
        /// <param name="userId"></param>
        /// <returns></returns>
        private Boolean CheckAndUpdatePhysicalCopyKuInfo(PhysicalCopyKuInfo phyCopyKuInfo)
        {
            bool result = false;

            try
            {
                PhysicalCopyKuInfo copyKu = dBConnectivity.SelectPhysicalCopyKuInfo(phyCopyKuInfo.CPYPHY_SubSysId, phyCopyKuInfo.CPYPHY_InfoId); 
                
                if (copyKu.CPYPHY_STATUS != ConstantUtils.STATUS_DELELTE)
                {
                    if (copyKu.CPYPHY_Size > 0)
                    {
                        PhysicalCopyKuInfo oldUpdateUser = dBConnectivity.SelectLastUpdateUser(phyCopyKuInfo.CPYPHY_SubSysId, phyCopyKuInfo.CPYPHY_InfoId);

                        List<PhysicalCopyKuItemInfo> dbItemInfos = dBConnectivity.SelectPhysicalCopyKuItemInfos(phyCopyKuInfo.CPYPHY_SubSysId, phyCopyKuInfo.CPYPHY_InfoId);

                        if (dbItemInfos.Count > 0)
                        {
                            //不一致項目情報をログファイルに出力する。
                            var list = phyCopyKuInfo.phyCpyItemInfoList;
                            for (int i = 0; i < list.Count; i++)
                            {
                                if (list[i].PHYITM_ItemName == dbItemInfos[i].PHYITM_ItemName)
                                {
                                    result = true;
                                    list[i].PHYITM_Seq = dbItemInfos[i].PHYITM_Seq;
                                }
                                else if (list[i].PHYITM_ItemId != string.Empty)
                                {
                                    if (list[i].PHYITM_ItemId.Contains("\n"))
                                    {
                                        string[] arr = list[i].PHYITM_ItemId.Split('\n');
                                        if (arr.Length > 0)
                                        {
                                            if (!arr.Contains(dbItemInfos[i].PHYITM_ItemId))
                                            {
                                                logger.Error(string.Format(Resources.IDR00009_E, list[i].PHYITM_ItemNo, list[i].PHYITM_ItemId));
                                                throw new CopyKuInfoReadProcessException(string.Format(Resources.IDR00009_E, list[i].PHYITM_ItemNo, list[i].PHYITM_ItemId));
                                            }                                          
                                        }
                                    }
                                }
                                else
                                {
                                    logger.Error(string.Format(Resources.IDR00009_E, list[i].PHYITM_ItemNo, list[i].PHYITM_ItemName));
                                    throw new CopyKuInfoReadProcessException(string.Format(Resources.IDR00009_E, list[i].PHYITM_ItemNo, list[i].PHYITM_ItemName));
                                }
                                if (i == list.Count)
                                {
                                    break;
                                }
                            }
                            PhysicalCopyKuInfo lastUpdateUser = dBConnectivity.SelectLastUpdateUser(phyCopyKuInfo.CPYPHY_SubSysId, phyCopyKuInfo.CPYPHY_InfoId);
                            if (oldUpdateUser.CPYPHY_UserId != lastUpdateUser.CPYPHY_UserId || oldUpdateUser.CPYPHY_UPDTIME != lastUpdateUser.CPYPHY_UPDTIME)
                            {
                                logger.Error(string.Format(Resources.IF_LOG_UPDATE_NO_W, "物理コピー句情報", lastUpdateUser.CPYPHY_UserId, lastUpdateUser.CPYPHY_UPDTIME));
                                throw new CopyKuInfoReadProcessException(string.Format(Resources.IF_LOG_UPDATE_NO_W, "物理コピー句情報", lastUpdateUser.CPYPHY_UserId, lastUpdateUser.CPYPHY_UPDTIME));
                            }
                            updatePhysicalCopyKuItemInfo(dbItemInfos, list);
                            result = true;
                        }
                    }
                    else
                    {
                        logger.Error(string.Format(Resources.IDR00005_E, phyCopyKuInfo.CPYPHY_InfoId));
                        throw new CopyKuInfoReadProcessException(string.Format(Resources.IDR00005_E, phyCopyKuInfo.CPYPHY_InfoId));
                    }
                }                
            }
            catch (CopyKuInfoReadProcessException e)
            {
                throw new CopyKuInfoReadProcessException(e.GetMessage());
            }
            catch (Exception e)
            {
                //Log for unexpected error
                //想定外エラーが発生する場合、ログに記録
              logger.Error(e, Resources.CKR00099_E);

                //Throw Error CKR00099-E
                //CKR00099-E　エラーをスロー
                throw new CopyKuInfoReadProcessException(Resources.CKR00099_E, e);
            }
            return result;
        }

        /// <summary>
        ///アイテム内容と記事更新処理
        /// </summary>
        /// <param name="phyCopyKuInfo"></param>       
        /// <param name="userId"></param>
        /// <returns></returns>
        private Boolean updatePhysicalCopyKuItemInfo(List<PhysicalCopyKuItemInfo> dbItemInfos, List<PhysicalCopyKuItemInfo> inputItems)
        {
            bool result = false;
            try
            {
                using (TransactionScope scope = new System.Transactions.TransactionScope(TransactionScopeOption.RequiresNew))
                {
                    //update item
                    for (int j = 0; j < dbItemInfos.Count; j++)
                    {
                        if (dbItemInfos[j].PHYITM_ItemName != string.Empty)
                        {
                            if ((dbItemInfos[j].PHYITM_Note == string.Empty || dbItemInfos[j].PHYITM_Comment == string.Empty) && (inputItems[j].PHYITM_Note != string.Empty || inputItems[j].PHYITM_Comment != string.Empty))
                            {
                                if ((dbItemInfos[j].PHYITM_Comment == string.Empty || dbItemInfos[j].PHYITM_Comment == null) && inputItems[j].PHYITM_Comment != string.Empty)
                                {
                                    dbItemInfos[j].PHYITM_Comment = inputItems[j].PHYITM_Comment;
                                }
                                if ((dbItemInfos[j].PHYITM_Note == string.Empty || dbItemInfos[j].PHYITM_Note == null) && inputItems[j].PHYITM_Note != string.Empty)
                                {
                                    dbItemInfos[j].PHYITM_Note = inputItems[j].PHYITM_Note;
                                }                            
                                dBConnectivity.updatePhyCopyKuItemInfoCommentAndNOTE(dbItemInfos[j]);
                            }
                        }
                    }
                    scope.Complete();
                }                
                result = true;
            }
            catch (Exception e)
            {
              logger.Error(e, string.Format(Resources.CKR00003_E, "物理アイテム情報"));                              
                
                throw new CopyKuInfoReadProcessException(string.Format(Resources.CKR00003_E, "物理アイテム情報"), e);
            }
            return result;
        }

        /// <summary>
        ///入力ファイルからデータを取得する。
        /// </summary>
        /// <param name="inputPath"></param>
        /// <param name="subSysId"></param>
        /// <param name="infoId"></param>       
        /// <returns></returns>
        private PhysicalCopyKuInfo CreatePhysicalCopyKuInfo(string inputFilePath, string subSysId, string infoId) 
        {
            Excel.Application xlApp = null;
            Excel.Workbook xlWorkBook = null;
            Excel.Worksheet xlWorkSheet = null;
            PhysicalCopyKuInfo phyCopyInfo = new PhysicalCopyKuInfo();
            try
            {
                xlApp = new Excel.Application();
                xlApp.DisplayAlerts = false;
                xlApp.Visible = false;
                xlWorkBook = xlApp.Workbooks.Open(inputFilePath, ReadOnly: true);
                bool isFirstItem = false;
                int copykuSize = 0;
                Dictionary<int, string> paths = new Dictionary<int, string>();
                List<PhysicalCopyKuItemInfo> itemInfos = new List<PhysicalCopyKuItemInfo>();
                int no = 1;


                for (int i = 1; i <= xlWorkBook.Worksheets.Count; i++)
                {
                    xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets[i];

                    int usedRows = xlWorkSheet.Cells.Find("*", System.Reflection.Missing.Value,
                       System.Reflection.Missing.Value, System.Reflection.Missing.Value, Excel.XlSearchOrder.xlByRows,
                       Excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Row;

                    int usedCols = xlWorkSheet.Cells.Find("*", System.Reflection.Missing.Value,
                                System.Reflection.Missing.Value, System.Reflection.Missing.Value, Excel.XlSearchOrder.xlByColumns,
                                Excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Column;

                    Excel.Range xlRange = xlWorkSheet.UsedRange;

                    int colCount = xlWorkSheet.Cells.Find("*", System.Reflection.Missing.Value,
                        System.Reflection.Missing.Value, System.Reflection.Missing.Value, Excel.XlSearchOrder.xlByColumns,
                        Excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Column;

                    object[,] values = new object[usedRows, colCount];
                    string colName = ColumnInt2String(colCount);
                    values = xlWorkSheet.get_Range("A1", colName + usedRows).Value;

                    //Check Template File
                    //テンプレートファイルをチェック
                    if (ReadCell(4, ConstantUtils.SERIALNO_CELLADD, xlRange) == ConstantUtils.SERIALNO &&
                        ReadCell(4, ConstantUtils.ITEMNO_CELLADD, xlRange) == ConstantUtils.ITEMNO &&
                        ReadCell(4, ConstantUtils.ITEMNM_CELLADD, xlRange) == ConstantUtils.ITEMNM &&
                        ReadCell(4, ConstantUtils.DTYPE_CELLADD, xlRange) == ConstantUtils.DTYPE &&
                        ReadCell(4, ConstantUtils.DSIZE_CELLADD, xlRange) == ConstantUtils.DSIZE &&
                        ReadCell(4, ConstantUtils.DESCRIPTION_CELLADD, xlRange) == ConstantUtils.DESCRIPTION &&
                        ReadCell(4, ConstantUtils.MEMO_CELLADD, xlRange) == ConstantUtils.MEMO)
                    {
                        phyCopyInfo.CPYPHY_SubSysId = subSysId;
                        phyCopyInfo.CPYPHY_InfoId = infoId;
                        int lastRow = 6 - 1;
                        StringBuilder itemNoBuilder = null;
                        StringBuilder itemNMBuilder = null;
                        StringBuilder dTypeBuilder = null;
                        StringBuilder dataSizeBuilder = null;
                        StringBuilder descriptionBuilder = null;
                        StringBuilder memoBuilder = null;

                        for (int j = 6; j <= usedRows; j++)
                        {
                            string serialNo = ReadCell(j, ConstantUtils.SERIALNO_CELLADD, xlRange);

                            //bool isCellStart = false;
                            PhysicalCopyKuItemInfo itemInfo = null;
                            if (serialNo != string.Empty)
                            {
                                itemInfo = new PhysicalCopyKuItemInfo();
                                if (itemNMBuilder == null && dataSizeBuilder == null && descriptionBuilder == null)
                                {
                                    itemNoBuilder = new StringBuilder();
                                    itemNMBuilder = new StringBuilder();
                                    dTypeBuilder = new StringBuilder();
                                    dataSizeBuilder = new StringBuilder();
                                    descriptionBuilder = new StringBuilder();
                                    memoBuilder = new StringBuilder();
                                }

                                if (itemNMBuilder.ToString() != string.Empty && dataSizeBuilder.ToString() != string.Empty)
                                {
                                    string itemNo = itemNoBuilder.ToString();
                                    string itemName = itemNMBuilder.ToString();
                                    string dataType = dTypeBuilder.ToString();
                                    string dSize = dataSizeBuilder.ToString();
                                    string description = descriptionBuilder.ToString();
                                    string memo = memoBuilder.ToString();
                                    itemInfo.PHYITM_SubSysId = subSysId;
                                    itemInfo.PHYITM_InfoId = infoId;
                                    itemInfo.PHYITM_ItemNo = no;
                                    itemInfo.PHYITM_ItemId = itemNo;

                                    if (itemName == string.Empty)
                                    {
                                        logger.Error(string.Format(Resources.IDR00002_E, serialNo, ConstantUtils.ITEMNM));
                                        throw new CopyKuInfoReadProcessException(string.Format(Resources.IDR00002_E, serialNo, ConstantUtils.ITEMNM));
                                        
                                    }
                                    itemInfo.PHYITM_ItemName = itemName;

                                    if (Utils.IsFiller(itemName))
                                    {
                                        itemInfo.PHYITM_ItemName = "FILLER";
                                    }

                                    itemInfo.PHYITM_DTTYPE = dataType;

                                    if (dSize == string.Empty)
                                    {
                                        logger.Error(string.Format(Resources.IDR00002_E, serialNo, ConstantUtils.DSIZE));
                                        throw new CopyKuInfoReadProcessException(string.Format(Resources.IDR00002_E, serialNo, ConstantUtils.DSIZE));

                                    }
                                    if (dataType == string.Empty && itemInfo.PHYITM_ItemName != "FILLER")
                                    {
                                        var match = Regex.Match(dSize.Trim(), "^[(]([0-9]+)[)]$");
                                        if (match.Success)
                                        {
                                            itemInfo.PHYITM_DTLEN = int.Parse(match.Groups[1].Value);
                                            itemInfo.PHYITM_ItemFlg = "0";
                                        }
                                        else
                                        {
                                            var match1 = Regex.Match(dSize.Trim(), @"^[(]([0-9]+)[)]\s*[×]\s*([0-9]+)$");
                                            if (match1.Success)
                                            {
                                                var size = int.Parse(match1.Groups[1].Value);
                                                var occurs = int.Parse(match1.Groups[2].Value);
                                                itemInfo.PHYITM_DTLEN = size;
                                                itemInfo.PHYITM_Occurs = occurs;
                                                itemInfo.PHYITM_ItemFlg = "0";
                                            }
                                        }
                                    }
                                    else
                                    {
                                        var match2 = Regex.Match(dSize.Trim(), @"^([0-9]+)\s*[×]\s*([0-9]+)$");
                                        if (match2.Success)
                                        {
                                            var size = int.Parse(match2.Groups[1].Value);
                                            var occurs = int.Parse(match2.Groups[2].Value);
                                            itemInfo.PHYITM_DTLEN = size;
                                            itemInfo.PHYITM_Occurs = occurs;
                                            itemInfo.PHYITM_ItemFlg = "0";
                                        }
                                        else
                                        {
                                            itemInfo.PHYITM_DTLEN = int.Parse(dSize != null && dSize.EndsWith("b") ? dSize.Replace("b", "") : dSize);

                                            itemInfo.PHYITM_ItemFlg = "1";
                                        }
                                    }

                                    itemInfo.PHYITM_Note = memo;
                                    itemInfo.PHYITM_Comment = description;

                                    itemInfos.Add(itemInfo);
                                    //結合文字をクリアする。
                                    itemNoBuilder.Clear();
                                    itemNMBuilder.Clear();
                                    dTypeBuilder.Clear();
                                    dataSizeBuilder.Clear();
                                    descriptionBuilder.Clear();
                                    memoBuilder.Clear();

                                    if (itemNMBuilder.ToString() == string.Empty)
                                    {
                                        itemNoBuilder = new StringBuilder();
                                        itemNMBuilder = new StringBuilder();
                                        dTypeBuilder = new StringBuilder();
                                        dataSizeBuilder = new StringBuilder();
                                        descriptionBuilder = new StringBuilder();
                                        memoBuilder = new StringBuilder();

                                        string noItem = ReadCell(j, ConstantUtils.ITEMNO_CELLADD, xlRange);
                                        itemNoBuilder.Append(noItem);

                                        string name = ReadCell(j, ConstantUtils.ITEMNM_CELLADD, xlRange);
                                        if(name != string.Empty)
                                        {
                                            itemNMBuilder.Append(name);
                                        }
                                        else
                                        {
                                            logger.Error(string.Format(Resources.IDR00002_E, serialNo, ConstantUtils.ITEMNM));
                                            throw new CopyKuInfoReadProcessException(string.Format(Resources.IDR00002_E, serialNo, ConstantUtils.ITEMNM));
                                        }                                       

                                        string dType = ReadCell(j, ConstantUtils.DTYPE_CELLADD, xlRange);

                                        string dataSize = ReadCell(j, ConstantUtils.DSIZE_CELLADD, xlRange);
                                        if (dataSize == string.Empty)
                                        {
                                            logger.Error(string.Format(Resources.IDR00002_E, serialNo, ConstantUtils.ITEMNM));
                                            throw new CopyKuInfoReadProcessException(string.Format(Resources.IDR00002_E, serialNo, ConstantUtils.DSIZE));
                                        }

                                        if (!dataSize.StartsWith("(") && name != "予備")
                                        {
                                            if (dType == string.Empty)
                                            {
                                                logger.Error(string.Format(Resources.IDR00002_E, serialNo, ConstantUtils.ITEMNM));
                                                throw new CopyKuInfoReadProcessException(string.Format(Resources.IDR00002_E, serialNo, "データ形式"));
                                            }
                                        }
                                        dTypeBuilder.Append(dType);

                                        dataSizeBuilder.Append(dataSize);

                                        string desc = ReadCell(j, ConstantUtils.DESCRIPTION_CELLADD, xlRange);
                                        descriptionBuilder.Append(desc);

                                        string note = ReadCell(j, ConstantUtils.MEMO_CELLADD, xlRange);
                                        memoBuilder.Append(note);
                                    }
                                    no++;
                                }
                                else
                                {
                                    string itemNo = ReadCell(j, ConstantUtils.ITEMNO_CELLADD, xlRange);
                                    itemNoBuilder.Append(itemNo);

                                    string itemName = ReadCell(j, ConstantUtils.ITEMNM_CELLADD, xlRange);
                                    if (itemName != string.Empty)
                                    {
                                        itemNMBuilder.Append(itemName);
                                    }
                                    else
                                    {
                                        logger.Error(string.Format(Resources.IDR00002_E, serialNo, ConstantUtils.ITEMNM));
                                        throw new CopyKuInfoReadProcessException(string.Format(Resources.IDR00002_E, serialNo, ConstantUtils.ITEMNM));
                                    }                                    

                                    if (j == 6 && isFirstItem == false)
                                    {
                                        phyCopyInfo.CPYPHY_BcpNm = itemName;
                                    }
                                    else
                                    {
                                        phyCopyInfo.CPYPHY_BcpNm = itemName;

                                    }
                                    string dataType = ReadCell(j, ConstantUtils.DTYPE_CELLADD, xlRange);
                                    dTypeBuilder.Append(dataType);

                                    string dSize = ReadCell(j, ConstantUtils.DSIZE_CELLADD, xlRange);
                                    if (dSize == string.Empty)
                                    {
                                        break;
                                    }
                                    dataSizeBuilder.Append(dSize);
                                    if (j == 6 && isFirstItem == false && dSize.StartsWith("(") && dSize.EndsWith(")"))
                                    {
                                        string size = dSize.Substring(dSize.IndexOf("(") + 1, dSize.IndexOf(")") - 1);
                                        copykuSize = int.Parse(size);
                                    }
                                    string description = ReadCell(j, ConstantUtils.DESCRIPTION_CELLADD, xlRange);
                                    descriptionBuilder.Append(description);

                                    string memo = ReadCell(j, ConstantUtils.MEMO_CELLADD, xlRange);
                                    memoBuilder.Append(memo);
                                }
                                //isCellStart = true;
                            }

                            //if (isCellStart == true)
                            //{
                            //　項番が変わるタイミングでアイテム情報をデータ一覧に追加する。

                            //}
                            else
                            {
                                if (itemNoBuilder == null)
                                {
                                    itemNoBuilder = new StringBuilder();
                                }

                                if (itemNMBuilder == null)
                                {
                                    itemNMBuilder = new StringBuilder();
                                }

                                if (dTypeBuilder == null)
                                {
                                    dTypeBuilder = new StringBuilder();
                                }

                                if (dataSizeBuilder == null)
                                {
                                    dataSizeBuilder = new StringBuilder();
                                }

                                if (descriptionBuilder == null)
                                {
                                    descriptionBuilder = new StringBuilder();
                                }

                                if (memoBuilder == null)
                                {
                                    memoBuilder = new StringBuilder();
                                }

                                string itemNo = ReadCell(j, ConstantUtils.ITEMNO_CELLADD, xlRange);
                                if (itemNo != string.Empty && itemNoBuilder.ToString() != string.Empty)
                                {
                                    itemNoBuilder.Append("\n");
                                    itemNoBuilder.Append(itemNo);
                                }
                                string itemName = ReadCell(j, ConstantUtils.ITEMNM_CELLADD, xlRange);
                                itemNMBuilder.Append(itemName);

                                string dataType = ReadCell(j, ConstantUtils.DTYPE_CELLADD, xlRange);
                                
                                string dSize = ReadCell(j, ConstantUtils.DSIZE_CELLADD, xlRange);
                                dataSizeBuilder.Append(dSize);

                                string description = ReadCell(j, ConstantUtils.DESCRIPTION_CELLADD, xlRange);
                                descriptionBuilder.Append(description);

                                string memo = ReadCell(j, ConstantUtils.MEMO_CELLADD, xlRange);
                                memoBuilder.Append(memo);
                            }
                            lastRow++;
                        }

                        //シートが変わるタイミングでアイテム情報をデータ一覧に追加する。
                        if (lastRow == usedRows)
                        {
                            if (itemNMBuilder.ToString() != string.Empty && dataSizeBuilder.ToString() != string.Empty)
                            {
                                PhysicalCopyKuItemInfo itemInfo = new PhysicalCopyKuItemInfo();
                                string itemNo = itemNoBuilder.ToString();
                                string itemName = itemNMBuilder.ToString();
                                string dataType = dTypeBuilder.ToString();
                                string dSize = dataSizeBuilder.ToString();
                                string description = descriptionBuilder.ToString();
                                string memo = memoBuilder.ToString();
                                itemInfo.PHYITM_SubSysId = subSysId;
                                itemInfo.PHYITM_InfoId = infoId;
                                itemInfo.PHYITM_ItemId = itemNo;
                                itemInfo.PHYITM_ItemNo = no;

                                if (itemName == string.Empty)
                                {
                                    break;
                                }
                                itemInfo.PHYITM_ItemName = itemName;

                                if (Utils.IsFiller(itemName))
                                {
                                    itemInfo.PHYITM_ItemName = "FILLER";
                                }

                                itemInfo.PHYITM_DTTYPE = dataType;

                                if (dSize == string.Empty)
                                {
                                    logger.Error(string.Format(Resources.IDR00002_E, itemNo, ConstantUtils.ITEMNM));
                                    throw new CopyKuInfoReadProcessException(string.Format(Resources.IDR00002_E, itemNo, ConstantUtils.DTYPE));                                    
                                }

                                if (dataType == string.Empty && itemInfo.PHYITM_ItemName != "FILLER")
                                {
                                    var match = Regex.Match(dSize.Trim(), "^[(]([0-9]+)[)]$");
                                    if (match.Success)
                                    {
                                        itemInfo.PHYITM_DTLEN = int.Parse(match.Groups[1].Value);
                                        itemInfo.PHYITM_ItemFlg = "0";
                                    }
                                    else
                                    {
                                        var match1 = Regex.Match(dSize.Trim(), @"^[(]([0-9]+)[)]\s*[×]\s*([0-9]+)$");
                                        if (match1.Success)
                                        {
                                            var size = int.Parse(match1.Groups[1].Value);
                                            var occurs = int.Parse(match1.Groups[2].Value);
                                            itemInfo.PHYITM_DTLEN = size;
                                            itemInfo.PHYITM_Occurs = occurs;
                                            itemInfo.PHYITM_ItemFlg = "0";
                                        }
                                    }
                                }
                                else
                                {
                                    var match2 = Regex.Match(dSize.Trim(), @"^([0-9]+)\s*[×]\s*([0-9]+)$");
                                    if (match2.Success)
                                    {
                                        var size = int.Parse(match2.Groups[1].Value);
                                        var occurs = int.Parse(match2.Groups[2].Value);
                                        itemInfo.PHYITM_DTLEN = size;
                                        itemInfo.PHYITM_Occurs = occurs;
                                        itemInfo.PHYITM_ItemFlg = "0";
                                    }
                                    else
                                    {
                                        itemInfo.PHYITM_DTLEN = int.Parse(dSize != null && dSize.EndsWith("b") ? dSize.Replace("b", "") : dSize);
                                        itemInfo.PHYITM_ItemFlg = "1";
                                    }
                                    
                                }
                                itemInfo.PHYITM_Note = memo;
                                itemInfo.PHYITM_Comment = description; 
                                itemInfos.Add(itemInfo);                              
                                itemNoBuilder.Clear();
                                itemNMBuilder.Clear();
                                dTypeBuilder.Clear();
                                dataSizeBuilder.Clear();
                                descriptionBuilder.Clear();
                                memoBuilder.Clear();
                                no++;
                            }
                        }
                    }
                    else
                    {
                        //Log for Template file is worng.
                        //テンプレートファイルは間違っている場合、ログに記録
                        logger.Error(string.Format(Resources.IDR00008_E, xlWorkSheet.Name));
                        throw new CopyKuInfoReadProcessException(string.Format(Resources.IDR00008_E, xlWorkSheet.Name));
                    }
                }
                phyCopyInfo.phyCpyItemInfoList = itemInfos;
            }
            catch (CopyKuInfoReadProcessException e)
            {
                throw new CopyKuInfoReadProcessException(e.GetMessage());
            }            
            finally
            {
                if (xlWorkSheet != null)
                {
                    Marshal.ReleaseComObject(xlWorkSheet);
                    xlWorkSheet = null;
                }

                if (xlWorkBook != null)
                {
                    xlWorkBook.Close(Type.Missing, Type.Missing, Type.Missing);
                    Marshal.ReleaseComObject(xlWorkBook);
                    xlWorkBook = null;
                }

                if (xlApp != null)
                {
                    xlApp.Quit();
                    Marshal.ReleaseComObject(xlApp);
                    xlApp = null;
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
            return phyCopyInfo;
        }


        /// <summary>
        /// セルの読み取り
        /// </summary>
        /// <param name="row">行</param>
        /// <param name="column">列</param>
        /// <returns>セルの値</returns>
        public string ReadCell(int row, int column, Excel.Range range)
        {
            string col = ColumnInt2String(column);
            try
            {
                object value = range.Cells[row, column].Value;
                if (value == null)
                {
                    return string.Empty;
                }
                return value.ToString();
            }
            catch
            {
                throw;
            }
        }

        private string ColumnInt2String(int nCol)
        {
            if (nCol < 1) return string.Empty;

            string strCol = string.Empty;
            do
            {
                strCol = (char)((nCol - 1) % 26 + 'A') + strCol;
                nCol = (nCol - 1) / 26;
            } while (nCol > 0);

            return strCol;
        }

        public bool checkDatalengthData(PhysicalCopyKuItemInfo itemInfo)
        {
            var validator = new ValidationContext(itemInfo, null, null);
            List<ValidationResult> valres = new List<ValidationResult>();
            bool isVal = Validator.TryValidateObject(itemInfo, validator, valres, true);

            if (valres.Count > 0 && isVal == false)
            {
                foreach (ValidationResult val in valres)
                {
                    logger.Error(val.ErrorMessage);
                    throw new CopyKuInfoReadProcessException(val.ErrorMessage);
                }
            }
            return isVal;
        }
    }
}
