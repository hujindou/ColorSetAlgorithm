﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MarsTool.Models;
using MarsTool.Models.DB;
using System.Windows.Forms;
using MarsTool.Common.Forms;
using MarsTool.Common;
using System.IO;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Runtime.Serialization.Formatters.Binary;
using MarsTool.Properties;

namespace MarsTool.Services
{
    /// <summary>
    /// インタフェース管理・編集機能処理群
    /// </summary>
    class InterfaceEdit
    {
        private NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        #region クラス
        /// <summary>
        /// ヘッダ情報
        /// </summary>
        public class HeaderInfo
        {
            /// <summary>物理コピー句情報</summary>
            public T_CPYPHY cpyphy;
            /// <summary>論理コピー句情報</summary>
            public List<T_CPYLOG> cpylog;
            /// <summary>論理設定条件名称</summary>
            public List<string> conditionNames;
            /// <summary>論理ＩＦ設定情報</summary>
            public List<LogicIfHeader> logicIfHeader;
        }

        /// <summary>
        /// 行情報
        /// </summary>
        public class RowInfo
        {
            /// <summary>物理アイテム情報</summary>
            public T_PHYITM phyitm;
            /// <summary>候補値設定</summary>
            public List<T_KOHO> koho;
            /// <summary>論理設定条件情報</summary>
            public List<T_CONDITION> condition;
            /// <summary>物理Ｍパーサ情報</summary>
            public T_PHYPRS_EF phyprs;
            /// <summary>論理アイテム情報<summary>
            public List<T_LOGITM> logitm;
            /// <summary>図表ファイルパス</summary>
            public string PictureFilePath;
        }

        /// <summary>
        /// 編集情報
        /// </summary>
        public class EditInfo
        {
            /// <summary>
            /// 編集種別
            /// </summary>
            public enum EditTypes
            {
                /// <summary>追加</summary>
                Add,
                /// <summary>削除</summary>
                Delete,
                /// <summary>変更</summary>
                Change
            };

            /// <summary>
            /// コンストラクタ
            /// </summary>
            /// <param name="editType">編集種別</param>
            /// <param name="rowIndex">編集行</param>
            public EditInfo(EditTypes editType, int rowIndex)
            {
                this.EditType = editType;
                this.RowIndex = rowIndex;
            }
            /// <summary>
            /// 編集種別
            /// </summary>
            public EditTypes EditType { get; }
            /// <summary>
            /// 編集行
            /// </summary>
            public int RowIndex { get; }
            /// <summary>
            /// 行情報
            /// </summary>
            public RowInfo RowInfo { get; set; }
            /// <summary>
            /// 変更前行情報
            /// </summary>
            public RowInfo BeforeRowInfo { get; set; }
            /// <summary>
            /// 変更後行情報
            /// </summary>
            public RowInfo AfterRowInfo { get; set; }
        }

        public class LogicIfHeader
        {
            public string OPNM { get; set; }
            public string ID { get; set; }
        }

        public class UpdateInfo
        {
            public bool Result { get; set; }
            public bool CPYPHY { get; set; }
            public bool PHYPRS { get; set; }
            public List<string> updateLCPID { get; set; }
            public List<string> deleteLCPID { get; set; }
        }


        /// <summary>
        /// 最終更新者情報
        /// </summary>
        public class LastUpdateUser
        {
            /// <summary>
            /// コンストラクタ
            /// </summary>
            /// <param name="user">更新ユーザ</param>
            /// <param name="datetime">更新日時</param>
            internal LastUpdateUser(string user, DateTime? datetime)
            {
                this.User = user;
                this.DateTime = datetime;
            }

            /// <summary>
            /// 更新ユーザ
            /// </summary>
            public string User { get; }
            /// <summary>
            /// 更新日時
            /// </summary>
            public DateTime? DateTime { get; }
        }

        /// <summary>
        /// レイアウト項目
        /// </summary>
        [SerializableAttribute()]
        public class LayoutItem
        {
            /// <summary>
            /// 項目名
            /// </summary>
            public string Name { get; set; }
            /// <summary>
            /// 項目タグ
            /// </summary>
            public string Tag { get; set; }
            /// <summary>
            /// 属性
            /// </summary>
            public string Type { get; set; }
            /// <summary>
            /// サイズ
            /// </summary>
            public int Size { get; set; }
            /// <summary>
            /// 対象
            /// </summary>
            public bool IsTarget { get; set; }
            /// <summary>
            /// 開始位置
            /// </summary>
            public int offset { get; set; }
            /// <summary>
            /// 内部レベル
            /// </summary>
            public int Level { get; set; }
            /// <summary>
            /// 繰返し数
            /// </summary>
            public int Occurs { get; set; }
            public string CodeF { get; set; }
            public string Sign { get; set; }
            /// <summary>
            /// 親項目
            /// </summary>
            public LayoutItem ParentItem;
            /// <summary>
            /// 子項目
            /// </summary>
            public List<LayoutItem> ChildItems;
            /// <summary>
            /// コンストラクタ
            /// </summary>
            public LayoutItem()
            {
                ChildItems = new List<LayoutItem>();
            }
            /// <summary>
            /// DeepClone
            /// </summary>
            /// <returns></returns>
            public LayoutItem DeepClone()
            {
                // 高速化の為、一旦親項目をnullに変更する
                LayoutItem OriginalParent = this.ParentItem;
                this.ParentItem = null;
                // BinaryFormatter でシリアライズしたオブジェクトを
                // デシリアライズすることで、DeepClone（参照型も値を複製）する。
                object result;
                BinaryFormatter b = new BinaryFormatter();
                MemoryStream mem = new MemoryStream();
                try
                {
                    b.Serialize(mem, this);
                    mem.Position = 0;
                    result = b.Deserialize(mem);
                }
                finally
                {
                    //オリジナルの親項目を元に戻す
                    this.ParentItem = OriginalParent;
                    mem.Close();
                }
                //但し、親項目については、コピー元と同じ参照先とする
                LayoutItem Item = (LayoutItem)result;
                Item.ParentItem = this.ParentItem;
                return Item;
            }
        }

        #endregion

        #region 内部プロパティ
        private VersionModel VersionModel { get; set; }
        private GroupDataGridView DataGridView { get; set; }
        private string SubsystemuID { get; set; }
        private string InfoID { get; set; }
        #endregion

        /// <summary>
        /// 論理サブシステム
        /// </summary>
        public string LogicSubsystem { get; set; }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="version"></param>
        public InterfaceEdit(VersionModel version, GroupDataGridView dataGridView, string subsystemID, string infoID, string logicSybsystemID)
        {
            this.VersionModel = version;
            this.DataGridView = dataGridView;
            this.SubsystemuID = subsystemID;
            this.LogicSubsystem = logicSybsystemID;
            this.InfoID = infoID;
        }
        public InterfaceEdit(VersionModel version, GroupDataGridView dataGridView, string PhysicCobolfile, string logicSybsystemID)
        {
            this.VersionModel = version;
            this.DataGridView = dataGridView;
            this.LogicSubsystem = logicSybsystemID;
            string id = Path.GetFileNameWithoutExtension(PhysicCobolfile);
            //
            try
            {
                T_CPYPHY cpyphy = this.VersionModel.context.T_CPYPHY.AsNoTracking().Where(r => r.CPYPHY_BCPID == id).SingleOrDefault();
                this.SubsystemuID = cpyphy.CPYPHY_SUBSYSID;
                this.InfoID = cpyphy.CPYPHY_INFOID;
            }
            catch
            {
            }
        }

        /// <summary>
        /// 物理コピー句情報取得
        /// </summary>
        /// <returns></returns>
        public T_CPYPHY getPhysicCopyInfo()
        {
            IQueryable<T_CPYPHY> cpyphy = this.VersionModel.context.T_CPYPHY.AsNoTracking().Where(r => r.CPYPHY_SUBSYSID == this.SubsystemuID && r.CPYPHY_INFOID == this.InfoID).Take(1);
            List<T_CPYPHY> l = cpyphy.ToList();
            if (l != null && l.Count == 1 )
            {
                return l.First();
            }
            return null;
        }

        /// <summary>
        /// コピー句ファイルより物理コピー句情報取得
        /// </summary>
        /// <param name="file"></param>
        /// <returns></returns>
        public T_CPYPHY getPhysicCopyInfoFromFile(string file)
        {
            T_CPYPHY cpyphy = new T_CPYPHY();
            try
            {
                using (StreamReader sr = new StreamReader(file, Encoding.GetEncoding("Shift_Jis")))
                {
                    StringBuilder sb = new StringBuilder();
                    while (sr.EndOfStream == false)
                    {
                        string buf = sr.ReadLine().Trim();
                        //空行とコメント行は無視する
                        if (buf.Length == 0) continue;
                        if (buf.First() == '*' || buf.First() == 'D') continue;

                        sb.Append(buf);
                        //行末がピリオド(.)かチェックする
                        if (buf.Last() != '.')
                        {
                            sb.Append(" ");
                            continue;
                        }

                        //連続するスペースと最後のピリオドを削る。
                        buf = Regex.Replace(sb.ToString(), @"\s+", " ");
                        buf = buf.Substring(0, buf.Length - 1);

                        string[] items = buf.Split(' ');
                        if(items.Length < 2)
                        {
                            return null;
                        }
                        else
                        {
                            cpyphy.CPYPHY_LEVNO = int.Parse(items[0]);
                            cpyphy.CPYPHY_BCPID = Path.GetFileNameWithoutExtension(file);
                            return cpyphy;
                        }
                    }
                }
            }
            catch (Exception)
            {
                return null;
            }
            return cpyphy;
        }

        /// <summary>
        /// 物理アイテム情報取得
        /// </summary>
        /// <returns></returns>
        public List<T_PHYITM> getPhysicItemInfo()
        {
            IQueryable<T_PHYITM> phyitm = this.VersionModel.context.T_PHYITM.AsNoTracking().Where(r => r.PHYITM_SUBSYSID == this.SubsystemuID && r.PHYITM_INFOID == this.InfoID).OrderBy(r => r.PHYITM_ITEMNO);
            return phyitm.ToList();
        }

        /// <summary>
        /// コピー句ファイルより物理アイテム情報取得
        /// </summary>
        /// <param name="file"></param>
        /// <returns></returns>
        public List<T_PHYITM> getPhysicItemInfoFromFile(string file)
        {
            List<TreeNode> listNode = new List<TreeNode>();
            List<int> listLevel = new List<int>();
            try
            {
                using (StreamReader sr = new StreamReader(file, Encoding.GetEncoding("Shift_Jis")))
                {
                    StringBuilder sb = new StringBuilder();
                    while(sr.EndOfStream == false)
                    {
                        string buf = sr.ReadLine().Trim();
                        //空行とコメント行は無視する
                        if (buf.Length == 0) continue;
                        if (buf.First() == '*' || buf.First() == 'D' || buf.First() == '/') continue;

                        sb.Append(buf);
                        //行末がピリオド(.)かチェックする
                        if (buf.Last() != '.')
                        {
                            sb.Append(" ");
                            continue;
                        }

                        //前後のスペースと最後のピリオドを削り、後ろのスペースを削る
                        buf = sb.ToString().TrimEnd();
                        buf = buf.Substring(0, buf.Length - 1).TrimEnd();

                        T_PHYITM phyitm = new T_PHYITM();
                        TreeNode node = new TreeNode();
                        int pos = 0;
                        int idx = 0;
                        bool find;

                        //レベル番号
                        pos = buf.IndexOf(' ', idx);
                        if(int.TryParse(buf.Substring(idx, pos - idx), out int level))
                        {
                            if(listNode.Count == 0)
                            {
                                phyitm.PHYITM_LEVEL = 1;
                            }
                            else
                            {
                                int checkIndex = listNode.Count - 1;
                                TreeNode checkNode = listNode[checkIndex];

                                while(checkNode != null)
                                {
                                    int l = listLevel[checkIndex];
                                    if (l < level)
                                    {
                                        checkNode.Nodes.Add(node);
                                        phyitm.PHYITM_LEVEL = checkNode.Level + 2;
                                        break;
                                    }
                                    else
                                    {
                                        checkNode = checkNode.Parent;
                                        checkIndex = listNode.IndexOf(checkNode);
                                    }
                                }
                            }
                            listLevel.Add(level);
                        }

                        //項目名称
                        find = false;
                        for (idx = pos + 1; idx < buf.Length; idx++)
                        {
                            if (buf[idx] != ' ')
                            {
                                find = true;
                                break;
                            }
                        }
                        if (find)
                        {
                            pos = buf.IndexOf(' ', idx);
                            if (pos == -1)
                            {
                                phyitm.PHYITM_ITEMNM = buf.Substring(idx);
                            }
                            else
                            {
                                phyitm.PHYITM_ITEMNM = buf.Substring(idx, pos - idx);
                            }
                        }

                        //PICTURE句 / ADDRESS句 / OCCURS句
                        find = false;
                        for (idx = pos + 1; idx < buf.Length; idx++)
                        {
                            if (buf[idx] != ' ')
                            {
                                find = true;
                                break;
                            }
                        }
                        if(find)
                        {
                            pos = buf.IndexOf(' ', idx);
                            if (pos == -1) pos = buf.Length;
                            string item = buf.Substring(idx, pos - idx );
                            if (item == "PIC" || item == "ADDRESS" || item == "OCCURS")
                            {
                                if (item == "PIC")
                                {
                                    idx = pos + 1;
                                    // OCCURS句があるかチェックする
                                    int o = buf.IndexOf(" OCCURS ", idx);
                                    if(o != -1)
                                    {
                                        phyitm.PHYITM_CPYDTTYPE = buf.Substring(idx, o - idx ).Trim();
                                        if (int.TryParse(buf.Substring(o + 8), out int count))
                                        {
                                            phyitm.PHYITM_OCCURS = count;
                                        }
                                    }
                                    else
                                    {
                                        phyitm.PHYITM_CPYDTTYPE = buf.Substring(idx).Trim();
                                    }
                                }
                                else if (item == "ADDRESS")
                                {
                                    phyitm.PHYITM_CPYDTTYPE = item;
                                }
                                else if (item == "OCCURS")
                                {
                                    if (int.TryParse(buf.Substring(pos + 1), out int count))
                                    {
                                        phyitm.PHYITM_OCCURS = count;
                                    }
                                }
                            }
                        }
                        node.Tag = phyitm;
                        listNode.Add(node);
                        sb.Clear();
                    }
                }
            }
            catch(Exception)
            {
                return null;
            }
            List<T_PHYITM> listPHYITM = new List<T_PHYITM>();
            foreach(TreeNode node in listNode)
            {
                listPHYITM.Add(node.Tag as T_PHYITM);
            }
            return listPHYITM;
        }

        /// <summary>
        /// 該当シーケンスの物理アイテム情報を取得
        /// </summary>
        /// <param name="SEQ"></param>
        /// <returns></returns>
        private T_PHYITM getPhysicItem(string SEQ)
        {
            IQueryable<T_PHYITM> phyitm = this.VersionModel.context.T_PHYITM.AsNoTracking().Where(r => r.PHYITM_SUBSYSID == this.SubsystemuID && r.PHYITM_INFOID == this.InfoID && r.PHYITM_SEQ == SEQ);
            if(phyitm.Count() != 0)
            {
                return phyitm.Single();
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// 論理設定条件名称の取得
        /// </summary>
        /// <returns></returns>
        public List<string> getConditionName()
        {
            IQueryable<string> name = this.VersionModel.context.T_CONDITION.AsNoTracking().Where(r => r.COND_SUBSYSID == this.SubsystemuID && r.COND_INFOID == this.InfoID).OrderBy(r => r.COND_OUTPUTORDER).Select(r => r.COND_OPNM).Distinct();
            return name.ToList();
        }

        /// <summary>
        /// 論理設定条件情報取得
        /// </summary>
        /// <returns></returns>
        public List<T_CONDITION> getConditionInfo()
        {
            IQueryable<T_CONDITION> cond = this.VersionModel.context.T_CONDITION.AsNoTracking().Where(r => r.COND_SUBSYSID == this.SubsystemuID && r.COND_INFOID == this.InfoID).OrderBy(r => r.COND_OUTPUTORDER);
            int Count = cond.Count();
            if (Count > 0)
            {
                return cond.ToList();
            }
            return null;
        }

        public List<T_CONDITION> getCondition(string SEQ)
        {
            IQueryable<T_CONDITION> cond = this.VersionModel.context.T_CONDITION.AsNoTracking().Where(r => 
                                                                                                        r.COND_SUBSYSID == this.SubsystemuID && 
                                                                                                        r.COND_INFOID == this.InfoID && 
                                                                                                        r.COND_SEQ == SEQ).OrderBy(r => r.COND_OUTPUTORDER);
            return cond.ToList();
        }

        /// <summary>
        /// 論理コピー句名称＆コピー句ＩＤ取得
        /// </summary>
        /// <returns></returns>
        public List<LogicIfHeader> getLogicHeader()
        {
            List<LogicIfHeader> headers = new List<LogicIfHeader>();
            IQueryable<T_CPYLOG> queryable = this.VersionModel.context.T_CPYLOG.AsNoTracking().Where(r =>
                                                                                                r.CPYLGC_PHYSYSID == this.SubsystemuID &&
                                                                                                r.CPYLGC_INFOID == this.InfoID &&
                                                                                                r.CPYLGC_SUBSYSID == this.LogicSubsystem).OrderBy(r =>
                                                                                                                r.CPYLGC_OUTPUTORDER);
            foreach(T_CPYLOG cpylog in queryable.ToList())
            {
                LogicIfHeader header = new LogicIfHeader
                {
                    OPNM = cpylog.CPYLGC_OPNM,
                    ID = cpylog.CPYLGC_LCPID
                };
                headers.Add(header);
            }
            return headers;
        }

        public List<T_CPYLOG> getLogicInterfaceInfo()
        {
            List<T_CPYLOG> cpylog = this.VersionModel.context.T_CPYLOG.AsNoTracking().Where(r =>
                                                                                            r.CPYLGC_PHYSYSID == this.SubsystemuID &&
                                                                                            r.CPYLGC_INFOID == this.InfoID &&
                                                                                            r.CPYLGC_SUBSYSID == this.LogicSubsystem).OrderBy(r => r.CPYLGC_OUTPUTORDER).ToList();
            return cpylog;
        }

        /// <summary>
        /// 論理コピー句情報取得
        /// </summary>
        /// <param name="CopyID">コピー句ＩＤ</param>
        /// <returns></returns>
        public T_CPYLOG getCPYLOG(string CopyID)
        {
            T_CPYLOG cpylog = this.VersionModel.context.T_CPYLOG.AsNoTracking().Where(r => r.CPYLGC_PHYSYSID == this.SubsystemuID && r.CPYLGC_INFOID == this.InfoID && r.CPYLGC_SUBSYSID == this.LogicSubsystem && r.CPYLGC_LCPID == CopyID).SingleOrDefault();
            return cpylog;
        }

        /// <summary>
        /// 候補値一覧の取得
        /// </summary>
        /// <param name="groupName"></param>
        /// <returns></returns>
        public List<T_KOHO> getKOHO(string groupName)
        {
            IQueryable<T_KOHO> queryable = this.VersionModel.context.T_KOHO.AsNoTracking().Where(r => r.KOHO_GROUP == groupName).OrderBy(r => r.KOHO_ORDER);
            return queryable.ToList();
        }

        /// <summary>
        /// 物理Ｍパーサ定義のレイアウト定義名称取得
        /// </summary>
        /// <returns></returns>
        public string getLayoutDef()
        {
            string layoutDef = this.VersionModel.context.T_PHYPRS.AsNoTracking().Where(r => r.PHYPRS_PHYSYSID == this.SubsystemuID && r.PHYPRS_INFOID == this.InfoID && r.PHYPRS_SUBSYSID == this.LogicSubsystem).Select(r => r.PHYPRS_LAYDEF).Distinct().SingleOrDefault();
            return layoutDef;
        }

        /// <summary>
        /// 物理Ｍパーサ定義の取得
        /// </summary>
        /// <param name="SEQ">取得するシーケンス</param>
        /// <returns></returns>
        public T_PHYPRS_EF getPHYPRS(string SEQ)
        {
            T_PHYPRS_EF phyprs = this.VersionModel.context.T_PHYPRS.AsNoTracking().Where(r => r.PHYPRS_PHYSYSID == this.SubsystemuID && r.PHYPRS_INFOID == this.InfoID && r.PHYPRS_SUBSYSID == this.LogicSubsystem && r.PHYPRS_SEQ == SEQ).SingleOrDefault();
            return phyprs;
        }

        /// <summary>
        /// 電文構成パターン物理情報の取得
        /// </summary>
        /// <returns></returns>
        public List<T_DENSTRB> getDENSTRB()
        {
            IQueryable<T_DENSTRB> queryable = this.VersionModel.context.T_DENSTRB.AsNoTracking().Where(r =>
                                                                                                        r.DENSTRB_SUBSYSID == this.SubsystemuID).OrderBy(r =>
                                                                                                                                                         r.DENSTRB_ORDER);
            return queryable.ToList();
        }

        /// <summary>
        /// 電文構成パターン物理アイテム情報の取得
        /// </summary>
        /// <param name="subsys"></param>
        /// <param name="type"></param>
        /// <param name="no"></param>
        /// <returns></returns>
        public List<T_DENSTRBITM> getDENSRTBITM(string subsys, string type, string no)
        {
            IQueryable<T_DENSTRBITM> queryable = this.VersionModel.context.T_DENSTRBITM.AsNoTracking().Where(r =>
                                                                                                             r.DENSTRBITM_SUBSYSID == this.SubsystemuID &&
                                                                                                             r.DENSTRBITM_TELSUBSYSID == subsys &&
                                                                                                             r.DENSTRBITM_TELTYPE == type &&
                                                                                                             r.DENSTRBITM_PATNO == no).OrderBy(r => r.DENSTRBITM_ORDER);
            return queryable.ToList();
        }

        /// <summary>
        /// GroupDataGridViewに行を追加
        /// </summary>
        /// <param name="cpyphy">物理コピー句情報</param>
        /// <param name="phyitm">追加する物理アイテム情報</param>
        /// <param name="koho">追加する候補値</param>>
        /// <param name="condition">追加する論理設定条件情報</param>
        public void AddRow(T_CPYPHY cpyphy, T_PHYITM phyitm, List<T_KOHO> koho, List<T_CONDITION> condition, T_PHYPRS_EF phyprs, List<T_CPYLOG> cpylog, List<T_LOGITM> logitm)
        {
            int rowIndex = DataGridView.Rows.Add();
            DataGridViewRow row = DataGridView.Rows[rowIndex];
            setRow(row, cpyphy, phyitm, koho, condition, phyprs, cpylog, logitm);
        }

        private void setRow(DataGridViewRow row, T_CPYPHY cpyphy, T_PHYITM phyitm, List<T_KOHO> koho, List<T_CONDITION> condition, T_PHYPRS_EF phyprs, List<T_CPYLOG> cpylog,  List<T_LOGITM> logitm)
        {
            int Index, Count;
            row.Cells[0].Value = string.Format("{0:D2}", phyitm.PHYITM_LEVEL);      //  レベル
            row.Cells[1].Value = phyitm.PHYITM_ITEMID;                              //  アイテム記号名称
            if(phyitm.PHYITM_ITEMNM != null && phyitm.PHYITM_ITEMNM == "FILLER")
            {
                row.Cells[2].Value = "予備";                                        //  アイテム名称（FILLER）
            }
            else
            {
                row.Cells[2].Value = phyitm.PHYITM_ITEMNM;                          //  アイテム名称
            }
            if(phyitm.PHYITM_DTTYPE == null)                                        //  データ形式
            {
                row.Cells[3].Value = string.Empty;
            }
            else
            {
                row.Cells[3].Value = phyitm.PHYITM_DTTYPE;
            }
            if (phyitm.PHYITM_DTLEN != 0)
            {
                row.Cells[4].Value = string.Format("{0:D}", phyitm.PHYITM_DTLEN);   //  データサイズ
            }
            if (phyitm.PHYITM_OCCURS != 0)
            {
                row.Cells[5].Value = string.Format("{0:D}", phyitm.PHYITM_OCCURS);  //  繰返し数
            }
            row.Cells[6].Value = phyitm.PHYITM_COMMENT;                             //  アイテム内容
            row.Cells[7].Value = phyitm.PHYITM_GROUP;                               //  候補値
            if(koho == null || koho.Count == 0)
            {
                row.Cells[7].Tag = null;
            }
            else
            {
                row.Cells[7].Tag = koho;
            }
            row.Cells[8].Value = phyitm.PHYITM_IMAGENM;                             //  図表
            row.Cells[9].Value = phyitm.PHYITM_NOTE;                                //  記事
            if (phyitm.PHYITM_ITEMNO == 0)
            {
                row.Cells[10].Value = string.Format("{0:D2}", cpyphy.CPYPHY_LEVNO); //  開始レベル番号
            }
                                                                                    //  コピー句データ形式
            if (string.IsNullOrEmpty(phyitm.PHYITM_CPYDTTYPE) == false && phyitm.PHYITM_CPYDTTYPE.IndexOf("ADDRESS") == 0)
            {
                row.Cells[11].Value = "ADDRESS";
                row.Cells[11].Tag = phyitm.PHYITM_CPYDTTYPE;
            }
            else
            {
                row.Cells[11].Value = phyitm.PHYITM_CPYDTTYPE;
                row.Cells[11].Tag = phyitm.PHYITM_CPYDTTYPE;
            }

            Index = this.DataGridView.GetIndexVariableColumn(Resources.IF_TAG_REQUIREMENT);
            Count = this.DataGridView.GetCountVariableColumn(Resources.IF_TAG_REQUIREMENT);
            for (int i = 0; i < condition.Count; i++)
            {
                if (i < Count)
                {
                    if (condition[i] != null)
                    {
                        
                        row.Cells[Index + i].Value = condition[i].COND_SETCOND;     // 論理設定条件
                    }
                }
            }
            if(phyprs != null)
            {
                Index = this.DataGridView.GetIndexVariableColumn(Resources.IF_TAG_PARSER);
                if (phyitm.PHYITM_ITEMNO == 0)                                      // 物理ＩＤ
                {
                    row.Cells[Index].Value = phyprs.PHYPRS_PHYID;
                }
                else
                {
                    row.Cells[Index].Value = string.Empty;
                }

                if(phyprs.PHYPRS_TAGNM != null)                                     // タグ名
                {
                    row.Cells[Index + 1].Value = phyprs.PHYPRS_TAGNM;
                }
                else
                {
                    row.Cells[Index + 1].Value = string.Empty;
                }
                                                                                    // Ｍパーサ物理属性
                if(phyitm.PHYITM_DTTYPE == null)
                {
                    phyitm.PHYITM_DTTYPE = string.Empty;
                }
                List<string> types = Common.IntefaceCommon.getItemToParseType(phyitm.PHYITM_DTTYPE);
                if (types.Contains(phyprs.PHYPRS_LTYPE))
                {
                    row.Cells[Index + 2].Value = phyprs.PHYPRS_LTYPE;
                }
                else
                {
                    row.Cells[Index + 2].Value = string.Empty;
                }
                if (phyprs.PHYPRS_CDCHG == "1")                                      // コード変換要
                {
                    row.Cells[Index + 3].Value = true;
                }
                else
                {
                    row.Cells[Index + 3].Value = false;
                }
                if (phyprs.PHYPRS_FLG == "1")                                       // 符号有無
                {
                    row.Cells[Index + 4].Value = true;
                }
                else
                {
                    row.Cells[Index + 4].Value = false;
                }
                                                                                    // 文字コード
                if (phyprs.PHYPRS_MCODE != null && phyprs.PHYPRS_MCODE != string.Empty)
                {
                    if (phyprs.PHYPRS_MCODE == "1")
                    {
                        row.Cells[Index + 5].Value = Resources.VALUE_SJIS;
                    }
                    else
                    {
                        row.Cells[Index + 5].Value = Resources.VALUE_UTF8;
                    }
                }
                else
                {
                    row.Cells[Index + 5].Value = string.Empty;
                }
            }
            int LogicIndex = this.DataGridView.GetIndexVariableColumn(Resources.IF_TAG_LOGICLAYOUT);
            for (int i = 0; i < logitm.Count; i++)
            {
                if (logitm[i] != null)
                {
                    row.Cells[LogicIndex + (7 * i)].Value = true;                        // 対象
                    if (phyitm.PHYITM_ITEMNO == 0)
                    {
                        row.Cells[LogicIndex + (7 * i) + 1].Value                        // 開始レベル
                                    = string.Format("{0:D2}",cpylog[i].CPYLGC_LEVNO); 
                    }
                    // Ｍパーサ論理属性
                    if (row.Cells[Index + 2].Value == null) row.Cells[Index + 2].Value = string.Empty;
                    List<string> types = Common.IntefaceCommon.getParseToParseType(row.Cells[Index + 2].Value as string);
                    if (types.Contains(logitm[i].LOGITM_TYPE))
                    {
                        row.Cells[LogicIndex + (7 * i) + 2].Value = logitm[i].LOGITM_TYPE;
                    }
                    else
                    {
                        row.Cells[LogicIndex + (7 * i) + 2].Value = string.Empty;
                    }
                                                                                    // Ｍパーサ論理サイズ
                    if (logitm[i].LOGITM_DATALEN > 0)
                    {
                        row.Cells[LogicIndex + (7 * i) + 3].Value                            
                                    = string.Format("{0:D}", logitm[i].LOGITM_DATALEN);
                    }
                    if (logitm[i].LOGITM_MCODE != null && logitm[i].LOGITM_MCODE != string.Empty)
                    {
                        if(logitm[i].LOGITM_MCODE == "1")
                        {
                            row.Cells[LogicIndex + (7 * i) + 4].Value = Resources.VALUE_SJIS;
                        }
                        else
                        {
                            row.Cells[LogicIndex + (7 * i) + 4].Value = Resources.VALUE_UTF8;
                        }
                    }
                    else
                    {
                        row.Cells[LogicIndex + (7 * i) + 4].Value = string.Empty;
                    }
                    row.Cells[LogicIndex + (7 * i) + 5].Value = logitm[i].LOGITM_PREFIX; // コピー句Ｐｒｅｆｉｘ
                    row.Cells[LogicIndex + (7 * i) + 6].Value = logitm[i].LOGITM_DTTYPE; // コピー句データ形式
                }
            }

            RowInfo rowInfo = new RowInfo
            {
                phyitm = phyitm,
                koho = koho,
                condition = condition,
                phyprs = phyprs,
                logitm = logitm
            };
            row.Tag = (object)rowInfo;
        }

        /// <summary>
        /// 論理設定条件情報の追加
        /// </summary>
        /// <param name="ConditionName">論理設定条件情報の名称</param>
        public void AddCondition(string ConditionName)
        {
            int Index = this.DataGridView.GetIndexVariableColumn(Resources.IF_TAG_REQUIREMENT);
            if (this.DataGridView.Columns[Index].HeaderText != string.Empty)
            {
                int Count = this.DataGridView.GetCountVariableColumn(Resources.IF_TAG_REQUIREMENT);
                this.DataGridView.InsertVariableColumn(Resources.IF_TAG_REQUIREMENT, 1, new GroupDataGridView.GroupCell(), Count - 1, 1);
                Index += Count;
                this.DataGridView.Columns[Index].HeaderText = ConditionName;
            }
            else
            {
                this.DataGridView.Columns[Index].HeaderText = ConditionName;
            }
        }

        /// <summary>
        /// 論理インタフェースの追加
        /// </summary>
        /// <param name="logicIfHeader"></param>
        public void AddLogicIf(LogicIfHeader logicIfHeader)
        {
            int Index = this.DataGridView.GetIndexVariableColumn(Resources.IF_TAG_LOGICLAYOUT);
            if (this.DataGridView.GetGroupCellText(Index, 3) != string.Empty)
            {
                //GroupCellの作成
                GroupDataGridView.GroupCell groupNameCell = new GroupDataGridView.GroupCell
                {
                    Text = logicIfHeader.OPNM,
                    Alignment = StringAlignment.Center,
                    LineAlignment = StringAlignment.Center,
                    BackColor = SystemColors.GradientActiveCaption,
                    Count = 7
                };
                GroupDataGridView.GroupCell groupIdCell = new GroupDataGridView.GroupCell
                {
                    Text = logicIfHeader.ID,
                    Alignment = StringAlignment.Center,
                    LineAlignment = StringAlignment.Center,
                    Count = 7
                };
                groupNameCell.ChildCells.Add(groupIdCell);
                this.DataGridView.InsertVariableColumn(Resources.IF_TAG_LOGICLAYOUT,
                                                        2,
                                                        groupNameCell,
                                                        this.DataGridView.GetCountVariableColumn(Resources.IF_TAG_LOGICLAYOUT) - 1,
                                                        7
                                                        );
            }
            else
            {
                this.DataGridView.RenameGroup(Index, 2, logicIfHeader.OPNM);
                this.DataGridView.RenameGroup(Index, 3, logicIfHeader.ID);
            }
        }

        /// <summary>
        /// 物理Ｍパーサ・レイアウト定義名称設定
        /// </summary>
        /// <param name="LayoutName"></param>
        public void setPhysicLayoutDef(string LayoutName)
        {
            int Index = this.DataGridView.GetIndexVariableColumn(Resources.IF_TAG_PARSER);
            this.DataGridView.RenameGroup(Index, 3, LayoutName);
        }

        /// <summary>
        /// ＤＢの内容をDataGridViewに反映
        /// </summary>
        /// <returns></returns>
        public bool setDataGridViewFromDB()
        {
            HeaderInfo headerInfo = new HeaderInfo();

            headerInfo.cpyphy = getPhysicCopyInfo();
            if (headerInfo.cpyphy == null) return false;
            List<T_PHYITM> listPhyitm = getPhysicItemInfo();
            if (listPhyitm == null) return false;
            headerInfo.conditionNames = getConditionName();
            if (headerInfo.conditionNames != null)
            {
                foreach(string nm in headerInfo.conditionNames)
                {
                    AddCondition(nm);
                }
            }
            headerInfo.logicIfHeader = getLogicHeader();
            if (headerInfo.logicIfHeader != null)
            {
                foreach (LogicIfHeader ll in headerInfo.logicIfHeader)
                {
                    AddLogicIf(ll);
                }
            }

            setPhysicLayoutDef(string.Empty);
            foreach (T_PHYITM phyitm in listPhyitm)
            {
                List<T_KOHO> koho = new List<T_KOHO>();
                if(phyitm.PHYITM_GROUP != null && phyitm.PHYITM_GROUP != string.Empty)
                {
                    koho = getKOHO(phyitm.PHYITM_GROUP);
                }
                List<T_CONDITION> condition = new List<T_CONDITION>();
                foreach (string nm in headerInfo.conditionNames)
                {
                    IQueryable<T_CONDITION> queryable = this.VersionModel.context.T_CONDITION.AsNoTracking().Where(r =>
                                                                                                                    r.COND_SUBSYSID == this.SubsystemuID && 
                                                                                                                    r.COND_INFOID == this.InfoID && 
                                                                                                                    r.COND_OPNM == nm && 
                                                                                                                    r.COND_SEQ == phyitm.PHYITM_SEQ).Take(1);
                    if (queryable.Count() == 1)
                    {
                        condition.Add(queryable.ToArray()[0]);
                    }
                    else
                    {
                        condition.Add(null);
                    }
                }
                T_PHYPRS_EF phyprs = this.VersionModel.context.T_PHYPRS.AsNoTracking().Where(r => 
                                                                                                r.PHYPRS_PHYSYSID == this.SubsystemuID && 
                                                                                                r.PHYPRS_INFOID == this.InfoID && 
                                                                                                r.PHYPRS_SUBSYSID == this.LogicSubsystem && 
                                                                                                r.PHYPRS_SEQ == phyitm.PHYITM_SEQ).SingleOrDefault();
                if(phyprs != null)
                {
                    setPhysicLayoutDef(phyprs.PHYPRS_LAYDEF);
                }

                headerInfo.cpylog = new List<T_CPYLOG>();
                List<T_LOGITM> logitm = new List<T_LOGITM>();
                foreach(LogicIfHeader ll in headerInfo.logicIfHeader)
                {
                    T_CPYLOG cpy = this.VersionModel.context.T_CPYLOG.AsNoTracking().Where(r =>
                                                                                            r.CPYLGC_PHYSYSID == this.SubsystemuID &&
                                                                                            r.CPYLGC_INFOID == this.InfoID &&
                                                                                            r.CPYLGC_SUBSYSID == this.LogicSubsystem &&
                                                                                            r.CPYLGC_LCPID == ll.ID).SingleOrDefault();
                   T_LOGITM itm = this.VersionModel.context.T_LOGITM.AsNoTracking().Where(r =>
                                                                                            r.LOGITM_SUBSYSIDL == this.LogicSubsystem &&
                                                                                            r.LOGITM_LCPID == ll.ID &&
                                                                                            r.LOGITM_SEQ == phyitm.PHYITM_SEQ).SingleOrDefault();
                    headerInfo.cpylog.Add(cpy);
                    logitm.Add(itm);
                }

                AddRow(headerInfo.cpyphy, phyitm, koho, condition, phyprs, headerInfo.cpylog, logitm);
            }
            this.DataGridView.Tag = headerInfo;
            return true;
        }

        /// <summary>
        /// DataGridViewの行から物理アイテム情報を取得する
        /// </summary>
        /// <param name="rowIndex">行</param>
        /// <returns></returns>
        public T_PHYITM getPHYITMformDataGridView(int rowIndex, bool autoSEQ)
        {
            int iNum;

            if (rowIndex >= this.DataGridView.RowCount) return null;

            T_PHYITM phyitm = new T_PHYITM();
            DataGridViewRow row = this.DataGridView.Rows[rowIndex];

            //  サブシステムＩＤ
            phyitm.PHYITM_SUBSYSID = this.SubsystemuID;
            //  情報部ＩＤ
            phyitm.PHYITM_INFOID = this.InfoID;
            //  パス
            phyitm.PHYITM_PATH = getPhysicPATH(rowIndex);
            //  項番
            phyitm.PHYITM_ITEMNO = rowIndex;
            // シーケンス
            if (row.Tag != null)
            {
                phyitm.PHYITM_SEQ = ((RowInfo)row.Tag).phyitm.PHYITM_SEQ;
            }
            else
            {
                if(autoSEQ)
                {
                    // 新しいシーケンスを設定する
                    phyitm.PHYITM_SEQ = this.VersionModel.genSequenceID("T_PHYITM");
                }
            }
            //  レベル
            if (int.TryParse(row.Cells[0].Value as string, out iNum))
            {
                phyitm.PHYITM_LEVEL = iNum;
            }
            //  アイテム記号名称
            phyitm.PHYITM_ITEMID = row.Cells[1].Value as string;
            //  アイテム名称
            phyitm.PHYITM_ITEMNM = row.Cells[2].Value as string;
            if(phyitm.PHYITM_ITEMNM != null && phyitm.PHYITM_ITEMNM == "予備")
            {
                phyitm.PHYITM_ITEMNM = "FILLER";
            }
            //  データ形式
            phyitm.PHYITM_DTTYPE = row.Cells[3].Value as string;
            //  データサイズ
            if (int.TryParse(row.Cells[4].Value as string, out iNum))
            {
                phyitm.PHYITM_DTLEN = iNum;
            }
            else
            {
                phyitm.PHYITM_DTLEN = 0;
            }
            //  繰返し数
            if (int.TryParse(row.Cells[5].Value as string, out iNum))
            {
                phyitm.PHYITM_OCCURS = iNum;
            }
            else
            {
                phyitm.PHYITM_OCCURS = 0;
            }

            //  アイテム内容
            phyitm.PHYITM_COMMENT = row.Cells[6].Value as string;
            //  記事
            phyitm.PHYITM_NOTE = row.Cells[9].Value as string;
            //  コピー句データ形式
            if(row.Cells[11].Tag != null)
            {
                string v = row.Cells[11].Value as string;
                string o = row.Cells[11].Tag as string;
                if (string.IsNullOrEmpty(v) == false　&& v.IndexOf("ADDRESS") == 0 && o.IndexOf("ADDRESS") == 0)
                {
                    if(v.IndexOf("(") >= 7)
                    {
                        if (CobolUtils.GetSize(v) > 0)
                        {
                            phyitm.PHYITM_CPYDTTYPE = v;
                        }
                        else
                        {
                            phyitm.PHYITM_CPYDTTYPE = o;
                        }
                    }
                    else
                    {
                        phyitm.PHYITM_CPYDTTYPE = o;
                    }
                }
                else
                {
                    phyitm.PHYITM_CPYDTTYPE = row.Cells[11].Value as string;
                }
            }
            else
            {
                phyitm.PHYITM_CPYDTTYPE = row.Cells[11].Value as string;
            }
            //  アイテムフラグ
            if (phyitm.PHYITM_DTTYPE == "GROUP")
            {
                phyitm.PHYITM_ITEMFLG = "1";
            }
            else
            {
                phyitm.PHYITM_ITEMFLG = "0";
            }
            //  候補値グループ名
            phyitm.PHYITM_GROUP = row.Cells[7].Value as string;
            //  イメージ名
            phyitm.PHYITM_IMAGENM = row.Cells[8].Value as string;
            //  イメージ
            if(phyitm.PHYITM_IMAGENM != null && phyitm.PHYITM_IMAGENM != string.Empty)
            {
                if (row.Cells[8].Tag != null)
                {
                    string filenm = row.Cells[8].Tag as string;
                    try
                    {
                        using (FileStream fsr = new FileStream(filenm, FileMode.Open, FileAccess.Read))
                        {
                            byte[] buf = new byte[(new FileInfo(filenm)).Length];
                            fsr.Read(buf, 0, buf.Length);
                            phyitm.PHYITM_IMAGE = buf;
                        }
                    }
                    catch
                    {
                        MessageBox.Show(string.Format("図表ファイルの読込に失敗しました\nfile={0}\n処理を続行します", filenm));
                        phyitm.PHYITM_IMAGE = null;
                    }
                }
                else
                {
                    if (row.Tag != null)
                    {
                        phyitm.PHYITM_IMAGE = ((RowInfo)row.Tag).phyitm.PHYITM_IMAGE;
                    }
                }
            }

            return phyitm;
        }

        /// <summary>
        /// DataGridViewの行から論理設定条件を取得する
        /// </summary>
        /// <param name="rowIndex">行</param>
        /// <param name="seq">該当する物理アイテム情報のシーケンス</param>
        /// <returns></returns>
        public List<T_CONDITION> getCONDITIONfromDataGridView(int rowIndex, string seq)
        {
            int Index = this.DataGridView.GetIndexVariableColumn(Resources.IF_TAG_REQUIREMENT);
            int Count = this.DataGridView.GetCountVariableColumn(Resources.IF_TAG_REQUIREMENT);

            List<T_CONDITION> condition = new List<T_CONDITION>();
            if (Count == 0) return condition;

            DataGridViewRow  row = this.DataGridView.Rows[rowIndex];
            for(int i = 0; i < Count; i++)
            {
                T_CONDITION conditionItem = new T_CONDITION
                {
                    COND_OPNM = this.DataGridView.Columns[Index + i].HeaderText,
                    COND_SEQ = seq,
                    COND_SUBSYSID = this.SubsystemuID,
                    COND_INFOID = this.InfoID,
                    COND_OUTPUTORDER = i
                };
                string value = row.Cells[Index + i].Value as string;
                if (value == null) value = string.Empty;
                conditionItem.COND_SETCOND = value;

                condition.Add(conditionItem);
            }

            return condition;
        }

        /// <summary>
        /// DataGridViewの行から物理Ｍパーサ情報を取得する
        /// </summary>
        /// <param name="rowIndex">行</param>
        /// <param name="seq">該当する物理アイテム情報のシーケンス</param>
        /// <returns></returns>
        public T_PHYPRS_EF getPHYPRSfromDataGridView(int rowIndex, string seq)
        {
            int Index = this.DataGridView.GetIndexVariableColumn(Resources.IF_TAG_PARSER);

            DataGridViewRow row = this.DataGridView.Rows[rowIndex];
            T_PHYPRS_EF phyprs = null;

            if (this.DataGridView.GetGroupCellText(Index, 3) != null && this.DataGridView.GetGroupCellText(Index, 3) != string.Empty)
            {
                phyprs = new T_PHYPRS_EF
                {
                    PHYPRS_PHYSYSID = this.SubsystemuID,
                    PHYPRS_INFOID = this.InfoID,
                    PHYPRS_SUBSYSID = this.LogicSubsystem,
                    PHYPRS_LAYDEF = this.DataGridView.GetGroupCellText(Index, 3),
                    PHYPRS_SEQ = seq
                };
                if (row.Cells[Index + 0].Value != null)
                {
                    phyprs.PHYPRS_PHYID = row.Cells[Index + 0].Value as string;
                }
                else
                {
                    phyprs.PHYPRS_PHYID = string.Empty;
                }
                if (row.Cells[Index + 1].Value != null)
                {
                    phyprs.PHYPRS_TAGNM = row.Cells[Index + 1].Value as string;
                }
                else
                {
                    phyprs.PHYPRS_TAGNM = string.Empty;
                }
                if (row.Cells[Index + 2].Value != null)
                {
                    phyprs.PHYPRS_LTYPE = row.Cells[Index + 2].Value as string;
                }
                else
                {
                    phyprs.PHYPRS_LTYPE = string.Empty;
                }
                if (row.Cells[Index + 3].Value != null && (bool)row.Cells[Index + 3].Value)
                {
                    phyprs.PHYPRS_CDCHG = "1";
                }
                else
                {
                    phyprs.PHYPRS_CDCHG = "0";
                }
                if (row.Cells[Index + 4].Value != null && (bool)row.Cells[Index + 4].Value)
                {
                    phyprs.PHYPRS_FLG = "1";
                }
                else
                {
                    phyprs.PHYPRS_FLG = "0";
                }
                if (row.Cells[Index + 5].Value as string == Resources.VALUE_SJIS)
                {
                    phyprs.PHYPRS_MCODE = "1";
                }
                else if(row.Cells[Index + 5].Value as string == Resources.VALUE_UTF8)
                {
                    phyprs.PHYPRS_MCODE = "2";
                }
                else
                {
                    phyprs.PHYPRS_MCODE = null;
                }
            }

            return phyprs;
        }

        /// <summary>
        /// DataGridViewから論理コピー句情報を取得する
        /// </summary>
        /// <returns></returns>
        public List<T_CPYLOG> getCPYLOGfromDataGridView()
        {
            return ((HeaderInfo)this.DataGridView.Tag).cpylog;
        }

        /// <summary>
        /// DataGridViewに論理コピー句情報を設定する
        /// </summary>
        /// <param name="list"></param>
        public void setCPYLOGtoDataGridView(List<T_CPYLOG> list)
        {
            ((HeaderInfo)this.DataGridView.Tag).cpylog = list;
        }

        /// <summary>
        /// ＤＢから論理アイテム情報を取得する
        /// </summary>
        /// <param name="LCPID"></param>
        /// <param name="seq"></param>
        /// <returns></returns>
        public T_LOGITM getLOGITMfromDB(string LCPID ,string seq)
        {
            T_LOGITM logitm = this.VersionModel.context.T_LOGITM.AsNoTracking().Where(r => r.LOGITM_LCPID == LCPID && r.LOGITM_SEQ == seq).SingleOrDefault();
            return logitm;
        }

        /// <summary>
        /// DataGridViewの行から論理アイテム情報を取得する
        /// </summary>
        /// <param name="rowIndex">行</param>
        /// <param name="seq">該当する物理アイテム情報のシーケンス</param>
        /// <returns></returns>
        public List<T_LOGITM> getLOGITMfromDataGridView(int rowIndex, string seq)
        {
            int Index = this.DataGridView.GetIndexVariableColumn(Resources.IF_TAG_LOGICLAYOUT);
            int Count = this.DataGridView.GetCountVariableColumn(Resources.IF_TAG_LOGICLAYOUT);

            DataGridViewRow row = this.DataGridView.Rows[rowIndex];
            List<T_LOGITM> list = new List<T_LOGITM>();
            for (int i = 0; i < Count; i += 7)
            {
                T_LOGITM logitm = null;
                if (row.Cells[Index + i].Value != null)
                {
                    if (row.Cells[Index + i].Value as string != string.Empty && (bool)row.Cells[Index + i].Value == true)
                    {
                        logitm = new T_LOGITM();
                        logitm.LOGITM_SUBSYSIDL = this.LogicSubsystem;
                        logitm.LOGITM_SEQ = seq;
                        logitm.LOGITM_LCPID = this.DataGridView.GetGroupCellText(Index + i, 3);
                        logitm.LOGITM_TYPE = row.Cells[Index + i + 2].Value as string;
                        if (logitm.LOGITM_TYPE == null) logitm.LOGITM_TYPE = string.Empty;
                        if (int.TryParse(row.Cells[Index + i + 3].Value as string, out int size))
                        {
                            logitm.LOGITM_DATALEN = size;
                        }
                        else
                        {
                            logitm.LOGITM_DATALEN = 0;
                        }
                        if(row.Cells[Index + i + 4].Value as string == Resources.VALUE_SJIS)
                        {
                            logitm.LOGITM_MCODE = "1";
                        }
                        else if(row.Cells[Index + i + 4].Value as string == Resources.VALUE_UTF8)
                        {
                            logitm.LOGITM_MCODE = "2";
                        }
                        else
                        {
                            logitm.LOGITM_MCODE = null;
                        }
                        logitm.LOGITM_PREFIX = row.Cells[Index + i + 5].Value as string;
                        if (logitm.LOGITM_PREFIX == null) logitm.LOGITM_PREFIX = string.Empty;
                        logitm.LOGITM_DTTYPE = row.Cells[Index + i + 6].Value as string;
                        if (logitm.LOGITM_DTTYPE == null) logitm.LOGITM_DTTYPE = string.Empty;
                    }
                }
                list.Add(logitm);
            }

            return list;
        }

        /// <summary>
        /// DataGridView から 論理設定条件 のヘッダ情報を取得
        /// </summary>
        /// <returns></returns>
        public List<String> getConditionNameFromDataGridView()
        {
            int Index = this.DataGridView.GetIndexVariableColumn(Resources.IF_TAG_REQUIREMENT);
            int Count = this.DataGridView.GetCountVariableColumn(Resources.IF_TAG_REQUIREMENT);

            List<String> list = new List<string>();
            for(int i = 0; i < Count; i++)
            {
                list.Add(this.DataGridView.Columns[Index + i].HeaderText);
            }
            return list;
        }

        /// <summary>
        /// DataGridView から 物理Ｍパーサ情報 のヘッダ情報を取得
        /// </summary>
        /// <returns></returns>
        public string getPhysicParserDefFormDataGridView()
        {
            int Index = this.DataGridView.GetIndexVariableColumn(Resources.IF_TAG_PARSER);
            return this.DataGridView.GetGroupCellText(Index, 3);
        }

        /// <summary>
        /// DataGridView から 論理インタフェース のヘッダ情報を取得
        /// </summary>
        /// <returns></returns>
        public List<LogicIfHeader> getLogicIfHeaderFormDataGridView()
        {
            int Index = this.DataGridView.GetIndexVariableColumn(Resources.IF_TAG_LOGICLAYOUT);
            int Count = this.DataGridView.GetCountVariableColumn(Resources.IF_TAG_LOGICLAYOUT);

            List<LogicIfHeader> list = new List<LogicIfHeader>();
            for (int i = 0; i < Count; i += 7)
            {
                LogicIfHeader li = new LogicIfHeader();
                li.OPNM = this.DataGridView.GetGroupCellText(Index + i, 2);
                li.ID = this.DataGridView.GetGroupCellText(Index + i, 3);
                list.Add(li);
            }
            return list;
        }

        public List<RowInfo> getRowInfosFromDB()
        {
            List<RowInfo> listRowInfo = new List<RowInfo>();
            List<T_PHYITM> listPHYITM = getPhysicItemInfo();
            List<T_CPYLOG> listCPYLOG = getLogicInterfaceInfo();
            foreach(T_PHYITM phyitm in listPHYITM)
            {
                RowInfo rowInfo = new RowInfo();
                rowInfo.phyitm = phyitm;
                rowInfo.koho = getKOHO(phyitm.PHYITM_GROUP);
                rowInfo.condition = getCondition(phyitm.PHYITM_SEQ);
                rowInfo.phyprs = getPHYPRS(phyitm.PHYITM_SEQ);
                rowInfo.logitm = new List<T_LOGITM>();
                foreach(T_CPYLOG cpylog in listCPYLOG)
                {
                    rowInfo.logitm.Add(getLOGITMfromDB(cpylog.CPYLGC_LCPID, phyitm.PHYITM_SEQ));
                }
                listRowInfo.Add(rowInfo);
            }
            return listRowInfo;
        }

        /// <summary>
        /// DataGridView から 行情報 のリストを取得
        /// </summary>
        /// <returns></returns>
        public List<RowInfo> getRowInfosFromDataGridView()
        {
            return getRowInfosFromDataGridView(true);
        }

        /// <summary>
        /// DataGridView から 行情報 のリストを取得
        /// </summary>
        /// <param name="autoSEQ">シーケンス自動取得</param>
        /// <returns></returns>
        public List<RowInfo> getRowInfosFromDataGridView(bool autoSEQ)
        {
            List<RowInfo> listRowInfo = new List<RowInfo>();
            for (int rowIndex = 0; rowIndex < this.DataGridView.RowCount; rowIndex++)
            {
                listRowInfo.Add(getRowInfoFormDataGridView(rowIndex));
            }
            return listRowInfo;
        }

        /// <summary>
        /// DataGridViewの行から行情報を取得
        /// </summary>
        /// <param name="rowIndex">行</param>
        /// <returns></returns>
        public RowInfo getRowInfoFormDataGridView(int rowIndex)
        {
            return getRowInfoFormDataGridView(rowIndex, true);
        }

        /// <summary>
        /// DataGridViewの行から行情報を取得
        /// </summary>
        /// <param name="rowIndex">行</param>
        /// <param name="autoSEQ">シーケンス自動取得</param>
        /// <returns></returns>
        public RowInfo getRowInfoFormDataGridView(int rowIndex, bool autoSEQ)
        {
            RowInfo rowInfo = new RowInfo();
            rowInfo.phyitm = getPHYITMformDataGridView(rowIndex, autoSEQ);
            if (this.DataGridView.Rows[rowIndex].Cells[7].Tag != null)
            {
                rowInfo.koho = this.DataGridView.Rows[rowIndex].Cells[7].Tag as List<T_KOHO>;
            }
            if (this.DataGridView.Rows[rowIndex].Cells[8].Tag != null)
            {
                rowInfo.PictureFilePath = this.DataGridView.Rows[rowIndex].Cells[8].Tag as string;
            }
            rowInfo.condition = getCONDITIONfromDataGridView(rowIndex, rowInfo.phyitm.PHYITM_SEQ);
            rowInfo.phyprs = getPHYPRSfromDataGridView(rowIndex, rowInfo.phyitm.PHYITM_SEQ);
            rowInfo.logitm = getLOGITMfromDataGridView(rowIndex, rowInfo.phyitm.PHYITM_SEQ);
            return rowInfo;
        }

        /// <summary>
        /// DataGridViewの行情報をDataGridViewの内容で更新
        /// </summary>
        /// <returns></returns>
        public bool UpdateRowInfoFromDataGridView()
        {
            List<RowInfo> listRowInfo = getRowInfosFromDataGridView();
            if (listRowInfo.Count != this.DataGridView.RowCount) return false;
            for(int Index = 0; Index < listRowInfo.Count; Index++)
            {
                listRowInfo[Index].PictureFilePath = string.Empty;
                this.DataGridView.Rows[Index].Tag = listRowInfo[Index];
                this.DataGridView.Rows[Index].Cells[8].Tag = null;
            }
            return true;
        }

        /// <summary>
        /// 最終更新情報取得
        /// </summary>
        /// <returns></returns>
        public LastUpdateUser getPhysicLastUpdateUser()
        {
            try
            {
                var chyphy = this.VersionModel.context.T_CPYPHY.AsNoTracking().First(r => r.CPYPHY_SUBSYSID == this.SubsystemuID && r.CPYPHY_INFOID == this.InfoID);
                LastUpdateUser last = new LastUpdateUser(chyphy.CPYPHY_USERID, chyphy.CPYPHY_UPDTIME);
                return last;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// 最終更新情報取得
        /// </summary>
        /// <returns></returns>
        public LastUpdateUser getLogicLastUpdateUser(string CopyID)
        {
            try
            {
                var cpylog = this.VersionModel.context.T_CPYLOG.AsNoTracking().First(r =>
                                                                        r.CPYLGC_PHYSYSID == this.SubsystemuID &&
                                                                        r.CPYLGC_INFOID == this.InfoID &&
                                                                        r.CPYLGC_SUBSYSID == this.LogicSubsystem &&
                                                                        r.CPYLGC_LCPID == CopyID);
                LastUpdateUser last = new LastUpdateUser(cpylog.CPYLGC_USERID, cpylog.CPYLGC_UPDTIME);
                return last;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// 行削除
        /// </summary>
        /// <param name="rows"></param>
        /// <returns></returns>
        public bool DeleteDB(T_CPYPHY cpyphy, List<RowInfo> rows)
        {
            string sql = string.Empty;
            try
            {
                if (rows == null || rows.Count == 0) return true;
                List<string> logicID = new List<string>();
                foreach (RowInfo row in rows)
                {
                    if (row == null || (row.phyitm.PHYITM_SEQ == null || row.phyitm.PHYITM_SEQ == string.Empty)) continue;

                    //物理アイテム情報
                    sql = "DELETE FROM t_phyitm" +
                            $" WHERE PHYITM_SUBSYSID='{row.phyitm.PHYITM_SUBSYSID}' AND" +
                                  $" PHYITM_INFOID='{row.phyitm.PHYITM_INFOID}' AND" +
                                  $" PHYITM_SEQ='{row.phyitm.PHYITM_SEQ}'";
                    this.VersionModel.context.Database.ExecuteSqlCommand(sql);

                    //紐付く論理設定条件情報
                    sql = "DELETE FROM t_condition" +
                            $" WHERE COND_SUBSYSID='{row.phyitm.PHYITM_SUBSYSID}' AND" +
                                  $" COND_INFOID='{row.phyitm.PHYITM_INFOID}' AND" +
                                  $" COND_SEQ='{row.phyitm.PHYITM_SEQ}'";
                    this.VersionModel.context.Database.ExecuteSqlCommand(sql);

                    //紐付く論理インタフェース（物理Ｍパーサ情報）
                    sql = "DELETE FROM t_phyprs" +
                            $" WHERE PHYPRS_PHYSYSID='{row.phyitm.PHYITM_SUBSYSID}' AND" +
                                    $" PHYPRS_INFOID='{row.phyitm.PHYITM_INFOID}' AND" +
                                    $" PHYPRS_SEQ='{row.phyitm.PHYITM_SEQ}'";
                    this.VersionModel.context.Database.ExecuteSqlCommand(sql);

                    //紐付く論理インタフェース（論理ＩＦ）
                    IQueryable<T_LOGITM> logitm = this.VersionModel.context.T_LOGITM.AsNoTracking().Where(r => r.LOGITM_SEQ == row.phyitm.PHYITM_SEQ);
                    if(logitm.Count() > 0)
                    {
                        foreach(T_LOGITM item in logitm)
                        {
                            if (logicID.Contains(item.LOGITM_LCPID) == false)
                            {
                                logicID.Add(item.LOGITM_LCPID);
                            }
                        }
                    }
                    sql = $"DELETE FROM t_logitm WHERE LOGITM_SEQ='{row.phyitm.PHYITM_SEQ}'";
                    this.VersionModel.context.Database.ExecuteSqlCommand(sql);
                }
                // 物理コピー句情報の更新
                WritePhysicHeaderDB(cpyphy);

                // 論理コピー句情報の更新
                foreach(string id in logicID)
                {
                    T_CPYLOG cpylog;

                    try
                    {
                        cpylog = this.VersionModel.context.T_CPYLOG.AsNoTracking().Single(r => r.CPYLGC_LCPID == id);
                    }
                    catch (Exception ex)
                    {
                        this.logger.Error(ex, Resources.IF_LOG_DBERROR);
                        return false;
                    }
                    sql = "UPDATE t_cpylog" +
                            $" SET CPYLGC_USERID='{this.VersionModel.User.USERID}'," +
                                $" CPYLGC_UPDTIME='{DateTime.Now.ToString()}'" +
                            $" WHERE CPYLGC_LCPID='{cpylog.CPYLGC_LCPID}'";
                    this.VersionModel.context.Database.ExecuteSqlCommand(sql);
                }
            }
            catch(Exception ex)
            {
                this.logger.Error(ex, string.Format(Resources.IF_LOG_SQL_E, sql));
                return false;
            }
            return true;
        }

        /// <summary>
        /// 物理コピー句情報書き込み
        /// </summary>
        /// <returns></returns>
        public bool WritePhysicHeaderDB(T_CPYPHY cpyphy)
        {
            string sql = string.Empty;
            cpyphy.CPYPHY_SIZE = getPhysicSize();
            try
            {
                sql = "UPDATE t_cpyphy" +
                            $" SET CPYPHY_COMMENT='{cpyphy.CPYPHY_COMMENT}'," +
                                $" CPYPHY_LEVNO={cpyphy.CPYPHY_LEVNO}," +
                                $" CPYPHY_SIZE={cpyphy.CPYPHY_SIZE}," +
                                $" CPYPHY_USERID='{this.VersionModel.User.USERID}'," +
                                $" CPYPHY_UPDTIME='{DateTime.Now.ToString()}'" +
                            $" WHERE CPYPHY_SUBSYSID='{this.SubsystemuID}' AND CPYPHY_INFOID='{this.InfoID}'";
                this.VersionModel.context.Database.ExecuteSqlCommand(sql);
            }
            catch(Exception ex)
            {
                this.logger.Error(ex, string.Format(Resources.IF_LOG_SQL_E, sql));
                return false;
            }
            return true;
        }

        /// <summary>
        /// 物理コピー句情報のステータスを変更する
        /// </summary>
        /// <param name="cpyphy"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        public bool WritePhysicHeaderDB(T_CPYPHY cpyphy, string status)
        {
            string sql = string.Empty;
            try
            {
                sql = "UPDATE t_cpyphy" +
                            $" SET CPYPHY_STATUS='{status}'," +
                                $" CPYPHY_USERID='{this.VersionModel.User.USERID}'," +
                                $" CPYPHY_UPDTIME='{DateTime.Now.ToString()}'" +
                            $" WHERE CPYPHY_SUBSYSID='{this.SubsystemuID}' AND CPYPHY_INFOID='{this.InfoID}'";
                this.VersionModel.context.Database.ExecuteSqlCommand(sql);
            }
            catch (Exception ex)
            {
                this.logger.Error(ex, string.Format(Resources.IF_LOG_SQL_E, sql));
                return false;
            }
            return true;
        }

        /// <summary>
        /// 論理コピー句情報書き込み
        /// </summary>
        /// <param name="cpylog"></param>
        /// <returns></returns>
        public bool WriteLogicHeaderDB(T_CPYLOG cpylog)
        {
            string sql = string.Empty;
            try
            {
                bool isFind = false;
                List<LogicIfHeader> ll = (this.DataGridView.Tag as HeaderInfo).logicIfHeader;
                for(int Index = 0; Index < ll.Count; Index ++)
                {
                    if(ll[Index].ID == cpylog.CPYLGC_LCPID)
                    {
                        isFind = true;
                        //更新
                        sql = "UPDATE t_cpylog" +
                                    $" SET CPYLGC_OPNM='{cpylog.CPYLGC_OPNM}'," +
                                        $" CPYLGC_OUTPUTORDER={cpylog.CPYLGC_OUTPUTORDER}," +
                                        $" CPYLGC_LEVNO={cpylog.CPYLGC_LEVNO}," +
                                        $" CPYLGC_COMMENT='{cpylog.CPYLGC_COMMENT}'," +
                                        $" CPYLGC_USERID='{this.VersionModel.User.USERID}'," +
                                        $" CPYLGC_UPDTIME='{DateTime.Now.ToString()}'" +
                                    $" WHERE CPYLGC_PHYSYSID='{this.SubsystemuID}' AND" +
                                            $" CPYLGC_INFOID='{this.InfoID}' AND" +
                                            $" CPYLGC_SUBSYSID='{this.LogicSubsystem}' AND" +
                                            $" CPYLGC_LCPID='{cpylog.CPYLGC_LCPID}'";
                        this.VersionModel.context.Database.ExecuteSqlCommand(sql);
                    }
                }
                if(isFind == false)
                {
                    //既に同一論理コピー句が無いか検定する
                    int count = this.VersionModel.context.T_CPYLOG.AsNoTracking().Where(r => r.CPYLGC_LCPID == cpylog.CPYLGC_LCPID).Count();
                    if(count == 0)
                    {
                        //追加
                        sql = "INSERT INTO t_cpylog(" +
                                            " CPYLGC_PHYSYSID," +
                                            " CPYLGC_INFOID," +
                                            " CPYLGC_SUBSYSID," +
                                            " CPYLGC_LCPID," +
                                            " CPYLGC_OPNM," +
                                            " CPYLGC_OUTPUTORDER," +
                                            " CPYLGC_LEVNO," +
                                            " CPYLGC_COMMENT," +
                                            " CPYLGC_USERID," +
                                            " CPYLGC_UPDTIME" +
                                            " )" +
                                            "VALUES(" +
                                            $"'{cpylog.CPYLGC_PHYSYSID}'," +
                                            $"'{cpylog.CPYLGC_INFOID}'," +
                                            $"'{cpylog.CPYLGC_SUBSYSID}'," +
                                            $"'{cpylog.CPYLGC_LCPID}'," +
                                            $"'{cpylog.CPYLGC_OPNM}'," +
                                            $"{cpylog.CPYLGC_OUTPUTORDER}," +
                                            $"{cpylog.CPYLGC_LEVNO}," +
                                            $"'{cpylog.CPYLGC_COMMENT}'," +
                                            $"'{this.VersionModel.User.USERID}'," +
                                            $"'{DateTime.Now.ToString()}'" +
                                            " )";
                        this.VersionModel.context.Database.ExecuteSqlCommand(sql);
                    }
                    else
                    {
                        this.logger.Error(string.Format(Resources.IF_LOG_LOGIC_ISID_E, cpylog.CPYLGC_LCPID));
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                this.logger.Error(ex, string.Format(Resources.IF_LOG_SQL_E, sql));
                return false;
            }
            return true;
        }

        /// <summary>
        /// 論理コピー句情報の削除
        /// </summary>
        /// <param name="LCPID">論理コピー句ＩＤ</param>
        /// <returns></returns>
        public bool deleteLogicHeaderDB(string LCPID)
        {
            string sql = string.Empty;
            try
            {
                sql = "DELETE FROM t_cpylog" +
                                $" WHERE CPYLGC_PHYSYSID='{this.SubsystemuID}' AND" +
                                        $" CPYLGC_INFOID='{this.InfoID}' AND" +
                                        $" CPYLGC_SUBSYSID='{this.LogicSubsystem}' AND" +
                                        $" CPYLGC_LCPID='{LCPID}'";
                this.VersionModel.context.Database.ExecuteSqlCommand(sql);
            }
            catch (Exception ex)
            {
                this.logger.Error(ex, string.Format(Resources.IF_LOG_SQL_E, sql));
                return false;
            }
            return true;
        }

        public UpdateInfo getUpdateInfo()
        {
            UpdateInfo updateInfo = new UpdateInfo
            {
                updateLCPID = new List<string>(),
                deleteLCPID = new List<string>()
            };

            //論理コピー句情報の更新チェック
            List<T_CPYLOG> listCLEDT = getCPYLOGfromDataGridView();
            List<T_CPYLOG> listCLORI = getLogicInterfaceInfo();
            for(int i = 0; i < listCLEDT.Count; i++)
            {
                if(i < listCLORI.Count)
                {
                    if (listCLEDT[i].CPYLGC_LCPID != listCLORI[i].CPYLGC_LCPID ||
                       listCLEDT[i].CPYLGC_LEVNO != listCLORI[i].CPYLGC_LEVNO ||
                       listCLEDT[i].CPYLGC_OPNM != listCLORI[i].CPYLGC_OPNM ||
                       listCLEDT[i].CPYLGC_OUTPUTORDER != listCLORI[i].CPYLGC_OUTPUTORDER ||
                       listCLEDT[i].CPYLGC_COMMENT != listCLORI[i].CPYLGC_COMMENT)
                    {
                        if (updateInfo.updateLCPID.Contains(listCLEDT[i].CPYLGC_LCPID) == false)
                        {
                            updateInfo.updateLCPID.Add(listCLEDT[i].CPYLGC_LCPID);
                        }
                    }
                }
                else
                {
                    if (updateInfo.updateLCPID.Contains(listCLEDT[i].CPYLGC_LCPID) == false)
                    {
                        updateInfo.updateLCPID.Add(listCLEDT[i].CPYLGC_LCPID);
                    }
                }
            }
            for(int i = 0; i < listCLORI.Count; i++)
            {
                bool find = false;
                foreach(T_CPYLOG cpylog in listCLEDT)
                {
                    if (listCLORI[i].CPYLGC_LCPID == cpylog.CPYLGC_LCPID)
                    {
                        find = true;
                        break;
                    }
                }
                if(find == false)
                {
                    updateInfo.deleteLCPID.Add(listCLORI[i].CPYLGC_LCPID);
                }
            }


            try
            {
                for (int rowIndex = 0; rowIndex < this.DataGridView.Rows.Count; rowIndex++)
                {
                    DataGridViewRow row = this.DataGridView.Rows[rowIndex];
                    RowInfo rowInfo = getRowInfoFormDataGridView(rowIndex);
                    if (row.Tag == null) // 追加行
                    {
                        updateInfo.CPYPHY = true;
                        foreach (T_LOGITM logitm in rowInfo.logitm)
                        {
                            if(logitm != null)
                            {
                                if (updateInfo.updateLCPID.Contains(logitm.LOGITM_LCPID) == false)
                                {
                                    updateInfo.updateLCPID.Add(logitm.LOGITM_LCPID);
                                }
                            }
                        }
                    }
                    else
                    {
                        RowInfo origin = row.Tag as RowInfo;
                        bool update = false;
                        #region 物理アイテム情報の更新
                        //変更されているか検定し、変更項目のみを更新する
                        if (origin.phyitm.PHYITM_PATH != rowInfo.phyitm.PHYITM_PATH)                    // パス
                        {
                            update = true;
                        }
                        if (origin.phyitm.PHYITM_ITEMNO != rowInfo.phyitm.PHYITM_ITEMNO)                // 項番
                        {
                            update = true;
                        }
                        if (origin.phyitm.PHYITM_LEVEL != rowInfo.phyitm.PHYITM_LEVEL)                  // レベル
                        {
                            update = true;
                        }
                                                                                                        // アイテム記号名称
                        if ((origin.phyitm.PHYITM_ITEMID != rowInfo.phyitm.PHYITM_ITEMID) &&
                            !(string.IsNullOrEmpty(origin.phyitm.PHYITM_ITEMID) && string.IsNullOrEmpty(rowInfo.phyitm.PHYITM_ITEMID)))
                        {
                            update = true;
                        }
                        if ((origin.phyitm.PHYITM_ITEMNM != rowInfo.phyitm.PHYITM_ITEMNM) &&             // アイテム名称
                            !(string.IsNullOrEmpty(origin.phyitm.PHYITM_ITEMNM) && string.IsNullOrEmpty(rowInfo.phyitm.PHYITM_ITEMNM)))
                        {
                            update = true;
                        }
                        if ((origin.phyitm.PHYITM_DTTYPE != rowInfo.phyitm.PHYITM_DTTYPE) &&             // データ形式
                            !(string.IsNullOrEmpty(origin.phyitm.PHYITM_DTTYPE) && string.IsNullOrEmpty(rowInfo.phyitm.PHYITM_DTTYPE)))
                        {
                            update = true;
                        }
                        if ((origin.phyitm.PHYITM_DTLEN != rowInfo.phyitm.PHYITM_DTLEN) &&               // データサイズ
                            !((origin.phyitm.PHYITM_DTLEN == null || origin.phyitm.PHYITM_DTLEN == 0) &&
                               (rowInfo.phyitm.PHYITM_DTLEN == null || rowInfo.phyitm.PHYITM_DTLEN == 0)))
                        {
                            update = true;
                        }
                        if ((origin.phyitm.PHYITM_OCCURS != rowInfo.phyitm.PHYITM_OCCURS) &&               // 繰返し回数
                            !((origin.phyitm.PHYITM_OCCURS == null || origin.phyitm.PHYITM_OCCURS == 0) &&
                               (rowInfo.phyitm.PHYITM_OCCURS == null || rowInfo.phyitm.PHYITM_OCCURS == 0)))
                        {
                            update = true;
                        }
                        if ((origin.phyitm.PHYITM_COMMENT != rowInfo.phyitm.PHYITM_COMMENT) &&          // アイテム内容
                            !(string.IsNullOrEmpty(origin.phyitm.PHYITM_COMMENT) && string.IsNullOrEmpty(rowInfo.phyitm.PHYITM_COMMENT)))
                        {
                            update = true;
                        }
                        if ((origin.phyitm.PHYITM_NOTE != rowInfo.phyitm.PHYITM_NOTE) &&                // 記事
                            !(string.IsNullOrEmpty(origin.phyitm.PHYITM_NOTE) && string.IsNullOrEmpty(rowInfo.phyitm.PHYITM_NOTE)))
                        {
                            update = true;
                        }
                        if ((origin.phyitm.PHYITM_CPYDTTYPE != rowInfo.phyitm.PHYITM_CPYDTTYPE) &&      // コピー句データ形式
                            !(string.IsNullOrEmpty(origin.phyitm.PHYITM_CPYDTTYPE) && string.IsNullOrEmpty(rowInfo.phyitm.PHYITM_CPYDTTYPE)))
                        {
                            update = true;
                        }
                        if ((origin.phyitm.PHYITM_ITEMFLG != rowInfo.phyitm.PHYITM_ITEMFLG) &&          // アイテムフラグ
                            !(string.IsNullOrEmpty(origin.phyitm.PHYITM_ITEMFLG) && string.IsNullOrEmpty(rowInfo.phyitm.PHYITM_ITEMFLG)))
                        {
                            update = true;
                        }
                        if ((origin.phyitm.PHYITM_GROUP != rowInfo.phyitm.PHYITM_GROUP) &&              // 候補値グループ名
                            !(string.IsNullOrEmpty(origin.phyitm.PHYITM_GROUP) && string.IsNullOrEmpty(rowInfo.phyitm.PHYITM_GROUP)))
                        {
                            update = true;
                        }
                        if ((origin.phyitm.PHYITM_IMAGENM != rowInfo.phyitm.PHYITM_IMAGENM) &&          // イメージ名
                            !(string.IsNullOrEmpty(origin.phyitm.PHYITM_IMAGENM) && string.IsNullOrEmpty(rowInfo.phyitm.PHYITM_IMAGENM)))
                        {
                            update = true;
                        }
                        if (ToHex(origin.phyitm.PHYITM_IMAGE) != ToHex(rowInfo.phyitm.PHYITM_IMAGE))    // イメージ
                        {
                            update = true;
                        }

                        if (update == true)
                        {
                            updateInfo.CPYPHY = true;
                        }
                        #endregion
                        #region 論理設定条件情報
                        foreach (T_CONDITION condition in rowInfo.condition)
                        {
                            bool find = false;
                            foreach (T_CONDITION ori in origin.condition)
                            {
                                if (ori != null && condition.COND_OPNM == ori.COND_OPNM)
                                {
                                    find = true;
                                    update = false;
                                    //更新された項目のみ更新する
                                    if (ori.COND_OUTPUTORDER != condition.COND_OUTPUTORDER)
                                    {
                                        update = true;
                                    }
                                    if ((ori.COND_SETCOND != condition.COND_SETCOND) &&
                                        !(string.IsNullOrEmpty(ori.COND_SETCOND) && string.IsNullOrEmpty(condition.COND_SETCOND)))
                                    {
                                        update = true;
                                    }
                                    if (update == true)
                                    {
                                        updateInfo.CPYPHY = true;
                                    }
                                    break;
                                }
                            }
                            if (find == false)
                            {
                                //追加
                                if (condition.COND_SETCOND != null && condition.COND_SETCOND != string.Empty)
                                {
                                    updateInfo.CPYPHY = true;
                                }
                            }
                        }
                        //削除
                        foreach (T_CONDITION delTarget in origin.condition)
                        {
                            bool find = false;
                            foreach (T_CONDITION condition in rowInfo.condition)
                            {
                                if (delTarget != null && delTarget.COND_OPNM == condition.COND_OPNM)
                                {
                                    find = true;
                                    break;
                                }
                            }
                            if (delTarget != null && find == false)
                            {
                                updateInfo.CPYPHY = true;
                            }
                        }
                        #endregion
                        #region 物理Ｍパーサ情報
                        if (rowInfo.phyprs != null)
                        {
                            if (origin.phyprs == null)
                            {
                                //新規追加
                                if (string.IsNullOrEmpty(rowInfo.phyprs.PHYPRS_LAYDEF) == false)
                                {
                                    updateInfo.PHYPRS = true;
                                }
                            }
                            else
                            {
                                if (string.IsNullOrEmpty(rowInfo.phyprs.PHYPRS_LAYDEF) == false)
                                {
                                    //更新
                                    update = false;
                                    if (origin.phyprs.PHYPRS_LAYDEF != rowInfo.phyprs.PHYPRS_LAYDEF)   // レイアウト定義
                                    {
                                        update = true;
                                    }
                                    if (origin.phyprs.PHYPRS_PHYID != rowInfo.phyprs.PHYPRS_PHYID)   // 物理ＩＤ
                                    {
                                        update = true;
                                    }
                                    if (origin.phyprs.PHYPRS_TAGNM != rowInfo.phyprs.PHYPRS_TAGNM)   // 物理タグ名
                                    {
                                        update = true;
                                    }
                                    if (origin.phyprs.PHYPRS_LTYPE != rowInfo.phyprs.PHYPRS_LTYPE)   // 物理属性
                                    {
                                        update = true;
                                    }
                                    if (origin.phyprs.PHYPRS_CDCHG != rowInfo.phyprs.PHYPRS_CDCHG)   // コード変換要
                                    {
                                        update = true;
                                    }
                                    if (origin.phyprs.PHYPRS_FLG != rowInfo.phyprs.PHYPRS_FLG)      // 符号有無
                                    {
                                        update = true;
                                    }
                                    if (origin.phyprs.PHYPRS_MCODE != rowInfo.phyprs.PHYPRS_MCODE)   // 文字コード
                                    {
                                        update = true;
                                    }
                                    if (update == true)
                                    {
                                        updateInfo.PHYPRS = true;
                                    }
                                }
                                else
                                {
                                    //削除
                                    updateInfo.PHYPRS = true;
                                }
                            }
                        }
                        else
                        {
                            if (origin.phyprs != null)
                            {
                                //削除
                                updateInfo.PHYPRS = true;
                            }
                        }
                        #endregion
                        #region 論理アイテム情報
                        foreach (T_LOGITM logitm in rowInfo.logitm)
                        {
                            if (logitm != null)
                            {
                                bool find = false;
                                update = false;
                                int i = 0;
                                foreach (T_LOGITM ori in origin.logitm)
                                {
                                    if (ori != null && ori.LOGITM_LCPID == logitm.LOGITM_LCPID)
                                    {
                                        find = true;
                                        if ((ori.LOGITM_TYPE != logitm.LOGITM_TYPE) &&                 // 論理属性
                                            !(string.IsNullOrEmpty(ori.LOGITM_TYPE) && string.IsNullOrEmpty(logitm.LOGITM_TYPE)))
                                        {
                                            update = true;
                                        }
                                        if ((ori.LOGITM_DATALEN != logitm.LOGITM_DATALEN) &&          // 論理サイズ
                                            !((ori.LOGITM_DATALEN == null || ori.LOGITM_DATALEN == 0) &&
                                              (logitm.LOGITM_DATALEN == null || logitm.LOGITM_DATALEN == 0)))
                                        {
                                            update = true;
                                        }
                                        if ((ori.LOGITM_MCODE != logitm.LOGITM_MCODE) &&               // 文字コード
                                            !(string.IsNullOrEmpty(ori.LOGITM_MCODE) && string.IsNullOrEmpty(logitm.LOGITM_MCODE)))
                                        {
                                            update = true;
                                        }
                                        if ((ori.LOGITM_PREFIX != logitm.LOGITM_PREFIX) &&            // コピー句Ｐｒｅｆｉｘ
                                            !(string.IsNullOrEmpty(ori.LOGITM_PREFIX) && string.IsNullOrEmpty(logitm.LOGITM_PREFIX)))
                                        {
                                            update = true;
                                        }
                                        if ((ori.LOGITM_DTTYPE != logitm.LOGITM_DTTYPE) &&            // コピー句データ形式
                                            !(string.IsNullOrEmpty(ori.LOGITM_DTTYPE) && string.IsNullOrEmpty(logitm.LOGITM_DTTYPE)))
                                        {
                                            update = true;
                                        }
                                        if (update)
                                        {
                                            if (updateInfo.updateLCPID.Contains(logitm.LOGITM_LCPID) == false)
                                            {
                                                updateInfo.updateLCPID.Add(logitm.LOGITM_LCPID);
                                            }
                                        }
                                        break;
                                    }
                                }
                                if (find == false)    // 追加
                                {
                                    if (updateInfo.updateLCPID.Contains(logitm.LOGITM_LCPID) == false)
                                    {
                                        updateInfo.updateLCPID.Add(logitm.LOGITM_LCPID);
                                    }
                                }
                                i++;
                            }
                        }
                        //削除
                        foreach (T_LOGITM delTarget in origin.logitm)
                        {
                            if (delTarget != null)
                            {
                                bool find = false;
                                foreach (T_LOGITM logitm in rowInfo.logitm)
                                {
                                    if (logitm != null && delTarget.LOGITM_LCPID == logitm.LOGITM_LCPID)
                                    {
                                        find = true;
                                        break;
                                    }
                                }
                                if (find == false)
                                {
                                    if (updateInfo.updateLCPID.Contains(delTarget.LOGITM_LCPID) == false)
                                    {
                                        updateInfo.updateLCPID.Add(delTarget.LOGITM_LCPID);
                                    }
                                }
                            }
                        }
                        #endregion
                    }
                }
            }
            catch (Exception)
            {
                updateInfo.Result = false;
                return updateInfo;
            }
            updateInfo.Result = true;
            return updateInfo;
        }

        /// <summary>
        /// 行情報をＤＢに書き込み
        /// </summary>
        /// <returns></returns>
        public bool WriteRowDB()
        {
            string sql = string.Empty;
            int topLevel = 0;
            try
            {
                int rowIndex = 0;
                Dictionary<int, RowInfo> dicRowInfo = new Dictionary<int, RowInfo>();   // 主キーチェック用
                Dictionary<int, RowInfo> dicUpdate = new Dictionary<int, RowInfo>();
                //更新対象リストの作成
                foreach (DataGridViewRow row in this.DataGridView.Rows)
                {
                    if (row.Tag != null)
                    {
                        RowInfo ri = row.Tag as RowInfo;
                        dicRowInfo.Add(ri.phyitm.PHYITM_ITEMNO, ri);
                    }
                    RowInfo rowInfo = getRowInfoFormDataGridView(row.Index);
                    dicUpdate.Add(rowInfo.phyitm.PHYITM_ITEMNO, rowInfo);
                    if (rowIndex == 0)
                    {
                        topLevel = (int)rowInfo.phyitm.PHYITM_LEVEL;
                    }
                    rowIndex++;
                }

                rowIndex = 0;
                while (true)
                {
                    bool flag = false;
                    DataGridViewRow row = this.DataGridView.Rows[rowIndex];
                    RowInfo rowInfo = getRowInfoFormDataGridView(rowIndex);
                    RowInfo origin = null;
                    if (dicUpdate.Keys.Contains(rowInfo.phyitm.PHYITM_ITEMNO))  // 未更新のデータか？
                    {
                        if (row.Tag != null)
                        {
                            origin = row.Tag as RowInfo;
                            if (origin.phyitm.PHYITM_ITEMNO == rowInfo.phyitm.PHYITM_ITEMNO)    // 主キーは変更なしか？
                            {
                                flag = true;
                                dicUpdate.Remove(rowInfo.phyitm.PHYITM_ITEMNO); //更新するので更新対象リストから削除
                            }
                            else
                            {
                                if (dicRowInfo.Keys.Contains(rowInfo.phyitm.PHYITM_ITEMNO) == false)    // 主キーが被らないか？
                                {
                                    flag = true;
                                    // 主キーを更新後のキーに差し替える
                                    dicRowInfo.Remove(origin.phyitm.PHYITM_ITEMNO);
                                    dicRowInfo.Add(rowInfo.phyitm.PHYITM_ITEMNO, rowInfo);
                                    dicUpdate.Remove(rowInfo.phyitm.PHYITM_ITEMNO); //更新するので更新対象リストから削除
                                }
                            }
                        }
                        else
                        {
                            if (dicRowInfo.Keys.Contains(rowInfo.phyitm.PHYITM_ITEMNO) == false)     // 主キーが被らないか？
                            {
                                flag = true;
                                dicRowInfo.Add(rowInfo.phyitm.PHYITM_ITEMNO, rowInfo);
                                dicUpdate.Remove(rowInfo.phyitm.PHYITM_ITEMNO); //追加するので更新対象リストから削除
                            }
                        }
                    }

                    if (flag)
                    {
                        //レベル番号の補正
                        rowInfo.phyitm.PHYITM_LEVEL = rowInfo.phyitm.PHYITM_LEVEL - topLevel + 1;
                        if (row.Tag == null) // 追加行
                        {
                            List<string> listInsert = new List<string>();
                            List<string> listValues = new List<string>();
                            StringBuilder sbInsert = new StringBuilder();
                            #region 物理コピー句情報
                            if (rowInfo.phyitm.PHYITM_GROUP != null && rowInfo.phyitm.PHYITM_GROUP != string.Empty)
                            {
                                listInsert.Add(" PHYITM_GROUP");
                                listValues.Add($"'{rowInfo.phyitm.PHYITM_GROUP}'");
                            }
                            if (rowInfo.phyitm.PHYITM_IMAGENM != null && rowInfo.phyitm.PHYITM_IMAGENM != string.Empty)
                            {
                                listInsert.Add(" PHYITM_IMAGENM");
                                listValues.Add($"'{rowInfo.phyitm.PHYITM_IMAGENM}'");
                            }
                            if (rowInfo.phyitm.PHYITM_IMAGE != null)    // イメージ
                            {
                                listInsert.Add(" PHYITM_IMAGE");
                                listValues.Add($"unhex('{ToHex(rowInfo.phyitm.PHYITM_IMAGE)}')");
                            }

                            sbInsert.Append("INSERT INTO t_phyitm(" +
                                                    " PHYITM_SUBSYSID," +
                                                    " PHYITM_INFOID," +
                                                    " PHYITM_PATH," +
                                                    " PHYITM_ITEMNO," +
                                                    " PHYITM_SEQ," +
                                                    " PHYITM_LEVEL," +
                                                    " PHYITM_ITEMID," +
                                                    " PHYITM_ITEMNM," +
                                                    " PHYITM_DTTYPE," +
                                                    " PHYITM_DTLEN," +
                                                    " PHYITM_OCCURS," +
                                                    " PHYITM_COMMENT," +
                                                    " PHYITM_NOTE," +
                                                    " PHYITM_CPYDTTYPE," +
                                                    " PHYITM_ITEMFLG");
                            foreach(string s in listInsert)
                            {
                                sbInsert.Append(", " + s);
                            }
                            sbInsert.Append(" ) VALUES(" +
                                                 $"'{rowInfo.phyitm.PHYITM_SUBSYSID}'," +
                                                 $"'{rowInfo.phyitm.PHYITM_INFOID}'," +
                                                 $"'{rowInfo.phyitm.PHYITM_PATH}'," +
                                                  $"{rowInfo.phyitm.PHYITM_ITEMNO}," +
                                                 $"'{rowInfo.phyitm.PHYITM_SEQ}'," +
                                                  $"{rowInfo.phyitm.PHYITM_LEVEL}," +
                                                 $"'{rowInfo.phyitm.PHYITM_ITEMID}'," +
                                                 $"'{rowInfo.phyitm.PHYITM_ITEMNM}'," +
                                                 $"'{rowInfo.phyitm.PHYITM_DTTYPE}'," +
                                                  $"{rowInfo.phyitm.PHYITM_DTLEN}," +
                                                  $"{rowInfo.phyitm.PHYITM_OCCURS}," +
                                                 $"'{rowInfo.phyitm.PHYITM_COMMENT}'," +
                                                 $"'{rowInfo.phyitm.PHYITM_NOTE}'," +
                                                 $"'{rowInfo.phyitm.PHYITM_CPYDTTYPE}'," +
                                                 $"'{rowInfo.phyitm.PHYITM_ITEMFLG}'");
                            foreach (string s in listValues)
                            {
                                sbInsert.Append(", " + s);
                            }
                            sbInsert.Append(" )");
                            sql = sbInsert.ToString();
                            this.VersionModel.context.Database.ExecuteSqlCommand(sql);
                            #endregion
                            #region 論理設定条件情報
                            foreach (T_CONDITION condition in rowInfo.condition)
                            {
                                if(condition.COND_SETCOND != null && condition.COND_SETCOND != string.Empty)
                                {
                                    sql = "INSERT INTO t_condition(" +
                                                            " COND_SUBSYSID," +
                                                            " COND_INFOID," +
                                                            " COND_OPNM," +
                                                            " COND_SEQ," +
                                                            " COND_OUTPUTORDER," +
                                                            " COND_SETCOND," +
                                                            " )" +
                                                         "VALUES(" +
                                                         $"'{condition.COND_SUBSYSID}'," +
                                                         $"'{condition.COND_INFOID}'," +
                                                         $"'{condition.COND_OPNM}'," +
                                                         $"'{condition.COND_SEQ}'," +
                                                         $"{condition.COND_OUTPUTORDER}," +
                                                         $"'{condition.COND_SETCOND}'," +
                                                         " )";
                                    this.VersionModel.context.Database.ExecuteSqlCommand(sql);
                                }
                            }
                            #endregion
                            #region 物理Ｍパーサ情報
                            if (rowInfo.phyprs != null && 
                                (rowInfo.phyprs.PHYPRS_LAYDEF != null && rowInfo.phyprs.PHYPRS_LAYDEF != string.Empty))
                            {
                                sql = "INSERT INTO t_phyprs(" +
                                                        " PHYPRS_PHYSYSID," +
                                                        " PHYPRS_INFOID," +
                                                        " PHYPRS_SUBSYSID," +
                                                        " PHYPRS_PHYID," +
                                                        " PHYPRS_LAYDEF," +
                                                        " PHYPRS_SEQ," +
                                                        " PHYPRS_TAGNM," +
                                                        " PHYPRS_LTYPE," +
                                                        " PHYPRS_CDCHG," +
                                                        " PHYPRS_FLG," +
                                                        " PHYPRS_MCODE," +
                                                        " PHYPRS_USERID," +
                                                        " PHYPRS_UPDTIME" +
                                                        " )" +
                                                     "VALUES(" +
                                                     $"'{rowInfo.phyprs.PHYPRS_PHYSYSID}'," +
                                                     $"'{rowInfo.phyprs.PHYPRS_INFOID}'," +
                                                     $"'{rowInfo.phyprs.PHYPRS_SUBSYSID}'," +
                                                     $"'{rowInfo.phyprs.PHYPRS_PHYID}'," +
                                                     $"'{rowInfo.phyprs.PHYPRS_LAYDEF}'," +
                                                     $"'{rowInfo.phyprs.PHYPRS_SEQ}'," +
                                                     $"'{rowInfo.phyprs.PHYPRS_TAGNM}'," +
                                                     $"'{rowInfo.phyprs.PHYPRS_LTYPE}'," +
                                                     $"'{rowInfo.phyprs.PHYPRS_CDCHG}'," +
                                                     $"'{rowInfo.phyprs.PHYPRS_FLG}'," +
                                                     $"'{rowInfo.phyprs.PHYPRS_MCODE}'" +
                                                     $"'{rowInfo.phyprs.PHYPRS_MCODE}'," +
                                                     $"'{this.VersionModel.User.USERID}'," +
                                                     $"'{DateTime.Now.ToString()}'" +
                                                     " )";
                                this.VersionModel.context.Database.ExecuteSqlCommand(sql);
                            }
                            #endregion
                            #region 論理アイテム情報
                            foreach(T_LOGITM logitm in rowInfo.logitm)
                            {
                                if(logitm != null)
                                {
                                    sql = "INSERT INTO t_logitm(" +
                                                            " LOGITM_SUBSYSIDL," +
                                                            " LOGITM_LCPID," +
                                                            " LOGITM_SEQ," +
                                                            " LOGITM_TYPE," +
                                                            " LOGITM_DATALEN," +
                                                            " LOGITM_MCODE," +
                                                            " LOGITM_PREFIX," +
                                                            " LOGITM_DTTYPE" +
                                                            " )" +
                                                         "VALUES(" +
                                                         $"'{logitm.LOGITM_SUBSYSIDL}'," +
                                                         $"'{logitm.LOGITM_LCPID}'," +
                                                         $"'{logitm.LOGITM_SEQ}'," +
                                                         $"'{logitm.LOGITM_TYPE}'," +
                                                         $"{logitm.LOGITM_DATALEN}," +
                                                         $"'{logitm.LOGITM_MCODE}'," +
                                                         $"'{logitm.LOGITM_PREFIX}'," +
                                                         $"'{logitm.LOGITM_DTTYPE}'" +
                                                         " )";
                                    this.VersionModel.context.Database.ExecuteSqlCommand(sql);
                                }
                            }
                            #endregion
                        }
                        else
                        {
                            List<string> listUpdate = new List<string>();
                            StringBuilder sbUpdate = new StringBuilder();
                            #region 物理アイテム情報の更新
                            //変更されているか検定し、変更項目のみを更新する
                            if (origin.phyitm.PHYITM_PATH != rowInfo.phyitm.PHYITM_PATH)                    // パス
                            {
                                listUpdate.Add($" PHYITM_PATH='{rowInfo.phyitm.PHYITM_PATH}'");
                            }
                            if (origin.phyitm.PHYITM_ITEMNO != rowInfo.phyitm.PHYITM_ITEMNO)                // 項番
                            {
                                listUpdate.Add($" PHYITM_ITEMNO='{rowInfo.phyitm.PHYITM_ITEMNO}'");
                            }
                            if (origin.phyitm.PHYITM_LEVEL != rowInfo.phyitm.PHYITM_LEVEL)                  // レベル
                            {
                                listUpdate.Add($" PHYITM_LEVEL={rowInfo.phyitm.PHYITM_LEVEL}");
                            }
                                                                                                            // アイテム記号名称
                            if ((origin.phyitm.PHYITM_ITEMID != rowInfo.phyitm.PHYITM_ITEMID) &&
                                !(string.IsNullOrEmpty(origin.phyitm.PHYITM_ITEMID) && string.IsNullOrEmpty(rowInfo.phyitm.PHYITM_ITEMID)))
                            {
                                listUpdate.Add($" PHYITM_ITEMID='{rowInfo.phyitm.PHYITM_ITEMID}'");
                            }
                            if ((origin.phyitm.PHYITM_ITEMNM != rowInfo.phyitm.PHYITM_ITEMNM) &&             // アイテム名称
                                !(string.IsNullOrEmpty(origin.phyitm.PHYITM_ITEMNM) && string.IsNullOrEmpty(rowInfo.phyitm.PHYITM_ITEMNM)))  
                            {
                                listUpdate.Add($" PHYITM_ITEMNM='{rowInfo.phyitm.PHYITM_ITEMNM}'");
                            }
                            if ((origin.phyitm.PHYITM_DTTYPE != rowInfo.phyitm.PHYITM_DTTYPE) &&             // データ形式
                                !(string.IsNullOrEmpty(origin.phyitm.PHYITM_DTTYPE) && string.IsNullOrEmpty(rowInfo.phyitm.PHYITM_DTTYPE)))
                            {
                                listUpdate.Add($" PHYITM_DTTYPE='{rowInfo.phyitm.PHYITM_DTTYPE}'");
                            }
                            if ((origin.phyitm.PHYITM_DTLEN != rowInfo.phyitm.PHYITM_DTLEN) &&               // データサイズ
                                !( (origin.phyitm.PHYITM_DTLEN == null || origin.phyitm.PHYITM_DTLEN == 0) && 
                                   (rowInfo.phyitm.PHYITM_DTLEN == null || rowInfo.phyitm.PHYITM_DTLEN == 0)))
                            {
                                listUpdate.Add($" PHYITM_DTLEN={rowInfo.phyitm.PHYITM_DTLEN}");
                            }
                            if ((origin.phyitm.PHYITM_OCCURS != rowInfo.phyitm.PHYITM_OCCURS) &&               // 繰返し回数
                                !((origin.phyitm.PHYITM_OCCURS == null || origin.phyitm.PHYITM_OCCURS == 0) &&
                                   (rowInfo.phyitm.PHYITM_OCCURS == null || rowInfo.phyitm.PHYITM_OCCURS == 0)))
                            {
                                listUpdate.Add($" PHYITM_OCCURS={rowInfo.phyitm.PHYITM_OCCURS}");
                            }
                            if ((origin.phyitm.PHYITM_COMMENT != rowInfo.phyitm.PHYITM_COMMENT) &&          // アイテム内容
                                !(string.IsNullOrEmpty(origin.phyitm.PHYITM_COMMENT) && string.IsNullOrEmpty(rowInfo.phyitm.PHYITM_COMMENT)))
                            {
                                listUpdate.Add($" PHYITM_COMMENT='{rowInfo.phyitm.PHYITM_COMMENT}'");
                            }
                            if ((origin.phyitm.PHYITM_NOTE != rowInfo.phyitm.PHYITM_NOTE) &&                // 記事
                                !(string.IsNullOrEmpty(origin.phyitm.PHYITM_NOTE) && string.IsNullOrEmpty(rowInfo.phyitm.PHYITM_NOTE)))
                            {
                                listUpdate.Add($" PHYITM_NOTE='{rowInfo.phyitm.PHYITM_NOTE}'");
                            }
                            if ((origin.phyitm.PHYITM_CPYDTTYPE != rowInfo.phyitm.PHYITM_CPYDTTYPE) &&      // コピー句データ形式
                                !(string.IsNullOrEmpty(origin.phyitm.PHYITM_CPYDTTYPE) && string.IsNullOrEmpty(rowInfo.phyitm.PHYITM_CPYDTTYPE)))
                            {
                                listUpdate.Add($" PHYITM_CPYDTTYPE='{rowInfo.phyitm.PHYITM_CPYDTTYPE}'");
                            }
                            if ((origin.phyitm.PHYITM_ITEMFLG != rowInfo.phyitm.PHYITM_ITEMFLG) &&          // アイテムフラグ
                                !(string.IsNullOrEmpty(origin.phyitm.PHYITM_ITEMFLG) && string.IsNullOrEmpty(rowInfo.phyitm.PHYITM_ITEMFLG)))
                            {
                                listUpdate.Add($" PHYITM_ITEMFLG='{rowInfo.phyitm.PHYITM_ITEMFLG}'");
                            }
                            if ((origin.phyitm.PHYITM_GROUP != rowInfo.phyitm.PHYITM_GROUP) &&              // 候補値グループ名
                                !(string.IsNullOrEmpty(origin.phyitm.PHYITM_GROUP) && string.IsNullOrEmpty(rowInfo.phyitm.PHYITM_GROUP)))
                            {
                                listUpdate.Add($" PHYITM_GROUP='{rowInfo.phyitm.PHYITM_GROUP}'");
                            }
                            if ((origin.phyitm.PHYITM_IMAGENM != rowInfo.phyitm.PHYITM_IMAGENM) &&          // イメージ名
                                !(string.IsNullOrEmpty(origin.phyitm.PHYITM_IMAGENM) && string.IsNullOrEmpty(rowInfo.phyitm.PHYITM_IMAGENM)))
                            {
                                listUpdate.Add($" PHYITM_IMAGENM='{rowInfo.phyitm.PHYITM_IMAGENM}'");
                            }
                            if (ToHex(origin.phyitm.PHYITM_IMAGE) != ToHex(rowInfo.phyitm.PHYITM_IMAGE))    // イメージ
                            {
                                listUpdate.Add($" PHYITM_IMAGE=unhex('{ToHex(rowInfo.phyitm.PHYITM_IMAGE)}')");
                            }

                            if (listUpdate.Count > 0)
                            {
                                for (int index = 0; index < listUpdate.Count; index++)
                                {
                                    if (index > 0)
                                    {
                                        sbUpdate.Append(",");
                                    }
                                    sbUpdate.Append(listUpdate[index]);
                                }
                                sql = $"UPDATE t_phyitm SET" +  sbUpdate.ToString() + $" WHERE PHYITM_SUBSYSID='{rowInfo.phyitm.PHYITM_SUBSYSID}' AND PHYITM_INFOID='{rowInfo.phyitm.PHYITM_INFOID}' AND PHYITM_SEQ='{rowInfo.phyitm.PHYITM_SEQ}'";
                                this.VersionModel.context.Database.ExecuteSqlCommand(sql);
                            }
                            #endregion
                            #region 論理設定条件情報
                            foreach (T_CONDITION condition in rowInfo.condition)
                            {
                                bool find = false;
                                foreach (T_CONDITION ori in origin.condition)
                                {
                                    if (ori != null && condition.COND_OPNM == ori.COND_OPNM)
                                    {
                                        listUpdate.Clear();
                                        find = true;
                                        //更新された項目のみ更新する
                                        if(ori.COND_OUTPUTORDER != condition.COND_OUTPUTORDER)
                                        {
                                            listUpdate.Add($" COND_OUTPUTORDER={condition.COND_OUTPUTORDER}");
                                        }
                                        if ((ori.COND_SETCOND != condition.COND_SETCOND) &&
                                            !(string.IsNullOrEmpty(ori.COND_SETCOND) && string.IsNullOrEmpty(condition.COND_SETCOND)))
                                        {
                                            listUpdate.Add($" COND_SETCOND='{condition.COND_SETCOND}'");
                                        }
                                        if(listUpdate.Count > 0)
                                        {
                                            sbUpdate.Clear();
                                            for (int index = 0; index < listUpdate.Count; index++)
                                            {
                                                if (index > 0)
                                                {
                                                    sbUpdate.Append(",");
                                                }
                                                sbUpdate.Append(listUpdate[index]);
                                            }
                                            sql = sbUpdate.ToString();
                                            this.VersionModel.context.Database.ExecuteSqlCommand
                                                (
                                                    $"UPDATE t_condition SET" +
                                                                    sql +
                                                                    $" WHERE COND_SUBSYSID='{condition.COND_SUBSYSID}'" + 
                                                                      $" AND COND_INFOID='{condition.COND_INFOID}'"+
                                                                      $" AND COND_SEQ='{condition.COND_SEQ}'" +
                                                                      $" AND COND_OPNM='{condition.COND_OPNM}'");
                                        }
                                        break;
                                    }
                                }
                                if (find == false)
                                {
                                    //追加
                                    if(string.IsNullOrEmpty(condition.COND_SETCOND) == false)
                                    {
                                        sql = "INSERT INTO t_condition(" +
                                                                " COND_SUBSYSID," +
                                                                " COND_INFOID," +
                                                                " COND_OPNM," +
                                                                " COND_SEQ," +
                                                                " COND_OUTPUTORDER," +
                                                                " COND_SETCOND" +
                                                                " )" +
                                                             "VALUES(" +
                                                             $"'{condition.COND_SUBSYSID}'," +
                                                             $"'{condition.COND_INFOID}'," +
                                                             $"'{condition.COND_OPNM}'," +
                                                             $"'{condition.COND_SEQ}'," +
                                                             $"{condition.COND_OUTPUTORDER}," +
                                                             $"'{condition.COND_SETCOND}'" +
                                                             " )";
                                        this.VersionModel.context.Database.ExecuteSqlCommand(sql);
                                    }
                                }
                            }
                            //削除
                            foreach(T_CONDITION delTarget in origin.condition)
                            {
                                bool find = false;
                                foreach (T_CONDITION condition in rowInfo.condition)
                                {
                                    if(delTarget != null && delTarget.COND_OPNM == condition.COND_OPNM)
                                    {
                                        find = true;
                                        break;
                                    }
                                }
                                if(delTarget != null && find == false)
                                {
                                    this.VersionModel.context.Database.ExecuteSqlCommand
                                        (
                                            $"DELETE FROM t_condition" +
                                                            $" WHERE COND_SUBSYSID='{delTarget.COND_SUBSYSID}'" +
                                                              $" AND COND_INFOID='{delTarget.COND_INFOID}'" +
                                                              $" AND COND_SEQ='{delTarget.COND_SEQ}'" +
                                                              $" AND COND_OPNM='{delTarget.COND_OPNM}'");
                                }
                            }
                            #endregion
                            #region 物理Ｍパーサ情報
                            if(rowInfo.phyprs != null)
                            {
                                if(origin.phyprs == null)
                                {
                                    //新規追加
                                    if (string.IsNullOrEmpty(rowInfo.phyprs.PHYPRS_LAYDEF) == false)
                                    {
                                        sql = "INSERT INTO t_phyprs(" +
                                                                " PHYPRS_PHYSYSID," +
                                                                " PHYPRS_INFOID," +
                                                                " PHYPRS_SUBSYSID," +
                                                                " PHYPRS_PHYID," +
                                                                " PHYPRS_LAYDEF," +
                                                                " PHYPRS_SEQ," +
                                                                " PHYPRS_TAGNM," +
                                                                " PHYPRS_LTYPE," +
                                                                " PHYPRS_CDCHG," +
                                                                " PHYPRS_FLG," +
                                                                " PHYPRS_MCODE," +
                                                                " PHYPRS_USERID," +
                                                                " PHYPRS_UPDTIME" +
                                                                " )" +
                                                             "VALUES(" +
                                                             $"'{rowInfo.phyprs.PHYPRS_PHYSYSID}'," +
                                                             $"'{rowInfo.phyprs.PHYPRS_INFOID}'," +
                                                             $"'{rowInfo.phyprs.PHYPRS_SUBSYSID}'," +
                                                             $"'{rowInfo.phyprs.PHYPRS_PHYID}'," +
                                                             $"'{rowInfo.phyprs.PHYPRS_LAYDEF}'," +
                                                             $"'{rowInfo.phyprs.PHYPRS_SEQ}'," +
                                                             $"'{rowInfo.phyprs.PHYPRS_TAGNM}'," +
                                                             $"'{rowInfo.phyprs.PHYPRS_LTYPE}'," +
                                                             $"'{rowInfo.phyprs.PHYPRS_CDCHG}'," +
                                                             $"'{rowInfo.phyprs.PHYPRS_FLG}'," +
                                                             $"'{rowInfo.phyprs.PHYPRS_MCODE}'," +
                                                             $"'{this.VersionModel.User.USERID}'," +
                                                             $"'{DateTime.Now.ToString()}'" +
                                                             " )";
                                        this.VersionModel.context.Database.ExecuteSqlCommand(sql);
                                    }
                                }
                                else
                                {
                                    if(string.IsNullOrEmpty(rowInfo.phyprs.PHYPRS_LAYDEF) == false)
                                    {
                                        //更新
                                        listUpdate.Clear();
                                        if ((origin.phyprs.PHYPRS_LAYDEF != rowInfo.phyprs.PHYPRS_LAYDEF) &&   // レイアウト定義
                                            !(string.IsNullOrEmpty(origin.phyprs.PHYPRS_LAYDEF) && string.IsNullOrEmpty(rowInfo.phyprs.PHYPRS_LAYDEF)))
                                        {
                                            listUpdate.Add($" PHYPRS_LAYDEF='{rowInfo.phyprs.PHYPRS_LAYDEF}'");
                                        }
                                        if ((origin.phyprs.PHYPRS_PHYID != rowInfo.phyprs.PHYPRS_PHYID) &&  // 物理ＩＤ
                                            !(string.IsNullOrEmpty(origin.phyprs.PHYPRS_PHYID) && string.IsNullOrEmpty(rowInfo.phyprs.PHYPRS_PHYID)))
                                        {
                                            listUpdate.Add($" PHYPRS_PHYID='{rowInfo.phyprs.PHYPRS_PHYID}'");
                                        }
                                        if ((origin.phyprs.PHYPRS_TAGNM != rowInfo.phyprs.PHYPRS_TAGNM) &&   // 物理タグ名
                                            !(string.IsNullOrEmpty(origin.phyprs.PHYPRS_TAGNM) && string.IsNullOrEmpty(rowInfo.phyprs.PHYPRS_TAGNM)))
                                        {
                                            listUpdate.Add($" PHYPRS_TAGNM='{rowInfo.phyprs.PHYPRS_TAGNM}'");
                                        }
                                        if ((origin.phyprs.PHYPRS_LTYPE != rowInfo.phyprs.PHYPRS_LTYPE) &&  // 物理属性
                                            !(string.IsNullOrEmpty(origin.phyprs.PHYPRS_LTYPE) && string.IsNullOrEmpty(rowInfo.phyprs.PHYPRS_LTYPE)))
                                        {
                                            listUpdate.Add($" PHYPRS_LTYPE='{rowInfo.phyprs.PHYPRS_LTYPE}'");
                                        }
                                        if ((origin.phyprs.PHYPRS_CDCHG != rowInfo.phyprs.PHYPRS_CDCHG) &&   // コード変換要
                                            !(string.IsNullOrEmpty(origin.phyprs.PHYPRS_CDCHG) && string.IsNullOrEmpty(rowInfo.phyprs.PHYPRS_CDCHG)))
                                        {
                                            listUpdate.Add($" PHYPRS_CDCHG='{rowInfo.phyprs.PHYPRS_CDCHG}'");
                                        }
                                        if ((origin.phyprs.PHYPRS_FLG != rowInfo.phyprs.PHYPRS_FLG) &&  // 符号有無
                                            !(string.IsNullOrEmpty(origin.phyprs.PHYPRS_FLG) && string.IsNullOrEmpty(rowInfo.phyprs.PHYPRS_FLG)))
                                        {
                                            listUpdate.Add($" PHYPRS_FLG='{rowInfo.phyprs.PHYPRS_FLG}'");
                                        }
                                        if ((origin.phyprs.PHYPRS_MCODE != rowInfo.phyprs.PHYPRS_MCODE) &&   // 文字コード
                                            !(string.IsNullOrEmpty(origin.phyprs.PHYPRS_MCODE) && string.IsNullOrEmpty(rowInfo.phyprs.PHYPRS_MCODE)))
                                        {
                                            listUpdate.Add($" PHYPRS_MCODE='{rowInfo.phyprs.PHYPRS_MCODE}'");
                                        }
                                        if (listUpdate.Count > 0)
                                        {
                                            sbUpdate.Clear();
                                            for (int index = 0; index < listUpdate.Count; index++)
                                            {
                                                if (index > 0)
                                                {
                                                    sbUpdate.Append(",");
                                                }
                                                sbUpdate.Append(listUpdate[index]);
                                            }
                                            sbUpdate.Append($" ,PHYPRS_USERID='{this.VersionModel.User.USERID}', PHYPRS_UPDTIME='{DateTime.Now.ToString()}'");
                                            this.VersionModel.context.Database.ExecuteSqlCommand
                                                (
                                                    $"UPDATE t_phyprs SET" +
                                                                    sbUpdate.ToString() +
                                                                    $" WHERE PHYPRS_PHYSYSID='{origin.phyprs.PHYPRS_PHYSYSID}'" +
                                                                      $" AND PHYPRS_INFOID='{origin.phyprs.PHYPRS_INFOID}'" +
                                                                      $" AND PHYPRS_SUBSYSID='{origin.phyprs.PHYPRS_SUBSYSID}'" +
                                                                      $" AND PHYPRS_LAYDEF='{origin.phyprs.PHYPRS_LAYDEF}'" +
                                                                      $" AND PHYPRS_SEQ='{origin.phyprs.PHYPRS_SEQ}'");
                                        }
                                    }
                                    else
                                    {
                                        //削除
                                        this.VersionModel.context.Database.ExecuteSqlCommand
                                            (
                                                $"DELETE FROM t_phyprs" +
                                                                    $" WHERE PHYPRS_PHYSYSID='{rowInfo.phyprs.PHYPRS_PHYSYSID}'" +
                                                                      $" AND PHYPRS_INFOID='{rowInfo.phyprs.PHYPRS_INFOID}'" +
                                                                      $" AND PHYPRS_SUBSYSID='{rowInfo.phyprs.PHYPRS_SUBSYSID}'" +
                                                                      $" AND PHYPRS_LAYDEF='{rowInfo.phyprs.PHYPRS_LAYDEF}'" +
                                                                      $" AND PHYPRS_SEQ='{rowInfo.phyprs.PHYPRS_SEQ}'");
                                    }
                                }
                            }
                            else
                            {
                                if(origin.phyprs != null)
                                {
                                    //削除
                                    this.VersionModel.context.Database.ExecuteSqlCommand
                                        (
                                            $"DELETE FROM t_phyprs" +
                                                                $" WHERE PHYPRS_PHYSYSID='{rowInfo.phyprs.PHYPRS_PHYSYSID}'" +
                                                                  $" AND PHYPRS_INFOID='{rowInfo.phyprs.PHYPRS_INFOID}'" +
                                                                  $" AND PHYPRS_SUBSYSID='{rowInfo.phyprs.PHYPRS_SUBSYSID}'" +
                                                                  $" AND PHYPRS_LAYDEF='{rowInfo.phyprs.PHYPRS_LAYDEF}'" +
                                                                  $" AND PHYPRS_SEQ='{rowInfo.phyprs.PHYPRS_SEQ}'");
                                }
                            }
                            #endregion
                            #region 論理アイテム情報
                            foreach(T_LOGITM logitm in rowInfo.logitm)
                            {
                                if(logitm != null)
                                {
                                    bool find = false;
                                    int i = 0;
                                    foreach (T_LOGITM ori in origin.logitm)
                                    {
                                        if (ori != null && ori.LOGITM_LCPID == logitm.LOGITM_LCPID)
                                        {
                                            listUpdate.Clear();
                                            find = true;
                                            if((ori.LOGITM_TYPE != logitm.LOGITM_TYPE) &&                 // 論理属性
                                                !(string.IsNullOrEmpty(ori.LOGITM_TYPE)  && string.IsNullOrEmpty(logitm.LOGITM_TYPE)))
                                            {
                                                listUpdate.Add($" LOGITM_TYPE='{logitm.LOGITM_TYPE}'");
                                            }
                                            if ((ori.LOGITM_DATALEN != logitm.LOGITM_DATALEN) &&          // 論理サイズ
                                                !((ori.LOGITM_DATALEN == null || ori.LOGITM_DATALEN == 0) &&
                                                  (logitm.LOGITM_DATALEN == null || logitm.LOGITM_DATALEN == 0)))
                                            {
                                                if (logitm.LOGITM_DATALEN == null || logitm.LOGITM_DATALEN == 0) logitm.LOGITM_DATALEN = null;
                                                listUpdate.Add($" LOGITM_DATALEN={logitm.LOGITM_DATALEN}");
                                            }
                                            if ((ori.LOGITM_MCODE != logitm.LOGITM_MCODE) &&               // 文字コード
                                                !(string.IsNullOrEmpty(ori.LOGITM_MCODE) && string.IsNullOrEmpty(logitm.LOGITM_MCODE)))
                                            {
                                                listUpdate.Add($" LOGITM_MCODE='{logitm.LOGITM_MCODE}'");
                                            }
                                            if ((ori.LOGITM_PREFIX != logitm.LOGITM_PREFIX) &&            // コピー句Ｐｒｅｆｉｘ
                                                !(string.IsNullOrEmpty(ori.LOGITM_PREFIX) && string.IsNullOrEmpty(logitm.LOGITM_PREFIX)))
                                            {
                                                listUpdate.Add($" LOGITM_PREFIX='{logitm.LOGITM_PREFIX}'");
                                            }
                                            if ((ori.LOGITM_DTTYPE != logitm.LOGITM_DTTYPE) &&            // コピー句データ形式
                                                !(string.IsNullOrEmpty(ori.LOGITM_DTTYPE) && string.IsNullOrEmpty(logitm.LOGITM_DTTYPE)))
                                            {
                                                listUpdate.Add($" LOGITM_DTTYPE='{logitm.LOGITM_DTTYPE}'");
                                            }
                                            if(listUpdate.Count > 0)
                                            {
                                                sbUpdate.Clear();
                                                for (int index = 0; index < listUpdate.Count; index++)
                                                {
                                                    if (index > 0)
                                                    {
                                                        sbUpdate.Append(",");
                                                    }
                                                    sbUpdate.Append(listUpdate[index]);
                                                }
                                                this.VersionModel.context.Database.ExecuteSqlCommand
                                                    (
                                                        $"UPDATE t_logitm SET" +
                                                                        sbUpdate.ToString() +
                                                                        $" WHERE LOGITM_SUBSYSIDL='{logitm.LOGITM_SUBSYSIDL}'" +
                                                                          $" AND LOGITM_LCPID='{logitm.LOGITM_LCPID}'" +
                                                                          $" AND LOGITM_SEQ='{logitm.LOGITM_SEQ}'");
                                            }
                                            break;
                                        }
                                    }
                                    if (find == false)    // 追加
                                    {
                                        sql = "INSERT INTO t_logitm(" +
                                                                " LOGITM_SUBSYSIDL," +
                                                                " LOGITM_LCPID," +
                                                                " LOGITM_SEQ," +
                                                                " LOGITM_TYPE," +
                                                                " LOGITM_DATALEN," +
                                                                " LOGITM_MCODE," +
                                                                " LOGITM_PREFIX," +
                                                                " LOGITM_DTTYPE" +
                                                                " )" +
                                                             "VALUES(" +
                                                             $"'{logitm.LOGITM_SUBSYSIDL}'," +
                                                             $"'{logitm.LOGITM_LCPID}'," +
                                                             $"'{logitm.LOGITM_SEQ}'," +
                                                             $"'{logitm.LOGITM_TYPE}'," +
                                                             $"{logitm.LOGITM_DATALEN}," +
                                                             $"'{logitm.LOGITM_MCODE}'," +
                                                             $"'{logitm.LOGITM_PREFIX}'," +
                                                             $"'{logitm.LOGITM_DTTYPE}'" +
                                                             " )";
                                        this.VersionModel.context.Database.ExecuteSqlCommand(sql);
                                    }
                                    i++;
                                }
                            }
                            //削除
                            foreach (T_LOGITM delTarget in origin.logitm)
                            {
                                if (delTarget != null)
                                {
                                    bool find = false;
                                    foreach (T_LOGITM logitm in rowInfo.logitm)
                                    {
                                        if (logitm != null && delTarget.LOGITM_LCPID == logitm.LOGITM_LCPID)
                                        {
                                            find = true;
                                            break;
                                        }
                                    }
                                    if (find == false)
                                    {
                                        this.VersionModel.context.Database.ExecuteSqlCommand
                                            (
                                                $"DELETE FROM t_logitm" +
                                                                $" WHERE LOGITM_SUBSYSIDL='{delTarget.LOGITM_SUBSYSIDL}'" +
                                                                    $" AND LOGITM_LCPID='{delTarget.LOGITM_LCPID}'" +
                                                                    $" AND LOGITM_SEQ='{delTarget.LOGITM_SEQ}'");
                                    }
                                }
                            }
                            #endregion
                        }
                    }
                    if (dicUpdate.Count == 0) break;    //全部更新したら終わり

                    rowIndex++;
                    if(rowIndex >= DataGridView.Rows.Count)
                    {
                        rowIndex = 0;
                    }
                }
            }
            catch (Exception ex)
            {
                this.logger.Error(ex, string.Format(Resources.IF_LOG_SQL_E, sql));
                return false;
            }
            return true;
        }

        private string ToHex(byte[] b)
        {
            if (b == null) return string.Empty;

            StringBuilder sb = new StringBuilder();
            foreach(byte dat in b)
            {
                sb.Append(dat.ToString("X2"));
            }
            return sb.ToString();
        }

        private string getPhysicPATH(int rowIndex)
        {
            DataGridViewRow row = this.DataGridView.Rows[rowIndex];
            string path = row.Cells[2].Value as string;

            //レベルを取得
            if(int.TryParse(row.Cells[0].Value as string, out int level))
            {
                for(int index = rowIndex - 1; index >= 0; index--)
                {
                    DataGridViewRow r = this.DataGridView.Rows[index];
                    if(int.TryParse(r.Cells[0].Value as string, out int l))
                    {
                        if (level > l)
                        {
                            path = (r.Cells[2].Value as string) + "_" + path;
                            level = l;
                        }
                    }
                }
            }
            return path;
        }

        /// <summary>
        /// ＤＢから物理コピー句の内容を取得する
        /// </summary>
        /// <returns></returns>
        public string getPhysicCopyphraseFromDB()
        {
            //物理コピー句情報を取得
            T_CPYPHY cpyphy = getPhysicCopyInfo();
            //物理アイテム情報を取得
            List<T_PHYITM> phyitms = getPhysicItemInfo();

            //コピー句クラスの組み立て
            CobolUtils.CopyPhrase copyPhrase = new CobolUtils.CopyPhrase();
            foreach(T_PHYITM phyitm in phyitms)
            {
                
                copyPhrase.Add((int)phyitm.PHYITM_LEVEL, phyitm.PHYITM_ITEMNM, phyitm.PHYITM_CPYDTTYPE, (int)phyitm.PHYITM_OCCURS, null, null);
            }
            StringBuilder sb = new StringBuilder();
            if(cpyphy.CPYPHY_COMMENT != null && cpyphy.CPYPHY_COMMENT != string.Empty)
            {
                foreach(string buf in cpyphy.CPYPHY_COMMENT.Split('\n'))
                {
                    if (buf.Length > 0 && buf.Last() == '\r')
                    {
                        sb.Append(string.Format("      *{0}\n", buf));
                    }
                    else
                    {
                        sb.Append(string.Format("      *{0}\r\n", buf));
                    }
                }
            }
            sb.Append(copyPhrase.ToString((int)cpyphy.CPYPHY_LEVNO));

            return sb.ToString();
        }

        private string getCopyType(string type)
        {
            if (string.IsNullOrEmpty(type)) return type;
            if (type.IndexOf("ADDRESS") == 0)
            {
                return "ADDRESS";
            }
            return type;
        }
        /// <summary>
        /// ＤＢから論理コピー句の内容を取得する
        /// </summary>
        /// <returns></returns>
        public Dictionary<string, string> getLogicCopyPharseFromDB()
        {
            Dictionary<string, string> dictionarySource = new Dictionary<string, string>();
            //物理コピー句情報を取得
            T_CPYPHY cpyphy = getPhysicCopyInfo();
            //物理アイテム情報を取得
            List<T_PHYITM> phyitms = getPhysicItemInfo();
            //論理コピー句情報を取得
            List<T_CPYLOG> listCPYLOG = getLogicInterfaceInfo();

            foreach(T_CPYLOG cpylog in listCPYLOG)
            {
                //コピー句クラスの組み立て
                CobolUtils.CopyPhrase copyPhrase = new CobolUtils.CopyPhrase();

                foreach (T_PHYITM phyitm in phyitms)
                {
                    T_LOGITM logitm = this.VersionModel.context.T_LOGITM.AsNoTracking().Where(r =>
                                                                                             r.LOGITM_SUBSYSIDL == this.LogicSubsystem &&
                                                                                             r.LOGITM_LCPID == cpylog.CPYLGC_LCPID &&
                                                                                             r.LOGITM_SEQ == phyitm.PHYITM_SEQ).SingleOrDefault();
                    if(logitm != null)
                    {
                        copyPhrase.Add((int)phyitm.PHYITM_LEVEL, 
                                       string.Format("{0}{1}", logitm.LOGITM_PREFIX, phyitm.PHYITM_ITEMNM), 
                                       logitm.LOGITM_DTTYPE, 
                                       (int)phyitm.PHYITM_OCCURS, 
                                       null, null);
                    }
                }
                StringBuilder sb = new StringBuilder();
                if (cpylog.CPYLGC_COMMENT != null && cpylog.CPYLGC_COMMENT != string.Empty)
                {
                    foreach (string buf in cpylog.CPYLGC_COMMENT.Split('\n'))
                    {
                        if (buf.Length > 0 && buf.Last() == '\r')
                        {
                            sb.Append(string.Format("      *{0}\n", buf));
                        }
                        else
                        {
                            sb.Append(string.Format("      *{0}\r\n", buf));
                        }
                    }
                }
                if(copyPhrase.copyItem != null)
                {
                    sb.Append(copyPhrase.ToString((int)cpylog.CPYLGC_LEVNO));
                    dictionarySource.Add(cpylog.CPYLGC_LCPID, sb.ToString());
                }
            }

            return dictionarySource;
        }

        /// <summary>
        /// 物理レイアウト定義の取得
        /// </summary>
        /// <returns></returns>
        public string getPhysicLayoutDef()
        {
            List<T_PHYITM> listPHYITM = getPhysicItemInfo();
            LayoutItem rootItem = null;
            LayoutItem curItem = null;
            string PHYID = string.Empty;
            foreach (T_PHYITM phyitm in listPHYITM)
            {
                T_PHYPRS_EF phyprs = getPHYPRS(phyitm.PHYITM_SEQ);
                if(phyprs != null)
                {
                    LayoutItem layout = new LayoutItem()
                    {
                        Name = phyitm.PHYITM_ITEMNM,
                        Type = phyprs.PHYPRS_LTYPE,
                        Tag = phyprs.PHYPRS_TAGNM,
                        Size = (int)phyitm.PHYITM_DTLEN,
                        Occurs = (int)phyitm.PHYITM_OCCURS,
                        Level = (int)phyitm.PHYITM_LEVEL,
                        CodeF = phyprs.PHYPRS_CDCHG,
                        Sign = phyprs.PHYPRS_FLG
                    };
                    if(rootItem == null)
                    {
                        rootItem = layout;
                        PHYID = phyprs.PHYPRS_PHYID;
                    }
                    else
                    {
                        if (curItem.Level == layout.Level)
                        {
                            layout.ParentItem = curItem.ParentItem;
                            curItem.ParentItem.ChildItems.Add(layout);
                        }
                        else if (curItem.Level < layout.Level)
                        {
                            layout.ParentItem = curItem;
                            curItem.ChildItems.Add(layout);
                        }
                        else if (curItem.Level > layout.Level)
                        {
                            while (curItem.Level >= layout.Level)
                            {
                                curItem = curItem.ParentItem;
                            }
                            layout.ParentItem = curItem;
                            curItem.ChildItems.Add(layout);
                        }
                    }
                    curItem = layout;
                }
            }
            //繰返し項目の展開を行う
            rootItem = expandLyaout(rootItem);

            //サイズ／対象更新
            rootItem = updateLayout(rootItem);

            //変換
            StringBuilder sb = new StringBuilder();
            sb.Append(string.Format("{0,-12},{1},,,,,,,\r\n", PHYID, rootItem.Name));
            sb.Append("項目ﾀｸﾞ     ,属性,LOC ,SIZ ,BIT位置,BIT数,CD変換要,符号有,項目名\r\n");
            sb.Append(string.Format("{0,-12},{1,-4},{2,-4},{3,-4},{4,-4},{5,-4},{6,-1},{7,-1},{8}\r\n",
                                      rootItem.Tag, rootItem.Type, rootItem.offset, rootItem.Size, "0", "0", rootItem.CodeF, rootItem.Sign, rootItem.Name));
            int bp = 0;
            foreach (LayoutItem item in rootItem.ChildItems)
            {
                sb.Append(layoutToString(item, ref bp));
            }
            return sb.ToString();
        }

        private LayoutItem expandLyaout(LayoutItem Item)
        {
            // 子項目のOCCURS展開
            for (int i = 0; i < Item.ChildItems.Count; i++)
            {
                if (Item.ChildItems[i].Occurs > 0)
                {
                    LayoutItem[] Items = new LayoutItem[Item.ChildItems[i].Occurs];
                    for (int j = 0; j < Items.Length; j++)
                    {
                        Items[j] = Item.ChildItems[i].DeepClone();
                        Items[j].Occurs = 0;
                        foreach (string word in new string[] { "nn", "mm", "ll" })
                        {
                            if (Items[j].Tag.IndexOf(word) > -1)
                            {
                                Items[j].Tag = Items[j].Tag.Replace(word, string.Format("{0:D2}", j + 1));
                                // 子項目がある場合は、全ての子項目についても置換する
                                for (int k = 0; k < Items[j].ChildItems.Count; k++)
                                {
                                    Items[j].ChildItems[k] = this.ChildExpand(Items[j].ChildItems[k], word, j + 1);
                                }
                                break;
                            }
                        }
                    }
                    Item.ChildItems.RemoveAt(i);
                    Item.ChildItems.InsertRange(i, Items);
                }
            }
            // 孫項目のOCCURS展開
            for (int i = 0; i < Item.ChildItems.Count; i++)
            {
                Item.ChildItems[i] = expandLyaout(Item.ChildItems[i]);
            }

            return Item;
        }

        private LayoutItem ChildExpand(LayoutItem Item, string word, int iNumber)
        {
            Item.Tag = Item.Tag.Replace(word, string.Format("{0:D2}", iNumber));
            // 子項目がある場合は子項目も置換する
            for (int i = 0; i < Item.ChildItems.Count; i++)
            {
                Item.ChildItems[i] = ChildExpand(Item.ChildItems[i], word, iNumber);
            }
            return Item;
        }

        private LayoutItem updateLayout(LayoutItem Item)
        {
            if (Item.ParentItem != null)
            {
                Item.offset = Item.ParentItem.offset;
                int bitOffset = 0;
                foreach (LayoutItem offsetItem in Item.ParentItem.ChildItems)
                {
                    if (Item == offsetItem)
                    {
                        break;
                    }
                    if(offsetItem.Type == "BIT")
                    {
                        bitOffset += offsetItem.Size;
                        if(bitOffset >= 8)
                        {
                            Item.offset += (bitOffset / 8);
                            bitOffset %= 8;
                        }
                    }
                    else
                    {
                        if ((bitOffset % 8) > 0) bitOffset += (8 - bitOffset % 8);
                        Item.offset += (offsetItem.Size + bitOffset / 8);
                        bitOffset = 0;
                    }
                }
            }
            if (Item.ChildItems.Count > 0)
            {
                //子項目がビット項目かチェックする
                bool IsTarget = false;
                int size = 0;
                int bitSize = 0;
                for (int i = 0; i < Item.ChildItems.Count; i++)
                {
                    if (Item.ChildItems[i].Type == "BIT" && Item.ChildItems[i].IsTarget)
                    {
                        IsTarget = true;
                    }
                    Item.ChildItems[i] = updateLayout(Item.ChildItems[i]);
                    if (Item.ChildItems[i].Type == "BIT")
                    {
                        bitSize += Item.ChildItems[i].Size;
                    }
                    else
                    {
                        size += Item.ChildItems[i].Size;
                    }
                }
                Item.IsTarget = IsTarget;

                Item.Size = size + bitSize / 8;
                if ((bitSize % 8) > 0) Item.Size++;

                return Item;
            }
            else if (Item.Type == "BIT")
            {
                Item.IsTarget = false;
                return Item;
            }
            else
            {
                return Item;
            }
        }

        private string layoutToString(LayoutItem Item, ref int bitPosition)
        {
            int size = 0;
            int bitSize = 0;
            int loc = Item.offset;
            StringBuilder sb = new StringBuilder();

            if (Item.Type == "BIT")
            {
                bitSize = Item.Size;
            }
            else
            {
                size = Item.Size;
                if (bitPosition > 0) size++;
                bitPosition = 0;
            }

            if (Item.Tag != "*")
            {
                sb.Append(string.Format("{0,-12},{1,-4},{2,-4},{3,-4},{4,-4},{5,-4},{6,-1},{7,-1},{8}\r\n",
                                          Item.Tag, Item.Type, loc, size, bitPosition, bitSize, Item.CodeF, Item.Sign, Item.Name));
            }
            bitPosition += bitSize;
            if(bitPosition >= 8)
            {
                bitPosition %= 8;
            }

            foreach (LayoutItem ChildItem in Item.ChildItems)
            {
                sb.Append(layoutToString(ChildItem, ref bitPosition));
            }
            return sb.ToString();
        }

        /// <summary>
        /// ＤＢの内容を検定する
        /// </summary>
        /// <returns></returns>
        public bool checkDB()
        {
            T_CPYPHY cpyphy = getPhysicCopyInfo();
            List<T_CPYLOG> listCPYLOG = getLogicInterfaceInfo();
            List<RowInfo> listRowInfo = getRowInfosFromDB();
            return checkRowInfo(cpyphy, listCPYLOG, listRowInfo);
        }

        /// <summary>
        /// DataGridViewの入力内容を検定する
        /// </summary>
        /// <returns></returns>
        public bool checkDataGridView()
        {
            if (this.DataGridView.Rows.Count > 0)
            {
                List<RowInfo> listRowInfo = getRowInfosFromDataGridView(false);
                T_CPYPHY cpyphy = new T_CPYPHY();
                if(this.DataGridView.Rows[0].Cells[10].Value != null)
                {
                    if(int.TryParse(this.DataGridView.Rows[0].Cells[10].Value as string, out int level))
                    {
                        cpyphy.CPYPHY_LEVNO = level;
                    }
                }
                int Index = this.DataGridView.GetIndexVariableColumn(Resources.IF_TAG_LOGICLAYOUT);
                int Count = this.DataGridView.GetCountVariableColumn(Resources.IF_TAG_LOGICLAYOUT);
                List<T_CPYLOG> cpylog = new List<T_CPYLOG>();
                for(int i = 0; i < Count; i+=7)
                {
                    T_CPYLOG itm = new T_CPYLOG();
                    if (this.DataGridView.Rows[0].Cells[Index + i + 1].Value != null)
                    {
                        if (int.TryParse(this.DataGridView.Rows[0].Cells[Index + i + 1].Value as string, out int level))
                        {
                            itm.CPYLGC_LEVNO = level;
                        }
                    }
                    cpylog.Add(itm);
                }

                return checkRowInfo(cpyphy, cpylog, listRowInfo);
            }
            return false;

        }

        /// <summary>
        /// 内容検定
        /// </summary>
        /// <param name="cpyphy">物理コピー句情報</param>
        /// <param name="cpylog">論理コピー句情報(List)</param>
        /// <param name="listRowInfo">行情報</param>
        /// <returns></returns>
        public bool checkRowInfo(T_CPYPHY cpyphy, List<T_CPYLOG> cpylog, List<RowInfo> listRowInfo)
        {
            bool Result = true;
            bool flgPhysicCheck = false;
            RowInfo preRowInfo = null;
            List<TreeNode> listNode = new List<TreeNode>();
            List<TreeNode>[] listLogicNode = null;
            if (cpylog != null)
            {
                listLogicNode = new List<TreeNode>[cpylog.Count];
                for(int i = 0; i < cpylog.Count; i++)
                {
                    listLogicNode[i] = new List<TreeNode>();
                }
            }
            int Index = 0;
            if (this.DataGridView != null) Index = this.DataGridView.GetIndexVariableColumn(Resources.IF_TAG_PARSER);

            if (this.SubsystemuID == this.LogicSubsystem)
            {
                flgPhysicCheck = true;
            }
            int rowIndex = 0;
            try
            {
                if(cpyphy != null && listRowInfo.Count == 0)
                {
                    this.logger.Error(string.Format(Resources.IF_LOG_NOPHYSIC_E, cpyphy.CPYPHY_BCPID));
                    return false;
                }

                //各行の入力内容を検定する
                for (rowIndex = 0; rowIndex < listRowInfo.Count; rowIndex++)
                {
                    DataGridViewRow row = null;
                    RowInfo rowInfo = listRowInfo[rowIndex];
                    if (this.DataGridView != null)
                    {
                        row = this.DataGridView.Rows[rowIndex];
                    }

                    TreeNode node = new TreeNode();
                    node.Tag = rowInfo;
                    //レベルの比較
                    if (listNode.Count > 0)
                    {
                        int NodeIndex = listNode.Count - 1;
                        while (true)
                        {
                            if (rowInfo.phyitm.PHYITM_LEVEL > (listNode[NodeIndex].Tag as RowInfo).phyitm.PHYITM_LEVEL)
                            {
                                listNode[NodeIndex].Nodes.Add(node);
                                break;
                            }
                            else
                            {
                                if (listNode[NodeIndex].Parent != null)
                                {
                                    NodeIndex = listNode.IndexOf(listNode[NodeIndex].Parent);
                                }
                                else
                                {
                                    break;
                                }
                            }
                        }
                    }
                    listNode.Add(node);

                    if (flgPhysicCheck)  // 物理アイテム情報
                    {
                        //アイテム情報
                        //  レベル番号
                        if (row != null) row.Cells[0].Style.BackColor = SystemColors.Window;
                        if (rowInfo.phyitm.PHYITM_LEVEL == null || rowInfo.phyitm.PHYITM_LEVEL > 100)
                        {
                            Result = false;
                            if (row != null) row.Cells[0].Style.BackColor = Color.Red;
                            this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "レベル番号", rowInfo.phyitm.PHYITM_LEVEL));
                        }
                        else
                        {
                            if(rowIndex == 0 && rowInfo.phyitm.PHYITM_LEVEL != 1)
                            {
                                Result = false;
                                if (row != null) row.Cells[0].Style.BackColor = Color.Red;
                                this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "レベル番号", rowInfo.phyitm.PHYITM_LEVEL));
                            }
                            if (preRowInfo != null)
                            {
                                //前項目が集団項目の場合は、レベル差が１であること
                                //前項目が単項目の場合は、  レベルが前項目以下であること
                                if (string.IsNullOrEmpty(preRowInfo.phyitm.PHYITM_CPYDTTYPE))
                                {
                                    if ((rowInfo.phyitm.PHYITM_LEVEL - preRowInfo.phyitm.PHYITM_LEVEL) != 1)
                                    {
                                        Result = false;
                                        if (row != null) row.Cells[0].Style.BackColor = Color.Red;
                                        this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "レベル番号", rowInfo.phyitm.PHYITM_LEVEL));
                                    }
                                }
                                else
                                {
                                    if (preRowInfo.phyitm.PHYITM_LEVEL < rowInfo.phyitm.PHYITM_LEVEL)
                                    {
                                        Result = false;
                                        if (row != null) row.Cells[0].Style.BackColor = Color.Red;
                                        this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "レベル番号", rowInfo.phyitm.PHYITM_LEVEL));
                                    }
                                }
                            }
                        }
                        //  アイテム記号名称（省略可：６０文字以内）
                        if (row != null) row.Cells[1].Style.BackColor = SystemColors.Window;
                        if (rowInfo.phyitm.PHYITM_ITEMID != null && rowInfo.phyitm.PHYITM_ITEMID.Length > 60)
                        {
                            Result = false;
                            if (row != null) row.Cells[1].Style.BackColor = Color.Red;
                            this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "アイテム記号名称", rowInfo.phyitm.PHYITM_ITEMID));
                        }
                        //  アイテム名称（１～２８文字）
                        if (row != null) row.Cells[2].Style.BackColor = SystemColors.Window;
                        if (rowInfo.phyitm.PHYITM_ITEMNM == null || rowInfo.phyitm.PHYITM_ITEMNM.Length == 0 || rowInfo.phyitm.PHYITM_ITEMNM.Length > 28)
                        {
                            Result = false;
                            if (row != null) row.Cells[2].Style.BackColor = Color.Red;
                            this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "アイテム名称", rowInfo.phyitm.PHYITM_ITEMNM));
                        }
                        //　データ形式
                        if (row != null) row.Cells[3].Style.BackColor = SystemColors.Window;
                        if (!string.IsNullOrEmpty(rowInfo.phyitm.PHYITM_DTTYPE) && IntefaceCommon.getItemToParseType(rowInfo.phyitm.PHYITM_DTTYPE) == null)
                        {
                            Result = false;
                            if (row != null) row.Cells[3].Style.BackColor = Color.Red;
                            this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "データ形式", rowInfo.phyitm.PHYITM_DTTYPE));
                        }
                        //  データサイズ
                        if (row != null) row.Cells[4].Style.BackColor = SystemColors.Window;
                        if (rowInfo.phyitm.PHYITM_DTLEN == null || rowInfo.phyitm.PHYITM_DTLEN == 0)
                        {
                            if (string.IsNullOrEmpty(rowInfo.phyitm.PHYITM_DTTYPE) == false)
                            {
                                if (rowInfo.phyitm.PHYITM_DTTYPE != "GROUP")
                                {
                                    Result = false;
                                    if (row != null) row.Cells[4].Style.BackColor = Color.Red;
                                    this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "データサイズ", rowInfo.phyitm.PHYITM_DTLEN));
                                }
                            }
                        }
                        else if (rowInfo.phyitm.PHYITM_DTLEN > 999999 || rowInfo.phyitm.PHYITM_DTTYPE == "GROUP")
                        {
                            Result = false;
                            if (row != null) row.Cells[4].Style.BackColor = Color.Red;
                            this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "データサイズ", rowInfo.phyitm.PHYITM_DTLEN));
                        }
                        //  繰返し回数（省略可：６桁以内）
                        if (row != null) row.Cells[5].Style.BackColor = SystemColors.Window;
                        if (rowInfo.phyitm.PHYITM_OCCURS != null && (rowInfo.phyitm.PHYITM_OCCURS > 999999))
                        {
                            Result = false;
                            if (row != null) row.Cells[5].Style.BackColor = Color.Red;
                            this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "繰返し回数", rowInfo.phyitm.PHYITM_OCCURS));
                        }
                        //  アイテム内容（省略可：4096文字以内）
                        if (row != null) row.Cells[6].Style.BackColor = SystemColors.Window;
                        if (rowInfo.phyitm.PHYITM_COMMENT != null && rowInfo.phyitm.PHYITM_COMMENT.Length > 4096)
                        {
                            Result = false;
                            if (row != null) row.Cells[6].Style.BackColor = Color.Red;
                            this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "アイテム内容", rowInfo.phyitm.PHYITM_COMMENT));
                        }
                        //  記事（省略可：５０文字以内）
                        if (row != null) row.Cells[9].Style.BackColor = SystemColors.Window;
                        if (rowInfo.phyitm.PHYITM_NOTE != null && rowInfo.phyitm.PHYITM_NOTE.Length > 50)
                        {
                            Result = false;
                            if (row != null) row.Cells[9].Style.BackColor = Color.Red;
                            this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "記事", rowInfo.phyitm.PHYITM_NOTE));
                        }
                        //コピー句情報
                        //  コピー句開始レベル番号（省略不可：1～99）
                        if (rowIndex == 0)
                        {
                            if (row != null) row.Cells[10].Style.BackColor = SystemColors.Window;
                            if (cpyphy.CPYPHY_LEVNO == null || cpyphy.CPYPHY_LEVNO < 1 || cpyphy.CPYPHY_LEVNO > 99)
                            {
                                Result = false;
                                if (row != null) row.Cells[10].Style.BackColor = Color.Red;
                                this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "コピー句開始レベル番号", cpyphy.CPYPHY_LEVNO));
                            }
                        }
                        //  コピー句データ形式（省略可：コピー句属性対象文字 かつ 60文字以内 かつ データサイズと同サイズ）
                        if (row != null) row.Cells[11].Style.BackColor = SystemColors.Window;
                        if (string.IsNullOrEmpty(rowInfo.phyitm.PHYITM_CPYDTTYPE))
                        {
                            if (string.IsNullOrEmpty(rowInfo.phyitm.PHYITM_DTTYPE) == false && rowInfo.phyitm.PHYITM_DTTYPE != "GROUP" )
                            {
                                Result = false;
                                if (row != null) row.Cells[3].Style.BackColor = Color.Red;
                                this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "データ形式", rowInfo.phyitm.PHYITM_DTTYPE));
                            }
                        }
                        else
                        {
                            string type = rowInfo.phyitm.PHYITM_CPYDTTYPE;
                            if ((rowInfo.phyitm.PHYITM_CPYDTTYPE != string.Empty && CobolUtils.TypeCheck(type) == false)
                                                                                                    || rowInfo.phyitm.PHYITM_CPYDTTYPE.Length > 60)
                            {
                                Result = false;
                                if (row != null) row.Cells[11].Style.BackColor = Color.Red;
                                this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "コピー句データ形式", rowInfo.phyitm.PHYITM_CPYDTTYPE));
                            }
                            else
                            {
                                //データサイズが設定されていたら、サイズが一致するか検定する
                                if (rowInfo.phyitm.PHYITM_DTLEN != null && rowInfo.phyitm.PHYITM_DTLEN != 0 )
                                {
                                    if (CobolUtils.GetSize(type) != rowInfo.phyitm.PHYITM_DTLEN)
                                    {
                                        Result = false;
                                        if (row != null) row.Cells[11].Style.BackColor = Color.Red;
                                        this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "コピー句データ形式", rowInfo.phyitm.PHYITM_CPYDTTYPE));
                                    }
                                    else
                                    {
                                        if (string.IsNullOrEmpty(rowInfo.phyitm.PHYITM_DTTYPE) == false && rowInfo.phyitm.PHYITM_DTTYPE == "GROUP")
                                        {
                                            Result = false;
                                            if (row != null) row.Cells[3].Style.BackColor = Color.Red;
                                            this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "データ形式", rowInfo.phyitm.PHYITM_DTTYPE));
                                        }
                                    }
                                }
                            }
                        }
                        //設定条件（省略可：40文字以内）
                        if (rowInfo.condition != null)
                        {
                            for (int i = 0; i < rowInfo.condition.Count; i++)
                            {
                                if (row != null) row.Cells[12 + i].Style.BackColor = SystemColors.Window;
                                if (rowInfo.condition[i].COND_SETCOND.Length > 40)
                                {
                                    Result = false;
                                    if (row != null) row.Cells[12 + i].Style.BackColor = Color.Red;
                                    this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "設定条件", rowInfo.condition));
                                }
                            }
                        }
                        preRowInfo = rowInfo;
                    }

                    //論理インタフェース
                    //  Ｍパーサ物理情報
                    if (rowInfo.phyprs != null)
                    {
                        //    物理ＩＤ（半角英数 かつ 8文字以内 但し、先頭行のみ）
                        if (row != null) row.Cells[Index].Style.BackColor = SystemColors.Window;
                        if (rowIndex == 0 &&
                                (rowInfo.phyprs.PHYPRS_PHYID == string.Empty ||
                                (Utils.IsAlpahNum(rowInfo.phyprs.PHYPRS_PHYID) == false || rowInfo.phyprs.PHYPRS_PHYID.Length > 8)))
                        {
                            Result = false;
                            if (row != null) row.Cells[Index].Style.BackColor = Color.Red;
                            this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "物理ＩＤ", rowInfo.phyprs.PHYPRS_PHYID));
                        }
                        if (row != null) row.Cells[Index + 1].Style.BackColor = SystemColors.Window;
                        if (row != null) row.Cells[Index + 2].Style.BackColor = SystemColors.Window;
                        //    １エントリ分すべて設定無の場合は対象外
                        if (rowInfo.phyprs.PHYPRS_TAGNM != string.Empty ||
                           rowInfo.phyprs.PHYPRS_LTYPE != string.Empty ||
                           rowInfo.phyprs.PHYPRS_CDCHG != "0" ||
                           rowInfo.phyprs.PHYPRS_FLG != "0")
                        {
                            //    タグ名（省略可：半角英数と* かつ 12文字以内）
                            if (rowInfo.phyprs.PHYPRS_TAGNM == string.Empty || (Utils.IsAlpahNum(rowInfo.phyprs.PHYPRS_TAGNM) == false && rowInfo.phyprs.PHYPRS_TAGNM != "*") || rowInfo.phyprs.PHYPRS_TAGNM.Length > 12)
                            {
                                Result = false;
                                if (row != null) row.Cells[Index + 1].Style.BackColor = Color.Red;
                                this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "タグ名", rowInfo.phyprs.PHYPRS_TAGNM));
                            }
                            //  Ｍパーサ物理属性（１２文字以内）
                            if (rowInfo.phyprs.PHYPRS_LTYPE == string.Empty || rowInfo.phyprs.PHYPRS_LTYPE.Length > 12)
                            {
                                Result = false;
                                if (row != null) row.Cells[Index + 2].Style.BackColor = Color.Red;
                                this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "Ｍパーサ物理属性", rowInfo.phyprs.PHYPRS_LTYPE));
                            }
                            //（データサイズとの組み合わせ検定）
                            int size = 0;
                            if (rowInfo.phyitm.PHYITM_DTLEN != null)
                            {
                                size = (int)rowInfo.phyitm.PHYITM_DTLEN;
                            }
                            if (Common.IntefaceCommon.checkParseSize(rowInfo.phyprs.PHYPRS_LTYPE, size) == false)
                            {
                                Result = false;
                                if (row != null) row.Cells[Index + 2].Style.BackColor = Color.Red;
                                this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "Ｍパーサ物理属性", rowInfo.phyprs.PHYPRS_LTYPE));
                            }
                        }
                    }

                    //  論理条件
                    if (rowInfo.logitm != null)
                    {
                        int logicIndex = 0;
                        if (this.DataGridView != null) logicIndex = this.DataGridView.GetIndexVariableColumn(Resources.IF_TAG_LOGICLAYOUT);
                        for (int i = 0; i < rowInfo.logitm.Count; i++)
                        {
                            T_LOGITM logitm = rowInfo.logitm[i];
                            if (logitm != null)
                            {
                                //    物理Ｍパーサ情報（タグ名）設定されているか
                                if (string.IsNullOrWhiteSpace(rowInfo.phyprs.PHYPRS_TAGNM))
                                {
                                    Result = false;
                                    if (row != null) row.Cells[Index + 1].Style.BackColor = Color.Red;
                                    this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "タグ名", rowInfo.phyprs.PHYPRS_TAGNM));
                                }

                                if (rowIndex == 0)
                                {
                                    if (row != null) row.Cells[logicIndex].Style.BackColor = SystemColors.Window;
                                    //    開始レベル番号（2桁以内）
                                    if (row != null) row.Cells[logicIndex + 1].Style.BackColor = SystemColors.Window;
                                    if (cpylog[i].CPYLGC_LEVNO == null || cpylog[i].CPYLGC_LEVNO <= 0 || cpylog[i].CPYLGC_LEVNO > 99)
                                    {
                                        Result = false;
                                        if (row != null) row.Cells[logicIndex + 1].Style.BackColor = Color.Red;
                                        this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "開始レベル番号", cpylog[i].CPYLGC_LEVNO));
                                    }
                                }

                                //    Ｍパーサ論理属性
                                if (row != null) row.Cells[logicIndex + 2].Style.BackColor = SystemColors.Window;
                                if (string.IsNullOrWhiteSpace(logitm.LOGITM_TYPE))
                                {
                                    Result = false;
                                    if (row != null) row.Cells[logicIndex + 2].Style.BackColor = Color.Red;
                                    this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "Ｍパーサ論理属性", logitm.LOGITM_TYPE));
                                }

                                //    Ｍパーサ論理サイズ（6桁以内）
                                if (row != null) row.Cells[logicIndex + 3].Style.BackColor = SystemColors.Window;
                                if (logitm.LOGITM_DATALEN == null || logitm.LOGITM_DATALEN <= 0 || logitm.LOGITM_DATALEN > 999999)
                                {
                                    // 物理サイズが無い場合（集団項目）は、0も許可する
                                    if (rowInfo.phyitm.PHYITM_DTLEN != null && rowInfo.phyitm.PHYITM_DTLEN != 0)
                                    {
                                        Result = false;
                                        if (row != null) row.Cells[logicIndex + 3].Style.BackColor = Color.Red;
                                        this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "Ｍパーサ論理サイズ", logitm.LOGITM_DATALEN));
                                    }
                                }

                                //  （Ｍパーサ論理サイズとの組み合わせ検定）
                                if (Common.IntefaceCommon.checkParseSize(logitm.LOGITM_TYPE, (int)logitm.LOGITM_DATALEN) == false)
                                {
                                    Result = false;
                                    if (row != null) row.Cells[logicIndex + 3].Style.BackColor = Color.Red;
                                    this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "Ｍパーサ論理サイズ", logitm.LOGITM_DATALEN));
                                }

                                //    コピー句Prefix（２０文字以内）
                                if (row != null) row.Cells[logicIndex + 5].Style.BackColor = SystemColors.Window;
                                if (logitm.LOGITM_PREFIX != null && logitm.LOGITM_PREFIX.Length > 20)
                                {
                                    Result = false;
                                    if (row != null) row.Cells[logicIndex + 5].Style.BackColor = Color.Red;
                                    this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "コピー句Prefix", logitm.LOGITM_PREFIX));
                                }

                                //    コピー句データ形式（コピー句属性対象文字 かつ 60文字以内 かつ Ｍパーサ論理サイズと同サイズ）
                                if (row != null) row.Cells[logicIndex + 6].Style.BackColor = SystemColors.Window;
                                if (logitm.LOGITM_DTTYPE != null && logitm.LOGITM_DTTYPE != string.Empty)
                                {
                                    string type = logitm.LOGITM_DTTYPE;

                                    if (CobolUtils.TypeCheck(type) == false || logitm.LOGITM_DTTYPE.Length > 60)
                                    {
                                        if (row != null) row.Cells[logicIndex + 6].Style.BackColor = Color.Red;
                                        Result = false;
                                        this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "コピー句データ形式", logitm.LOGITM_DTTYPE));
                                    }
                                    else
                                    {
                                        //Ｍパーサ論理サイズが設定されていたら、サイズが一致するか検定する
                                        if (logitm.LOGITM_DATALEN != null)
                                        {
                                            if (CobolUtils.GetSize(type) != logitm.LOGITM_DATALEN)
                                            {
                                                Result = false;
                                                if (row != null) row.Cells[logicIndex + 6].Style.BackColor = Color.Red;
                                                this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "コピー句データ形式", logitm.LOGITM_DTTYPE));
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    if (!string.IsNullOrEmpty(rowInfo.phyitm.PHYITM_CPYDTTYPE))
                                    {
                                        if (row != null) row.Cells[logicIndex + 6].Style.BackColor = Color.Red;
                                        Result = false;
                                        this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "コピー句データ形式", logitm.LOGITM_DTTYPE));
                                    }
                                }

                                //親の集団項目も存在するか検定する
                                if (row != null) row.Cells[logicIndex].Style.BackColor = SystemColors.Window;
                                node = listNode[rowIndex];
                                while (node.Parent != null)
                                {
                                    if (listRowInfo[listNode.IndexOf(node.Parent)].logitm[i] != null)
                                    {
                                        node = node.Parent;
                                    }
                                    else
                                    {
                                        Result = false;
                                        if (row != null) this.DataGridView.Rows[listNode.IndexOf(node.Parent)].Cells[logicIndex].Style.BackColor = Color.Red;
                                        this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "対象", "0"));
                                        break;
                                    }
                                }

                                node = new TreeNode();
                                node.Tag = rowInfo;
                                //レベルの比較
                                if (listLogicNode[i].Count > 0)
                                {
                                    int NodeIndex = listLogicNode[i].Count - 1;
                                    while (true)
                                    {
                                        if (rowInfo.phyitm.PHYITM_LEVEL > (listLogicNode[i][NodeIndex].Tag as RowInfo).phyitm.PHYITM_LEVEL)
                                        {
                                            listLogicNode[i][NodeIndex].Nodes.Add(node);
                                            break;
                                        }
                                        else
                                        {
                                            if (listLogicNode[i][NodeIndex].Parent != null)
                                            {
                                                NodeIndex = listLogicNode[i].IndexOf(listLogicNode[i][NodeIndex].Parent);
                                            }
                                            else
                                            {
                                                break;
                                            }
                                        }
                                    }
                                }
                                listLogicNode[i].Add(node);
                            }
                            else
                            {
                                //最上位項目がチェック無しはエラー
                                if(rowIndex == 0)
                                {
                                    if(cpylog[i] != null && string.IsNullOrEmpty(cpylog[i].CPYLGC_LCPID) == false)
                                    {
                                        Result = false;
                                        if (row != null) row.Cells[logicIndex].Style.BackColor = Color.Red;
                                        this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "対象", "0"));
                                    }
                                }
                            }
                            logicIndex += 7;
                        }
                    }
                }
                //親子関係検定
                rowIndex = 0;
                foreach (TreeNode node in listNode)
                {
                    //集団項目の時、子項目が存在しない
                    if(string.IsNullOrEmpty((node.Tag as RowInfo).phyitm.PHYITM_CPYDTTYPE) && node.Nodes.Count == 0)
                    {
                        Result = false;
                        if (this.DataGridView != null) this.DataGridView.Rows[rowIndex].Cells[0].Style.BackColor = Color.Red;
                        this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "レベル番号", (node.Tag as RowInfo).phyitm.PHYITM_LEVEL));
                    }
                    //子項目がある時、単項目となっている
                    if (node.Nodes.Count > 0 && string.IsNullOrEmpty((node.Tag as RowInfo).phyitm.PHYITM_CPYDTTYPE) == false)
                    {
                        Result = false;
                        if (this.DataGridView != null) this.DataGridView.Rows[rowIndex].Cells[0].Style.BackColor = Color.Red;
                        this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "レベル番号", (node.Tag as RowInfo).phyitm.PHYITM_LEVEL));
                    }
                    rowIndex++;
                }
                if (listLogicNode != null)
                {
                    for(int i = 0; i < listLogicNode.Length; i++)
                    {
                        rowIndex = 0;
                        foreach (TreeNode node in listLogicNode[i])
                        {
                            //集団項目の時、子項目が存在しない
                            if (string.IsNullOrEmpty((node.Tag as RowInfo).phyitm.PHYITM_CPYDTTYPE) && node.Nodes.Count == 0)
                            {
                                Result = false;
                                if (this.DataGridView != null) this.DataGridView.Rows[rowIndex].Cells[0].Style.BackColor = Color.Red;
                                this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "レベル番号", (node.Tag as RowInfo).phyitm.PHYITM_LEVEL));
                            }
                            //子項目がある時、単項目となっている
                            if (node.Nodes.Count > 0 && string.IsNullOrEmpty((node.Tag as RowInfo).phyitm.PHYITM_CPYDTTYPE) == false)
                            {
                                Result = false;
                                if (this.DataGridView != null) this.DataGridView.Rows[rowIndex].Cells[0].Style.BackColor = Color.Red;
                                this.logger.Error(string.Format(Resources.IF_LOG_CHECK_E, rowIndex, "レベル番号", (node.Tag as RowInfo).phyitm.PHYITM_LEVEL));
                            }
                            rowIndex++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                this.logger.Error(ex, string.Format(Resources.IF_LOG_ROWCHECK_E, rowIndex));
                return false;
            }

            return Result;
        }

        public int getPhysicSize()
        {
            List<TreeNode> listNode = new List<TreeNode>();

            for(int i = 0; i < this.DataGridView.Rows.Count; i++)
            {
                TreeNode node = new TreeNode();
                T_PHYITM phyitm = getPHYITMformDataGridView(i, false);
                
                node.Tag = phyitm;
                //親子関係の構築
                if (listNode.Count > 0)
                {
                    int NodeIndex = listNode.Count - 1;
                    while (true)
                    {
                        if (phyitm.PHYITM_LEVEL > (listNode[NodeIndex].Tag as T_PHYITM).PHYITM_LEVEL)
                        {
                            listNode[NodeIndex].Nodes.Add(node);
                            break;
                        }
                        else
                        {
                            if (listNode[NodeIndex].Parent != null)
                            {
                                NodeIndex = listNode.IndexOf(listNode[NodeIndex].Parent);
                            }
                            else
                            {
                                break;
                            }
                        }
                    }
                }
                listNode.Add(node);
            }
            //サイズの算出
            if (listNode.Count > 0)
            {
                return getGroupSize(listNode[0]);
            }
            return 0;
        }

        private int getGroupSize(TreeNode node)
        {
            int size = 0;
            int bitSize = 0;
            int bitCheckSize = 0;
            bool bitFlag = false;
            foreach (TreeNode childNode in node.Nodes)
            {
                int itemSize = 0;
                int itemBitSize = 0;
                if (string.IsNullOrEmpty((childNode.Tag as T_PHYITM).PHYITM_CPYDTTYPE))
                {
                    itemSize = getGroupSize(childNode);
                }
                else
                {
                    string pic;
                    int l = (childNode.Tag as T_PHYITM).PHYITM_CPYDTTYPE.IndexOf(" VALUE ");
                    if ( l >= 0)
                    {
                        pic = (childNode.Tag as T_PHYITM).PHYITM_CPYDTTYPE.Substring(0, l);
                    }
                    else
                    {
                        pic = (childNode.Tag as T_PHYITM).PHYITM_CPYDTTYPE;
                    }
                    if(pic.IndexOf(" BIT") >= 0)
                    {
                        itemBitSize = CobolUtils.GetSize(pic);
                        bitFlag = true;
                    }
                    else
                    {
                        if(bitFlag)
                        {
                            //補正
                            bitSize += 8 - (bitCheckSize % 8);
                            bitCheckSize = 0;
                        }
                        itemSize = CobolUtils.GetSize(pic);
                    }
                }
                if((childNode.Tag as T_PHYITM).PHYITM_OCCURS != null && (childNode.Tag as T_PHYITM).PHYITM_OCCURS > 1)
                {
                    itemSize *= (int)((childNode.Tag as T_PHYITM).PHYITM_OCCURS);
                    itemBitSize *= (int)((childNode.Tag as T_PHYITM).PHYITM_OCCURS);
                }
                size += itemSize;
                bitSize += itemBitSize;
                bitCheckSize += itemBitSize;
            }

            bitSize += 8 - (bitCheckSize % 8);
            size += bitSize / 8;

            return size;
        }
    }
}
