﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data;
using MarsTool.Models.DB;
using System.Transactions;
using System.Text.RegularExpressions;
using MarsTool.Properties;
using MarsTool.Daos;
using MarsTool.Exceptions;
using MarsTool.Common;
using MarsTool.Models;
using System.ComponentModel.DataAnnotations;

namespace MarsTool.Services
{
    class PhysicalCopyKuReadProcess
    {
        private NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        private VersionModel version;

        private CopyKuDBConnectivity dBConnectivity;

        public PhysicalCopyKuReadProcess(VersionModel v)
        {
            version = v;
            dBConnectivity = new CopyKuDBConnectivity(v);
        }

        /// <summary>
        ///コピー句ファイルの読み込み処理と登録処理
        /// </summary>
        /// <param name="inputPath"></param>
        /// <param name="subSysId"></param>
        /// <param name="infoId"></param>
        /// <param name="addressSize"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public Boolean CopyKuFileReadAndRegisterProcess(string inputPath, string infoId, string subSysId, string addressSize, string userId)
        {
            bool result = false;

            try
            {
                // ディレクトリを取得する。
                string copyKuId = Path.GetFileNameWithoutExtension(inputPath);

                PhysicalCopyKuInfo copyKu = dBConnectivity.SelectPhysicalCopyKuInfo(subSysId, infoId);

                if (copyKu.CPYPHY_STATUS == ConstantUtils.STATUS_DELELTE)
                {
                    logger.Error($"{version.User.USERID}" + Resources.CKR00013_E);
                    throw new CopyKuInfoReadProcessException(Resources.CKR00013_E);
                }

                if(copyKu.CPYPHY_Size == 0)
                {
                    int count = dBConnectivity.SelectPhysicalCopyKuID(copyKuId);

                    if (count == 1)
                    {
                        logger.Error($"{version.User.USERID}" + string.Format(Resources.CKR00014_E, copyKuId));
                        throw new CopyKuInfoReadProcessException(string.Format(Resources.CKR00014_E, copyKuId));
                    }
                }              

                //一ファイルずつ読み込む。
                string[] lines = File.ReadAllLines(inputPath, Encoding.GetEncoding("Shift_JIS"));

                PhysicalCopyKuInfo phyCopyKuInfo = CreatePhysicalCopyKuInfo(lines, copyKuId, infoId, subSysId, addressSize);

                if (phyCopyKuInfo != null)
                {
                    using (TransactionScope scope = new TransactionScope(TransactionScopeOption.RequiresNew))
                    {
                        TransactionOptions transactionOptions = new TransactionOptions();
                        transactionOptions.Timeout = TransactionManager.DefaultTimeout;
                        result = RegisterPhysicalCopyKuInfo(phyCopyKuInfo, copyKuId, userId);

                        scope.Complete();
                    }
                }
            }
            catch (CopyKuInfoReadProcessException e)
            {
                throw new CopyKuInfoReadProcessException(e.GetMessage(), e);
            }
            catch (Exception e)
            {
                //Log for unexpected error
                //想定外エラーが発生する場合、ログに記録
                logger.Error(e, $"{version.User.USERID}" + e.Message);

                //Throw Error CKR00099-E
                //CKR00099-E　エラーをスロー
                throw new CopyKuInfoReadProcessException(e.Message, e);
            }
            return result;
        }

        /// <summary>
        ///コピー句情報登録
        /// </summary>
        /// <param name="phyCopyKuInfo"></param>
        /// <param name="inputFileName"></param>        
        /// <param name="userId"></param>
        /// <returns></returns>
        private Boolean RegisterPhysicalCopyKuInfo(PhysicalCopyKuInfo phyCopyKuInfo, string inputFileName, string userId)
        {
            bool result = false;

            try
            {
                PhysicalCopyKuInfo copyKu = dBConnectivity.SelectPhysicalCopyKuInfo(phyCopyKuInfo.CPYPHY_SubSysId, phyCopyKuInfo.CPYPHY_InfoId);

                if (copyKu.CPYPHY_STATUS != ConstantUtils.STATUS_DELELTE)
                {
                    if (copyKu.CPYPHY_Size > 0)
                    {
                        List<PhysicalCopyKuItemInfo> dbItemInfos = dBConnectivity.SelectPhysicalCopyKuItemInfos(phyCopyKuInfo.CPYPHY_SubSysId, phyCopyKuInfo.CPYPHY_InfoId);

                        var list = phyCopyKuInfo.phyCpyItemInfoList;

                        if (dbItemInfos.Count > 0)
                        {
                            //不一致項目情報をログファイルに出力する。                        
                            for (int i = 0; i < dbItemInfos.Count; i++)
                            {
                                //var temp = (PhysicalCopyKuItemInfo)phyCopyKuInfo.phyCpyItemInfoList.Find(c => (c.PHYITM_Path == dbItem.PHYITM_Path) && (c.PHYITM_ItemNo == dbItem.PHYITM_ItemNo));

                                if (dbItemInfos[i].PHYITM_ItemNo == list[i].PHYITM_ItemNo)
                                {
                                    if (!dbItemInfos[i].PHYITM_ItemName.Equals(list[i].PHYITM_ItemName))
                                    {
                                        logger.Error($"{version.User.USERID}" + string.Format(Resources.CKR00008_E, inputFileName, "アイテム名称", list[i].PHYITM_ItemName, dbItemInfos[i].PHYITM_ItemName));
                                        throw new CopyKuInfoReadProcessException(string.Format(Resources.CKR00008_E, inputFileName, "アイテム名称", list[i].PHYITM_ItemName, dbItemInfos[i].PHYITM_ItemName));
                                    }

                                    if (!dbItemInfos[i].PHYITM_Level.Equals(list[i].PHYITM_Level))
                                    {
                                        logger.Error($"{version.User.USERID}" + string.Format(Resources.CKR00008_E, inputFileName, "レベル", list[i].PHYITM_Level, dbItemInfos[i].PHYITM_Level));
                                        throw new CopyKuInfoReadProcessException(string.Format(Resources.CKR00008_E, inputFileName, "レベル", list[i].PHYITM_ItemName, dbItemInfos[i].PHYITM_ItemName));
                                    }

                                    string temp1 = dbItemInfos[i].PHYITM_CPYDTTYPE.Trim().Replace("(0", "");
                                    string temp2 = list[i].PHYITM_CPYDTTYPE == null ? string.Empty : list[i].PHYITM_CPYDTTYPE.Trim().Replace("(0", "");

                                    if (!temp1.Equals(temp2))
                                    {
                                        logger.Error($"{version.User.USERID}" + string.Format(Resources.CKR00008_E, inputFileName, "コピー句データ形式", list[i].PHYITM_CPYDTTYPE, dbItemInfos[i].PHYITM_CPYDTTYPE));
                                        throw new CopyKuInfoReadProcessException(string.Format(Resources.CKR00008_E, inputFileName, "コピー句データ形式", list[i].PHYITM_ItemName, dbItemInfos[i].PHYITM_ItemName));
                                    }

                                    //if (!dbItem.PHYITM_ItemFlg.Equals(temp.PHYITM_ItemFlg))
                                    //{
                                    //    logger.Error($"{version.User.USERID}"+ string.Format(Resources.CKR00008_E, inputFileName, "アイテムフラグ", dbItem.PHYITM_ItemFlg, temp.PHYITM_ItemFlg));
                                    //    throw new CopyKuInfoReadProcessException(string.Format(Resources.CKR00008_E, inputFileName, "アイテムフラグ", dbItem.PHYITM_ItemName, temp.PHYITM_ItemName));
                                    //}                                   
                                }
                                else
                                {
                                    if (!dbItemInfos[i].PHYITM_ItemName.Equals(list[i].PHYITM_ItemName))
                                    {
                                        logger.Error($"{version.User.USERID}" + string.Format(Resources.CKR00008_E, inputFileName, "アイテム名称", dbItemInfos[i].PHYITM_ItemName, list[i].PHYITM_ItemName));
                                        throw new CopyKuInfoReadProcessException(string.Format(Resources.CKR00008_E, inputFileName, "アイテム名称", list[i].PHYITM_ItemName, dbItemInfos[i].PHYITM_ItemName));
                                    }
                                }
                                if (dbItemInfos.Count > list.Count)
                                {
                                    if (i == list.Count)
                                    {
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        phyCopyKuInfo.CPYPHY_UserId = userId;
                        // 物理コピー句情報をDBへデータを登録する。
                        dBConnectivity.insertPhyCopyKuInfo(phyCopyKuInfo);
                        // 物理コピー句アイテム情報をDBへデータを登録する。
                        foreach (PhysicalCopyKuItemInfo item in phyCopyKuInfo.phyCpyItemInfoList)
                        {
                            item.PHYITM_Seq = this.version.genSequenceID2("T_PHYITM");
                            dBConnectivity.insertPhyCopyKuItemInfo(item);
                        }
                    }
                    result = true;
                }
            }
            catch (CopyKuInfoReadProcessException e)
            {
                throw new CopyKuInfoReadProcessException(e.GetMessage(), e);
            }
            catch (Exception e)
            {
                //Log for unexpected error
                //想定外エラーが発生する場合、ログに記録
                logger.Error(e, $"{version.User.USERID}" + Resources.CKR00099_E);

                //Throw Error CKR00099-E
                //CKR00099-E　エラーをスロー
                throw new CopyKuInfoReadProcessException(Resources.CKR00099_E, e);
            }
            return result;
        }

        /// <summary>
        ///コピー句ファイルから物理コピー句情報取得
        /// </summary>
        /// <param name="lines"></param>
        /// <param name="copyKuId"></param>
        /// <param name="infoId"></param>
        /// <param name="subSysId"></param>
        /// <param name="addressSize"></param>
        /// <returns></returns>
        private PhysicalCopyKuInfo CreatePhysicalCopyKuInfo(String[] lines, string copyKuId, string infoId, string subSysId, string addressSize)
        {
            PhysicalCopyKuInfo phyCpyInfo = new PhysicalCopyKuInfo();
            List<PhysicalCopyKuItemInfo> phyCopyItemInfoList = new List<PhysicalCopyKuItemInfo>();
            try
            {
                string firstItem = null;
                bool isHeaderCmtEnd = false;
                bool isFirstitem = false;
                int count = 0;
                //List<String> pathList = new List<String>();
                StringBuilder builder = new StringBuilder();
                Dictionary<int, string> paths = new Dictionary<int, string>();
                StringBuilder lineBuilder = new StringBuilder();
                StringBuilder liBuilder = new StringBuilder();

                int i = 1;
                //一行ずつ読み込む。
                foreach (string line in lines.ToArray())
                {
                    if (line != string.Empty)
                    {
                        int len = line.Length;
                        string lin = line.Substring(6, len - 6);
                        string li = Regex.Replace(lin, @"\s+", "");

                        if (i == 1 && !lin.ToString().StartsWith("*") && isHeaderCmtEnd == false)
                        {
                            isHeaderCmtEnd = true;
                        }
                        if (li.StartsWith("COPY"))
                        {
                            logger.Error($"{version.User.USERID}" + string.Format(Resources.CKR00009_E, copyKuId));
                            throw new CopyKuInfoReadProcessException(string.Format(Resources.CKR00009_E, copyKuId));
                        }

                        if (li.Contains("REDEFINES"))
                        {
                            logger.Error($"{version.User.USERID}" + string.Format(Resources.CKR00007_E, copyKuId));
                            throw new CopyKuInfoReadProcessException(string.Format(Resources.CKR00007_E, copyKuId));
                        }

                        if (li.Contains("VALUE"))
                        {
                            logger.Error($"{version.User.USERID}" + string.Format(Resources.CKR00012_E, copyKuId));
                            throw new CopyKuInfoReadProcessException(string.Format(Resources.CKR00012_E, copyKuId));
                        }

                        if (lin.ToString().StartsWith("*") && isHeaderCmtEnd == false)
                        {
                            if (builder.Length > 0)
                            {
                                builder.Append("\n");
                            }
                            string cmt = lin.Substring(1, lin.Length - 1);
                            builder.Append(cmt);
                        }

                        if (!lin.Trim().StartsWith("*"))
                        {
                            isHeaderCmtEnd = true;
                        }

                        if (!li.StartsWith("*") && isHeaderCmtEnd == true && isFirstitem == false)
                        {
                            if (li.EndsWith("."))
                            {
                                if (lineBuilder.ToString() != string.Empty && liBuilder.ToString() != string.Empty)
                                {
                                    liBuilder.Append(li);
                                    lineBuilder.Append(lin);
                                    li = liBuilder.ToString().Substring(0, li.Length - 1);
                                    lin = lineBuilder.ToString();
                                }
                                else
                                {
                                    li = li.Substring(0, li.Length - 1);
                                }

                                PhysicalCopyKuItemInfo phyItemInfo = GetPhysicalCopyKuItemInfo(li, subSysId, infoId, count, copyKuId, lin);
                                phyCpyInfo.CPYPHY_LEVNO = phyItemInfo.PHYITM_Level;
                                phyItemInfo.PHYITM_Path = phyItemInfo.PHYITM_ItemName;
                                phyItemInfo.PHYITM_Level = ((phyItemInfo.PHYITM_Level - phyCpyInfo.CPYPHY_LEVNO) / 2) + 1;
                                phyCopyItemInfoList.Add(phyItemInfo);
                                paths.Add(phyItemInfo.PHYITM_Level, phyItemInfo.PHYITM_ItemName);
                                firstItem = phyItemInfo.PHYITM_ItemName;
                                isFirstitem = true;
                                lineBuilder.Clear();
                                liBuilder.Clear();
                                count++;
                            }
                            else
                            {
                                lineBuilder.Append(li);
                                liBuilder.Append(lin);
                            }
                        }
                        else if (li != String.Empty && !li.StartsWith("*") && isHeaderCmtEnd == true)
                        {
                            if (li.EndsWith("."))
                            {
                                if (lineBuilder.ToString() != string.Empty && liBuilder.ToString() != string.Empty)
                                {
                                    liBuilder.Append(li);
                                    lineBuilder.Append(lin);
                                    li = liBuilder.ToString().Substring(0, liBuilder.ToString().Length - 1);
                                    lin = lineBuilder.ToString();
                                }
                                else
                                {
                                    li = li.Substring(0, li.Length - 1);
                                }
                                PhysicalCopyKuItemInfo phyItemInfo = GetPhysicalCopyKuItemInfo(li, subSysId, infoId, count, copyKuId, lin);

                                if (phyItemInfo != null)
                                {
                                    int val = phyItemInfo.PHYITM_Level % 2;
                                    //レベルのチェック
                                    if (val != 0)
                                    {
                                        phyItemInfo.PHYITM_Level = ((phyItemInfo.PHYITM_Level - phyCpyInfo.CPYPHY_LEVNO) / 2) + 1;
                                        int lvl = phyItemInfo.PHYITM_Level;

                                        if (phyItemInfo.PHYITM_CPYDTTYPE == "ADDRESS")
                                        {
                                            if (addressSize != null)
                                            {
                                                phyItemInfo.Tmp_DTLEN = int.Parse(addressSize);
                                                string tempStr = phyItemInfo.PHYITM_CPYDTTYPE + " (" + addressSize + ")";
                                                phyItemInfo.PHYITM_CPYDTTYPE = tempStr;
                                            }
                                        }
                                        bool isRes = checkDatalengthData(phyItemInfo);
                                        if (isRes == false) throw new CopyKuInfoReadProcessException(string.Format("COBOLファイルの行{0}に項目の桁数が最大長以上にになっています。エラー内容はログファイルに確認してください。", line));
                                        //if (pathList.Count - 1 >= lvl)
                                        //{
                                        //    if (pathList[1] != null && (pathList.Count > 2 && pathList[2] != null) && lvl == 1)
                                        //    {
                                        //        pathList.RemoveRange(1, pathList.Count - 2);
                                        //    }
                                        //    pathList[lvl] = pathList[lvl - 1] + "_" + phyItemInfo.PHYITM_ItemNm;
                                        //}
                                        //else
                                        //{
                                        //    pathList.Add(pathList[lvl - 1] + "_" + phyItemInfo.PHYITM_ItemNm);
                                        //}

                                        if (paths.ContainsKey(lvl))
                                        {
                                            if (lvl == 1)
                                            {
                                                paths[lvl] = phyItemInfo.PHYITM_ItemName;
                                            }
                                            else
                                            {
                                                paths[lvl] = paths[lvl - 1] + "_" + phyItemInfo.PHYITM_ItemName;
                                            }
                                        }
                                        else
                                        {
                                            paths.Add(lvl, paths[lvl - 1] + "_" + phyItemInfo.PHYITM_ItemName);
                                        }
                                        phyItemInfo.PHYITM_Path = paths[lvl].ToString();


                                        if (phyItemInfo.PHYITM_ItemFlg == "0")
                                        {
                                            if (!phyItemInfo.PHYITM_CPYDTTYPE.Contains("ADDRESS"))
                                            {
                                                if (phyItemInfo.PHYITM_CPYDTTYPE.EndsWith(".") && phyItemInfo.PHYITM_CPYDTTYPE.IndexOf(".") > 0)
                                                {
                                                    phyItemInfo.PHYITM_CPYDTTYPE = phyItemInfo.PHYITM_CPYDTTYPE.Remove(phyItemInfo.PHYITM_CPYDTTYPE.IndexOf("."), 1);
                                                }
                                                int dataTypeAndLength = CobolUtils.GetSize(phyItemInfo.PHYITM_CPYDTTYPE);

                                                if (dataTypeAndLength != 0)
                                                {
                                                    phyItemInfo.Tmp_DTLEN = dataTypeAndLength;
                                                }


                                                if (CobolUtils.TypeCheck(phyItemInfo.PHYITM_CPYDTTYPE) == false)
                                                {
                                                    logger.Error($"{version.User.USERID}" + string.Format(Resources.CKR00011_E, line, "データ形式"));
                                                    throw new CopyKuInfoReadProcessException(string.Format(Resources.CKR00011_E, line, "データ形式"));
                                                }
                                            }
                                        }
                                        phyCopyItemInfoList.Add(phyItemInfo);
                                        count++;
                                    }
                                    else
                                    {
                                        logger.Error($"{version.User.USERID}" + string.Format(Resources.CKR00011_E, line, "レベル"));
                                        throw new CopyKuInfoReadProcessException(string.Format(Resources.CKR00011_E, line, "レベル"));
                                    }
                                }
                                lineBuilder.Clear();
                                liBuilder.Clear();
                            }
                            else
                            {
                                lineBuilder.Append(lin);
                                liBuilder.Append(li);

                                if (line.ToArray().Count() == i)
                                {
                                    if (lineBuilder.ToString() != string.Empty && liBuilder.ToString() != string.Empty)
                                    {
                                        logger.Error("コピー句ファイルの行「{0}」に「.」がありません。");
                                    }
                                }
                            }
                        }
                    }
                    i++;
                }
                int copyKuSize = getGroupSize(phyCopyItemInfoList);
                //bool isGrp = false;
                //string groupName = null;
                //int bitSize = 0;
                //int lv = 0;
                //foreach (PhysicalCopyKuItemInfo item in phyCopyItemInfoList)
                //{
                //    if (item.PHYITM_ItemFlg == "1")
                //    {
                //        lv = item.PHYITM_Level;
                //    }
                //    if (item.PHYITM_ItemFlg == "0" && item.PHYITM_CPYDTTYPE.Contains("BIT"))
                //    {
                //        string[] lst = item.PHYITM_Path.Split('_').ToArray();
                //        int cnt = lst.Count();
                //        if (cnt >= 2)
                //        {
                //            if (isGrp == false)
                //            {
                //                groupName = lst[cnt - 2].ToString();
                //                lv = item.PHYITM_Level;
                //                isGrp = true;
                //                bitSize += item.Tmp_DTLEN;
                //            }
                //            else
                //            {
                //                string gpNm = lst[cnt - 2].ToString();
                //                if (groupName != null && isGrp == true && groupName == gpNm)
                //                {
                //                    bitSize += item.Tmp_DTLEN;
                //                }
                //            }
                //        }
                //    }
                //    else
                //    {
                //        if (lv >= item.PHYITM_Level && bitSize != 0)
                //        {
                //            int div = bitSize / 8;
                //            if (div == 0)
                //            {
                //                copyKuSize += div;
                //                bitSize = 0;
                //                groupName = null;
                //            }
                //            else
                //            {
                //                copyKuSize += div;
                //                bitSize = 0;
                //                groupName = null;
                //                isGrp = false;
                //            }
                //        }
                //        else
                //        {
                //            copyKuSize += item.Tmp_DTLEN;
                //        }
                //    }
                //    //if (item.PHYITM_ItemFlg.Equals("0"))
                //    //{
                //    //    if (item.PHYITM_Level < level || item.PHYITM_Level == level)
                //    //    {
                //    //        gpSize += item.PHYITM_DTLEN;
                //    //    }
                //    //    else
                //    //    {
                //    //        copyKuSize += gpSize;
                //    //        gpSize = 0;
                //    //        gpSize += item.PHYITM_DTLEN;
                //    //    }
                //    //    level = item.PHYITM_Level;
                //    //    tempList.Add(item);
                //    //}
                //    //else
                //    //{
                //    //    if (item.PHYITM_ItemFlg.Equals("1"))
                //    //    {
                //    //        if (item.PHYITM_Occurs != 0)
                //    //        {
                //    //            gpSize = gpSize * item.PHYITM_Occurs;
                //    //        }
                //    //        item.PHYITM_DTLEN = gpSize;
                //    //        tempList.Add(item);
                //    //        level = item.PHYITM_Level;
                //    //    }
                //    //}
                //}
                phyCpyInfo.phyCpyItemInfoList = phyCopyItemInfoList;
                phyCpyInfo.CPYPHY_InfoId = infoId;
                phyCpyInfo.CPYPHY_SubSysId = subSysId;
                phyCpyInfo.CPYPHY_BcpId = copyKuId;
                phyCpyInfo.CPYPHY_BcpNm = firstItem;
                phyCpyInfo.CPYPHY_Comment = builder.ToString();
                phyCpyInfo.CPYPHY_Size = copyKuSize;
            }
            catch (CopyKuInfoReadProcessException e)
            {
                throw new CopyKuInfoReadProcessException(e.GetMessage(), e);
            }
            catch (Exception e)
            {
                logger.Error(e, $"{version.User.USERID}" + string.Format(Resources.CKR00004_E, copyKuId));

                throw new CopyKuInfoReadProcessException(string.Format(Resources.CKR00004_E, copyKuId), e);
            }
            return phyCpyInfo;
        }

        /// <summary>
        ///コピー句ファイルから物理アイテム情報取得
        /// </summary>
        /// <param name="line"></param>
        /// <param name="subSysId"></param>
        /// <param name="infoId"></param>
        /// <param name="count"></param>
        /// <param name="copyKuId"></param>
        /// <param name="li"></param>
        /// <returns></returns>
        private PhysicalCopyKuItemInfo GetPhysicalCopyKuItemInfo(string line, string subSysId, string infoId, int count, string copyKuId, string li)
        {
            PhysicalCopyKuItemInfo itemInfo = null;
            try
            {
                //Get PhysicalItemInfo
                string level = null;
                string itemName = null;
                string occurs = null;
                string itemFlg = null;
                int endIndex = 0;
                string copyDTType = null;

                if (line != String.Empty)
                {
                    itemInfo = new PhysicalCopyKuItemInfo();
                    if (!line.StartsWith("*"))
                    {
                        level = line.Substring(0, 2);

                        if (line.Contains("PIC") || line.Contains("ADDRESS"))
                        {
                            itemFlg = "0";
                            if (line.Contains("ADDRESS"))
                            {
                                endIndex = line.IndexOf("ADDRESS") - level.Length;
                                int len = li.Length - li.IndexOf("ADDRESS");
                                copyDTType = li.Substring(li.IndexOf("ADDRESS"), len - 1);
                            }

                            if (line.Contains("PIC"))
                            {
                                endIndex = line.IndexOf("PIC") - level.Length;

                                int picIndex = li.IndexOf("PIC") + 3;
                                int len = li.Length - picIndex;
                                copyDTType = li.Substring(picIndex, len - 1).TrimEnd();

                                //if (line.Contains("S9"))
                                //{
                                //    int len = li.Length - li.IndexOf("S9");
                                //    copyDTType = li.Substring(li.IndexOf("S9"), len - 1).TrimEnd();
                                //}

                                //if (line.Contains("Z9"))
                                //{
                                //    int len = li.Length - li.IndexOf("Z9");
                                //    copyDTType = li.Substring(li.IndexOf("Z9"), len - 1).TrimEnd();
                                //}

                                //if (line.Substring(line.IndexOf("PIC") + 3, 1) == "X")
                                //{
                                //    int picIndex = li.IndexOf("PIC") + 3;
                                //    int len = li.Length - picIndex;
                                //    copyDTType = li.Substring(picIndex, len - 1).TrimEnd();
                                //}

                                //if (line.Substring(line.IndexOf("PIC") + 3, 1) == "9")
                                //{
                                //    int picIndex = li.IndexOf("PIC") + 3;
                                //    int len = li.Length - picIndex;
                                //    copyDTType = li.Substring(picIndex, len - 1).TrimEnd();
                                //}

                                //if (line.Substring(line.IndexOf("PIC") + 3, 1) == "1")
                                //{
                                //    int picIndex = li.IndexOf("PIC") + 3;
                                //    int len = li.Length - picIndex;
                                //    copyDTType = li.Substring(picIndex, len - 1).TrimEnd();
                                //}
                            }

                            if (copyDTType.Contains("OCCURS"))
                            {
                                int idx = line.IndexOf("OCCURS") + 6;
                                occurs = line.Substring(idx, line.Length - idx);
                                string tmp = copyDTType.Substring(0, copyDTType.IndexOf("OCCURS"));
                                copyDTType = tmp.TrimEnd();
                            }
                            itemName = line.Substring(2, endIndex);
                        }
                        else
                        {
                            if (line.Contains("OCCURS"))
                            {
                                int idx = line.IndexOf("OCCURS") + 6;
                                occurs = line.Substring(idx, line.Length - idx);
                                itemName = line.Substring(2, line.IndexOf("OCCURS") - level.Length);
                            }
                            else
                            {
                                itemName = line.Substring(2, line.Length - level.Length);
                            }
                            itemFlg = "1";
                        }
                    }
                    itemInfo.PHYITM_InfoId = infoId;
                    itemInfo.PHYITM_SubSysId = subSysId;
                    itemInfo.PHYITM_Level = level.StartsWith("0") ? int.Parse(level.Remove(0, 1)) : int.Parse(level);
                    itemInfo.PHYITM_ItemName = itemName;
                    itemInfo.PHYITM_Occurs = occurs == null ? 0 : int.Parse(occurs);
                    itemInfo.PHYITM_ItemFlg = itemFlg;
                    itemInfo.PHYITM_ItemNo = count;
                    itemInfo.PHYITM_CPYDTTYPE = copyDTType == null ? string.Empty : copyDTType.TrimStart();
                }
            }
            catch (Exception e)
            {
                logger.Error(e, $"{version.User.USERID}" + string.Format(Resources.CKR00004_E, copyKuId));

                throw new CopyKuInfoReadProcessException(string.Format(Resources.CKR00004_E, copyKuId), e);

            }
            return itemInfo;
        }

        public bool checkDatalengthData(PhysicalCopyKuItemInfo itemInfo)
        {
            var validator = new ValidationContext(itemInfo, null, null);
            List<ValidationResult> valres = new List<ValidationResult>();
            bool isVal = Validator.TryValidateObject(itemInfo, validator, valres, true);

            if (valres.Count > 0 && isVal == false)
            {
                foreach (ValidationResult val in valres)
                {
                    logger.Error($"{version.User.USERID}" + val.ErrorMessage);
                    throw new CopyKuInfoReadProcessException(val.ErrorMessage);

                }
            }
            return isVal;
        }

        private int getGroupSize(List<PhysicalCopyKuItemInfo> phyCopyItemInfoList)
        {
            int size = 0;
            int bitSize = 0;
            int bitCheckSize = 0;
            bool bitFlag = false;
            foreach (PhysicalCopyKuItemInfo item in phyCopyItemInfoList)
            {
                int itemSize = 0;
                int itemBitSize = 0;

                if (item.PHYITM_CPYDTTYPE != string.Empty)
                {
                    if (item.PHYITM_CPYDTTYPE.Contains("BIT"))
                    {
                        itemBitSize = item.Tmp_DTLEN;
                        bitFlag = true;
                    }
                    else
                    {
                        if (bitFlag)
                        {
                            //補正
                            bitSize += 8 - (bitCheckSize % 8);
                            bitCheckSize = 0;
                            bitFlag = false;
                        }
                        else
                        {
                            if(bitSize > 0)
                            {
                                size += bitSize / 8;
                                bitSize = 0;                      
                            }                          
                        }
                        itemSize = item.Tmp_DTLEN;
                    }
                    if (item.PHYITM_Occurs != 0 && item.PHYITM_Occurs > 1)
                    {
                        itemSize *= item.PHYITM_Occurs;
                        itemBitSize *= item.PHYITM_Occurs;
                    }
                }
                size += itemSize;
                bitSize += itemBitSize;
                bitCheckSize += itemBitSize;
            }
            bitSize += 8 - (bitCheckSize % 8);
            size += bitSize / 8;
            return size;
        }
    }
}