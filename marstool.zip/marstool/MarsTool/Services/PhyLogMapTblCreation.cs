﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.IO;
using System.Data;
using System.Windows.Forms;
using System.Threading.Tasks;
using MarsTool.Models;
using MarsTool.Properties;
using MarsTool.Exceptions;
using MarsTool.Common;
using MarsTool.Daos;
using Excel = Microsoft.Office.Interop.Excel;

namespace MarsTool.Services
{
    class PhyLogMapTblCreation
    {
        #region public Method
        private static PhyLogMapTblCreation instance;
        private VersionModel ver;

        public PhyLogMapTblCreation(VersionModel v)
        {
            ver = v;
        }
        public static PhyLogMapTblCreation getInstance(VersionModel v)
        {
            if (instance == null)
            {
                instance = new PhyLogMapTblCreation(v);
            }
            return instance;
        }
        /// <summary>
        /// Export Data to Excel.<br/>
        /// データをエクセルにエクスポート<br/>
        /// </summary>
        /// <param name="copyClauseID">
        /// copyClauseID is used to find Mapping Data.<br/>
        /// マッピングデータを検索するため、copyClauseIDを利用<br/>
        /// </param>
        /// <param name="copyClauseName">
        /// copyClauseName is used to find Mapping Data.<br/>
        /// マッピングデータを検索するため、copyClauseName　を使用<br/>
        /// </param>
        /// <param name="logSubSysID">
        /// logSubSysID is used to find Mapping Data.<br/>
        /// マッピングデータを検索するため、logSubSysID　を使用<br/>
        /// </param>
        /// <param name="outputPath">
        /// output file path<br/>
        /// 出力ファイルパス<br/>
        /// </param>
        /// <exception cref="PhysicalLogicalMappingException">
        /// Throw exception if exception occurs.<br/>
        /// 例外が発生する場合、例外をスロー<br/>
        /// </exception>
        /// <remarks>
        /// 2018/05/22 修正<br/>
        /// </remarks>
        public bool CreateMappingTable(string copyClauseID, string copyClauseName, string logSubSysID, string outputPath)
        {
            bool isExport = false;

            PhysicalLogicalMappingModel phyLogMap = new PhysicalLogicalMappingModel();
            phyLogMap.Cpyphy_bcpid = copyClauseID;
            phyLogMap.Cpyphy_bcpnm = copyClauseName;
            phyLogMap.Logitm_subsysidl = logSubSysID;

            //Get Mapping Data from Database
            //データベースからマッピングデータを取得
            PhyLogMappingDBConnectivity.getInstance(ver).SeletDataFromDb(phyLogMap);
            try
            {
                //Check Data is empty or not
                //データは空であるかチェック
                if (string.IsNullOrEmpty(phyLogMap.Cpyphy_subsysid))
                {
                    //Log for no data found.
                    //データは見つからない場合、ログに記録
                    LogUtils.WriteLogInfo(ver.User.USERID, Resources.PLM00004_E, LogUtils.GetMsgType(ConstantUtils.PLM00004_E));

                    return false;
                }
                //Check Physical Information is empty or not
                //物理情報は空であるかチェック
                else if (phyLogMap.phyItmInfoList.Count == 0)
                {
                    //Log for Physical information doesn't exist.
                    //物理情報は存在しない場合、ログに記録
                    LogUtils.WriteLogInfo(ver.User.USERID, Resources.PLM00005_E, LogUtils.GetMsgType(ConstantUtils.PLM00005_E));

                    return false;
                }
                //Check Logical Infomation is empty or not
                //論理情報は空であるかチェック
                else if (!phyLogMap.phyItmInfoList.Any(x => x.logicalOperation.Cpylgc_opnm != string.Empty)
                    && !phyLogMap.phyItmInfoList.Any(x => x.logicalOperation.Cpylgc_lcpid != string.Empty))
                {
                    //Log for logical information doesn't exist.
                    //論理情報は存在しない場合、ログに記録
                    LogUtils.WriteLogInfo(ver.User.USERID, Resources.PLM00006_E, LogUtils.GetMsgType(ConstantUtils.PLM00006_E));

                    return false;
                }
                else
                {
                    //log for finishing data acquisition
                    //データの取得は終了する場合、ログに記録
                    LogUtils.WriteLogInfo(ver.User.USERID, Resources.PLM00001_I, LogUtils.GetMsgType(ConstantUtils.PLM00001_I));

                    object[,] headerArr = ConvertHeaderDataTo2DArray(phyLogMap.phyItmInfoList);

                    object[,] dataArr = ConvertDataTo2DArray(phyLogMap.phyItmInfoList, headerArr);

                    phyLogMap.phyItmInfoList.Clear();
                    //Export Data to excel
                    //データをエクセルにエクスポート
                    ExportToExcel(headerArr, dataArr, outputPath, phyLogMap);
                    isExport = true;
                    phyLogMap = null;
                    headerArr = null;
                    dataArr = null;
                }
            }
            catch (PhysicalLogicalMappingException e)
            {
                //Throw Error 
                //エラーをスロー
                throw new PhysicalLogicalMappingException(e.GetMessage());
            }
            catch (Exception e)
            {
                //Log for unexpected error
                //想定外エラーが発生する場合、ログに記録
                LogUtils.WriteLogInfo(ver.User.USERID, LogUtils.GetMsgInfo(Resources.PLM00099_E, e.Message), LogUtils.GetMsgType(ConstantUtils.PLM00099_E), e);

                //Throw Error PLM00099_E
                //PLM00099_E　エラーをスロー
                throw new PhysicalLogicalMappingException(LogUtils.GetMsgInfo(Resources.PLM00099_E, e.Message), e);
            }

            return isExport;
        }

        #endregion

        #region private method

        /// <summary>
        /// Convert header data to two dimensional array.<br/>
        /// ヘッダデータを二次元配列に変換<br/>
        /// </summary>
        /// <param name="physicalInfoList">
        /// Get header data<br/>
        /// ヘッダデータを取得<br/>
        /// </param>
        /// <exception cref="PhysicalLogicalMappingException">
        /// Throw exception if exception occurs.<br/>
        /// 例外が発生する場合、例外をスロー<br/>
        /// </exception>
        /// <returns>
        /// Return header value with two dimensional arrray according to input parameter list.<br/>
        /// 入力パラメータ一覧により、ヘッダ値を二次元配列で返す<br/>
        /// </returns>
        /// <remarks>
        /// 2018/05/22 新規作成<br/>
        /// </remarks>
        private object[,] ConvertHeaderDataTo2DArray(List<PhysicalLogicalItmInfoModel> physicalInfoList)
        {
            object[,] headerArr = null;
            try
            {
                //Get Operation List
                //操作リストを取得
                List<PhysicalLogicalOperationModel> operationList = physicalInfoList.Select(x => x.logicalOperation).ToList();

                //Get Unique Operation Information
                //ユニーク操作情報を取得
                List<PhysicalLogicalOperationModel> uniOperationInfoList = operationList.Where(o => o.Cpylgc_lcpid != string.Empty)
                                                                    .GroupBy(p => p.Cpylgc_lcpid)
                                                                    .Select(g => g.First())
                                                                    .OrderBy(x => x.Cpylgc_outputorder)
                                                                    .ToList();

                headerArr = new object[2, uniOperationInfoList.Count];

                //Prepare column data
                //列のデータを準備
                for (int i = 0; i < uniOperationInfoList.Count; i++)
                {
                    headerArr[0, i] = uniOperationInfoList[i].Cpylgc_opnm;
                    headerArr[1, i] = uniOperationInfoList[i].Cpylgc_lcpid;
                }
            }
            catch (Exception e)
            {
                //Log for unexpected error
                //想定外のエラーが発生する場合、ログに記録
                LogUtils.WriteLogInfo(ver.User.USERID, LogUtils.GetMsgInfo(Resources.PLM00099_E, e.Message), LogUtils.GetMsgType(ConstantUtils.PLM00099_E), e);

                //Throw Error PLM00099_E
                //PLM00099_E　エラーをスロー
                throw new PhysicalLogicalMappingException(LogUtils.GetMsgInfo(Resources.PLM00099_E, e.Message), e);
            }
            return headerArr;
        }

        /// <summary>
        /// Convert Mapping data to two dimensional array.<br/>
        /// マッピングデータを二次元配列に変換<br/>
        /// </summary>
        /// <param name="physicalInfoList">
        /// Get Physical Logical Mapping data.<br/>
        /// 物理論理マッピングデータを取得<br/>
        /// </param>
        /// <param name="headerArr">
        /// To map mapping data of operation ID and header of operation ID.<br/>
        /// 操作IDのマッピングデータと操作IDのヘッダをマップ<br/>
        /// </param>
        /// <exception cref="PhysicalLogicalMappingException">
        /// Throw exception if exception occurs.<br/>
        /// 例外が発生する場合、例外をスロー<br/>
        /// </exception>
        /// <returns>
        /// Return Physical Logical  Mapping value with two dimensional arrray according to input parameter list.<br/>
        /// 入力パラメータ一覧により、物理論理マッピング値を二次元配列で返す<br/>
        /// </returns>
        /// <remarks>
        /// 2018/05/22 修正<br/>
        /// </remarks>
        private object[,] ConvertDataTo2DArray(List<PhysicalLogicalItmInfoModel> physicalInfoList, object[,] headerArr)
        {
            object[,] dataArr = null;
            try
            {
                //Get Unique Info.
                //ユニーク情報を取得
                List<PhysicalLogicalItmInfoModel> uniMappingList = physicalInfoList
                                                            .GroupBy(x => new
                                                            {
                                                                x.Phyitm_seq
                                                            })
                                                            .Select(o => o.FirstOrDefault())
                                                            .ToList();

                dataArr = new object[uniMappingList.Count, headerArr.GetLength(1) + ConstantUtils.LOGDATASTART_COL];

                //Prepare data to export
                //エクスポートするため、データを準備
                for (int j = 0; j < uniMappingList.Count; j++)
                {
                    dataArr[j, 0] = j + 1;
                    dataArr[j, 1] = uniMappingList[j].Phyitm_itemnm;
                    dataArr[j, 2] = uniMappingList[j].Phyitm_dttype;
                    dataArr[j, 3] = uniMappingList[j].Phyitm_dtlen;
                    dataArr[j, 4] = uniMappingList[j].Phyitm_occurs;

                    uniMappingList[j].logicalOperationIDList = physicalInfoList
                                                                .Where(w => w.Phyitm_seq == uniMappingList[j].Phyitm_seq)
                                                                .Select(s => s.logicalOperation.Cpylgc_lcpid)
                                                                .ToList();

                    for (int l = 0; l < headerArr.GetLength(1); l++)
                    {
                        if (uniMappingList[j].logicalOperationIDList.Contains(headerArr[1, l].ToString()))
                        {
                            dataArr[j, l + 5] = ConstantUtils.MARU;
                        }
                        else
                        {
                            dataArr[j, l + 5] = ConstantUtils.DASH;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                //Log for unexpected error
                //想定外のエラーが発生する場合、ログに記録
                LogUtils.WriteLogInfo(ver.User.USERID, LogUtils.GetMsgInfo(Resources.PLM00099_E, e.Message), LogUtils.GetMsgType(ConstantUtils.PLM00099_E), e);

                //Throw Error PLM00099_E
                //PLM00099_E　エラーをスロー
                throw new PhysicalLogicalMappingException(LogUtils.GetMsgInfo(Resources.PLM00099_E, e.Message), e);
            }
            return dataArr;
        }

        /// <summary>
        /// To Export mapping data to excel.<br/>
        /// マッピングデータをエクセルにエクスポート<br/>
        /// </summary>
        /// <param name="headerArr">
        /// Get header data<br/>
        /// ヘッダデータを取得<br/>
        /// </param>
        /// <param name="dataArr">
        /// Get physical logical mapping data.<br/>
        /// 物理論理マッピングデータを取得<br/>
        /// </param>
        /// <param name="outputPath">
        /// Excel file output path.<br/>
        /// エクセルファイル出力パス<br/>
        /// </param>
        /// <param name="phyLogMap">
        /// phyLogMap is used to get copy clause ID,copy clause name and logical sub system id.<br/>
        /// phyLogMapはコピー句ID、コピー句名と論理サブシステムIDを取得するために使用する。<br/>
        /// </param>
        /// <exception cref="PhysicalLogicalMappingException">
        /// Throw exception if exception occurs.<br/>
        /// 例外が発生する場合、例外をスロー<br/>
        /// </exception>
        /// <remarks>
        /// 2018/05/22 新規作成<br/>
        /// </remarks>
        private void ExportToExcel(object[,] headerArr, object[,] dataArr, string outputPath, PhysicalLogicalMappingModel phyLogMap)
        {
            Excel.Application xlApp = null;
            Excel.Workbook xlWorkBook = null;
            Excel.Worksheet xlWorkSheet = null;
            Boolean isSheetExists = false;
            try
            {
                xlApp = new Excel.Application();
                xlApp.DisplayAlerts = false;
                xlApp.Visible = false;

                string templateFilePath = Application.StartupPath + Path.DirectorySeparatorChar + ConstantUtils.TEMPLATE_FILENAME_1;

                //Check Template file exists or not
                //テンプレートファイルは存在するかチェック
                if (!File.Exists(templateFilePath))
                {
                    //Log for template file is not exists.
                    //テンプレートファイルは存在しない場合、ログに記録
                    LogUtils.WriteLogInfo(ver.User.USERID, LogUtils.GetMsgInfo(Resources.PLM00008_E, ConstantUtils.TEMPLATE_FILENAME_1), LogUtils.GetMsgType(ConstantUtils.PLM00008_E));

                    //Throw Error PLM00008_E
                    //PLM00008_E　エラーをスロー
                    throw new PhysicalLogicalMappingException(LogUtils.GetMsgInfo(Resources.PLM00008_E, ConstantUtils.TEMPLATE_FILENAME_1));
                }

                xlWorkBook = xlApp.Workbooks.Open(templateFilePath);

                //Check template sheet is exists or not
                //テンプレートシートは存在するかチェック
                foreach (Excel.Worksheet sheet in xlWorkBook.Sheets)
                {
                    // Check the name of the current sheet
                    //現在のシートの名称をチェック
                    if (sheet.Name == ConstantUtils.SHEETNAME_2)
                    {
                        isSheetExists = true;
                        break;
                    }
                }

                if (!isSheetExists)
                {
                    //Log for template sheet doesn't exists
                    //テンプレートシートは存在しない場合、ログに記録
                    LogUtils.WriteLogInfo(ver.User.USERID, LogUtils.GetMsgInfo(Resources.PLM00009_E, ConstantUtils.SHEETNAME_2), LogUtils.GetMsgType(ConstantUtils.PLM00009_E));

                    //Throw Error PLM00009_E
                    //PLM00009_E　エラーをスロー
                    throw new PhysicalLogicalMappingException(LogUtils.GetMsgInfo(Resources.PLM00009_E, ConstantUtils.SHEETNAME_2));
                }

                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(ConstantUtils.SHEETNAME_2);

                //Set Name to sheet Name
                //名称をシート名に設定
                xlWorkSheet.Name = phyLogMap.Cpyphy_bcpnm.Length < ConstantUtils.MAX_SHEETNAME_LENGTH_1 ?
                                   phyLogMap.Cpyphy_bcpnm : phyLogMap.Cpyphy_bcpnm.Substring(0, ConstantUtils.MAX_SHEETNAME_LENGTH_1);

                xlWorkSheet.Range[ConstantUtils.PHYSYSID_CELL].Value = phyLogMap.Cpyphy_subsysid;
                xlWorkSheet.Range[ConstantUtils.LOGSYSID_CELL].Value = phyLogMap.Logitm_subsysidl;
                xlWorkSheet.Range[ConstantUtils.COPYCLAUSEID_CELL].Value = phyLogMap.Cpyphy_bcpid;
                xlWorkSheet.Range[ConstantUtils.COPYCLAUSENAME_CELL].Value = phyLogMap.Cpyphy_bcpnm;

                Excel.Range headerRng = xlWorkSheet.Range[xlWorkSheet.Cells[ConstantUtils.DATASTART_ROW_3, ConstantUtils.DATASTART_COL_1 + ConstantUtils.LOGDATASTART_COL],
                                                          xlWorkSheet.Cells[ConstantUtils.DATASTART_ROW_3 + 1, ConstantUtils.LOGDATASTART_COL + headerArr.GetLength(1)]];

                Excel.Range dataRng = xlWorkSheet.Range[xlWorkSheet.Cells[ConstantUtils.DATASTART_ROW_3 + 2, 1], xlWorkSheet.Cells[dataArr.GetLength(0) + ConstantUtils.DATASTART_ROW_3 + 1, dataArr.GetLength(1)]];

                Excel.Range sizeRng = xlWorkSheet.Range[ConstantUtils.SIZE_COL + (ConstantUtils.DATASTART_ROW_3 + 2), ConstantUtils.SIZE_COL + (dataArr.GetLength(0) + ConstantUtils.DATASTART_ROW_3 + 2).ToString()];

                sizeRng.NumberFormat = "@";
                sizeRng.Cells.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

                xlWorkSheet.Range[ConstantUtils.SAMPLE_CELLADD_1].Copy();
                headerRng.PasteSpecial(Excel.XlPasteType.xlPasteFormats);
                headerRng.UnMerge();

                headerRng.Value = headerArr;
                dataRng.Value = dataArr;

                xlWorkSheet.Range[headerRng, dataRng].Borders.get_Item(Excel.XlBordersIndex.xlInsideHorizontal).LineStyle = Excel.XlLineStyle.xlContinuous;
                xlWorkSheet.Range[headerRng, dataRng].Borders.get_Item(Excel.XlBordersIndex.xlInsideVertical).LineStyle = Excel.XlLineStyle.xlContinuous;
                xlWorkSheet.Range[headerRng, dataRng].BorderAround2(Excel.XlLineStyle.xlContinuous);

                xlWorkSheet.UsedRange.Style.Font.Name = ConstantUtils.FONTNAME;

                headerRng.Columns.AutoFit();

                //Set WrapText to ItemName Column
                //項目名列に「折り返して全体を表示する」に設定
                xlWorkSheet.Range[xlWorkSheet.Cells[ConstantUtils.DATASTART_ROW_3 + 2, ConstantUtils.DATASTART_COL_1 + 1],
                                  xlWorkSheet.Cells[dataArr.GetLength(0) + ConstantUtils.DATASTART_ROW_3 + 1, ConstantUtils.DATASTART_COL_1 + 1]]
                           .Cells.WrapText = true;

                xlWorkSheet.Range[xlWorkSheet.Cells[ConstantUtils.DATASTART_ROW_3, ConstantUtils.ATTRIBUTE_COL],
                                 xlWorkSheet.Cells[dataArr.GetLength(0) + ConstantUtils.DATASTART_ROW_3 + 1, dataArr.GetLength(1)]]
                           .Cells.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

                string fileName = DateTime.Now.ToString(ConstantUtils.DATETIMEFORMAT) + "_" + ConstantUtils.OUTPUTFILENAME_2 + "（" + phyLogMap.Cpyphy_bcpnm + "）.xlsx";

                //Check end of output file path is path separator.
                //出力ファイルパスの終わりがパスセパレータかチェック
                if (!outputPath.EndsWith(Path.DirectorySeparatorChar.ToString()))
                {
                    outputPath += Path.DirectorySeparatorChar;
                }
                xlWorkSheet.Cells[1, 1].Select();
                xlWorkBook.SaveAs(outputPath + fileName);

                //Log for File Export is success
                //ファイルエクスポートは成功する時、ログに記録
                LogUtils.WriteLogInfo(ver.User.USERID, LogUtils.GetMsgInfo(Resources.PLM00002_I, fileName), LogUtils.GetMsgType(ConstantUtils.PLM00002_I));
            }
            catch (PhysicalLogicalMappingException e)
            {
                //Throw Error 
                //エラーをスロー
                throw new PhysicalLogicalMappingException(e.GetMessage());
            }
            catch (Exception e)
            {
                //log for File Export is failed
                //ファイルエクスポートは失敗する時、ログに記録
                LogUtils.WriteLogInfo(ver.User.USERID, LogUtils.GetMsgInfo(Resources.PLM00007_E, e.Message), LogUtils.GetMsgType(ConstantUtils.PLM00007_E), e);

                //Throw Error PLM00007_E
                //PLM00007_E　エラーをスロー
                throw new PhysicalLogicalMappingException(LogUtils.GetMsgInfo(Resources.PLM00007_E, e.Message), e);
            }
            finally
            {
                //Close Work book
                //ワークブックを閉じる
                if (xlWorkSheet != null)
                {
                    Marshal.ReleaseComObject(xlWorkSheet);
                }

                if (xlWorkBook != null)
                {
                    xlWorkBook.Close(Type.Missing, Type.Missing, Type.Missing);
                    Marshal.ReleaseComObject(xlWorkBook);
                }

                if (xlApp != null)
                {
                    xlApp.Quit();
                    Marshal.ReleaseComObject(xlApp);
                }

                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }

        #endregion
    }
}
