﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MarsTool.Common;
using MarsTool.Common.Forms;
using MarsTool.Properties;
using MarsTool.Services;

namespace MarsTool.Services
{
    /// <summary>
    /// アイテム構成図／アイテム説明書・プレビュー画面／ファイル出力
    /// </summary>
    class SheetShowPreview
    {
        #region 列挙体
        /// <summary>
        /// プレビュータイプ
        /// </summary>
        public enum PreviewType
        {
            /// <summary>
            /// アイテム構成図
            /// </summary>
            ItemStructImage,
            /// <summary>
            /// アイテム説明書
            /// </summary>
            ItemSheet
        };

        /// <summary>
        /// アイテム種別
        /// </summary>
        private enum ItemType
        {
            /// <summary>デバッグ用</summary>
            Debug,
            /// <summary>アイテム構成図・バイト位置</summary>
            ByteNum,
            /// <summary>アイテム構成図・項目名称</summary>
            ItemName,
            /// <summary>アイテム構成図・項目矢印</summary>
            ItemArrow,
            /// <summary>アイテム構成図・項目の境界線</summary>
            SplitLine,
            /// <summary>アイテム構成図・集団項目名称</summary>
            GroupName,
            /// <summary>アイテム構成図・集団項目開始矢印</summary>
            GroupStart,
            /// <summary>アイテム構成図・集団項目終端矢印</summary>
            GroupEnd,
            /// <summary>アイテム構成図・集団項目中間線</summary>
            GroupLine,
            /// <summary>レコード名称</summary>
            RecordName,
            /// <summary>アイテム構成図・予備項目</summary>
            Yobi,
            /// <summary>アイテム構成図・終端線</summary>
            EndLine,
            /// <summary>アイテム構成図・終端のサイズ</summary>
            EndSize,
            /// <summary>アイテム説明書・項番</summary>
            SheetNo,
            /// <summary>アイテム説明書・レベル</summary>
            SheetLevel,
            /// <summary>アイテム説明書・アイテム記号名称</summary>
            SheetID,
            /// <summary>アイテム説明書・アイテム名称</summary>
            SheetName,
            /// <summary>アイテム説明書・データ形式</summary>
            SheetType,
            /// <summary>アイテム説明書・データ長</summary>
            SheetSize,
            /// <summary>アイテム説明書・ビット位置</summary>
            SheetBit,
            /// <summary>アイテム説明書・アイテム内容</summary>
            SheetText,
            /// <summary>アイテム説明書・記事</summary>
            SheetNote,
            /// <summary>アイテム説明書・候補値</summary>
            SheetKoho,
            /// <summary>アイテム説明書・図表</summary>
            SheetImage,
            /// <summary>アイテム説明書・罫線</summary>
            SheetLine

        }

        #endregion

        /// <summary>
        /// 最大頁数
        /// </summary>
        public int MaxPage { get; set; }
        /// <summary>
        /// 表示頁
        /// </summary>
        public int Page { get; set; }

        #region 内部プロパティ
        /// <summary>
        /// 描画先
        /// </summary>
        private Canvas canvas { get; set; }
        /// <summary>
        /// 表示種別
        /// </summary>
        private PreviewType previewType { get; set; }
        /// <summary>
        /// インタフェース情報
        /// </summary>
        private List<IFLayout> IFs { get; set; }
        /// <summary>
        /// インタフェース情報（展開後のルートノード）
        /// </summary>
        private IFLayout IFNode { get; set; }
        /// <summary>
        /// 描画位置情報
        /// </summary>
        private List<Position> ItemList { get; set; }
        /// <summary>
        /// ＳＪＩＳ
        /// </summary>
        private Encoding SJIS { get; }
        #endregion

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="canvas">描画先</param>
        /// <param name="previewType">表示種別</param>
        public SheetShowPreview(Canvas canvas, PreviewType previewType)
        {
            this.canvas = canvas;
            this.previewType = previewType;
            this.MaxPage = 0;
            this.Page = 0;
            this.SJIS = Encoding.GetEncoding("Shift_Jis");
            if(this.canvas != null)
            {
                this.canvas.CanvasItems = new System.Collections.ObjectModel.ObservableCollection<Canvas.CanvasItem>();
            }
        }

        /// <summary>
        /// DataGridViewの内容からプレビュー画面を作成する
        /// </summary>
        /// <param name="dataGridView">プレビュー内容を表示したいDataGridView</param>
        public void DataGridViewToCanvas(DataGridView dataGridView)
        {
            if(this.canvas != null)
            {
                lock (this.canvas.Lock)  //念の為、排他をかけてから描画アイテムをクリアする
                {
                    this.canvas.CanvasItems.Clear();
                }
            }
            this.IFs = new List<IFLayout>();

            int BitPos = 0;
            foreach(DataGridViewRow row in dataGridView.Rows)
            {
                if (row.Tag == null) return;

                InterfaceEdit.RowInfo rowInfo = row.Tag as InterfaceEdit.RowInfo;

                IFLayout IFItem = makeIFLayout(rowInfo, ref BitPos);

                this.IFs.Add(IFItem);
            }

            if (this.IFs.Count == 0) return;

            try
            {
                //親子関係の構築
                MakeChild();
                //結合項目のサイズ計算
                Recalculation();

                if (this.previewType == PreviewType.ItemStructImage) // アイテム構成図
                {
                    MakePreviewItemStruct();
                }
                else                                                // アイテム説明書
                {
                    MakePreviewItemSheet();
                }
                this.Page = 1;
            }
            catch(Exception)
            {
                // エラーが発生した場合、入力データがおかしいので、ここでは何もしない（この処理よりも前にエラーとしているので）
            }
        }

        public void RowInfoToCanvas(List<InterfaceEdit.RowInfo> listRowInfo)
        {
            if (this.canvas != null)
            {
                lock (this.canvas.Lock)  //念の為、排他をかけてから描画アイテムをクリアする
                {
                    this.canvas.CanvasItems.Clear();
                }
            }
            this.IFs = new List<IFLayout>();

            int BitPos = 0;
            foreach (InterfaceEdit.RowInfo rowInfo in listRowInfo)
            {
                IFLayout IFItem = makeIFLayout(rowInfo, ref BitPos);
                this.IFs.Add(IFItem);
            }

            if (this.IFs.Count == 0) return;

            try
            {
                //親子関係の構築
                MakeChild();
                //結合項目のサイズ計算
                Recalculation();

                if (this.previewType == PreviewType.ItemStructImage) // アイテム構成図
                {
                    MakePreviewItemStruct();
                }
                else                                                // アイテム説明書
                {
                    MakePreviewItemSheet();
                }
                this.Page = 1;
            }
            catch(Exception)
            {
                // エラーが発生した場合、入力データがおかしいので、ここでは何もしない（この処理よりも前にエラーとしているので）
            }
        }

        private IFLayout makeIFLayout(InterfaceEdit.RowInfo rowInfo, ref int BitPosition)
        {
            IFLayout IFItem = new IFLayout();
            if (rowInfo.phyitm.PHYITM_LEVEL > 0)                                        // レベル
            {
                IFItem.Level = string.Format("{0:D2}", rowInfo.phyitm.PHYITM_LEVEL);
            }
            else
            {
                IFItem.Level = string.Empty;
            }
            if (rowInfo.phyitm.PHYITM_ITEMID != null)                     // アイテム記号名称
            {
                IFItem.ID = rowInfo.phyitm.PHYITM_ITEMID;
            }
            else
            {
                IFItem.ID = string.Empty;
            }
            if (rowInfo.phyitm.PHYITM_ITEMNM != null)                      // アイテム名称
            {
                IFItem.Name = rowInfo.phyitm.PHYITM_ITEMNM;
                if (IFItem.Name == "FILLER")    // FILLER を 予備 に変更する
                {
                    IFItem.Name = "予備";
                    IFItem.FILLER = true;
                }
            }
            else
            {
                IFItem.Name = string.Empty;
            }
            if (rowInfo.phyitm.PHYITM_DTTYPE != null)                      // データ形式
            {
                IFItem.Type = rowInfo.phyitm.PHYITM_DTTYPE;
            }
            else
            {
                IFItem.Type = string.Empty;
            }
            if (rowInfo.phyitm.PHYITM_DTLEN != null)                    // データサイズ
            {
                IFItem.Size = (int)rowInfo.phyitm.PHYITM_DTLEN;
            }

            if (rowInfo.phyitm.PHYITM_OCCURS != null)                   // 繰返し数
            {
                IFItem.RepeatCount = (int)rowInfo.phyitm.PHYITM_OCCURS;
            }

            if (rowInfo.phyitm.PHYITM_DTTYPE == "BIT")                  //ビット位置
            {
                IFItem.BitPosition = BitPosition;
                if(IFItem.RepeatCount > 1)
                {
                    BitPosition += IFItem.Size * IFItem.RepeatCount;
                }
                else
                {
                    BitPosition += IFItem.Size;
                }
            }
            else
            {
                IFItem.BitPosition = 0;
                BitPosition = 0;
            }

            // アイテム内容
            if (rowInfo.phyitm.PHYITM_COMMENT != null)
            {
                IFItem.Text = rowInfo.phyitm.PHYITM_COMMENT;
            }
            else
            {
                IFItem.Text = string.Empty;
            }

            //候補値
            if (rowInfo.koho != null && rowInfo.koho.Count > 0)
            {
                StringBuilder sb = new StringBuilder();
                foreach (Models.DB.T_KOHO KOHO in rowInfo.koho)
                {
                    sb.Append(string.Format("{0}：{1}\n", KOHO.KOHO_CODE, KOHO.KOHO_CONTENT));
                }
                IFItem.KOHO = sb.ToString();
            }

            if (rowInfo.phyitm.PHYITM_IMAGENM != null && rowInfo.phyitm.PHYITM_IMAGENM != string.Empty && rowInfo.phyitm.PHYITM_IMAGE != null) // 図表
            {
                using (MemoryStream ms = new MemoryStream(rowInfo.phyitm.PHYITM_IMAGE))
                {
                    try
                    {
                        IFItem.image = Image.FromStream(ms);
                    }
                    catch
                    {
                        if (this.previewType == PreviewType.ItemSheet)
                        {
                            MessageBox.Show(string.Format("図表({0})が壊れています\n処理を続行します", rowInfo.phyitm.PHYITM_IMAGENM));
                        }
                    }
                }
            }
            if (rowInfo.phyitm.PHYITM_NOTE != null)
            {
                IFItem.Etc = rowInfo.phyitm.PHYITM_NOTE;                   // 記事
            }
            else
            {
                IFItem.Etc = string.Empty;
            }
            return IFItem;
        }

        /// <summary>
        /// プレビュー描画
        /// </summary>
        public void ShowPreview()
        {
            lock (this.canvas.Lock)  //念の為、排他をかけて該当頁番号の描画アイテムを追加する
            {
                this.canvas.CanvasItems.Clear();
                foreach (Position Item in this.ItemList)
                {
                    if (Item.PageNo == (this.Page - 1))
                    {
                        this.canvas.CanvasItems.Add(Item.CanvasItem);
                    }
                }
            }
            this.canvas.Refresh();
        }

        /// <summary>
        /// ファイル保存
        /// </summary>
        /// <param name="file">出力先ファイル</param>
        /// <returns>出力に成功した場合は True を返す</returns>
        public bool SaveXlsxFile(string file)
        {
            bool result = false;
            if (this.previewType == PreviewType.ItemStructImage) //アイテム構成図
            {
                result = outputXlsxStruct(file);
            }else if(this.previewType == PreviewType.ItemSheet) //アイテム説明書
            {
                result = outputXlsxSheet(file);
            }

            return result;
        }

        #region アイテム構成図
        /// <summary>
        /// アイテム構成図の作成
        /// </summary>
        private void MakePreviewItemStruct()
        {
            this.ItemList = new List<Position>();
            Position Current = new Position();
            IFLayout CurItem = this.IFNode;

            this.IFLayoutToCanvasItem(CurItem, ref Current, 0);
            if (Current.BoxNo == 0 && Current.BoxPosition == 0)
            {
                this.MaxPage = Current.PageNo;
            }
            else
            {
                this.MaxPage = Current.PageNo + 1;
            }
            //終端を示すラインを設定する
            Canvas.CanvasItem LineItem = new Canvas.CanvasItem
            {
                style = Canvas.Style.Line,
                Color = Color.Black,
                DoubleLine = true,
                LineWeight = 3
            };
            //終端に入れるサイズを設定する
            Canvas.CanvasItem SizeItem = new Canvas.CanvasItem
            {
                style = Canvas.Style.Text,
                Color = Color.White,
                FontColor = Color.Black,
                Text = Utils.ToZenkaku(string.Format("{0:D}B", this.IFNode.Size)),
                Font = new Font("ＭＳ 明朝", 8f),
                Alignment = StringAlignment.Far,
                LineAlignment = StringAlignment.Near
            };
            int LineX;
            int LineY;
            int BoxNo;
            bool Second = false;
            int p;
            if (Current.BoxNo == 0 && Current.BoxPosition == 0) //頁の終端までデータ有
            {
                p = Current.PageNo - 1;
                BoxNo = 9;
                Second = true;
                LineX = PictureLayout.Canvas.LineX[1];
            }
            else
            {
                p = Current.PageNo;
                if (Current.BoxPosition == 0)    //箱の終端までデータ有
                {
                    BoxNo = Current.BoxNo - 1;
                }
                else
                {
                    BoxNo = Current.BoxNo;
                }
                if (BoxNo < 10)
                {
                    LineX = PictureLayout.Canvas.LineX[0]; //１段目
                }
                else
                {
                    LineX = PictureLayout.Canvas.LineX[1]; //２段目
                    BoxNo = BoxNo - 10;
                    Second = true;
                }
            }

            LineY = PictureLayout.Canvas.LayoutY[BoxNo] + PictureLayout.Canvas.LayoutHeight[BoxNo] + PictureLayout.Canvas.LineY;

            LineItem.Recangle = new Rectangle(LineX, LineY, PictureLayout.Canvas.LineWidth, 0);
            SizeItem.Recangle = new Rectangle(LineX, LineY, PictureLayout.Canvas.LineWidth, 20);
            Position LinePos = new Position
            {
                PageNo = p,
                BoxNo = BoxNo,
                itemType = ItemType.EndLine,
                CanvasItem = LineItem
            };
            Position SizePos = new Position
            {
                PageNo = p,
                BoxNo = BoxNo,
                itemType = ItemType.EndSize,
                CanvasItem = SizeItem
            };
            if (Second)
            {
                LinePos.BoxNo += 10;
                SizePos.BoxNo += 10;
            }
            this.ItemList.Add(LinePos);
            this.ItemList.Add(SizePos);

            //レコード名称を各頁に設定する
            for (int page = 0; page < this.MaxPage; page++)
            {
                Canvas.CanvasItem recordItem = new Canvas.CanvasItem
                {
                    style = Canvas.Style.Text,
                    Text = this.IFNode.Name,
                    Alignment = StringAlignment.Near,
                    LineAlignment = StringAlignment.Center,
                    Multiline = true,
                    Font = new Font("ＭＳ 明朝", 9f),
                    Color = Color.White,
                    FontColor = Color.Black,
                    Recangle = new Rectangle(PictureLayout.Canvas.RecordX, PictureLayout.Canvas.RecordY, PictureLayout.Canvas.RecordWidth, PictureLayout.Canvas.RecordHeight)
                };
                Position recordPos = new Position
                {
                    PageNo = page,
                    itemType = ItemType.RecordName,
                    CanvasItem = recordItem
                };
                this.ItemList.Add(recordPos);
            }
        }

        /// <summary>
        /// アイテム構成図のファイル出力
        /// </summary>
        /// <param name="file">出力先ファイル</param>
        /// <returns></returns>
        private bool outputXlsxStruct(string file)
        {
            //雛形を読み込む
            try
            {
                using (FileStream fw = new FileStream(file, FileMode.Create, FileAccess.Write))
                {
                    fw.Write(Resources.ItemStruct, 0, Resources.ItemStruct.Length);
                    fw.Flush(); // エクセルで読み込むので、フラッシュしておく
                }
            }
            catch (Exception)
            {
                MessageBox.Show("ファイルの出力に失敗しました");
                //ファイル出力エラー
                return false;
            }

            try
            {
                using (ExcelUtils excel = new ExcelUtils())
                {
                    excel.FileName = file;
                    if (excel.Open())
                    {
                        for (int page = 0; page < this.MaxPage; page++)
                        {
                            //該当シートを雛形としてシートのコピーを行う
                            excel.WorkSheetName = "データ仕様書アイテム構成図（A4横）";
                            excel.CopySheet(string.Format("{0:D}", this.MaxPage - page));   //後ろの頁から複製することで、頁順に並ぶ

                            foreach (Position Item in this.ItemList)
                            {
                                if (Item.PageNo == (this.MaxPage - page - 1))   // 描画アイテムの頁とエクセルシートの頁が一致する場合は出力する
                                {
                                    int row, col;
                                    int BoxNo;
                                    RectangleF rectangle;
                                    switch (Item.itemType)
                                    {
                                        case ItemType.ByteNum:          // バイト位置
                                            BoxNo = Item.BoxNo;
                                            if (BoxNo > 9)
                                            {
                                                col = 11;
                                                BoxNo -= 10;
                                            }
                                            else
                                            {
                                                col = 1;
                                            }
                                            row = 7 + (BoxNo * 6);
                                            excel.WriteCell(row, col, Item.CanvasItem.Text);
                                            excel.SetHorizontalAlignment(row, col, ExcelUtils.HorizontalAlignment.xlRight);
                                            break;
                                        case ItemType.ItemName:     // 単項目名称
                                            BoxNo = Item.BoxNo;
                                            if (BoxNo > 9)
                                            {
                                                col = 12;
                                                BoxNo -= 10;
                                            }
                                            else
                                            {
                                                col = 2;
                                            }
                                            col += (Item.BoxPosition * 2);
                                            row = 8 + (BoxNo * 6);
                                            //サイズと文字サイズに応じて改行を設定する
                                            int MaxSize = PictureLayout.Excel.MaxWordSize[Item.BoxSize - 1];
                                            string buf;
                                            if (MaxSize != 0 && MaxSize < Item.CanvasItem.Text.Length)
                                            {
                                                StringBuilder sb = new StringBuilder();
                                                int AllSize = Item.CanvasItem.Text.Length;
                                                int pos = 0;
                                                while (AllSize > 0)
                                                {
                                                    if (pos != 0) sb.Append("\n");
                                                    sb.Append(Item.CanvasItem.Text.Substring(pos, MaxSize));
                                                    pos += MaxSize;
                                                    AllSize -= MaxSize;
                                                    if (AllSize < MaxSize) MaxSize = AllSize;
                                                }
                                                buf = sb.ToString();
                                            }
                                            else
                                            {
                                                buf = Item.CanvasItem.Text;
                                            }

                                            excel.WriteCell(row, col, buf);
                                            excel.CellMerge(row, col, row + 3, col + (2 * (Item.BoxSize - 1)) + 1);
                                            excel.SetHorizontalAlignment(row, col, ExcelUtils.HorizontalAlignment.xlCenter);
                                            excel.BorderAround(row, col, row + 3, col + (2 * (Item.BoxSize - 1)) + 1, ExcelUtils.XlLineStyle.xlContinuous);
                                            break;
                                        case ItemType.Yobi:     // 予備
                                            BoxNo = Item.BoxNo;
                                            if (BoxNo > 9)
                                            {
                                                col = 12;
                                                BoxNo -= 10;
                                            }
                                            else
                                            {
                                                col = 2;
                                            }
                                            col += (Item.BoxPosition * 2);
                                            row = 8 + (BoxNo * 6);
                                            excel.CellMerge(row, col, row + 3, col + (2 * (Item.BoxSize - 1)) + 1);
                                            excel.BorderAround(row, col, row + 3, col + (2 * (Item.BoxSize - 1)) + 1, ExcelUtils.XlLineStyle.xlContinuous);
                                            excel.SetBorderLine(row, col, row + 3, col + (2 * (Item.BoxSize - 1)) + 1, ExcelUtils.XlBordersIndex.xlDiagonalUp, ExcelUtils.XlLineStyle.xlContinuous);
                                            break;
                                        case ItemType.RecordName:   // レコード名称
                                            excel.SetTextBoxValue("Rectangle 25", Item.CanvasItem.Text);
                                            break;
                                        case ItemType.EndLine:      // 終端ライン
                                            BoxNo = Item.BoxNo;
                                            if (BoxNo > 9)
                                            {
                                                col = 1;
                                                BoxNo -= 10;
                                            }
                                            else
                                            {
                                                col = 0;
                                            }
                                            //終端線（二重線）
                                            excel.AddLine(PictureLayout.Excel.LineX[col],
                                                          PictureLayout.Excel.BoxY + (PictureLayout.Excel.BoxHeight + PictureLayout.Excel.BoxMargin) * BoxNo + PictureLayout.Excel.LineY,
                                                          PictureLayout.Excel.LineX[col] + PictureLayout.Excel.LineWidth,
                                                          PictureLayout.Excel.BoxY + (PictureLayout.Excel.BoxHeight + PictureLayout.Excel.BoxMargin) * BoxNo + PictureLayout.Excel.LineY,
                                                          Color.Black,
                                                          ExcelUtils.MsoLineDashStyle.msoLineSolid,
                                                          ExcelUtils.MsoLineStyle.msoLineThinThin,
                                                          2.0f);
                                            break;
                                        case ItemType.EndSize:      // 終端の全サイズ
                                            BoxNo = Item.BoxNo;
                                            if (BoxNo > 9)
                                            {
                                                col = 1;
                                                BoxNo -= 10;
                                            }
                                            else
                                            {
                                                col = 0;
                                            }
                                            float h = (PictureLayout.Excel.BoxY + (PictureLayout.Excel.BoxHeight + PictureLayout.Excel.BoxMargin) * (BoxNo + 1))
                                                        - (PictureLayout.Excel.BoxY + (PictureLayout.Excel.BoxHeight + PictureLayout.Excel.BoxMargin) * BoxNo + PictureLayout.Excel.LineY);
                                            //情報サイズ
                                            excel.AddTextBox(PictureLayout.Excel.LineX[col],
                                                             PictureLayout.Excel.BoxY + (PictureLayout.Excel.BoxHeight + PictureLayout.Excel.BoxMargin) * BoxNo + PictureLayout.Excel.LineY,
                                                             PictureLayout.Excel.LineWidth,
                                                             h,
                                                             ExcelUtils.MsoTextOrientation.msoTextOrientationHorizontal,
                                                             new Font(@"ＭＳ 明朝", 8.0f, FontStyle.Regular, GraphicsUnit.Point, 128, false),
                                                             Color.Black,
                                                             ExcelUtils.MsoParagraphAlignment.msoAlignRight,
                                                             ExcelUtils.MsoVerticalAnchor.msoAnchorTop,
                                                             Item.CanvasItem.Text);
                                            break;
                                        case ItemType.ItemArrow:    // 項目内の矢印
                                            BoxNo = Item.BoxNo;
                                            if (BoxNo > 9)
                                            {
                                                col = 1;
                                                BoxNo -= 10;
                                            }
                                            else
                                            {
                                                col = 0;
                                            }
                                            ExcelUtils.MsoArrowheadStyle startArrowheadStyle = ExcelUtils.MsoArrowheadStyle.msoArrowheadNone;
                                            ExcelUtils.MsoArrowheadStyle endArrowheadStyle = ExcelUtils.MsoArrowheadStyle.msoArrowheadNone;
                                            if (Item.CanvasItem.StartArrowCap) startArrowheadStyle = ExcelUtils.MsoArrowheadStyle.msoArrowheadOpen;
                                            if (Item.CanvasItem.EndArrowCap) endArrowheadStyle = ExcelUtils.MsoArrowheadStyle.msoArrowheadOpen;
                                            rectangle = new RectangleF();
                                            rectangle.X = PictureLayout.Excel.BoxX[col] + PictureLayout.Excel.BoxWidht * Item.BoxPosition;
                                            rectangle.Width = PictureLayout.Excel.BoxWidht * Item.BoxSize;
                                            rectangle.Y = PictureLayout.Excel.BoxY + (PictureLayout.Excel.BoxHeight + PictureLayout.Excel.BoxMargin) * BoxNo + PictureLayout.Excel.BoxHeight / 2.0f;
                                            rectangle.Height = 0;

                                            if (Item.Text == null || Item.Text == string.Empty)
                                            {
                                                excel.AddLine(rectangle.X, rectangle.Y, rectangle.Right, rectangle.Bottom, Color.Black,
                                                              ExcelUtils.MsoLineDashStyle.msoLineSolid, ExcelUtils.MsoLineStyle.msoLineSingle,
                                                              startArrowheadStyle, endArrowheadStyle, 0.5f);
                                            }
                                            else
                                            {
                                                //設定している文字数より、文字エリアを算出する
                                                RectangleF wordRectangleF = new RectangleF();
                                                if (PictureLayout.Excel.MaxWordSize[Item.BoxSize - 1] != 0 && Item.Text.Length > PictureLayout.Excel.MaxWordSize[Item.BoxSize - 1])
                                                {
                                                    wordRectangleF.Width = PictureLayout.Excel.CharWidth * PictureLayout.Excel.MaxWordSize[Item.BoxSize - 1];
                                                }
                                                else
                                                {
                                                    wordRectangleF.Width = PictureLayout.Excel.CharWidth * Item.Text.Length;
                                                }
                                                wordRectangleF.X = PictureLayout.Excel.BoxX[col]
                                                                    + (PictureLayout.Excel.BoxWidht * Item.BoxPosition)
                                                                    + (((PictureLayout.Excel.BoxWidht * Item.BoxSize) - wordRectangleF.Width) / 2f);
                                                //文字の左側
                                                excel.AddLine(rectangle.X, rectangle.Y, wordRectangleF.Left, rectangle.Bottom, Color.Black,
                                                              ExcelUtils.MsoLineDashStyle.msoLineSolid, ExcelUtils.MsoLineStyle.msoLineSingle,
                                                              startArrowheadStyle, ExcelUtils.MsoArrowheadStyle.msoArrowheadNone, 0.5f);
                                                //文字の右側
                                                excel.AddLine(wordRectangleF.Right, rectangle.Y, rectangle.Right, rectangle.Bottom, Color.Black,
                                                              ExcelUtils.MsoLineDashStyle.msoLineSolid, ExcelUtils.MsoLineStyle.msoLineSingle,
                                                              ExcelUtils.MsoArrowheadStyle.msoArrowheadNone, endArrowheadStyle, 0.5f);
                                            }
                                            break;
                                        case ItemType.GroupStart:   // 集団項目開始矢印
                                            BoxNo = Item.BoxNo;
                                            if (BoxNo > 9)
                                            {
                                                col = 1;
                                                BoxNo -= 10;
                                            }
                                            else
                                            {
                                                col = 0;
                                            }
                                            excel.AddLine(PictureLayout.Excel.BoxX[col] + PictureLayout.Excel.BoxWidht * 4,
                                                          PictureLayout.Excel.BoxY + (PictureLayout.Excel.BoxHeight + PictureLayout.Excel.BoxMargin) * BoxNo,
                                                          PictureLayout.Excel.BoxX[col] + PictureLayout.Excel.BoxWidht * 4 + PictureLayout.Excel.GroupWidth * (Item.LevelNo + 1),
                                                          PictureLayout.Excel.BoxY + (PictureLayout.Excel.BoxHeight + PictureLayout.Excel.BoxMargin) * BoxNo,
                                                          Color.Black,
                                                          ExcelUtils.MsoLineDashStyle.msoLineSolid,
                                                          ExcelUtils.MsoLineStyle.msoLineSingle,
                                                          ExcelUtils.MsoArrowheadStyle.msoArrowheadOpen,
                                                          ExcelUtils.MsoArrowheadWidth.msoArrowheadNarrow,
                                                          ExcelUtils.MsoArrowheadLength.msoArrowheadShort,
                                                          ExcelUtils.MsoArrowheadStyle.msoArrowheadNone,
                                                          ExcelUtils.MsoArrowheadWidth.msoArrowheadNarrow,
                                                          ExcelUtils.MsoArrowheadLength.msoArrowheadShort,
                                                          0.5f);
                                            break;
                                        case ItemType.GroupEnd:     // 集団項目終端矢印
                                            BoxNo = Item.BoxNo;
                                            if (BoxNo > 9)
                                            {
                                                col = 1;
                                                BoxNo -= 10;
                                            }
                                            else
                                            {
                                                col = 0;
                                            }
                                            excel.AddLine(PictureLayout.Excel.BoxX[col] + PictureLayout.Excel.BoxWidht * 4,
                                                          PictureLayout.Excel.BoxY + (PictureLayout.Excel.BoxHeight + PictureLayout.Excel.BoxMargin) * BoxNo + PictureLayout.Excel.BoxHeight,
                                                          PictureLayout.Excel.BoxX[col] + PictureLayout.Excel.BoxWidht * 4 + PictureLayout.Excel.GroupWidth * (Item.LevelNo + 1),
                                                          PictureLayout.Excel.BoxY + (PictureLayout.Excel.BoxHeight + PictureLayout.Excel.BoxMargin) * BoxNo + PictureLayout.Excel.BoxHeight,
                                                          Color.Black,
                                                          ExcelUtils.MsoLineDashStyle.msoLineSolid,
                                                          ExcelUtils.MsoLineStyle.msoLineSingle,
                                                          ExcelUtils.MsoArrowheadStyle.msoArrowheadOpen,
                                                          ExcelUtils.MsoArrowheadWidth.msoArrowheadNarrow,
                                                          ExcelUtils.MsoArrowheadLength.msoArrowheadShort,
                                                          ExcelUtils.MsoArrowheadStyle.msoArrowheadNone,
                                                          ExcelUtils.MsoArrowheadWidth.msoArrowheadNarrow,
                                                          ExcelUtils.MsoArrowheadLength.msoArrowheadShort,
                                                          0.5f);
                                            break;
                                        case ItemType.GroupLine:    // 集団項目中間線
                                            BoxNo = Item.BoxNo;
                                            if (BoxNo > 9)
                                            {
                                                col = 1;
                                                BoxNo -= 10;
                                            }
                                            else
                                            {
                                                col = 0;
                                            }
                                            excel.AddLine(PictureLayout.Excel.BoxX[col] + PictureLayout.Excel.BoxWidht * 4 + PictureLayout.Excel.GroupWidth * (Item.LevelNo + 1),
                                                          PictureLayout.Excel.BoxY + (PictureLayout.Excel.BoxHeight + PictureLayout.Excel.BoxMargin) * BoxNo,
                                                          PictureLayout.Excel.BoxX[col] + PictureLayout.Excel.BoxWidht * 4 + PictureLayout.Excel.GroupWidth * (Item.LevelNo + 1),
                                                          PictureLayout.Excel.BoxY + (PictureLayout.Excel.BoxHeight + PictureLayout.Excel.BoxMargin) * (BoxNo + Item.BoxCount - 1) + PictureLayout.Excel.BoxHeight,
                                                          Color.Black,
                                                          0.5f);
                                            break;
                                        case ItemType.GroupName:    // 集団項目名称
                                            BoxNo = Item.BoxNo;
                                            if (BoxNo > 9)
                                            {
                                                col = 1;
                                                BoxNo -= 10;
                                            }
                                            else
                                            {
                                                col = 0;
                                            }
                                            excel.AddTextBox(PictureLayout.Excel.BoxX[col] + PictureLayout.Excel.BoxWidht * 4 + PictureLayout.Excel.GroupNameOffset + PictureLayout.Excel.GroupWidth * Item.LevelNo,
                                                             PictureLayout.Excel.BoxY + (PictureLayout.Excel.BoxHeight + PictureLayout.Excel.BoxMargin) * BoxNo,
                                                             PictureLayout.Excel.GroupWidth - PictureLayout.Excel.GroupNameOffset,
                                                             (Item.CanvasItem.Text.Length * 2) * PictureLayout.Excel.CharWidth,
                                                             ExcelUtils.MsoTextOrientation.msoTextOrientationHorizontalRotatedFarEast,
                                                             new Font("ＭＳ 明朝", 7.0f),
                                                             Color.Black,
                                                             ExcelUtils.MsoParagraphAlignment.msoAlignLeft,
                                                             ExcelUtils.MsoVerticalAnchor.msoAnchorBottom,
                                                             Item.CanvasItem.Text);
                                            break;
                                        default:                // 出力対象外
                                            break;
                                    }
                                }
                            }
                        }
                        // 雛形のシートを削除する
                        excel.DeleteSheet("データ仕様書アイテム構成図（A4横）");
                        // 保存して閉じる
                        excel.Save();
                        excel.Close();
                    }
                }
            }
            catch
            {
                //エクセルのエラー
                return false;
            }
            GC.Collect();   // 強制的に解放

            return true;
        }

        /// <summary>
        /// アイテム構成図の描画設定
        /// </summary>
        /// <param name="CurItem"></param>
        /// <param name="Current"></param>
        /// <param name="Level"></param>
        private void IFLayoutToCanvasItem(IFLayout CurItem, ref Position Current, int Level)
        {
            bool isTarget = CurItem.isTarget;
            foreach (IFLayout Item in CurItem.ChildNodes)
            {
                if (Item.Type == "GROUP" && Item.hasBit == false)   // 集団項目 かつ ビット項目をもっていない場合
                {
                    //開始位置
                    Position StartPos = Current;
                    //子項目
                    this.IFLayoutToCanvasItem(Item, ref Current, Level + 1);
                    //終了位置はCurrentから１つ前の位置
                    Position EndPos = Current;
                    EndPos.BoxPosition--;
                    if (EndPos.BoxPosition == -1)
                    {
                        EndPos.BoxNo--;
                        if (EndPos.BoxNo == -1)
                        {
                            EndPos.BoxNo = 19;
                            EndPos.PageNo--;
                        }
                        if (EndPos.BoxNo < 10)
                        {
                            EndPos.BoxPosition = 3;
                        }
                        else
                        {
                            EndPos.BoxPosition = 7;
                        }
                    }

                    if (Level < 4 && Item.isTarget)
                    {
                        string Name;
                        if (Item.MaxCount > 1)
                        {
                            Name = Utils.ToZenkaku(string.Format("{0}×{1:d}", Item.Name, Item.MaxCount));
                        }
                        else
                        {
                            Name = Item.Name;
                        }
                        AddCanvasItem(this.ItemList, StartPos, EndPos, 3 - Level, Item.ID, Name);
                    }

                }
                else
                {
                    if (Item.Type != "BIT") // ビット項目は描画対象外
                    {
                        string Name;
                        if (isTarget)
                        {
                            if (Item.Current > 0)
                            {
                                Name = Utils.ToZenkaku(string.Format("{0}({1:D})", Item.Name, Item.Current));   // 繰返し数有りの単項目名称
                            }
                            else
                            {
                                Name = Item.Name;
                            }
                            Current = AddCanvasItem(this.ItemList, Current, Item.ID, Name, Item.Size, Item.FILLER);
                        }
                        else
                        {
                            Current.BytePosition += Item.Size;
                        }
                    }
                }
            }
        }

        private void AddCanvasItem(List<Position> list, Position StartPos, Position EndPos, int Level, string ID, string Text)
        {
            Rectangle rec;
            int X = 0;
            int Y = 0;
            int H = 0;
            Position AddItem;
            int Pos = 0;
            int SPos = 0;
            int EPos = 0;
            int SBoxNo;
            int EBoxNo;

            //必要な頁数を求める
            int PageCount = EndPos.PageNo - StartPos.PageNo + 1;

            //開始はｎ段落目かを取得する
            if (StartPos.BoxNo > 9)
            {
                Pos = 2;    //２段目
            }
            else
            {
                Pos = 1;    //１段目
            }
            SPos = Pos;
            //終了はｎ段落目かを取得する
            if (EndPos.BoxNo > 9)
            {
                EPos = 2;    //２段目
            }
            else
            {
                EPos = 1;    //１段目
            }

            for (int page = 0; page < PageCount; page++)
            {
                for (int curPos = Pos; curPos < 3; curPos++)
                {
                    SBoxNo = GetStartBoxNo(PageCount, page, curPos, StartPos);
                    EBoxNo = GetEndBoxNo(PageCount, page, curPos, EndPos);

                    int StartBoxNo = SBoxNo;
                    int EndBoxNo = EBoxNo;

                    //２段落目補正
                    if (SBoxNo > 9)
                    {
                        SBoxNo = SBoxNo - 10;
                        EBoxNo = EBoxNo - 10;
                        X = 1010;
                    }
                    else
                    {
                        X = 470;
                    }

                    if (page == 0 && curPos == SPos)
                    {
                        //集団項目名称
                        Canvas.CanvasItem TextItem = new Canvas.CanvasItem
                        {
                            style = Canvas.Style.Text,
                            Vertical = true,
                            Font = new Font("ＭＳ 明朝", this.canvas.GetEmSize(7f)),
                            Color = Color.White,
                            FontColor = Color.Black,
                            Text = Text,
                            id = ID,
                            Event = true,
                            Margin = new Padding(0),
                            Alignment = StringAlignment.Near,
                            LineAlignment = StringAlignment.Far
                        };
                        Y = PictureLayout.Canvas.LayoutY[SBoxNo];
                        rec = new Rectangle(X + (15 * Level) + 1, Y + 2, 14, 1000);
                        TextItem.Recangle = rec;
                        AddItem = StartPos;
                        AddItem.itemType = ItemType.GroupName;
                        AddItem.LevelNo = Level;
                        AddItem.CanvasItem = new Canvas.CanvasItem(TextItem);
                        list.Add(AddItem);

                        //先頭矢印
                        Canvas.CanvasItem StartArrow = new Canvas.CanvasItem
                        {
                            style = Canvas.Style.Arrow,
                            StartArrowCap = true,
                            EndArrowCap = false,
                            Color = SystemColors.WindowText,
                            Event = false,
                            ArrowCapSize = 6
                        };
                        Y = PictureLayout.Canvas.LayoutY[SBoxNo];
                        rec = new Rectangle(X, Y, 15 * (Level + 1), 0);
                        StartArrow.Recangle = rec;
                        AddItem = StartPos;
                        AddItem.LevelNo = Level;
                        AddItem.itemType = ItemType.GroupStart;
                        AddItem.CanvasItem = new Canvas.CanvasItem(StartArrow);
                        list.Add(AddItem);

                    }
                    // 中間線
                    Canvas.CanvasItem LineItem = new Canvas.CanvasItem
                    {
                        style = Canvas.Style.Line,
                        StartArrowCap = false,
                        EndArrowCap = false,
                        Color = SystemColors.WindowText,
                        Event = false
                    };
                    Y = PictureLayout.Canvas.LayoutY[SBoxNo];
                    H = (PictureLayout.Canvas.LayoutY[EBoxNo] + PictureLayout.Canvas.LayoutHeight[EBoxNo]) - Y;
                    rec = new Rectangle(X + 15 * (Level + 1), Y, 0, H);
                    LineItem.Recangle = rec;
                    AddItem = new Position
                    {
                        PageNo = StartPos.PageNo + page,
                        BoxNo = StartBoxNo,
                        BoxCount = EndBoxNo - StartBoxNo + 1,
                        itemType = ItemType.GroupLine,
                        LevelNo = Level,
                        CanvasItem = new Canvas.CanvasItem(LineItem)
                    };
                    list.Add(AddItem);

                    if (page == (PageCount - 1) && curPos == EPos)
                    {
                        //終端矢印
                        Canvas.CanvasItem EndArrow = new Canvas.CanvasItem
                        {
                            style = Canvas.Style.Arrow,
                            StartArrowCap = true,
                            EndArrowCap = false,
                            Color = SystemColors.WindowText,
                            Event = false,
                            ArrowCapSize = 6
                        };
                        Y = PictureLayout.Canvas.LayoutY[EBoxNo] + PictureLayout.Canvas.LayoutHeight[EBoxNo];
                        rec = new Rectangle(X, Y, 15 * (Level + 1), 0);
                        EndArrow.Recangle = rec;
                        AddItem = EndPos;
                        AddItem.itemType = ItemType.GroupEnd;
                        AddItem.LevelNo = Level;
                        AddItem.CanvasItem = new Canvas.CanvasItem(EndArrow);
                        list.Add(AddItem);
                        break;
                    }
                }
                Pos = 1;
            }
        }

        private Position AddCanvasItem(List<Position> list, Position Current, string ID, string Text, int Size, bool Yobi)
        {

            Position AddItem;
            //８バイトよりも大きい場合は８バイトに省略する
            int Remain = Size - 8;
            if (Size > 8)
            {
                Size = 8;
            }

            //開始位置
            int StartBoxNo = Current.BoxNo;
            int StartPoint = Current.BoxPosition;

            //終了位置
            int EndBoxNo = StartBoxNo + ((StartPoint + Size - 1) / 4);
            int EndPoint = ((StartPoint + Size - 1) % 4);
            //繰返し回数
            int MaxCount = EndBoxNo;

            //どの箱に項目名を出力するか
            int DisplayNo;
            //項目名を出力するサイズが１か
            bool SingleLength = false;

            if ((EndBoxNo - StartBoxNo >= 2))
            {
                // ３箱以上に跨る場合は２番目に出力
                DisplayNo = StartBoxNo + 1;
            }
            else if (EndBoxNo == StartBoxNo)
            {
                // 箱１つの場合はそのまま
                DisplayNo = StartBoxNo;
                if (StartPoint == EndPoint)
                {
                    SingleLength = true;
                }
            }
            else
            {
                //２箱に跨る場合は領域が広い方に出力
                if ((4 - StartPoint) > EndPoint)
                {
                    DisplayNo = StartBoxNo;
                    if (StartPoint == 3)
                    {
                        SingleLength = true;
                    }
                }
                else
                {
                    DisplayNo = EndBoxNo;
                }
            }
            if (DisplayNo >= 20)
            {
                DisplayNo -= 20;
            }
            if (EndBoxNo >= 20)
            {
                EndBoxNo -= 20;
            }

            //箱単位にCanvasItemを生成し登録する（※ＩＤは同一とする）
            int X, Y, W, H;
            int XPlus = 0;
            int No = 0;
            int StartPageNo = Current.PageNo;
            for (int BoxCount = StartBoxNo; BoxCount <= MaxCount; BoxCount++)
            {
                bool BoxFirst = false;
                // 箱のサイズを算出
                if (Current.BoxNo == EndBoxNo)
                {
                    if (Current.BoxNo == StartBoxNo)
                    {
                        Current.BoxSize = (EndPoint + 1) - StartPoint;
                    }
                    else
                    {
                        Current.BoxSize = EndPoint + 1;
                    }
                }
                else
                {
                    if (Current.BoxNo == StartBoxNo)
                    {
                        Current.BoxSize = 4 - StartPoint;
                    }
                    else
                    {
                        Current.BoxSize = 4;
                    }
                }


                // 矢印
                Canvas.CanvasItem ArrowItem = new Canvas.CanvasItem
                {
                    style = Canvas.Style.Arrow,
                    Color = SystemColors.WindowText,
                    Event = false
                };

                // 境界線
                Canvas.CanvasItem LineItem = new Canvas.CanvasItem
                {
                    style = Canvas.Style.Line,
                    Color = SystemColors.WindowText,
                    Event = false
                };

                // 項目
                Canvas.CanvasItem Item = new Canvas.CanvasItem
                {
                    style = Canvas.Style.Text,
                    id = ID,
                    Font = new Font("ＭＳ 明朝", this.canvas.GetEmSize(8f)),
                    Color = Color.White,
                    FontColor = Color.Black,
                    Event = true,
                    Margin = new Padding(8, 0, 9, 0),
                    Multiline = true,
                    Alignment = StringAlignment.Center,
                    LineAlignment = StringAlignment.Center
                };
                if (DisplayNo == Current.BoxNo)
                {
                    if (SingleLength && Text.Length > 24)
                    {
                        Item.Text = Text.Substring(0, 23) + "…";     //表示領域を超える場合は３点リードを付けて省略する
                    }
                    else
                    {
                        Item.Text = Text;
                    }
                }
                else
                {
                    Item.Text = string.Empty;
                }

                //予備の斜線
                Canvas.CanvasItem yobiItem = new Canvas.CanvasItem
                {
                    style = Canvas.Style.Line,
                    id = ID,
                    Color = SystemColors.WindowText,
                    Event = false
                };

                //２段落目補正
                if (Current.BoxNo > 9)
                {
                    XPlus = 4;
                    No = Current.BoxNo - 10;
                }
                else
                {
                    XPlus = 0;
                    No = Current.BoxNo;
                }

                //描画開始位置の算出
                if (Current.BoxNo == StartBoxNo)
                {
                    X = PictureLayout.Canvas.LayoutX[StartPoint + XPlus];
                    ArrowItem.StartArrowCap = true;
                }
                else
                {
                    X = PictureLayout.Canvas.LayoutX[0 + XPlus];
                    ArrowItem.StartArrowCap = false;
                }
                if (StartPoint == 0 || Current.BoxNo > StartBoxNo || Current.PageNo > StartPageNo)
                {
                    BoxFirst = true;
                }
                Y = PictureLayout.Canvas.LayoutY[No];
                H = PictureLayout.Canvas.LayoutHeight[No];

                Rectangle rec;

                // 箱前の位置情報
                if (BoxFirst)
                {
                    Canvas.CanvasItem PosItem = new Canvas.CanvasItem
                    {
                        style = Canvas.Style.Box,
                        Font = new Font("ＭＳ 明朝", this.canvas.GetEmSize(8f)),
                        Color = Color.White,
                        FontColor = Color.Black,
                        Event = false,
                        LineAlignment = StringAlignment.Near,
                        Alignment = StringAlignment.Far,
                        Recangle = new Rectangle(X - PictureLayout.Canvas.LayoutWidth[0] / 3, Y - H / 4, PictureLayout.Canvas.LayoutWidth[0] / 3 - 2, H / 2)
                    };
                    if ((Current.PreBytePositon + 4) < Current.BytePosition)
                    {
                        PosItem.Text = string.Format("*{0}", Current.BytePosition);
                    }
                    else
                    {
                        PosItem.Text = string.Format("{0}", Current.BytePosition);
                    }
                    Current.PreBytePositon = Current.BytePosition;
                    AddItem = new Position
                    {
                        PageNo = Current.PageNo,
                        BoxNo = Current.BoxNo,
                        itemType = ItemType.ByteNum,
                        CanvasItem = new Canvas.CanvasItem(PosItem)
                    };
                    list.Add(AddItem);
                }


                //描画エリアの算出
                if (Current.BoxNo == EndBoxNo)
                {
                    W = PictureLayout.Canvas.LayoutX[EndPoint + XPlus] + PictureLayout.Canvas.LayoutWidth[EndPoint + XPlus] - X;
                    ArrowItem.EndArrowCap = true;
                }
                else
                {
                    W = PictureLayout.Canvas.LayoutX[3 + XPlus] + PictureLayout.Canvas.LayoutWidth[3 + XPlus] - X;
                    ArrowItem.EndArrowCap = false;
                }

                AddItem = new Position();

                rec = new Rectangle(X + W, Y, 0, H);
                LineItem.Recangle = rec;
                AddItem = Current;
                AddItem.itemType = ItemType.SplitLine;
                AddItem.CanvasItem = new Canvas.CanvasItem(LineItem);
                list.Add(AddItem);

                if (Yobi)
                {
                    rec = new Rectangle(X, Y + H, W, 0 - H);
                    yobiItem.Recangle = rec;
                    AddItem = Current;
                    AddItem.itemType = ItemType.Yobi;
                    AddItem.CanvasItem = new Canvas.CanvasItem(yobiItem);
                    list.Add(AddItem);
                }
                else
                {
                    rec = new Rectangle(X, Y + H / 2, W - 1, 0);
                    ArrowItem.Recangle = rec;
                    AddItem = Current;
                    AddItem.itemType = ItemType.ItemArrow;
                    AddItem.CanvasItem = new Canvas.CanvasItem(ArrowItem);
                    AddItem.Text = Item.Text;       // Ｅｘｃｅｌ出力時の計算用に文字列を退避する
                    list.Add(AddItem);

                    rec = new Rectangle(X, Y, W, H);
                    Item.Recangle = rec;
                    AddItem = Current;
                    AddItem.itemType = ItemType.ItemName;
                    AddItem.CanvasItem = new Canvas.CanvasItem(Item);
                    list.Add(AddItem);
                }


                //位置移動
                if (Current.BoxNo == EndBoxNo)
                {
                    if (Current.BoxNo == StartBoxNo)
                    {
                        Current.BytePosition += Current.BoxSize;
                        Current.BoxPosition += Current.BoxSize;
                    }
                    else
                    {
                        Current.BytePosition += Current.BoxSize;
                        Current.BoxPosition += Current.BoxSize;
                    }
                }
                else
                {
                    if (Current.BoxNo == StartBoxNo)
                    {
                        Current.BytePosition += Current.BoxSize;
                        Current.BoxPosition += Current.BoxSize;
                    }
                    else
                    {
                        Current.BytePosition += Current.BoxSize;
                        Current.BoxPosition += Current.BoxSize;
                    }
                }
                Current.BoxSize = 0;

                //省略している場合は、省略したサイズを加算する
                if (Remain > 0)
                {
                    Current.BytePosition += Remain;
                    Remain = 0;
                }

                if (Current.BoxPosition >= 4)
                {
                    Current.BoxNo++;
                    Current.BoxPosition -= 4;
                    if (Current.BoxNo >= 20)
                    {
                        Current.PageNo++;
                        Current.BoxNo -= 20;
                    }
                }
            }

            return Current;

        }

        private int GetStartBoxNo(int PageCount, int Page, int CurPos, Position StartPos)
        {
            if (Page == 0)
            {
                if (CurPos == 1)
                {
                    if (StartPos.BoxNo > 9)
                    {
                        return 0;   //これはおかしいケース・通常発生しない
                    }
                    else
                    {
                        return StartPos.BoxNo;
                    }
                }
                else
                {
                    if (StartPos.BoxNo > 9)
                    {
                        return StartPos.BoxNo;
                    }
                    else
                    {
                        return 10;
                    }
                }
            }
            else
            {
                if (CurPos == 1)
                {
                    return 0;
                }
                else
                {
                    return 10;
                }

            }
        }

        private int GetEndBoxNo(int PageCount, int Page, int CurPos, Position EndPos)
        {
            if (Page == (PageCount - 1))
            {
                if (EndPos.BoxNo > 9)
                {
                    if (CurPos == 1)
                    {
                        return 9;
                    }
                    else
                    {
                        return EndPos.BoxNo;
                    }
                }
                else
                {
                    if (CurPos == 1)
                    {
                        return EndPos.BoxNo;
                    }
                    else
                    {
                        return 19;
                    }
                }
            }
            else
            {
                if (CurPos == 1)
                {
                    return 9;
                }
                else
                {
                    return 19;
                }
            }
        }

        #endregion

        #region アイテム説明書
        /// <summary>
        /// アイテム説明書の作成
        /// </summary>
        private void MakePreviewItemSheet()
        {
            this.ItemList = new List<Position>();
            Position Current = new Position();
            IFLayout CurItem = this.IFNode;

            this.IFLayoutToCanvasText(CurItem, ref Current, 0);
            if (Current.LineNo == 0)
            {
                this.MaxPage = Current.PageNo;
            }
            else
            {
                this.MaxPage = Current.PageNo + 1;
            }
            for (int page = 0; page < this.MaxPage; page++)
            {
                //レコード名称を各頁に設定する
                Canvas.CanvasItem canvasItem = new Canvas.CanvasItem
                {
                    style = Canvas.Style.Text,
                    Text = this.IFNode.Name,
                    Alignment = StringAlignment.Near,
                    LineAlignment = StringAlignment.Center,
                    Multiline = true,
                    Font = new Font("ＭＳ 明朝", 9f),
                    Color = Color.White,
                    FontColor = Color.Black,
                    Recangle = new Rectangle(TextLayout.RecordX, TextLayout.RecordY, TextLayout.RecordWidth, TextLayout.RecordHeight)
                };
                Position recordPos = new Position
                {
                    itemType = ItemType.RecordName,
                    PageNo = page,
                    CanvasItem = canvasItem
                };
                this.ItemList.Add(recordPos);
            }
        }


        /// <summary>
        /// アイテム説明書の描画設定
        /// </summary>
        /// <param name="Item"></param>
        /// <param name="Current"></param>
        /// <param name="Level"></param>
        private void IFLayoutToCanvasText(IFLayout Item, ref Position Current, int Level)
        {
            if (Item.Current > 1) return;

            Position AddItem;
            int DrawLevel;
            List<string> IDs = new List<string>();
            List<string> NAMEs = new List<string>();
            List<string> COMMENTs = new List<string>();
            List<string> KOHOs = new List<string>();
            List<string> NOTEs = new List<string>();
            float zoom = 1.00f;

            int outCount = 1;
            //該当行の出力行数を算出する
            //・以下の項目が複数行出力可能である為、各項目の行数を求める
            //    アイテム記号名称
            //    アイテム名称
            //    データ長
            //    アイテム内容（候補値、図表を含む）
            //    記事
            int imageCount = 0;
            IDs = getLines(Item.ID, 9);                           //アイテム記号名称
            if (IDs.Count > outCount) outCount = IDs.Count;
            NAMEs = getLines(Item.Name, 16);                        //アイテム名称
            if (NAMEs.Count > outCount) outCount = NAMEs.Count;
            if (Item.MaxCount > 1 && outCount == 1) outCount = 2;       //データ長
            //アイテム内容
            if(Item.Text != string.Empty)
            {
                COMMENTs.AddRange(getLines(Item.Text, 47));
            }
            if(Item.KOHO != string.Empty)                               //候補値
            {
                KOHOs.AddRange(getLines(Item.KOHO, 45));
            }
            if (Item.image != null)                                     //図表
            {
                if(Item.image.Width > 480 || Item.image.Height > 480)
                {
                    if (Item.image.Width > Item.image.Height)
                    {
                        zoom = 480f / Item.image.Width;
                    }
                    else
                    {
                        zoom = 480f / Item.image.Height;
                    }
                }
                imageCount = ((int)((Item.image.Height * zoom) / 16f));
                if(((Item.image.Height * zoom + 1.6) % 16) > 1.6)
                {
                    imageCount++;
                }

            }
            if ((COMMENTs.Count + KOHOs.Count + imageCount) > outCount) outCount = COMMENTs.Count + KOHOs.Count + imageCount;
            NOTEs = getLines(Item.Etc, 7);                          //記事
            if (NOTEs.Count > outCount) outCount = NOTEs.Count;

            if(outCount > 40)
            {
                MessageBox.Show(string.Format("項目：{0} が１頁に収まりません", Item.Name), "アイテム説明書", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            //頁内に収まるか検定する
            if ((Current.LineNo + outCount) > 40)
            {
                //改頁
                Current.PageNo++;
                Current.LineNo = 0;
            }

            for (int inNo = 0; inNo < outCount; inNo++)
            {
                //項番
                if (inNo == 0)
                {
                    AddItem = new Position();
                    AddItem.CanvasItem = new Canvas.CanvasItem
                    {
                        style = Canvas.Style.Text,
                        Color = Color.White,
                        FontColor = Color.Black,
                        Font = new Font("ＭＳ 明朝", 7f),
                        Text = string.Format("{0:D}", Current.Index + 1),
                        Alignment = StringAlignment.Center,
                        LineAlignment = StringAlignment.Near,
                        Recangle = new Rectangle(TextLayout.IndexX,
                                                                TextLayout.Top + (Current.LineNo * TextLayout.Height),
                                                                TextLayout.IndexWidth,
                                                                TextLayout.Height)
                    };
                    AddItem.PageNo = Current.PageNo;
                    AddItem.LineNo = Current.LineNo;
                    AddItem.itemType = ItemType.SheetNo;
                    this.ItemList.Add(AddItem);
                }

                //アイテム記号名称
                if (IDs.Count > inNo)
                {
                    AddItem = new Position();
                    AddItem.CanvasItem = new Canvas.CanvasItem
                    {
                        style = Canvas.Style.Text,
                        Color = Color.White,
                        FontColor = Color.Black,
                        Font = new Font("ＭＳ 明朝", 7f),
                        Text = IDs[inNo],
                        Alignment = StringAlignment.Near,
                        LineAlignment = StringAlignment.Near,
                        Recangle = new Rectangle(TextLayout.IdX,
                                                                TextLayout.Top + (Current.LineNo * TextLayout.Height),
                                                                TextLayout.IdWidth,
                                                                TextLayout.Height)
                    };
                    AddItem.PageNo = Current.PageNo;
                    AddItem.LineNo = Current.LineNo;
                    AddItem.itemType = ItemType.SheetID;
                    this.ItemList.Add(AddItem);
                }
                //アイテム名称
                if (NAMEs.Count > inNo)
                {
                    AddItem = new Position();
                    AddItem.CanvasItem = new Canvas.CanvasItem
                    {
                        id = Item.Name,
                        style = Canvas.Style.Text,
                        Color = Color.White,
                        FontColor = Color.Black,
                        Font = new Font("ＭＳ 明朝", 7f),
                        Text = NAMEs[inNo],
                        Alignment = StringAlignment.Near,
                        LineAlignment = StringAlignment.Near,
                        Recangle = new Rectangle(TextLayout.NameX,
                                                                TextLayout.Top + (Current.LineNo * TextLayout.Height),
                                                                TextLayout.NameWidth,
                                                                TextLayout.Height)
                    };
                    AddItem.PageNo = Current.PageNo;
                    AddItem.LineNo = Current.LineNo;
                    AddItem.itemType = ItemType.SheetName;
                    this.ItemList.Add(AddItem);
                }

                if (inNo == 0)
                {
                    //データ形式
                    string type = Item.Type;
                    if (Item.Type == null || Item.Type == "GROUP")
                    {
                        type = string.Empty;
                    }
                    AddItem = new Position();
                    AddItem.CanvasItem = new Canvas.CanvasItem
                    {
                        style = Canvas.Style.Text,
                        Color = Color.White,
                        FontColor = Color.Black,
                        Font = new Font("ＭＳ 明朝", 7f),
                        Text = type,
                        Alignment = StringAlignment.Center,
                        LineAlignment = StringAlignment.Near,
                        Recangle = new Rectangle(TextLayout.TypeX,
                                                 TextLayout.Top + (Current.LineNo * TextLayout.Height),
                                                 TextLayout.TypeWidth,
                                                 TextLayout.Height)
                    };
                    AddItem.PageNo = Current.PageNo;
                    AddItem.LineNo = Current.LineNo;
                    AddItem.itemType = ItemType.SheetType;
                    this.ItemList.Add(AddItem);
                }

                //データ長（バイト）
                if (inNo == 0)
                {
                    string value;
                    if (Item.Type == "GROUP")
                    {
                        value = string.Format("({0:D})", Item.Size);
                    }
                    else if(Item.Type == "BIT")
                    {
                        value = string.Format("{0:D}b", Item.Size);
                    }
                    else
                    {
                        value = string.Format("{0:D}", Item.Size);
                    }
                    AddItem = new Position();
                    AddItem.CanvasItem = new Canvas.CanvasItem
                    {
                        style = Canvas.Style.Text,
                        Color = Color.White,
                        FontColor = Color.Black,
                        Font = new Font("ＭＳ 明朝", 7f),
                        Text = value,
                        Alignment = StringAlignment.Center,
                        LineAlignment = StringAlignment.Near,
                        Recangle = new Rectangle(TextLayout.SizeX,
                                                                TextLayout.Top + (Current.LineNo * TextLayout.Height),
                                                                TextLayout.SizeWidth,
                                                                TextLayout.Height)
                    };
                    AddItem.PageNo = Current.PageNo;
                    AddItem.LineNo = Current.LineNo;
                    AddItem.itemType = ItemType.SheetSize;
                    this.ItemList.Add(AddItem);
                }
                if(inNo == 1 && Item.MaxCount > 1)   // 繰返し数
                {
                    AddItem = new Position();
                    AddItem.CanvasItem = new Canvas.CanvasItem
                    {
                        style = Canvas.Style.Text,
                        Color = Color.White,
                        FontColor = Color.Black,
                        Font = new Font("ＭＳ 明朝", 7f),
                        Text = string.Format("×{0:D}", Item.MaxCount),
                        Alignment = StringAlignment.Center,
                        LineAlignment = StringAlignment.Near,
                        Recangle = new Rectangle(TextLayout.SizeX,
                                                                TextLayout.Top + (Current.LineNo * TextLayout.Height),
                                                                TextLayout.SizeWidth,
                                                                TextLayout.Height)
                    };
                    AddItem.PageNo = Current.PageNo;
                    AddItem.LineNo = Current.LineNo;
                    AddItem.itemType = ItemType.SheetSize;
                    this.ItemList.Add(AddItem);
                }

                //ビット位置
                if (inNo == 0)
                {
                    string bit;
                    if (Item.Type == "BIT")
                    {
                        if(Item.MaxCount > 0)
                        {
                            bit = string.Format("{0:D}～{1:D}", Item.BitPosition, Item.BitPosition + (Item.Size * Item.MaxCount) - 1);
                        }
                        else
                        {
                            if(Item.Size > 1)
                            {
                                bit = string.Format("{0:D}～{1:D}", Item.BitPosition, Item.BitPosition + Item.Size - 1);
                            }
                            else
                            {
                                bit = string.Format("{0:D}", Item.BitPosition);
                            }
                        }
                    }
                    else
                    {
                        bit = string.Format("{0:D}", Item.BitPosition);
                    }
                    AddItem = new Position();
                    AddItem.CanvasItem = new Canvas.CanvasItem
                    {
                        style = Canvas.Style.Text,
                        Color = Color.White,
                        FontColor = Color.Black,
                        Font = new Font("ＭＳ 明朝", 7f),
                        Text = bit,
                        Alignment = StringAlignment.Center,
                        LineAlignment = StringAlignment.Near,
                        Recangle = new Rectangle(TextLayout.BitX,
                                                                TextLayout.Top + (Current.LineNo * TextLayout.Height),
                                                                TextLayout.BitWidth,
                                                                TextLayout.Height)
                    };
                    AddItem.PageNo = Current.PageNo;
                    AddItem.LineNo = Current.LineNo;
                    AddItem.itemType = ItemType.SheetBit;
                    this.ItemList.Add(AddItem);
                }

                //アイテム内容（テキスト）
                if (COMMENTs.Count > inNo)
                {
                    AddItem = new Position();
                    AddItem.CanvasItem = new Canvas.CanvasItem
                    {
                        style = Canvas.Style.Text,
                        Color = Color.White,
                        FontColor = Color.Black,
                        Font = new Font("ＭＳ 明朝", 7f),
                        Text = COMMENTs[inNo],
                        Alignment = StringAlignment.Near,
                        LineAlignment = StringAlignment.Near,
                        Recangle = new Rectangle(TextLayout.TextX,
                                                                TextLayout.Top + (Current.LineNo * TextLayout.Height),
                                                                TextLayout.TextWidth,
                                                                TextLayout.Height)
                    };
                    AddItem.PageNo = Current.PageNo;
                    AddItem.LineNo = Current.LineNo;
                    AddItem.itemType = ItemType.SheetText;
                    this.ItemList.Add(AddItem);
                }
                //アイテム内容（候補値）
                if (COMMENTs.Count <= inNo && (COMMENTs.Count + KOHOs.Count) > inNo)
                {
                    AddItem = new Position();
                    AddItem.CanvasItem = new Canvas.CanvasItem
                    {
                        style = Canvas.Style.Text,
                        Color = Color.White,
                        FontColor = Color.Black,
                        Font = new Font("ＭＳ 明朝", 7f),
                        Text = KOHOs[inNo - COMMENTs.Count],
                        Alignment = StringAlignment.Near,
                        LineAlignment = StringAlignment.Near,
                        Recangle = new Rectangle(TextLayout.TextX + 12,
                                                                TextLayout.Top + (Current.LineNo * TextLayout.Height),
                                                                TextLayout.TextWidth,
                                                                TextLayout.Height)
                    };
                    AddItem.PageNo = Current.PageNo;
                    AddItem.LineNo = Current.LineNo;
                    AddItem.itemType = ItemType.SheetKoho;
                    this.ItemList.Add(AddItem);
                }

                //アイテム内容（図表）
                if (inNo == (COMMENTs.Count + KOHOs.Count) && Item.image != null)
                {
                    AddItem = new Position();
                    AddItem.CanvasItem = new Canvas.CanvasItem
                    {
                        style = Canvas.Style.Image,
                        image = Item.image,
                        Zoom = true,
                        Recangle = new Rectangle(TextLayout.TextX + 12,
                                                                TextLayout.Top + (Current.LineNo * TextLayout.Height) + 1,
                                                                (int)(Item.image.Width * zoom),
                                                                (int)(Item.image.Height * zoom))
                    };
                    AddItem.PageNo = Current.PageNo;
                    AddItem.LineNo = Current.LineNo;
                    AddItem.itemType = ItemType.SheetImage;
                    this.ItemList.Add(AddItem);
                }

                //記事
                if (NOTEs.Count > inNo)
                {
                    AddItem = new Position();
                    AddItem.CanvasItem = new Canvas.CanvasItem
                    {
                        style = Canvas.Style.Text,
                        Color = Color.White,
                        FontColor = Color.Black,
                        Font = new Font("ＭＳ 明朝", 7f),
                        Text = NOTEs[inNo],
                        Alignment = StringAlignment.Near,
                        LineAlignment = StringAlignment.Near,
                        Recangle = new Rectangle(TextLayout.EtcX,
                                                                TextLayout.Top + (Current.LineNo * TextLayout.Height),
                                                                TextLayout.EtcWidth,
                                                                TextLayout.Height)
                    };
                    AddItem.PageNo = Current.PageNo;
                    AddItem.LineNo = Current.LineNo;
                    AddItem.itemType = ItemType.SheetNote;
                    this.ItemList.Add(AddItem);
                }

                //レベル
                DrawLevel = Level;
                if (DrawLevel > 5) DrawLevel = 5;
                if (DrawLevel > 0)
                {
                    AddItem = new Position();
                    AddItem.CanvasItem = new Canvas.CanvasItem
                    {
                        style = Canvas.Style.Box,
                        Color = Color.LightGray,
                        Fill = true,
                        Recangle = new Rectangle(TextLayout.LevelX,
                                                                TextLayout.Top + (Current.LineNo * TextLayout.Height) + 1,
                                                                (int)(TextLayout.LevelWidth / 5f * DrawLevel),
                                                                TextLayout.Height)
                    };
                    AddItem.PageNo = Current.PageNo;
                    AddItem.LineNo = Current.LineNo;
                    this.ItemList.Add(AddItem);

                    AddItem = new Position();
                    AddItem.CanvasItem = new Canvas.CanvasItem
                    {
                        style = Canvas.Style.Line,
                        dashStyle = System.Drawing.Drawing2D.DashStyle.Solid,
                        Color = Color.Black,
                        Recangle = new Rectangle(TextLayout.LevelX + (TextLayout.LevelWidth / 5 * DrawLevel),
                                                                TextLayout.Top + (Current.LineNo * TextLayout.Height) + 1,
                                                                0,
                                                                TextLayout.Height)
                    };
                    AddItem.PageNo = Current.PageNo;
                    AddItem.LineNo = Current.LineNo;
                    AddItem.LevelNo = DrawLevel;
                    AddItem.itemType = ItemType.SheetLevel;
                    this.ItemList.Add(AddItem);

                    for (int LinePos = 1; LinePos < DrawLevel; LinePos++)
                    {
                        AddItem = new Position();
                        AddItem.CanvasItem = new Canvas.CanvasItem
                        {
                            style = Canvas.Style.Line,
                            dashStyle = System.Drawing.Drawing2D.DashStyle.Dash,
                            Color = Color.Black,
                            Recangle = new Rectangle(TextLayout.LevelX + (TextLayout.LevelWidth / 5 * LinePos),
                                                                    TextLayout.Top + (Current.LineNo * TextLayout.Height) + 1,
                                                                    0,
                                                                    TextLayout.Height)
                        };
                        AddItem.PageNo = Current.PageNo;
                        AddItem.LineNo = Current.LineNo;
                        this.ItemList.Add(AddItem);
                    }
                }
                Current.LineNo++;
            }
            //罫線
            AddItem = new Position();
            AddItem.CanvasItem = new Canvas.CanvasItem();
            AddItem.CanvasItem.style = Canvas.Style.Line;
            AddItem.CanvasItem.dashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            AddItem.CanvasItem.LineWeight = 1;
            AddItem.CanvasItem.Color = Color.Black;
            AddItem.CanvasItem.Recangle = new Rectangle(TextLayout.Left,
                                                        TextLayout.Top + (Current.LineNo * TextLayout.Height),
                                                        TextLayout.Width,
                                                        0);
            AddItem.PageNo = Current.PageNo;
            AddItem.LineNo = Current.LineNo;
            AddItem.itemType = ItemType.SheetLine;
            this.ItemList.Add(AddItem);

            Current.Index++;

            foreach (IFLayout ChildItem in Item.ChildNodes)
            {
                this.IFLayoutToCanvasText(ChildItem, ref Current, Level + 1);
            }
        }

        /// <summary>
        /// 行取得
        /// </summary>
        /// <param name="str">文字列</param>
        /// <param name="MaxLength">１行当たりの最大文字数</param>
        /// <returns></returns>
        private List<string> getLines(string str, int MaxLength)
        {
            List<string> listLine = new List<string>();

            //改行が含まれているか確認する
            if (str.IndexOf('\n') != -1)
            {
                listLine.AddRange(str.Split('\n'));
            }
            else
            {
                listLine.Add(str);
            }
            List<string> bufLine = new List<string>();

            foreach(string t in listLine)
            {
                int pos = 0;
                while(pos < t.Length)
                {
                    if ((t.Length - pos) > MaxLength)
                    {
                        bufLine.Add(t.Substring(pos, MaxLength));
                        pos += MaxLength;
                    }
                    else
                    {
                        bufLine.Add(t.Substring(pos));
                        break;
                    }
                }
            }
            return bufLine;
        }

        private bool outputXlsxSheet(string file)
        {
            //雛形を読み込む
            try
            {
                using (FileStream fw = new FileStream(file, FileMode.Create, FileAccess.Write))
                {
                    fw.Write(Resources.ItemSheet, 0, Resources.ItemSheet.Length);
                    fw.Flush(); // エクセルで読み込むので、フラッシュしておく
                }
            }
            catch (Exception)
            {
                MessageBox.Show("ファイルの出力に失敗しました");
                //ファイル出力エラー
                return false;
            }

            try
            {
                using (ExcelUtils excel = new ExcelUtils())
                {
                    excel.FileName = file;
                    if (excel.Open())
                    {
                        for (int page = 0; page < this.MaxPage; page++)
                        {
                            //該当シートを雛形としてシートのコピーを行う
                            excel.WorkSheetName = "データ仕様書アイテム説明書（A4横）";
                            excel.CopySheet(string.Format("{0:D}", this.MaxPage - page));   //後ろの頁から複製することで、頁順に並ぶ

                            foreach (Position Item in this.ItemList)
                            {
                                if (Item.PageNo == (this.MaxPage - page - 1))   // 描画アイテムの頁とエクセルシートの頁が一致する場合は出力する
                                {
                                    int row = Item.LineNo + 6;
                                    switch (Item.itemType)
                                    {
                                        case ItemType.RecordName:               // レコード名称
                                            excel.SetTextBoxValue("Rectangle 25", Item.CanvasItem.Text);
                                            break;
                                        case ItemType.SheetNo:                  // 項番
                                            excel.WriteCell(row, 1, Item.CanvasItem.Text);
                                            break;
                                        case ItemType.SheetLevel:               // レベル番号
                                            for(int i = 0; i < Item.LevelNo; i++)
                                            {
                                                excel.SetBorderLine(row, 2 + i,
                                                                    row, 2 + i,
                                                                    ExcelUtils.XlBordersIndex.xlEdgeRight, ExcelUtils.XlLineStyle.xlContinuous);
                                                excel.setCellColor(row, 2 + i, Color.Black, Color.LightGray);
                                            }
                                            break;
                                        case ItemType.SheetID:                  // アイテム記号名称
                                            excel.WriteCell(row, 7, Item.CanvasItem.Text);
                                            break;
                                        case ItemType.SheetName:                // アイテム名称
                                            excel.WriteCell(row, 8, Item.CanvasItem.Text);
                                            break;
                                        case ItemType.SheetType:                // データ形式
                                            excel.WriteCell(row, 9, Item.CanvasItem.Text);
                                            break;
                                        case ItemType.SheetSize:                // データ長
                                            excel.WriteCell(row, 10, Item.CanvasItem.Text);
                                            break;
                                        case ItemType.SheetBit:                 // ビット位置
                                            excel.WriteCell(row, 11, Item.CanvasItem.Text);
                                            break;
                                        case ItemType.SheetText:                // アイテム内容
                                            excel.WriteCell(row, 12, Item.CanvasItem.Text);
                                            break;
                                        case ItemType.SheetKoho:                // 候補値
                                            excel.WriteCell(row, 13, Item.CanvasItem.Text);
                                            break;
                                        case ItemType.SheetImage:               // 図表
                                            string tmpPaht = Path.GetTempFileName();
                                            try
                                            {
                                                // 図表を一時保存
                                                Item.CanvasItem.image.Save(tmpPaht);
                                                RectangleF rf = excel.GetRectangleF(row, 13);
                                                excel.AddPicture(rf.X, 
                                                                 rf.Y + rf.Height / 10, 
                                                                 excel.PixcelToPoint(Item.CanvasItem.Recangle.Width, 96), 
                                                                 excel.PixcelToPoint(Item.CanvasItem.Recangle.Height, 96), 
                                                                 tmpPaht);
                                            }
                                            catch(Exception)
                                            {
                                                //
                                            }
                                            finally
                                            {
                                                File.Delete(tmpPaht);
                                            }
                                            break;
                                        case ItemType.SheetNote:                // 記事
                                            excel.WriteCell(row, 52, Item.CanvasItem.Text);
                                            break;
                                        case ItemType.SheetLine:
                                            excel.SetBorderLine(row, 1,
                                                                row, 52,
                                                                ExcelUtils.XlBordersIndex.xlEdgeTop, ExcelUtils.XlLineStyle.xlContinuous);
                                            break;
                                        default:                                // 出力対象外
                                            break;
                                    }
                                }
                            }
                        }
                        // 雛形のシートを削除する
                        excel.DeleteSheet("データ仕様書アイテム説明書（A4横）");
                        // 保存して閉じる
                        excel.Save();
                        excel.Close();
                    }
                }
            }
            catch
            {
                //エクセルのエラー
                return false;
            }
            GC.Collect();   // 強制的に解放

            return true;
        }

        #endregion

        #region 内部関数
        /// <summary>
        /// 子項目の設定
        /// </summary>
        private void MakeChild()
        {
            if (this.IFs.Count == 0) return;
            IFLayout curItem = null;
            List<IFLayout> ll = new List<IFLayout>();

            //複製の作成
            foreach (IFLayout Item in this.IFs)
            {
                ll.Add(Item.Clone());
            }

            foreach (IFLayout Item in ll)
            {

                if (curItem != null)
                {
                    // レベルの取得
                    if (!int.TryParse(curItem.Level, out int CurLevel))
                    {
                        CurLevel = 0;
                    }
                    if (!int.TryParse(Item.Level, out int ThisLevel))
                    {
                        ThisLevel = 0;
                    }

                    //レベルを比較して、親子関係を設定する。
                    if (CurLevel < ThisLevel)
                    {
                        Item.ParentNode = curItem;
                        curItem.ChildNodes.Add(Item);
                    }
                    else
                    {
                        //子項目として設定できる項目をサーチする
                        IFLayout PItem = curItem.ParentNode;
                        if (!int.TryParse(PItem.Level, out CurLevel))
                        {
                            CurLevel = 0;
                        }
                        while (!(CurLevel < ThisLevel))
                        {
                            PItem = PItem.ParentNode;
                            if (PItem == null) break;
                            if (!int.TryParse(PItem.Level, out CurLevel))
                            {
                                CurLevel = 0;
                            }
                        }
                        Item.ParentNode = PItem;
                        PItem.ChildNodes.Add(Item);
                    }
                }
                curItem = Item;
            }
            //最上位項目の複製を作成し、繰返し数を展開する
            this.IFNode = this.Expand(ll[0].DeepClone());
        }

        /// <summary>
        /// 繰返し数の展開
        /// </summary>
        /// <param name="Item"></param>
        /// <returns></returns>
        private IFLayout Expand(IFLayout Item)
        {
            // 子項目のOCCURS展開
            for (int i = 0; i < Item.ChildNodes.Count; i++)
            {
                if (Item.ChildNodes[i].RepeatCount > 1)
                {
                    IFLayout[] Items = new IFLayout[Item.ChildNodes[i].RepeatCount];
                    for (int j = 0; j < Items.Length; j++)
                    {
                        Items[j] = Item.ChildNodes[i].DeepClone();
                        Items[j].Current = j + 1;
                        Items[j].MaxCount = Items[j].RepeatCount;
                        Items[j].RepeatCount = 0;
                        if (Items[j].Type == "GROUP")
                        {
                            if (j == 0)
                            {
                                Items[j].isTarget = Item.ChildNodes[i].ParentNode.isTarget;
                            }
                            else
                            {
                                Items[j].isTarget = false;
                            }
                        }
                    }
                    Item.ChildNodes.RemoveAt(i);
                    Item.ChildNodes.InsertRange(i, Items);
                    i += (Items.Length - 1);
                }
                else
                {
                    if(Item.ChildNodes[i].Type == "GROUP")
                    {
                        Item.ChildNodes[i].isTarget = Item.ChildNodes[i].ParentNode.isTarget;
                    }
                }
            }
            // 孫項目のOCCURS展開
            for (int i = 0; i < Item.ChildNodes.Count; i++)
            {
                Item.ChildNodes[i] = this.Expand(Item.ChildNodes[i]);
            }

            return Item;
        }

        /// <summary>
        /// サイズ計算
        /// </summary>
        private void Recalculation()
        {
            if (this.IFNode == null) return;

            IFLayout RootItem = this.IFNode;
            SetGroupSize(RootItem);
        }

        /// <summary>
        /// 集団項目のサイズ計算
        /// </summary>
        /// <param name="GroupItem"></param>
        private void SetGroupSize(IFLayout GroupItem)
        {
            int BitSize = 0;
            int checkBitSize = 0;
            GroupItem.hasBit = false;
            foreach (IFLayout ChildItem in GroupItem.ChildNodes)
            {
                if (ChildItem.Type == "GROUP")
                {
                    if (checkBitSize % 8 > 0)
                    {
                        BitSize += 8 - checkBitSize % 8;
                    }
                    checkBitSize = 0;
                    SetGroupSize(ChildItem);
                }
                //ビット項目は別集計する
                if(ChildItem.Type == "BIT")
                {
                    BitSize += ChildItem.Size;
                    checkBitSize += ChildItem.Size;
                    GroupItem.hasBit = true;            // ビット項目を持っている集団項目
                }
                else
                {
                    if (checkBitSize % 8 > 0)
                    {
                        BitSize += 8 - checkBitSize % 8;
                    }
                    checkBitSize = 0;
                    GroupItem.Size += ChildItem.Size;
                }
            }

            //ビットサイズをバイトに変換して、加算する
            if (checkBitSize % 8 > 0)
            {
                BitSize += 8 - checkBitSize % 8;
            }
            GroupItem.Size += BitSize / 8;
        }



        /// <summary>
        /// 頁単位の設定
        /// </summary>
        /// <param name="canvas">描画先のCanvasクラス</param>
        /// <param name="itemlist">描画アイテムのリスト</param>
        /// <param name="Page">描画する頁</param>
        private void AddPageItem(Canvas canvas, List<Position> itemlist, int Page)
        {
            canvas.CanvasItems.Clear();
            foreach (Position Item in itemlist)
            {
                if (Item.PageNo == Page)
                {
                    canvas.CanvasItems.Add(Item.CanvasItem);
                }
            }
        }

        #endregion

        #region 内部クラス
        /// <summary>
        /// インタフェースレイアウト
        /// </summary>
        [SerializableAttribute()]
        private class IFLayout
        {
            /// <summary>
            /// レベル番号
            /// </summary>
            public string Level { get; set; }
            /// <summary>
            /// アイテム記号名称
            /// </summary>
            public string ID { get; set; }
            /// <summary>
            /// アイテム名称
            /// </summary>
            public string Name { get; set; }
            /// <summary>
            /// データ形式
            /// </summary>
            public string Type { get; set; }
            /// <summary>
            /// データサイズ
            /// </summary>
            public int Size { get; set; }
            /// <summary>
            /// ビット位置
            /// </summary>
            public int BitPosition { get; set; }
            /// <summary>
            /// 繰返し数
            /// </summary>
            public int RepeatCount { get; set; }
            /// <summary>
            /// 最大繰返し数
            /// </summary>
            public int MaxCount { get; set; }
            /// <summary>
            /// 現在の繰返し数
            /// </summary>
            public int Current { get; set; }
            /// <summary>
            /// アイテム内容
            /// </summary>
            public string Text { get; set; }
            /// <summary>
            /// 記事
            /// </summary>
            public string Etc { get; set; }
            /// <summary>
            /// 親ノード
            /// </summary>
            public IFLayout ParentNode { get; set; }
            /// <summary>
            /// 子ノード
            /// </summary>
            public List<IFLayout> ChildNodes { get; set; }
            /// <summary>
            /// 対象
            /// </summary>
            public bool isTarget { get; set; }
            /// <summary>
            /// ビット項目を持っているか
            /// </summary>
            public bool hasBit { get; set; }
            /// <summary>
            /// 候補値
            /// </summary>
            public string KOHO { get; set; }
            /// <summary>
            /// 図表
            /// </summary>
            public Image image { get; set; }
            /// <summary>
            /// 予備項目フラグ
            /// </summary>
            public bool FILLER { get; set; }

            /// <summary>
            /// コンストラクタ
            /// </summary>
            public IFLayout()
            {
                this.Text = string.Empty;
                this.Etc = string.Empty;
                this.KOHO = string.Empty;
                this.ChildNodes = new List<IFLayout>();
                this.ParentNode = null;
                this.isTarget = true;
                this.image = null;
                this.hasBit = false;
            }

            /// <summary>
            /// 指定の内容を複製するコンストラクタ
            /// </summary>
            /// <param name="Item"></param>
            private IFLayout(IFLayout Item)
            {
                this.Level = Item.Level;
                this.ID = Item.ID;
                this.Name = Item.Name;
                this.Type = Item.Type;
                this.Size = Item.Size;
                this.BitPosition = Item.BitPosition;
                this.RepeatCount = Item.RepeatCount;
                this.Text = Item.Text;
                this.Etc = Item.Etc;
                this.KOHO = Item.KOHO;
                this.isTarget = Item.isTarget;
                this.hasBit = Item.hasBit;
                this.ParentNode = null;
                this.ChildNodes = new List<IFLayout>();
                this.MaxCount = Item.MaxCount;
                if (Item.image != null)
                {
                    this.image = (Image)Item.image.Clone();
                }
                this.FILLER = Item.FILLER;
            }

            /// <summary>
            /// 複製の作成
            /// </summary>
            /// <returns></returns>
            public IFLayout Clone()
            {
                return new IFLayout(this);
            }

            /// <summary>
            /// 複製の作成（参照型も値で複製）
            /// </summary>
            /// <returns></returns>
            public IFLayout DeepClone()
            {
                // 高速化の為、一旦親項目をnullに変更する
                IFLayout OriginalParent = this.ParentNode;
                this.ParentNode = null;
                // BinaryFormatter でシリアライズしたオブジェクトを
                // デシリアライズすることで、DeepClone（参照型も値を複製）する。
                object result;
                BinaryFormatter b = new BinaryFormatter();
                MemoryStream mem = new MemoryStream();
                try
                {
                    b.Serialize(mem, this);
                    mem.Position = 0;
                    result = b.Deserialize(mem);
                }
                finally
                {
                    //オリジナルの親項目を元に戻す
                    this.ParentNode = OriginalParent;
                    mem.Close();
                }
                //但し、親項目については、コピー元と同じ参照先とする
                IFLayout Node = (IFLayout)result;
                Node.ParentNode = this.ParentNode;
                return Node;
            }
        }

        /// <summary>
        /// アイテム説明書の座標情報
        /// </summary>
        private class TextLayout
        {
            public static readonly int Left = 3;
            public static readonly int Top = 60;
            public static readonly int Width = 1116;
            public static readonly int Height = 16;
            public static readonly int IndexX = 3;
            public static readonly int IndexWidth = 35;
            public static readonly int LevelX = 42;
            public static readonly int LevelWidth = 66;
            public static readonly int IdX = 110;
            public static readonly int IdWidth = 95;
            public static readonly int NameX = 208;
            public static readonly int NameWidth = 170;
            public static readonly int TypeX = 380;
            public static readonly int TypeWidth = 44;
            public static readonly int SizeX = 426;
            public static readonly int SizeWidth = 46;
            public static readonly int BitX = 474;
            public static readonly int BitWidth = 36;
            public static readonly int TextX = 520;
            public static readonly int TextWidth = 500;
            public static readonly int EtcX = 1041;
            public static readonly int EtcWidth = 76;
            public static readonly int RecordX = 360;
            public static readonly int RecordWidth = 275;
            public static readonly int RecordY = 710;
            public static readonly int RecordHeight = 44;

        }

        /// <summary>
        /// アイテム構成図の座標情報
        /// </summary>
        private class PictureLayout
        {
            /// <summary>
            /// 画面
            /// </summary>
            public class Canvas
            {
                /// <summary>箱（項目単位）のＸ座標</summary>
                public static readonly List<int> LayoutX = new List<int>() { 49, 154, 258, 363, 588, 693, 798, 903 };
                /// <summary>箱（箱単位）のＹ座標</summary>
                public static readonly List<int> LayoutY = new List<int>() { 99, 160, 222, 284, 345, 407, 468, 530, 592, 654 };
                /// <summary>箱（項目単位）の幅</summary>
                public static readonly List<int> LayoutWidth = new List<int>() { 104, 103, 104, 104, 104, 104, 104, 104 };
                /// <summary>箱（箱単位）の高さ</summary>
                public static readonly List<int> LayoutHeight = new List<int>() { 32, 33, 33, 32, 33, 33, 33, 33, 32, 32 };
                /// <summary>終端線の開始位置（Ｘ座標）</summary>
                public static readonly List<int> LineX = new List<int>() { 10, 549 };
                /// <summary>終端線の開始位置（Ｙ座標）</summary>
                public static readonly int LineY = 10;
                /// <summary>終端線の幅</summary>
                public static readonly int LineWidth = 529;
                /// <summary>レコード名称の開始位置（Ｘ座標）</summary>
                public static readonly int RecordX = 365;
                /// <summary>レコード名称の幅</summary>
                public static readonly int RecordWidth = 245;
                /// <summary>レコード名称の開始位置（Ｙ座標）</summary>
                public static readonly int RecordY = 725;
                /// <summary>レコード名称の高さ</summary>
                public static readonly int RecordHeight = 40;
            }
            /// <summary>
            /// エクセルシート
            /// </summary>
            public class Excel
            {
                /// <summary>箱（箱単位）のＸ座標</summary>
                public static readonly List<float> BoxX = new List<float>() { 25.5f, 435.8f };
                /// <summary>箱（最上部）のＹ座標</summary>
                public static readonly float BoxY = 58.5f;
                /// <summary>箱（項目単位）の幅</summary>
                public static readonly float BoxWidht = 79.5f;
                /// <summary>箱（箱単位）の高さ</summary>
                public static readonly float BoxHeight = 30.0f;
                /// <summary>箱の上下間の長さ</summary>
                public static readonly float BoxMargin = 18.75f;
                /// <summary>終端線のＸ座標</summary>
                public static readonly List<float> LineX = new List<float>() { 5.5f, 415, 8f };
                /// <summary>終端線のＹ座標</summary>
                public static readonly float LineY = 35.4f;
                /// <summary>終端線の幅</summary>
                public static readonly float LineWidth = 395f;
                /// <summary>１文字の幅</summary>
                public static readonly float CharWidth = 8.0f;
                /// <summary>項目サイズ毎の最大文字数</summary>
                public static readonly List<int> MaxWordSize = new List<int>() { 8, 17, 27, 0};
                /// <summary>集団項目の文字列表示幅</summary>
                public static readonly float GroupWidth = 13.5f;
                /// <summary>集団項目の文字列表示開始位置</summary>
                public static readonly float GroupNameOffset = 4.0f;
            }

        }

        #endregion

        #region 内部構造体
        /// <summary>
        /// 描画位置情報
        /// </summary>
        private struct Position
        {
            /// <summary>
            /// 頁番号
            /// </summary>
            public int PageNo;
            /// <summary>
            /// 構成図の箱番号
            /// </summary>
            public int BoxNo;
            /// <summary>
            /// 構成図の箱数
            /// </summary>
            public int BoxCount;
            /// <summary>
            /// 構成図の箱の位置
            /// </summary>
            public int BoxPosition;
            /// <summary>
            /// バイト位置
            /// </summary>
            public int BytePosition;
            /// <summary>
            /// 構成図の箱のエリアサイズ
            /// </summary>
            public int BoxSize;
            /// <summary>
            /// 階層
            /// </summary>
            public int LevelNo;
            /// <summary>
            /// 前回のバイト位置
            /// </summary>
            public int PreBytePositon;
            /// <summary>
            /// 説明書の行番号
            /// </summary>
            public int LineNo;
            /// <summary>
            /// 項目の種類
            /// </summary>
            public ItemType itemType;
            /// <summary>
            /// 識別子
            /// </summary>
            public int Index;
            /// <summary>
            /// 描画アイテム
            /// </summary>
            public Canvas.CanvasItem CanvasItem;
            /// <summary>
            /// テキスト内容
            /// </summary>
            public string Text;
        }
        #endregion
    }
}
