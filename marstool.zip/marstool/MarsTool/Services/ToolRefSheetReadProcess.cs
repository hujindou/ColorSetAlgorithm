﻿using MarsTool.Models.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;
using System.IO;
using System.Security.Principal;
using System.Transactions;
using MarsTool.Properties;
using MarsTool.Daos;
using MarsTool.Exceptions;
using MarsTool.Common;
using MarsTool.Models;
using System.ComponentModel.DataAnnotations;
using Microsoft.Office.Interop.Excel;

namespace MarsTool.Services
{
    class ToolRefSheetReadProcess
    {
        private NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        private VersionModel version;

        private CopyKuDBConnectivity dBConnectivity;

        public ToolRefSheetReadProcess(VersionModel v)
        {
            version = v;
            dBConnectivity = new CopyKuDBConnectivity(v);
        }

        /// <summary>
        /// ツール専用シートの読み込み処理と登録処理
        /// </summary>
        /// <param name="inputPath"></param>
        /// <param name="userId"></param>
        /// <param name="subSysIdList"></param>
        /// <param name="addressSize"></param>
        /// <returns></returns>
        public List<String> ToolRefSheetReadAndRegisterProcess(string inputPath, string userId, List<string> subSysIdList, string addressSize)
        {
            List<String> result = new List<string>();
            Excel.Application xlApp = null;
            Excel.Workbook xlWorkBook = null;
            Excel.Worksheet xlWorkSheet = null;
            try
            {
                xlApp = new Excel.Application();
                xlApp.DisplayAlerts = false;
                xlApp.Visible = false;
                xlWorkBook = xlApp.Workbooks.Open(inputPath, ReadOnly: true);
                string sheetName = null;
                //一シートずつ読み込む。       
                for (int i = 1; i <= xlWorkBook.Worksheets.Count; i++)
                {
                    xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets[i];
                    sheetName = xlWorkSheet.Name;
                    PhysicalCopyKuInfo phyCopyKuInfo = CreatePhysicalCopyKuInfo(xlWorkSheet, subSysIdList, inputPath);
                    using (TransactionScope scope = new TransactionScope(TransactionScopeOption.RequiresNew))
                    {
                        try
                        {
                            if (phyCopyKuInfo != null)
                            {
                                PhysicalCopyKuInfo copyKu = dBConnectivity.SelectPhysicalCopyKuInfo(phyCopyKuInfo.CPYPHY_SubSysId, phyCopyKuInfo.CPYPHY_InfoId);

                                if (copyKu.CPYPHY_Size > 0 && copyKu.CPYPHY_STATUS != ConstantUtils.STATUS_DELELTE)
                                {
                                    bool isErrorExist = false;

                                    isErrorExist = RegisterPhysicalCopyKuInfo(phyCopyKuInfo, phyCopyKuInfo.CPYPHY_InfoId, false, userId, addressSize);


                                    if (isErrorExist == false)
                                    {
                                        //　設定条件情報をDBへデータを登録する。
                                        List<string> opNameList = SelectSettingConditionInfo(phyCopyKuInfo.setCondList);
                                        if (opNameList.Count > 0)
                                        {
                                            int settingColOrder = dBConnectivity.SelectLastOutputOrderNoOfSettingInfo(phyCopyKuInfo.CPYPHY_SubSysId, phyCopyKuInfo.CPYPHY_InfoId);

                                            foreach (string col in opNameList)
                                            {
                                                List<SettingConditionInfo> conditionInfos = phyCopyKuInfo.setCondList.Where(sCond => col == sCond.COND_OPNM).ToList();

                                                if (conditionInfos.Count > 0)
                                                {
                                                    settingColOrder++;
                                                    foreach (SettingConditionInfo item in conditionInfos)
                                                    {
                                                        PhysicalCopyKuItemInfo itemInfo = dBConnectivity.SelectPhysicalCopyKuItemInfo(item.COND_SUBSYSID, item.COND_INFOID, item.PHYITM_Path, item.PHYITM_ItemNo);

                                                        if (itemInfo != null)
                                                        {
                                                            item.COND_SEQ = itemInfo.PHYITM_Seq;
                                                            item.COND_OUTPUTORDER = settingColOrder;
                                                            dBConnectivity.insertLogicalSettingCondtionInfo(item);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        if (phyCopyKuInfo.mParserInfoList.Count > 0)
                                        {
                                            // 物理Ｍパーサ情報をDBへデータを登録する 。
                                            bool isExist = RegisterPhysicalMParserInfo(phyCopyKuInfo.mParserInfoList, phyCopyKuInfo.CPYPHY_InfoId, phyCopyKuInfo.CPYPHY_SubSysId, phyCopyKuInfo.mParserInfoList[0].PHYPRS_SUBSYSID);

                                            if (isExist == false)
                                            {
                                                foreach (T_PHYPRS item in phyCopyKuInfo.mParserInfoList)
                                                {
                                                    PhysicalCopyKuItemInfo itemInfo = dBConnectivity.SelectPhysicalCopyKuItemInfo(item.PHYPRS_PHYSYSID, item.PHYPRS_INFOID, item.PHYITM_PATH, item.PHYITM_ITEMNO);

                                                    if (itemInfo != null)
                                                    {
                                                        item.PHYPRS_SEQ = itemInfo.PHYITM_Seq;
                                                        item.PHYPRS_USERID = userId;
                                                        dBConnectivity.insertPhysicalMParserInfo(item);
                                                    }
                                                }
                                            }
                                        }
                                        List<LogicalCopyKuInfo> headerInfos = IsExistLogicalHeaderInfo(phyCopyKuInfo.logicalHeaderInfos, phyCopyKuInfo.CPYPHY_InfoId, phyCopyKuInfo.CPYPHY_SubSysId, userId);
                                        if (headerInfos.Count > 0)
                                        {
                                            int logicColOrder = dBConnectivity.SelectLastOutputOrderNoOfLogicalInfo(phyCopyKuInfo.CPYPHY_SubSysId, phyCopyKuInfo.CPYPHY_InfoId, headerInfos[0].CPYLGC_SUBSYSID);

                                            foreach (LogicalCopyKuInfo info in headerInfos)
                                            {
                                                logicColOrder++;
                                                info.CPYLGC_USERID = userId;
                                                info.CPYLGC_OUTPUTORDER = logicColOrder;
                                                dBConnectivity.insertLogicalCopyKuInfo(info);

                                                List<LogicalCopyKuItemInfo> logicalItems = info.logCpyItemInfoList.Where(itm => (itm.LOGITM_SUBSYSIDL == info.CPYLGC_SUBSYSID) && (itm.LOGITM_LCPID == info.CPYLGC_LCPID)).ToList();

                                                if (logicalItems.Count > 0)
                                                {
                                                    foreach (LogicalCopyKuItemInfo logInfo in logicalItems)
                                                    {
                                                        PhysicalCopyKuItemInfo itemInfo = dBConnectivity.SelectPhysicalCopyKuItemInfo(info.CPYLGC_PHYSYSID, info.CPYLGC_INFOID, logInfo.PHYITM_Path, logInfo.PHYITM_ItemNo);

                                                        if (itemInfo != null)
                                                        {
                                                            logInfo.LOGITM_SEQ = itemInfo.PHYITM_Seq;

                                                            if (logInfo.LOGITM_DTTYPE == "ADDRESS")
                                                            {
                                                                logInfo.LOGITM_DTTYPE = logInfo.LOGITM_DTTYPE;
                                                                string tempStr = logInfo.LOGITM_DTTYPE + " (" + addressSize + ")";
                                                                logInfo.LOGITM_DTTYPE = tempStr;

                                                            }
                                                            dBConnectivity.insertLogicalCopyKuItemInfo(logInfo);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        result.Add(sheetName);
                                        logger.Info(string.Format("情報部「{0}」の読み込む処理が異常終了しました", sheetName));
                                    }
                                }
                                else
                                {
                                    int ctn = dBConnectivity.SelectPhysicalCopyKuID(phyCopyKuInfo.CPYPHY_BcpId);

                                    if (ctn == 1)
                                    {
                                        logger.Error($"{version.User.USERID}" + string.Format(Resources.TSR00018_E, xlWorkSheet.Name, phyCopyKuInfo.CPYPHY_BcpId));
                                        return null;
                                    }
                                    bool isError = RegisterPhysicalCopyKuInfo(phyCopyKuInfo, phyCopyKuInfo.CPYPHY_InfoId, true, userId, addressSize);
                                    if (isError == true) continue;
                                }
                                scope.Complete();
                                if (result.Contains(sheetName) == false)
                                {
                                    logger.Info(string.Format("情報部「{0}」の読み込む処理が正常終了しました", sheetName));
                                }
                            }
                            else
                            {
                                result.Add(sheetName);
                            }
                        }
                        catch (CopyKuInfoReadProcessException e)
                        {
                            scope.Dispose();
                            throw new CopyKuInfoReadProcessException(e.GetMessage());
                        }
                        catch (Exception e)
                        {
                            scope.Dispose();
                            //Log for unexpected error
                            //想定外エラーが発生する場合、ログに記録
                            logger.Error(e, $"{version.User.USERID}" + Resources.CKR00099_E);

                            //Throw Error CKR00099-E
                            //CKR00099-E　エラーをスロー
                            throw new CopyKuInfoReadProcessException(Resources.CKR00099_E, e);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                //Log for unexpected error
                //想定外エラーが発生する場合、ログに記録
                logger.Error(e, $"{version.User.USERID}" + e.Message);

                //Throw Error CKR00099-E
                //CKR00099-E　エラーをスロー
                throw new CopyKuInfoReadProcessException(e.Message, e);
            }
            finally
            {
                if (xlWorkSheet != null)
                {
                    Marshal.ReleaseComObject(xlWorkSheet);
                    xlWorkSheet = null;
                }

                if (xlWorkBook != null)
                {
                    xlWorkBook.Close(Type.Missing, Type.Missing, Type.Missing);
                    Marshal.ReleaseComObject(xlWorkBook);
                    xlWorkBook = null;
                }

                if (xlApp != null)
                {
                    xlApp.Quit();
                    Marshal.ReleaseComObject(xlApp);
                    xlApp = null;
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
            return result;
        }

        /// <summary>
        /// 物理コピー句情報登録
        /// </summary>
        /// <param name="phyCopyKuInfo"></param>
        /// <param name="infoId"></param>
        /// <param name="isPhyCpyNew"></param>
        /// <param name="userId"></param>
        /// <param name="addressSize"></param>
        /// <returns></returns>
        private Boolean RegisterPhysicalCopyKuInfo(PhysicalCopyKuInfo phyCopyKuInfo, string infoId, bool isPhyCpyNew, string userId, string addressSize)
        {
            bool isError = false;
            try
            {
                if (isPhyCpyNew == false)
                {
                    List<PhysicalCopyKuItemInfo> dbItemInfos = dBConnectivity.SelectPhysicalCopyKuItemInfos(phyCopyKuInfo.CPYPHY_SubSysId, phyCopyKuInfo.CPYPHY_InfoId);

                    PhysicalCopyKuInfo oldUpdateUser = dBConnectivity.SelectLastUpdateUser(phyCopyKuInfo.CPYPHY_SubSysId, phyCopyKuInfo.CPYPHY_InfoId);

                    int count = dBConnectivity.SelectCopyKuDataTypeCount(phyCopyKuInfo.CPYPHY_SubSysId, phyCopyKuInfo.CPYPHY_InfoId);

                    //不一致項目情報をログファイルに出力する。
                    //foreach (PhysicalCopyKuItemInfo dbItem in dbItemInfos)
                    //{
                    //    //var result = phyCopyKuInfo.phyCpyItemInfoList.FirstOrDefault(r => r.PHYITM_ItemNo == dbItem.PHYITM_ItemNo && r.PHYITM_Path == dbItem.PHYITM_Path);

                    //    if (result != null)
                    //    {
                    //        if (!dbItem.PHYITM_ItemName.Equals(result.PHYITM_ItemName))
                    //        {
                    //            logger.Error($"{version.User.USERID}" + string.Format(Resources.TSR00006_E, infoId, result.PHYITM_ItemNo + 16, "アイテム名称"));
                    //            isError = true;
                    //            return isError;
                    //        }

                    //        if (!dbItem.PHYITM_Level.Equals(result.PHYITM_Level))
                    //        {
                    //            logger.Error($"{version.User.USERID}" + string.Format(Resources.TSR00006_E, infoId, result.PHYITM_ItemNo + 16, "レベル"));
                    //            isError = true;
                    //            return isError;
                    //        }

                    //        if ((dbItem.PHYITM_DTTYPE != null && dbItem.PHYITM_DTTYPE != string.Empty) && (result.PHYITM_DTTYPE != null && result.PHYITM_DTTYPE != string.Empty))
                    //        {
                    //            if (!dbItem.PHYITM_DTTYPE.Equals(result.PHYITM_DTTYPE))
                    //            {
                    //                logger.Error($"{version.User.USERID}" + string.Format(Resources.TSR00006_E, infoId, result.PHYITM_ItemNo + 16, "データ形式"));
                    //                isError = true;
                    //                return isError;
                    //            }
                    //        }

                    //        if (dbItem.PHYITM_DTLEN != 0 && result.PHYITM_DTLEN != 0)
                    //        {
                    //            if (!dbItem.PHYITM_DTLEN.Equals(result.PHYITM_DTLEN))
                    //            {
                    //                logger.Error($"{version.User.USERID}" + string.Format(Resources.TSR00006_E, infoId, result.PHYITM_ItemNo + 16, "データサイズ"));
                    //                isError = true;
                    //                return isError;
                    //            }

                    //            if (count > 0)
                    //            {
                    //                if (dbItem.PHYITM_CPYDTTYPE != null)
                    //                {
                    //                    if (CobolUtils.GetSize(dbItem.PHYITM_CPYDTTYPE) != result.PHYITM_DTLEN)
                    //                    {
                    //                        logger.Error($"{version.User.USERID}" + string.Format(Resources.TSR00006_E, infoId, result.PHYITM_ItemNo + 16, "データサイズ"));
                    //                        isError = true;
                    //                        return isError;
                    //                    }
                    //                }
                    //            }
                    //        }

                    //        if ((dbItem.PHYITM_CPYDTTYPE != null && dbItem.PHYITM_CPYDTTYPE != string.Empty) && (result.PHYITM_CPYDTTYPE != null && result.PHYITM_CPYDTTYPE != string.Empty))
                    //        {
                    //            if (!dbItem.PHYITM_CPYDTTYPE.Equals(result.PHYITM_CPYDTTYPE))
                    //            {
                    //                logger.Error($"{version.User.USERID}" + string.Format(Resources.TSR00006_E, infoId, result.PHYITM_ItemNo + 16, "コピー句データ形式"));
                    //                isError = true;
                    //                return isError;
                    //            }
                    //        }
                    //    }
                    //    else
                    //    {
                    //        logger.Error($"{version.User.USERID}" + string.Format(Resources.TSR00006_E, infoId, result.PHYITM_ItemNo + 16, "アイテム名称"));
                    //        logger.Error($"{version.User.USERID}" + string.Format(Resources.TSR00006_E, infoId, "アイテム名称", dbItem.PHYITM_ItemName, dbItem.PHYITM_ItemFlg));
                    //        isError = true;
                    //        return isError;
                    //    }
                    //}

                    for (int i = 0; i < dbItemInfos.Count; i++)
                    {
                        if (phyCopyKuInfo.phyCpyItemInfoList.Count == i)
                        {
                            break;
                        }
                        if (dbItemInfos[i].PHYITM_ItemNo.Equals(phyCopyKuInfo.phyCpyItemInfoList[i].PHYITM_ItemNo))
                        {
                            if (!dbItemInfos[i].PHYITM_ItemName.Equals(phyCopyKuInfo.phyCpyItemInfoList[i].PHYITM_ItemName))
                            {
                                logger.Error($"{version.User.USERID}" + string.Format(Resources.TSR00006_E, infoId, phyCopyKuInfo.phyCpyItemInfoList[i].PHYITM_ItemNo + 16, "アイテム名称"));
                                isError = true;
                                return isError;
                            }

                            if (!dbItemInfos[i].PHYITM_Level.Equals(phyCopyKuInfo.phyCpyItemInfoList[i].PHYITM_Level))
                            {
                                logger.Error($"{version.User.USERID}" + string.Format(Resources.TSR00006_E, infoId, phyCopyKuInfo.phyCpyItemInfoList[i].PHYITM_ItemNo + 16, "レベル"));
                                isError = true;
                                return isError;
                            }

                            if ((dbItemInfos[i].PHYITM_DTTYPE != null && dbItemInfos[i].PHYITM_DTTYPE != string.Empty) && (phyCopyKuInfo.phyCpyItemInfoList[i].PHYITM_DTTYPE != null && phyCopyKuInfo.phyCpyItemInfoList[i].PHYITM_DTTYPE != string.Empty))
                            {
                                if (!dbItemInfos[i].PHYITM_DTTYPE.Equals(phyCopyKuInfo.phyCpyItemInfoList[i].PHYITM_DTTYPE))
                                {
                                    logger.Error($"{version.User.USERID}" + string.Format(Resources.TSR00006_E, infoId, phyCopyKuInfo.phyCpyItemInfoList[i].PHYITM_ItemNo + 16, "データ形式"));
                                    isError = true;
                                    return isError;
                                }
                            }

                            if (dbItemInfos[i].PHYITM_DTLEN != 0 && phyCopyKuInfo.phyCpyItemInfoList[i].PHYITM_DTLEN != 0)
                            {
                                if (!dbItemInfos[i].PHYITM_DTLEN.Equals(phyCopyKuInfo.phyCpyItemInfoList[i].PHYITM_DTLEN))
                                {
                                    logger.Error($"{version.User.USERID}" + string.Format(Resources.TSR00006_E, infoId, phyCopyKuInfo.phyCpyItemInfoList[i].PHYITM_ItemNo + 16, "データサイズ"));
                                    isError = true;
                                    return isError;
                                }

                                if (count > 0)
                                {
                                    if (dbItemInfos[i].PHYITM_CPYDTTYPE != null)
                                    {
                                        if (CobolUtils.GetSize(dbItemInfos[i].PHYITM_CPYDTTYPE) != phyCopyKuInfo.phyCpyItemInfoList[i].PHYITM_DTLEN)
                                        {
                                            logger.Error($"{version.User.USERID}" + string.Format(Resources.TSR00006_E, infoId, phyCopyKuInfo.phyCpyItemInfoList[i].PHYITM_ItemNo + 16, "データサイズ"));
                                            isError = true;
                                            return isError;
                                        }
                                    }
                                }
                            }
                            if ((dbItemInfos[i].PHYITM_CPYDTTYPE != null && dbItemInfos[i].PHYITM_CPYDTTYPE != string.Empty) && (phyCopyKuInfo.phyCpyItemInfoList[i].PHYITM_CPYDTTYPE != null && phyCopyKuInfo.phyCpyItemInfoList[i].PHYITM_CPYDTTYPE != string.Empty))
                            {
                                if (!dbItemInfos[i].PHYITM_CPYDTTYPE.Equals(phyCopyKuInfo.phyCpyItemInfoList[i].PHYITM_CPYDTTYPE))
                                {
                                    logger.Error($"{version.User.USERID}" + string.Format(Resources.TSR00006_E, infoId, phyCopyKuInfo.phyCpyItemInfoList[i].PHYITM_ItemNo + 16, "コピー句データ形式"));
                                    isError = true;
                                    return isError;
                                }
                            }
                        }
                    }

                    if(phyCopyKuInfo.phyCpyItemInfoList.Count > dbItemInfos.Count)
                    {
                        List<PhysicalCopyKuItemInfo> results = phyCopyKuInfo.phyCpyItemInfoList.Where(e => !dbItemInfos.Any(m => m.PHYITM_ItemNo == e.PHYITM_ItemNo && m.PHYITM_Path == e.PHYITM_Path)).ToList();
                        if (results.Count > 0)
                        {
                            logger.Error($"{version.User.USERID}" + string.Format("情報部ID「{0}」の項目「{1}」がDBに存在しません。", infoId, results[0].PHYITM_ItemName));
                            isError = true;
                            return isError;
                        }
                    }
                    else
                    {
                        List<PhysicalCopyKuItemInfo> results = dbItemInfos.Where(e => !phyCopyKuInfo.phyCpyItemInfoList.Any(m => m.PHYITM_ItemNo == e.PHYITM_ItemNo && m.PHYITM_Path == e.PHYITM_Path)).ToList();
                        if (results.Count > 0)
                        {
                            logger.Error($"{version.User.USERID}" + string.Format("情報部ID「{0}」の項目「{1}」がDBに存在しません。", infoId, results[0].PHYITM_ItemName));
                            isError = true;
                            return isError;
                        }
                    }                   

                    foreach (PhysicalCopyKuItemInfo dbItem in dbItemInfos)
                    {
                        var result = phyCopyKuInfo.phyCpyItemInfoList.FirstOrDefault(r => r.PHYITM_ItemNo == dbItem.PHYITM_ItemNo && r.PHYITM_Path == dbItem.PHYITM_Path);

                        if (result != null)
                        {
                            bool isUpdate = false;

                            if (dbItem.PHYITM_ItemId == null && result.PHYITM_ItemId != string.Empty)
                            {
                                dbItem.PHYITM_ItemId = result.PHYITM_ItemId;
                                isUpdate = true;
                            }
                            if ((dbItem.PHYITM_DTTYPE == null || dbItem.PHYITM_DTTYPE == string.Empty) && result.PHYITM_DTTYPE != string.Empty)
                            {
                                dbItem.PHYITM_DTTYPE = result.PHYITM_DTTYPE;
                                isUpdate = true;
                            }
                            if (dbItem.PHYITM_DTLEN == 0 && result.PHYITM_DTLEN != 0)
                            {
                                dbItem.PHYITM_DTLEN = result.PHYITM_DTLEN;
                                isUpdate = true;
                            }
                            if (dbItem.PHYITM_Occurs == 0 && result.PHYITM_Occurs != 0)
                            {
                                dbItem.PHYITM_Occurs = result.PHYITM_Occurs;
                                isUpdate = true;
                            }
                            if ((dbItem.PHYITM_Comment == null || dbItem.PHYITM_Comment == string.Empty) && result.PHYITM_Comment != string.Empty)
                            {
                                dbItem.PHYITM_Comment = result.PHYITM_Comment;
                                isUpdate = true;
                            }
                            if ((dbItem.PHYITM_Note == null || dbItem.PHYITM_Note == string.Empty) && result.PHYITM_Note != string.Empty)
                            {
                                dbItem.PHYITM_Note = result.PHYITM_Note;
                                isUpdate = true;
                            }
                            if (isUpdate == true)
                            {
                                PhysicalCopyKuInfo lastUpdateUser = dBConnectivity.SelectLastUpdateUser(phyCopyKuInfo.CPYPHY_SubSysId, phyCopyKuInfo.CPYPHY_InfoId);
                                if (oldUpdateUser.CPYPHY_UserId != lastUpdateUser.CPYPHY_UserId || oldUpdateUser.CPYPHY_UPDTIME != lastUpdateUser.CPYPHY_UPDTIME)
                                {
                                    logger.Error($"{version.User.USERID}" + string.Format(Resources.IF_LOG_UPDATE_NO_W, "物理コピー句情報", lastUpdateUser.CPYPHY_UserId, lastUpdateUser.CPYPHY_UPDTIME));
                                    throw new CopyKuInfoReadProcessException(string.Format(Resources.IF_LOG_UPDATE_NO_W, "物理コピー句情報", lastUpdateUser.CPYPHY_UserId, lastUpdateUser.CPYPHY_UPDTIME));
                                }
                                int res = dBConnectivity.updatePhyCopyKuItemInfo(dbItem);
                            }
                        }
                    }
                }
                else
                {
                    phyCopyKuInfo.CPYPHY_UserId = userId;
                    //phyCopyKuInfo.CPYPHY_UPDTIME = DateTime.Now.ToString("yyyyMMddHHmmssffff");
                    // 物理コピー句情報をDBへデータを登録する。
                    dBConnectivity.insertPhyCopyKuInfo(phyCopyKuInfo);

                    List<string> opNameList = SelectSettingConditionInfo(phyCopyKuInfo.setCondList);

                    bool isExist = RegisterPhysicalMParserInfo(phyCopyKuInfo.mParserInfoList, phyCopyKuInfo.CPYPHY_InfoId, phyCopyKuInfo.CPYPHY_SubSysId, phyCopyKuInfo.CPYPHY_BcpId);

                    List<LogicalCopyKuInfo> logCopyKuInfos = IsExistLogicalHeaderInfo(phyCopyKuInfo.logicalHeaderInfos, phyCopyKuInfo.CPYPHY_InfoId, phyCopyKuInfo.CPYPHY_SubSysId, userId);


                    // 物理コピー句アイテム情報をDBへデータを登録する。
                    foreach (PhysicalCopyKuItemInfo item in phyCopyKuInfo.phyCpyItemInfoList)
                    {
                        string seq = this.version.genSequenceID2("T_PHYITM");
                        item.PHYITM_Seq = seq;
                        if (item.PHYITM_CPYDTTYPE == "ADDRESS")
                        {
                            if (addressSize != null)
                            {
                                string tempStr = item.PHYITM_CPYDTTYPE + " (" + addressSize + ")";
                                item.PHYITM_CPYDTTYPE = tempStr;
                            }
                        }
                        dBConnectivity.insertPhyCopyKuItemInfo(item);

                        if (isExist == false)
                        {
                            //物理Ｍパーサ情報をDBへデータを登録する。
                            if (item.mParserItemInfo != null && item.mParserItemInfo.PHYPRS_TAGNM != string.Empty)
                            {
                                item.mParserItemInfo.PHYPRS_SEQ = seq;
                                item.mParserItemInfo.PHYPRS_USERID = userId;
                                dBConnectivity.insertPhysicalMParserInfo(item.mParserItemInfo);
                            }
                        }
                        //　設定条件情報をDBへデータを登録する。      
                        List<SettingConditionInfo> tempList = item.settingConditionInfos.Where(set => opNameList.Any(op => set.COND_OPNM == op)).ToList();

                        if (tempList.Count > 0)
                        {
                            foreach (SettingConditionInfo setInfo in tempList)
                            {
                                setInfo.COND_SEQ = seq;
                                dBConnectivity.insertLogicalSettingCondtionInfo(setInfo);
                            }
                        }
                        //if (opNameList.Count > 0)
                        //{
                        //    int settingColOrder = dBConnectivity.SelectLastOutputOrderNoOfSettingInfo(phyCopyKuInfo.CPYPHY_SubSysId, phyCopyKuInfo.CPYPHY_InfoId);

                        //    foreach (string col in opNameList)
                        //    {
                        //        List<SettingConditionInfo> conditionInfos = phyCopyKuInfo.setCondList.Where(sCond => col == sCond.COND_OPNM).ToList();

                        //        if (conditionInfos.Count > 0)
                        //        {
                        //            settingColOrder++;
                        //            foreach (SettingConditionInfo setItem in conditionInfos)
                        //            {
                        //                PhysicalCopyKuItemInfo itemInfo = dBConnectivity.SelectPhysicalCopyKuItemInfo(setItem.COND_SUBSYSID, setItem.COND_INFOID, setItem.PHYITM_Path, setItem.PHYITM_ItemNo);

                        //                if (itemInfo != null)
                        //                {
                        //                    setItem.COND_SEQ = itemInfo.PHYITM_Seq;
                        //                    setItem.COND_OUTPUTORDER = settingColOrder;
                        //                    dBConnectivity.insertLogicalSettingCondtionInfo(setItem);
                        //                }
                        //            }
                        //        }
                        //    }
                        //}
                        List<LogicalCopyKuItemInfo> logItemInfos = item.logicalCopyKuItemInfos.Where(it => logCopyKuInfos.Any(hed => (hed.CPYLGC_SUBSYSID == it.LOGITM_SUBSYSIDL) && (hed.CPYLGC_LCPID == it.LOGITM_LCPID))).ToList();

                        if (logItemInfos.Count > 0)
                        {
                            foreach (LogicalCopyKuItemInfo logInfo in logItemInfos)
                            {
                                logInfo.LOGITM_SEQ = seq;
                                if (logInfo.LOGITM_DTTYPE == "ADDRESS")
                                {
                                    logInfo.LOGITM_DTTYPE = logInfo.LOGITM_DTTYPE;
                                    string tempStr = logInfo.LOGITM_DTTYPE + " (" + addressSize + ")";
                                    logInfo.LOGITM_DTTYPE = tempStr;
                                }
                                dBConnectivity.insertLogicalCopyKuItemInfo(logInfo);
                            }
                        }
                    }

                    if (logCopyKuInfos.Count > 0)
                    {
                        foreach (LogicalCopyKuInfo info in logCopyKuInfos)
                        {
                            info.CPYLGC_USERID = userId;
                            dBConnectivity.insertLogicalCopyKuInfo(info);
                        }
                    }
                }
            }
            catch (CopyKuInfoReadProcessException e)
            {
                //Log for unexpected error
                //想定外エラーが発生する場合、ログに記録
                logger.Error($"{version.User.USERID}" + string.Format(e.Message), e);

                //Throw Error CKR00099-E
                //CKR00099-E　エラーをスロー
                throw new CopyKuInfoReadProcessException(string.Format(e.Message), e);
            }
            catch (Exception e)
            {
                //Log for unexpected error
                //想定外エラーが発生する場合、ログに記録
                logger.Error(e, $"{version.User.USERID}" + Resources.CKR00099_E);

                //Throw Error CKR00099-E
                //CKR00099-E　エラーをスロー
                throw new CopyKuInfoReadProcessException(string.Format(Resources.CKR00099_E, e.Message), e);
            }
            return isError;

        }

        /// <summary>
        /// Ｍパーサ物理情報のＤＢ既存チェック
        /// </summary>
        /// <param name="mParserInfos"></param>
        /// <param name="infoId"></param>
        /// <param name="subSysId"></param>
        /// <param name="phyCopyKuId"></param>
        /// <returns></returns>
        private bool RegisterPhysicalMParserInfo(List<T_PHYPRS> mParserInfos, string infoId, string subSysId, string phyCopyKuId)
        {
            bool isExist = false;
            try
            {
                if (mParserInfos.Count > 0)
                {
                    List<T_PHYPRS> dbItemInfos = dBConnectivity.SelectPhysicalMParserInfos(subSysId, phyCopyKuId, infoId, mParserInfos[0].PHYPRS_LAYDEF);


                    if (dbItemInfos.Count == 0)
                    {
                        //物理Ｍパーサ情報をDBへデータを登録する。
                        //foreach (T_PHYPRS item in mParserInfos)
                        //{
                        //    dBConnectivity.insertPhysicalMParserInfo(item);
                        //}
                        isExist = false;

                    }
                    else
                    {
                        isExist = true;
                    }
                }
            }
            catch (Exception e)
            {
                //Log for unexpected error
                //想定外エラーが発生する場合、ログに記録
                logger.Error(e, $"{version.User.USERID}" + Resources.CKR00099_E);

                //Throw Error CKR00099-E
                //CKR00099-E　エラーをスロー
                throw new CopyKuInfoReadProcessException(string.Format(Resources.CKR00099_E, e.Message), e);
            }
            return isExist;
        }

        /// <summary>
        /// 論理コピー句情報のＤＢ既存チェック
        /// </summary>
        /// <param name="logCopyKuInfos"></param>
        /// <param name="infoId"></param>
        /// <param name="subSysId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        private List<LogicalCopyKuInfo> IsExistLogicalHeaderInfo(List<LogicalCopyKuInfo> logCopyKuInfos, string infoId, string subSysId, string userId)
        {
            List<LogicalCopyKuInfo> headerInfo = new List<LogicalCopyKuInfo>();
            try
            {

                WindowsIdentity identity = WindowsIdentity.GetCurrent();

                // 物理コピー句アイテム情報をDBへデータを登録する。
                foreach (LogicalCopyKuInfo item in logCopyKuInfos)
                {
                    List<LogicalCopyKuItemInfo> dbItemInfos = dBConnectivity.SelectLogicalCopyKuItemInfos(item.CPYLGC_SUBSYSID, item.CPYLGC_LCPID);

                    if (dbItemInfos.Count == 0)
                    {
                        headerInfo.Add(item);
                        //item.CPYLGC_USERID = userId;
                        //dBConnectivity.insertLogicalCopyKuInfo(item);
                    }
                }
            }
            catch (Exception e)
            {
                //Log for unexpected error
                //想定外エラーが発生する場合、ログに記録
                logger.Error(e, $"{version.User.USERID}" + string.Format(e.Message));

                //Throw Error CKR00099-E
                //CKR00099-E　エラーをスロー
                throw new CopyKuInfoReadProcessException(string.Format(e.Message), e);
            }
            return headerInfo;
        }

        /// <summary>
        /// 設定条件情報のＤＢ既存チェック
        /// </summary>
        /// <param name="settingConditionInfos"></param>
        /// <returns></returns>
        private List<string> SelectSettingConditionInfo(List<SettingConditionInfo> settingConditionInfos)
        {
            List<string> list = new List<string>();
            try
            {
                if (settingConditionInfos.Count > 0)
                {
                    var opNameList = settingConditionInfos.Select(e => new { e.COND_SUBSYSID, e.COND_INFOID, e.COND_OPNM }).Distinct().ToList();

                    if (opNameList.Count > 0)
                    {
                        foreach (var str in opNameList)
                        {
                            List<SettingConditionInfo> infos = dBConnectivity.SelectSettingConditionInfos(str.COND_SUBSYSID, str.COND_INFOID, str.COND_OPNM);

                            if (infos.Count == 0)
                            {
                                list.Add(str.COND_OPNM);
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                //Log for unexpected error
                //想定外エラーが発生する場合、ログに記録
                logger.Error(e, $"{version.User.USERID}" + string.Format(e.Message));

                //Throw Error CKR00099-E
                //CKR00099-E　エラーをスロー
                throw new CopyKuInfoReadProcessException(string.Format(e.Message), e);
            }
            return list;
        }

        /// <summary>
        /// コピー句情報読み込み処理
        /// </summary>
        /// <param name="xlWorkSheet"></param>
        /// <param name="subSysIdList"></param>
        /// <param name="inputFilePath"></param>
        /// <returns></returns>
        private PhysicalCopyKuInfo CreatePhysicalCopyKuInfo(Excel.Worksheet xlWorkSheet, List<string> subSysIdList, string inputFilePath)
        {
            PhysicalCopyKuInfo phyCopyKuInfo = null;
            try
            {
               

                Excel.Range xlRange = xlWorkSheet.UsedRange;
                Excel.Range excelRange = xlWorkSheet.Rows;
                List<SettingConditionInfo> settCondList = new List<SettingConditionInfo>();
                List<PhysicalCopyKuItemInfo> itemInfoList = new List<PhysicalCopyKuItemInfo>();
                List<LogicalCopyKuItemInfo> logicalItems = new List<LogicalCopyKuItemInfo>();
                List<T_PHYPRS> mParsers = new List<T_PHYPRS>();
                //Check Template File
                //テンプレートファイルをチェック
                if (xlRange[1, 1].Value == ConstantUtils.TITLE &&
                    xlRange[4, 1].Value == ConstantUtils.SUBSYSID &&
                    xlRange[5, 1].Value == ConstantUtils.COPYKUID &&
                    xlRange[6, 1].Value == ConstantUtils.COPYKUNAME &&
                    xlRange[7, 1].Value == ConstantUtils.INFOID)
                {
                    phyCopyKuInfo = new PhysicalCopyKuInfo();
                    List<LogicalCopyKuInfo> logHeaderInfoList = new List<LogicalCopyKuInfo>();
                    //サブシステムＩＤを取得
                    string id = xlRange[4, 3].Value;

                    phyCopyKuInfo.CPYPHY_SubSysId = xlRange[4, 3].Value == null ? string.Empty : xlRange[4, 3].Value.ToString().Trim();

                    //コピー句IDを取得
                    phyCopyKuInfo.CPYPHY_BcpId = xlRange[5, 3].Value == null ? string.Empty : xlRange[5, 3].Value.ToString().Trim();

                    //コピー句名を取得
                    phyCopyKuInfo.CPYPHY_BcpNm = xlRange[6, 3].Value == null ? string.Empty : xlRange[6, 3].Value.ToString().Trim();

                    //情報IDを取得
                    phyCopyKuInfo.CPYPHY_InfoId = xlRange[7, 3].Value == null ? string.Empty : xlRange[7, 3].Value.ToString().Trim();

                    if (phyCopyKuInfo.CPYPHY_SubSysId == string.Empty)
                    {
                        //サブシステムＩＤは空の場合、ログに記録
                        logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00012_E, xlWorkSheet.Name, ConstantUtils.SUBSYSID));
                        return null;
                    }
                    if (phyCopyKuInfo.CPYPHY_BcpId == string.Empty)
                    {
                        //コピー句IDは空の場合、ログに記録
                        logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00012_E, xlWorkSheet.Name, ConstantUtils.COPYKUID));
                        return null;

                    }
                    if (phyCopyKuInfo.CPYPHY_BcpNm == string.Empty)
                    {
                        //コピー句名は空の場合、ログに記録
                        logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00012_E, xlWorkSheet.Name, ConstantUtils.COPYKUNAME));
                        return null;

                    }
                    if (phyCopyKuInfo.CPYPHY_InfoId == string.Empty)
                    {
                        //情報IDは空の場合、ログに記録
                        logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00012_E, xlWorkSheet.Name, ConstantUtils.INFOID));
                        return null;
                    }
                    if (!subSysIdList.Contains(phyCopyKuInfo.CPYPHY_SubSysId))
                    {
                        //サブシステムＩＤは空の場合、ログに記録
                        logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00015_E, xlWorkSheet.Name, ConstantUtils.SUBSYSID));
                        return null;
                    }
                    PhysicalCopyKuInfo copyKu = dBConnectivity.SelectPhysicalCopyKuInfo(phyCopyKuInfo.CPYPHY_SubSysId, phyCopyKuInfo.CPYPHY_InfoId);

                    if (copyKu.CPYPHY_STATUS == ConstantUtils.STATUS_DELELTE)
                    {
                        logger.Error($"{version.User.USERID}" + string.Format(Resources.TSR00017_E, xlWorkSheet.Name, phyCopyKuInfo.CPYPHY_InfoId));
                        return null;
                    }
                   
                    int usedCols = xlWorkSheet.Cells.Find("*", System.Reflection.Missing.Value,
                           System.Reflection.Missing.Value, System.Reflection.Missing.Value, Excel.XlSearchOrder.xlByColumns,
                           Excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Column;

                    int useRows = xlWorkSheet.Cells.Find("*", System.Reflection.Missing.Value,
                       System.Reflection.Missing.Value, System.Reflection.Missing.Value, Excel.XlSearchOrder.xlByRows,
                       Excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Row;

                    int colCount = xlWorkSheet.Cells.Find("*", System.Reflection.Missing.Value,
                        System.Reflection.Missing.Value, System.Reflection.Missing.Value, Excel.XlSearchOrder.xlByColumns,
                        Excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Column;
                    int usedRows = 0;
                    for (int a = 16; a <= excelRange.Rows.Count; a++)
                    {
                        string lvlVal = ReadCell(a, int.Parse(ConstantUtils.LEVEL_COL), xlRange);
                        string itemNmVal = ReadCell(a, int.Parse(ConstantUtils.ITEM_NAME_COL), xlRange);

                        if (lvlVal == string.Empty && itemNmVal == string.Empty)
                        {
                            usedRows = a - 1;
                            break;
                        }                       
                    }
                    object[,] values = new object[usedRows, colCount];
                    string colName = ColumnInt2String(colCount);
                    values = xlWorkSheet.get_Range("A1", colName + usedRows).Value;
                    int conditionLastCol = 0;
                    bool isLastCol = false;
                    Dictionary<int, string> setOpNameList = new Dictionary<int, string>();
                    List<string> opNameList = new List<string>();
                    Dictionary<int, string> subSysNameList = new Dictionary<int, string>();
                    Dictionary<int, string> paths = new Dictionary<int, string>();
                    bool isError = false;
                    string llSubSysId = null;
                    string mParserLayDef = null;
                    PhysicalCopyKuItemInfo info = new PhysicalCopyKuItemInfo();
                    string phyID = null;
                    bool settingResult = true;
                    bool logCopyResult = true;
                    bool mparsarResult = true;
                    bool phyCopyResult = true;
                    int copyKuSize = 0;
                    PhysicalCopyKuItemInfo preItemInfo = null;
                    bool isItemInfoExist = true;
                    int bitSize = 0;
                    int lv = 0;
                    for (int x = 11; x <= values.GetLength(0); x++)
                    {
                        //　設定条件情報の最終列の検索
                        if (isLastCol == false)
                        {
                            for (int c = int.Parse(ConstantUtils.SETTING_COL); c < colCount; c++)
                            {
                                if (xlRange[x, c].Value == "論理インタフェース")
                                {
                                    conditionLastCol = c;
                                    isLastCol = true;
                                    break;
                                }
                            }
                        }
                        //　設定条件情報のヘッダ情報の取得
                        if (x == 12)
                        {
                            for (int s = int.Parse(ConstantUtils.SETTING_COL); s < conditionLastCol; s++)
                            {
                                string col = ColumnInt2String(s);
                                Range rng = xlWorkSheet.get_Range(col + 16, col + usedRows).Find("*", System.Reflection.Missing.Value,
                           System.Reflection.Missing.Value, System.Reflection.Missing.Value, Excel.XlSearchOrder.xlByColumns,
                           Excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value);
                                if (rng != null)
                                {
                                    string opName = ReadCell(x, s, xlRange);

                                    if (opName != string.Empty)
                                    {
                                        setOpNameList.Add(s, opName);
                                    }
                                    else
                                    {
                                        //情報IDは空の場合、ログに記録
                                        logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00009_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, s)));

                                        isError = true;
                                        return null;
                                    }
                                }
                            }
                            // 論理サブシステムＩＤの取得
                            string column = ColumnInt2String(conditionLastCol + 2);

                            Range range = xlWorkSheet.get_Range(column + 16, column + usedRows).Find("*", System.Reflection.Missing.Value,
                    System.Reflection.Missing.Value, System.Reflection.Missing.Value, Excel.XlSearchOrder.xlByColumns,
                    Excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value);
                            llSubSysId = ReadCell(x, conditionLastCol, xlRange);
                            if (range != null)
                            {
                                if (isError == false)
                                {
                                    if (llSubSysId == string.Empty)
                                    {
                                        //論理操作名は空の場合、ログに記録
                                        logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00012_E, xlWorkSheet.Name, "論理サブシステム名"));
                                        isError = true;
                                        return null;
                                    }
                                }
                            }
                        }
                        // 論理コピー句情報ヘッダ部分の取得
                        if (isError == false)
                        {
                            if (x == 13)
                            {
                                mParserLayDef = ReadCell(x + 1, conditionLastCol, xlRange);
                                int cnt = 0;
                                for (int j = conditionLastCol + 6; j < colCount; j += 7)
                                {
                                    string column = ColumnInt2String(j + 3);

                                    Range range = xlWorkSheet.get_Range(column + 16, column + usedRows).Find("*", System.Reflection.Missing.Value,
                            System.Reflection.Missing.Value, System.Reflection.Missing.Value, Excel.XlSearchOrder.xlByColumns,
                            Excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value);
                                    if (range != null)
                                    {
                                        LogicalCopyKuInfo headerInfo = null;

                                        string opName = ReadCell(x, j, xlRange);

                                        if (opName != string.Empty)
                                        {
                                            cnt++;
                                            headerInfo = new LogicalCopyKuInfo();
                                            headerInfo.CPYLGC_PHYSYSID = phyCopyKuInfo.CPYPHY_SubSysId;
                                            headerInfo.CPYLGC_INFOID = phyCopyKuInfo.CPYPHY_InfoId;
                                            headerInfo.CPYLGC_SUBSYSID = llSubSysId;
                                            headerInfo.CPYLGC_OPNM = opName;
                                            headerInfo.LOGITM_COL = j;
                                            headerInfo.CPYLGC_OUTPUTORDER = cnt;
                                        }
                                        else
                                        {
                                            //論理操作名は空の場合、ログに記録
                                            logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00012_E, xlWorkSheet.Name, "論理操作名"));
                                            isError = true;
                                            return null;
                                        }

                                        string logicalId = ReadCell(x + 1, j, xlRange);

                                        if (logicalId != string.Empty)
                                        {
                                            headerInfo.CPYLGC_LCPID = logicalId;
                                        }
                                        else
                                        {
                                            //論理コピー句IDは空の場合、ログに記録
                                            logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00012_E, xlWorkSheet.Name, "論理コピー句ID"));
                                            isError = true;
                                            return null;
                                        }
                                        logHeaderInfoList.Add(headerInfo);
                                    }
                                }
                            }
                        }
                        // データ部分の取得
                        if (x >= 16 && isError == false)
                        {
                            PhysicalCopyKuItemInfo itemInfo = new PhysicalCopyKuItemInfo();
                            itemInfo.PHYITM_ItemNo = x - 16;
                            itemInfo.PHYITM_SubSysId = phyCopyKuInfo.CPYPHY_SubSysId;
                            itemInfo.PHYITM_InfoId = phyCopyKuInfo.CPYPHY_InfoId;

                            string level = ReadCell(x, int.Parse(ConstantUtils.LEVEL_COL), xlRange).Trim();

                            if (string.Empty != level)
                            {
                                if (x == 16 && level != "1")
                                {
                                    //レベル番号は1でない場合、ログに記録
                                    logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00014_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, int.Parse(ConstantUtils.LEVEL_COL))));
                                    return null;
                                }
                                if (int.Parse(level) < 100)
                                {
                                    itemInfo.PHYITM_Level = int.Parse(level);
                                }
                                else
                                {
                                    //レベル番号は100以上の場合、ログに記録
                                    logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00014_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, int.Parse(ConstantUtils.LEVEL_COL))));
                                    return null;
                                }
                               
                                //if (preItemInfo != null)
                                //{
                                //    if(preItemInfo.PHYITM_Level <= int.Parse(level))
                                //    {
                                //        int different = int.Parse(level) - preItemInfo.PHYITM_Level;
                                //        if (!(different == 0 || different == 1))
                                //        {
                                //            //レベルの差分は不正の場合、ログに記録
                                //            logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00014_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, int.Parse(ConstantUtils.LEVEL_COL))));
                                //            return null;
                                //        }
                                //    }
                                //    else
                                //    {
                                //        int different = preItemInfo.PHYITM_Level - int.Parse(level);
                                //        if (!(different == 0 || different == 1))
                                //        {
                                //            //レベルの差分は不正の場合、ログに記録
                                //            logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00014_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, int.Parse(ConstantUtils.LEVEL_COL))));
                                //            return null;
                                //        }
                                //    }
                                //}                                
                            }
                            else
                            {
                                //レベルは空の場合、ログに記録
                                logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00007_E, xlWorkSheet.Name, "レベル", CellAddress(xlWorkSheet, x, int.Parse(ConstantUtils.LEVEL_COL))));
                                return null;
                            }
                           
                            itemInfo.PHYITM_ItemId = ReadCell(x, int.Parse(ConstantUtils.ITEMNO_COL), xlRange).Trim(); ;

                            string itemName = ReadCell(x, int.Parse(ConstantUtils.ITEM_NAME_COL), xlRange).Trim(); ;

                            if (string.Empty != itemName)
                            {
                                itemInfo.PHYITM_ItemName = itemName;

                                if (Utils.IsFiller(itemName))
                                {
                                    itemInfo.PHYITM_ItemName = "FILLER";
                                }
                            }
                            else
                            {
                                //アイテム名称は空の場合、ログに記録
                                logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00007_E, xlWorkSheet.Name, "アイテム名称", CellAddress(xlWorkSheet, x, int.Parse(ConstantUtils.ITEM_NAME_COL))));
                                return null;
                            }
                            //項目のパス作成
                            int lvl = itemInfo.PHYITM_Level;
                            if (lvl != 0)
                            {
                                if (paths.ContainsKey(lvl))
                                {
                                    paths[lvl] = paths[lvl - 1] + "_" + itemInfo.PHYITM_ItemName;
                                }
                                else
                                {
                                    if (lvl == 1)
                                    {
                                        paths.Add(lvl, itemInfo.PHYITM_ItemName);
                                    }
                                    else
                                    {
                                        paths.Add(lvl, paths[lvl - 1] + "_" + itemInfo.PHYITM_ItemName);
                                    }
                                }
                            }
                            else
                            {
                                paths.Add(lvl, itemInfo.PHYITM_ItemName);
                            }

                            itemInfo.PHYITM_Path = paths[lvl].ToString();

                            // データ形式の取得
                            string cType = ReadCell(x, int.Parse(ConstantUtils.ITEMDES_DTYPE_COL), xlRange).Trim(); ;

                            if (string.Empty != cType)
                            {
                                if (preItemInfo != null)
                                {
                                    if (preItemInfo.PHYITM_ItemFlg == "1")
                                    {
                                        if (preItemInfo.PHYITM_Level >= itemInfo.PHYITM_Level)
                                        {
                                            logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00014_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, int.Parse(ConstantUtils.LEVEL_COL))));
                                            return null;
                                        }
                                    }
                                    else
                                    {
                                        if (preItemInfo.PHYITM_Level < itemInfo.PHYITM_Level)
                                        {
                                            logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00014_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, int.Parse(ConstantUtils.LEVEL_COL))));
                                            return null;
                                        }
                                    }
                                }
                                if (cType == "GROUP")
                                {
                                    itemInfo.PHYITM_ItemFlg = "1";
                                    itemInfo.PHYITM_DTTYPE = cType;
                                    lv = itemInfo.PHYITM_Level;
                                }
                                else
                                {
                                    itemInfo.PHYITM_ItemFlg = "0";
                                    if(cType != string.Empty)
                                    {
                                        if (IntefaceCommon.getItemToParseType(cType) == null)
                                        {
                                            logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00014_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, int.Parse(ConstantUtils.ITEMDES_DTYPE_COL))));
                                        }
                                        else
                                        {
                                            itemInfo.PHYITM_DTTYPE = cType;
                                        }
                                    }                                  
                                }
                                isItemInfoExist = true;
                            }
                            else
                            {
                                if (x == 16)
                                {
                                    isItemInfoExist = false;
                                }

                                if (isItemInfoExist == true)
                                {
                                    //データ形式は空の場合、ログに記録
                                    logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00007_E, xlWorkSheet.Name, "データ形式", CellAddress(xlWorkSheet, x, int.Parse(ConstantUtils.ITEMDES_DTYPE_COL))));
                                    return null;
                                }
                            }
                            if (isItemInfoExist == true)
                            {
                                // データサイズの取得
                                string iLen = ReadCell(x, int.Parse(ConstantUtils.ITEMDES_DLEN_COL), xlRange).Trim(); ;
                                if (cType != "GROUP" && iLen == string.Empty && iLen != "-")
                                {
                                    //データサイズは空の場合、ログに記録
                                    logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00007_E, xlWorkSheet.Name, "データサイズ", CellAddress(xlWorkSheet, x, int.Parse(ConstantUtils.ITEMDES_DLEN_COL))));
                                    return null;
                                }
                                if (cType != "GROUP")
                                {
                                    itemInfo.PHYITM_DTLEN = int.Parse(iLen);
                                }

                                if (itemInfo.PHYITM_DTTYPE == "BIT")
                                {
                                    if (lv < itemInfo.PHYITM_Level)
                                    {
                                        bitSize += itemInfo.PHYITM_DTLEN;
                                    }
                                }
                                else
                                {
                                    if (lv <= itemInfo.PHYITM_Level && bitSize != 0)
                                    {
                                        int div = 0;
                                        int res = Math.DivRem(bitSize, 8, out div);
                                        copyKuSize += div;
                                        bitSize = 0;
                                    }
                                    else
                                    {
                                        copyKuSize += itemInfo.PHYITM_DTLEN;
                                    }
                                }
                                // 繰り返し回数の取得
                                string occ = ReadCell(x, int.Parse(ConstantUtils.OCCURS_COL), xlRange).Trim();

                                if (occ != string.Empty && occ != "-")
                                {
                                    if(int.Parse(occ) > 999999)
                                    {
                                        logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00014_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, int.Parse(ConstantUtils.OCCURS_COL))));
                                    }                                  
                                }
                                itemInfo.PHYITM_Occurs = occ == string.Empty ? 0 : int.Parse(occ);
                                // アイテム内容の取得
                                itemInfo.PHYITM_Comment = ReadCell(x, int.Parse(ConstantUtils.DESCRIPTION_COL), xlRange);
                                // 記事の取得
                                itemInfo.PHYITM_Note = ReadCell(x, int.Parse(ConstantUtils.NOTE_COL), xlRange);

                                string column = ColumnInt2String(int.Parse(ConstantUtils.COPYKU_DTYPE_COL));

                                Range range = xlWorkSheet.get_Range(column + 16, column + usedRows).Find("*", System.Reflection.Missing.Value,
                                    System.Reflection.Missing.Value, System.Reflection.Missing.Value, Excel.XlSearchOrder.xlByColumns,
                                    Excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value);

                                // 物理コピー句情報の開始レベル番号の取得
                                if (x == 16)
                                {
                                    int count = dBConnectivity.SelectCopyKuDataTypeCount(phyCopyKuInfo.CPYPHY_SubSysId, phyCopyKuInfo.CPYPHY_InfoId);

                                    string copyKuLevel = ReadCell(x, int.Parse(ConstantUtils.COPYKU_LEVNO_COL), xlRange);
                                    if (copyKuLevel != string.Empty)
                                    {
                                        if (!(int.Parse(copyKuLevel) > 0 && int.Parse(copyKuLevel) < 100))
                                        {
                                            //レベル番号は100以上の場合、ログに記録
                                            logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00014_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, int.Parse(ConstantUtils.COPYKU_LEVNO_COL))));

                                            return null;
                                        }
                                        phyCopyKuInfo.CPYPHY_LEVNO = int.Parse(copyKuLevel);
                                    }
                                    else
                                    {
                                        if (range != null)
                                        {
                                            //レベル番号は1空の場合、ログに記録
                                            logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00007_E, xlWorkSheet.Name, "物理コピー句情報の開始レベル番号", CellAddress(xlWorkSheet, x, int.Parse(ConstantUtils.COPYKU_LEVNO_COL))));

                                            return null;
                                        }
                                        else
                                        {
                                            if (count == 0)
                                            {
                                                //レベル番号は1空の場合、ログに記録
                                                logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00016_E, xlWorkSheet.Name));

                                                return null;
                                            }
                                        }
                                    }
                                }
                                if (range != null)
                                {
                                    // コピー句データ形式の取得
                                    string copyKuDataType = ReadCell(x, int.Parse(ConstantUtils.COPYKU_DTYPE_COL), xlRange).Trim();
                                    if (cType != "GROUP" && (copyKuDataType == string.Empty || copyKuDataType == "-"))
                                    {
                                        //コピー句データ形式は空の場合、ログに記録
                                        logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00007_E, xlWorkSheet.Name, "コピー句データ形式", CellAddress(xlWorkSheet, x, int.Parse(ConstantUtils.COPYKU_DTYPE_COL))));
                                        return null;
                                    }

                                    // コピー句データ形式の組み合わせチェック
                                    if (copyKuDataType != string.Empty && copyKuDataType != "-")
                                    {
                                        int size = CobolUtils.GetSize(copyKuDataType);
                                        if (CobolUtils.TypeCheck(copyKuDataType) == false)
                                        {
                                            // コピー句データ形式の組み合わせチェックはＮＧの場合、ログファイルに記録
                                            logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00014_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, int.Parse(ConstantUtils.COPYKU_DTYPE_COL))));
                                            return null;
                                        }
                                        if (size != itemInfo.PHYITM_DTLEN)
                                        {
                                            // コピー句データ形式の組み合わせチェックはＮＧの場合、ログファイルに記録
                                            logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00013_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, int.Parse(ConstantUtils.COPYKU_DTYPE_COL)), "アイテム情報"));
                                            return null;
                                        }
                                        itemInfo.PHYITM_CPYDTTYPE = copyKuDataType;
                                    }
                                }
                            }

                            if (isItemInfoExist == false)
                            {
                                string copyKuDataType = ReadCell(x, int.Parse(ConstantUtils.COPYKU_DTYPE_COL), xlRange).Trim();
                                if (isItemInfoExist == false && copyKuDataType == string.Empty && x == 16)
                                {
                                    itemInfo.PHYITM_ItemFlg = "0";
                                }

                                string column = ColumnInt2String(int.Parse(ConstantUtils.COPYKU_DTYPE_COL));

                                Range range = xlWorkSheet.get_Range(column + 16, column + usedRows).Find("*", System.Reflection.Missing.Value,
                                    System.Reflection.Missing.Value, System.Reflection.Missing.Value, Excel.XlSearchOrder.xlByColumns,
                                    Excel.XlSearchDirection.xlPrevious, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value);
                                if (range != null)
                                {
                                    string copyKuLevel = ReadCell(x, int.Parse(ConstantUtils.COPYKU_LEVNO_COL), xlRange);
                                    if (copyKuLevel != string.Empty)
                                    {
                                        if (!(int.Parse(copyKuLevel) > 0 && int.Parse(copyKuLevel) < 100))
                                        {
                                            //レベル番号は100以上の場合、ログに記録
                                            logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00014_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, int.Parse(ConstantUtils.COPYKU_LEVNO_COL))));

                                            return null;
                                        }
                                        phyCopyKuInfo.CPYPHY_LEVNO = int.Parse(copyKuLevel);
                                    }
                                    bool re = LevelCheck(preItemInfo, itemInfo, xlWorkSheet, x);
                                    if (re == false) return null;
                                    itemInfo.PHYITM_CPYDTTYPE = copyKuDataType;

                                    if(copyKuDataType == string.Empty)
                                    {
                                        itemInfo.PHYITM_ItemFlg = "0";
                                    }
                                    else
                                    {
                                        itemInfo.PHYITM_ItemFlg = "1";
                                    }
                                    //if (preItemInfo != null && x > 17)
                                    //{
                                    //    if (preItemInfo.PHYITM_Level == itemInfo.PHYITM_Level && preItemInfo.PHYITM_CPYDTTYPE == null)
                                    //    {
                                    //        //コピー句データ形式は空の場合、ログに記録
                                    //        logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00007_E, xlWorkSheet.Name, "コピー句データ形式", CellAddress(xlWorkSheet, x - 1, int.Parse(ConstantUtils.COPYKU_DTYPE_COL))));
                                    //        return null;
                                    //    }
                                    //    if (copyKuDataType == string.Empty)
                                    //    {
                                    //        itemInfo.PHYITM_ItemFlg = "1";
                                    //    }
                                    //    else
                                    //    {
                                    //        if (copyKuDataType != string.Empty)
                                    //        {
                                    //            if (CobolUtils.TypeCheck(copyKuDataType) == true)
                                    //            {
                                    //                itemInfo.PHYITM_CPYDTTYPE = copyKuDataType;
                                    //            }
                                    //            else
                                    //            {
                                    //                //コピー句データ形式は空の場合、ログに記録
                                    //                logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00014_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, int.Parse(ConstantUtils.COPYKU_DTYPE_COL))));
                                    //                return null;
                                    //            }
                                    //        }
                                    //        itemInfo.PHYITM_ItemFlg = "0";
                                    //    }
                                    //}
                                    //else
                                    //{
                                    //    if (copyKuDataType == string.Empty)
                                    //    {
                                    //        itemInfo.PHYITM_ItemFlg = "1";
                                    //    }
                                    //    else
                                    //    {
                                    //        if (copyKuDataType != string.Empty)
                                    //        {
                                    //            if (CobolUtils.TypeCheck(copyKuDataType) == true)
                                    //            {
                                    //                itemInfo.PHYITM_CPYDTTYPE = copyKuDataType;
                                    //            }
                                    //            else
                                    //            {
                                    //                //コピー句データ形式は空の場合、ログに記録
                                    //                logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00014_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, int.Parse(ConstantUtils.COPYKU_DTYPE_COL))));
                                    //                return null;
                                    //            }
                                    //        }
                                    //        itemInfo.PHYITM_ItemFlg = "0";
                                    //    }
                                    //}
                                    itemInfo.Tmp_DTLEN = CobolUtils.GetSize(copyKuDataType);
                                    if (itemInfo.Tmp_DTLEN != 0 && copyKuDataType.Contains("BIT"))
                                    {
                                        if (lv < itemInfo.PHYITM_Level)
                                        {
                                            bitSize += itemInfo.Tmp_DTLEN;
                                        }
                                    }
                                    else
                                    {
                                        if (lv <= itemInfo.PHYITM_Level && bitSize != 0)
                                        {
                                            int div = 0;
                                            int res = Math.DivRem(bitSize, 8, out div);
                                            copyKuSize += div;
                                            bitSize = 0;
                                        }
                                        else
                                        {
                                            copyKuSize += itemInfo.Tmp_DTLEN;
                                        }
                                    }
                                }
                            }
                            // 設定条件情報の取得
                            List<SettingConditionInfo> conditionInfos = new List<SettingConditionInfo>();
                            int s = 0;
                            for (int k = 0; k < setOpNameList.Count; k++)
                            {
                                string setCondVal = ReadCell(x, setOpNameList.ElementAt(k).Key, xlRange);

                                if (setCondVal != string.Empty)
                                {
                                    SettingConditionInfo setCond = new SettingConditionInfo();
                                    setCond.COND_INFOID = phyCopyKuInfo.CPYPHY_InfoId;
                                    setCond.COND_SUBSYSID = phyCopyKuInfo.CPYPHY_SubSysId;
                                    setCond.COND_OPNM = setOpNameList.ElementAt(k).Value;
                                    setCond.COND_SETCOND = setCondVal;
                                    setCond.PHYITM_Path = itemInfo.PHYITM_Path;
                                    setCond.PHYITM_ItemNo = itemInfo.PHYITM_ItemNo;
                                    setCond.COND_OUTPUTORDER = s++;
                                    settingResult = checkDatalengthData(setCond);
                                    if (settingResult == false) return null;
                                    settCondList.Add(setCond);
                                    conditionInfos.Add(setCond);
                                }
                            }
                            itemInfo.settingConditionInfos = settCondList;

                            // Ｍパーサ物理情報取得
                            T_PHYPRS mParser = new T_PHYPRS();
                            mParser.PHYPRS_PHYSYSID = phyCopyKuInfo.CPYPHY_SubSysId;
                            mParser.PHYPRS_SUBSYSID = llSubSysId;
                            mParser.PHYPRS_INFOID = phyCopyKuInfo.CPYPHY_InfoId;
                            mParser.PHYPRS_LAYDEF = mParserLayDef;
                            mParser.PHYPRS_SUBSYSID = llSubSysId;

                            if (mParserLayDef != string.Empty && mParserLayDef != "レイアウト定義")
                            {
                                if (x == 16)
                                {
                                    phyID = ReadCell(x, conditionLastCol, xlRange).Trim();
                                    if (phyID == string.Empty)
                                    {
                                        logger.Error($"{version.User.USERID}" + Resources.TSR00007_E, xlWorkSheet.Name, "物理ID", CellAddress(xlWorkSheet, x, conditionLastCol));
                                        return null;
                                    }
                                    else
                                    {
                                        if ((Utils.IsAlpahNum(phyID) == false))
                                        {
                                            logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00014_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, conditionLastCol)));
                                            return null;
                                        }
                                        mParser.PHYPRS_PHYID = phyID;
                                    }
                                }
                                else
                                {
                                    mParser.PHYPRS_PHYID = phyID;
                                }

                                mParser.PHYPRS_TAGNM = ReadCell(x, conditionLastCol + 1, xlRange).Trim();
                                if (mParser.PHYPRS_TAGNM == string.Empty)
                                {
                                    logger.Error($"{version.User.USERID}" + string.Format(Resources.TSR00007_E, xlWorkSheet.Name, "タグ名", CellAddress(xlWorkSheet, x, conditionLastCol + 1)));
                                    return null;
                                }
                                if((Utils.IsAlpahNum(mParser.PHYPRS_TAGNM) == false))
                                {
                                    logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00014_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, conditionLastCol + 2)));
                                    return null;
                                }
                                mParser.PHYPRS_LTYPE = ReadCell(x, conditionLastCol + 2, xlRange).Trim();

                                if (cType == "GROUP" && mParser.PHYPRS_LTYPE != "HEX")
                                {
                                    logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00014_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, conditionLastCol + 2)));
                                    return null;
                                }

                                if (cType != "GROUP" && mParser.PHYPRS_LTYPE == string.Empty)
                                {
                                    logger.Error($"{version.User.USERID}" + string.Format(Resources.TSR00007_E, xlWorkSheet.Name, "Ｍパーサ物理属性", CellAddress(xlWorkSheet, x, conditionLastCol + 2)));
                                    return null;
                                }
                                mParser.PHYPRS_CDCHG = ReadCell(x, conditionLastCol + 3, xlRange) == "-" ? string.Empty : ReadCell(x, conditionLastCol + 3, xlRange);

                                mParser.PHYPRS_FLG = (ReadCell(x, conditionLastCol + 4, xlRange) == "-") || (ReadCell(x, conditionLastCol + 4, xlRange) == string.Empty) ? string.Empty : ReadCell(x, conditionLastCol + 4, xlRange);
                                mParser.PHYPRS_MCODE = ReadCell(x, conditionLastCol + 5, xlRange);
                                mParser.PHYITM_PATH = itemInfo.PHYITM_Path;
                                mParser.PHYITM_ITEMNO = itemInfo.PHYITM_ItemNo;

                                // Ｍパーサ物理情報の各項目データ最大長チェック
                                mparsarResult = checkDatalengthData(mParser);
                                if (mparsarResult == false) return null;

                                // Ｍパーサ物理情報のデータ形式揃えチェック

                                
                                if (mParser.PHYPRS_LTYPE != string.Empty && itemInfo.PHYITM_DTTYPE != null)
                                {
                                    List<string> result = IntefaceCommon.getItemToParseType(itemInfo.PHYITM_DTTYPE);
                                    if (result.Contains(mParser.PHYPRS_LTYPE) == false)
                                    {
                                        logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00014_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, conditionLastCol + 2)));
                                        return null;
                                    }

                                }

                                //Ｍパーサ物理情報のデータ揃えチェック
                                if (mParser.PHYPRS_LTYPE != string.Empty && itemInfo.PHYITM_DTLEN > 0)
                                {
                                    if (IntefaceCommon.checkParseSize(mParser.PHYPRS_LTYPE, itemInfo.PHYITM_DTLEN) == false)
                                    {
                                        logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00014_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, conditionLastCol + 2)));
                                        return null;
                                    }
                                }
                                mParsers.Add(mParser);
                                itemInfo.mParserItemInfo = mParser;
                            }

                            // 論理コピー句情報の取得
                            List<LogicalCopyKuItemInfo> logicalInfos = new List<LogicalCopyKuItemInfo>();
                            for (int j = 0; j < logHeaderInfoList.Count; j++)
                            {
                                if (x == 16)
                                {
                                    string logicalLevel = ReadCell(x, logHeaderInfoList[j].LOGITM_COL + 1, xlRange).Trim();
                                    if (logicalLevel != string.Empty)
                                    {
                                        int lev = int.Parse(logicalLevel);
                                        if (lev > 0 && lev < 100)
                                        {
                                            logHeaderInfoList[j].CPYLGC_LEVNO = lev;
                                        }
                                        else
                                        {
                                            //レベル番号は100以上の場合、ログに記録
                                            logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00014_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, logHeaderInfoList[j].LOGITM_COL + 1)));
                                            return null;
                                        }
                                    }
                                    else
                                    {
                                        logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00008_E, xlWorkSheet.Name, logHeaderInfoList[j].CPYLGC_LCPID, "論理コピー句情報の開始レベル番号", CellAddress(xlWorkSheet, x, logHeaderInfoList[j].LOGITM_COL + 1)));
                                        return null;
                                    }
                                }
                                string logicalId = ReadCell(x, logHeaderInfoList[j].LOGITM_COL, xlRange).Trim();

                                if (logicalId == "○")
                                {
                                    LogicalCopyKuItemInfo logicalInfo = new LogicalCopyKuItemInfo();
                                    logicalInfo.LOGITM_SUBSYSIDL = logHeaderInfoList[j].CPYLGC_SUBSYSID;
                                    logicalInfo.LOGITM_LCPID = logHeaderInfoList[j].CPYLGC_LCPID;
                                    logicalInfo.PHYITM_Path = itemInfo.PHYITM_Path;
                                    logicalInfo.PHYITM_ItemNo = itemInfo.PHYITM_ItemNo;
                                    logicalInfo.PHYITM_ItemName = itemInfo.PHYITM_ItemName;

                                    string ltype = ReadCell(x, logHeaderInfoList[j].LOGITM_COL + 2, xlRange).Trim();

                                    if (cType == "GROUP" && ltype != "HEX")
                                    {
                                        logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00014_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, logHeaderInfoList[j].LOGITM_COL + 2)));
                                        return null;
                                    }

                                    if (cType != "GROUP" && ltype == string.Empty)
                                    {
                                        logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00008_E, xlWorkSheet.Name, logicalInfo.LOGITM_LCPID, "Ｍパーサ論理属性", CellAddress(xlWorkSheet, x, logHeaderInfoList[j].LOGITM_COL + 2)));
                                        return null;
                                    }

                                    logicalInfo.LOGITM_TYPE = ltype;
                                    string len = ReadCell(x, logHeaderInfoList[j].LOGITM_COL + 3, xlRange).Trim();

                                    if (cType != "GROUP")
                                    {
                                        if ((len == string.Empty || len == "-") )
                                        {
                                            logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00008_E, xlWorkSheet.Name, logicalInfo.LOGITM_LCPID, "Ｍパーサ論理サイズ", CellAddress(xlWorkSheet, x, logHeaderInfoList[j].LOGITM_COL + 3)));
                                            return null;
                                        }
                                        else
                                        {
                                            logicalInfo.LOGITM_DATALEN = int.Parse(len);
                                        }
                                    }
                                    logicalInfo.LOGITM_MCODE = ReadCell(x, logHeaderInfoList[j].LOGITM_COL + 4, xlRange);
                                    logicalInfo.LOGITM_PREFIX = ReadCell(x, logHeaderInfoList[j].LOGITM_COL + 5, xlRange).Trim();

                                    string cpyDType = ReadCell(x, logHeaderInfoList[j].LOGITM_COL + 6, xlRange).Trim();

                                    if (cType != "GROUP" && (cpyDType == string.Empty || cpyDType == "-"))
                                    {
                                        logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00008_E, xlWorkSheet.Name, logicalInfo.LOGITM_LCPID, "コピー句データ形式", CellAddress(xlWorkSheet, x, logHeaderInfoList[j].LOGITM_COL + 6)));
                                        return null;
                                    }
                                    else
                                    {
                                        if (cType != "GROUP" && cType != string.Empty)
                                        {
                                            if (CobolUtils.TypeCheck(cpyDType) == true)
                                            {
                                                logicalInfo.LOGITM_DTTYPE = cpyDType;
                                            }
                                            else
                                            {
                                                logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00014_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, logHeaderInfoList[j].LOGITM_COL + 6)));
                                                return null;
                                            }
                                        }
                                    }
                                    // 論理コピー句情報の各項目データ最大長チェック
                                    logCopyResult = checkDatalengthData(logicalInfo);
                                    if (logCopyResult == false) return null;

                                    //項目の親子連携存在チェック
                                    List<LogicalCopyKuItemInfo> logicalList = logicalItems.Where(l => l.LOGITM_LCPID == logicalInfo.LOGITM_LCPID).ToList();
                                    bool res = IsExistParentID(logicalList, logicalInfo.PHYITM_Path);
                                    if (res == false)
                                    {
                                        logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00011_E, xlWorkSheet.Name, logicalInfo.LOGITM_LCPID));
                                        return null;
                                    }
                                    if(mParser.PHYPRS_LTYPE != string.Empty && mParser.PHYPRS_TAGNM != string.Empty)
                                    {
                                        //Ｍパーサの物論理情報データ形式揃えチェック
                                        if (mParser.PHYPRS_LTYPE != string.Empty && logicalInfo.LOGITM_TYPE != string.Empty)
                                        {
                                            List<string> re = IntefaceCommon.getParseToParseType(mParser.PHYPRS_LTYPE);

                                            if (!(re.Count > 0 && re.Contains(logicalInfo.LOGITM_TYPE)))
                                            {
                                                logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00013_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, logHeaderInfoList[j].LOGITM_COL + 2), "Mパーサ物理属性"));
                                                return null;
                                            }
                                        }
                                        // Ｍパーサ論理情報の属性とデータサイズ整合性チェック
                                        if (logicalInfo.LOGITM_TYPE != string.Empty && logicalInfo.LOGITM_DATALEN > 0)
                                        {
                                            if (IntefaceCommon.checkParseSize(logicalInfo.LOGITM_TYPE, logicalInfo.LOGITM_DATALEN) == false)
                                            {
                                                logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00014_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, logHeaderInfoList[j].LOGITM_COL + 3)));
                                                return null;
                                            }
                                        }
                                        // Ｍパーサ論理情報のデータサイズとコピー句データ形式の揃えチェック
                                        if (logicalInfo.LOGITM_TYPE != string.Empty && logicalInfo.LOGITM_DATALEN > 0)
                                        {
                                            if (IntefaceCommon.checkParseSize(logicalInfo.LOGITM_TYPE, logicalInfo.LOGITM_DATALEN) == false)
                                            {
                                                logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00014_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, logHeaderInfoList[j].LOGITM_COL + 3)));
                                                return null;
                                            }
                                        }
                                        // Ｍパーサ論理情報のデータ揃えチェック
                                        if (logicalInfo.LOGITM_DTTYPE != string.Empty && logicalInfo.LOGITM_DATALEN > 0)
                                        {
                                            if (CobolUtils.GetSize(logicalInfo.LOGITM_DTTYPE) != logicalInfo.LOGITM_DATALEN)
                                            {
                                                logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00013_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, logHeaderInfoList[j].LOGITM_COL + 6), "Ｍパーサ論理サイズ"));
                                                return null;
                                            }
                                        }
                                    }                                  
                                    logicalItems.Add(logicalInfo);
                                    logicalInfos.Add(logicalInfo);
                                }
                            }
                            // 物理コピー句情報の各項目データ最大長チェック
                            phyCopyResult = checkDatalengthData(itemInfo);
                            if (phyCopyResult == false) return null;
                            itemInfo.logicalCopyKuItemInfos = logicalInfos;
                            itemInfo.settingConditionInfos = conditionInfos;
                            itemInfoList.Add(itemInfo);
                            preItemInfo = itemInfo;
                        }
                    }
                    // 論理コピー句情報と論理アイテム情報のデータマージ
                    foreach (LogicalCopyKuInfo hed in logHeaderInfoList)
                    {
                        List<LogicalCopyKuItemInfo> tempList = logicalItems.Where(itm => hed.CPYLGC_SUBSYSID == itm.LOGITM_SUBSYSIDL && hed.CPYLGC_LCPID == itm.LOGITM_LCPID).ToList();
                        hed.logCpyItemInfoList = tempList;
                    }

                    //上記のチェック処理の結果がＯＫの場合、取得したデータを物理コピー句情報に設定する
                    if (phyCopyResult == true && logCopyResult == true && settingResult == true && mparsarResult == true)
                    {
                        phyCopyKuInfo.CPYPHY_Size = copyKuSize;
                        phyCopyKuInfo.phyCpyItemInfoList = itemInfoList;
                        phyCopyKuInfo.logicalHeaderInfos = logHeaderInfoList;
                        phyCopyKuInfo.setCondList = settCondList;
                        phyCopyKuInfo.mParserInfoList = mParsers;
                        if(isItemInfoExist == true)
                        {
                            phyCopyKuInfo.CPYPHY_Size = getGroupSizeByItemDataLen(itemInfoList);
                        }
                        else
                        {
                            phyCopyKuInfo.CPYPHY_Size = getGroupSizeByCopyDataType(itemInfoList);
                        }

                        bool res = checkDatalengthData(phyCopyKuInfo);
                        if (res == false) return null;                       
                    }
                    //phyCopyKuInfo.phyCpyItemInfoList = itemInfoList;
                    //phyCopyKuInfo.logicalHeaderInfos = logHeaderInfoList;
                    //phyCopyKuInfo.setCondList = settCondList;
                    //phyCopyKuInfo.mParserInfoList = mParsers;
                    //phyCopyInfoList.Add(phyCopyKuInfo);                        
                }
                else
                {
                    //Log for Template file is worng.
                    //テンプレートファイルは間違っている場合、ログに記録
                    logger.Error($"{version.User.USERID}" + string.Format(Resources.TSR00010_E, xlWorkSheet.Name));
                    return null;
                }
            }
            catch (CopyKuInfoReadProcessException e)
            {
                //Log for unexpected error
                //想定外エラーが発生する場合、ログに記録
                logger.Error($"{version.User.USERID}" + string.Format(e.Message), e);

                //Throw Error CKR00099-E
                //CKR00099-E　エラーをスロー
                throw new CopyKuInfoReadProcessException(string.Format(e.Message), e);
            }
            catch (Exception e)
            {
                //ツール専用シートを読み込む時に失敗した場合、ログに記録
                logger.Error(e, $"{version.User.USERID}" + string.Format(Resources.TSR00001_E, Path.GetFileName(inputFilePath)));

                //Throw Error CVR00003-E
                //CVR00003-E　エラーをスロー
                throw new CopyKuInfoReadProcessException(string.Format(Resources.TSR00001_E, Path.GetFileName(inputFilePath)), e);
            }
            finally
            {
                if (xlWorkSheet != null)
                {
                    Marshal.ReleaseComObject(xlWorkSheet);
                    xlWorkSheet = null;
                }
            }
            return phyCopyKuInfo;
        }

        /// <summary>
        /// 論理コピー句情報の親子連携存在チェック
        /// </summary>
        /// <param name="logItemInfos"></param>
        /// <param name="path"></param>
        /// <returns></returns>
        private Boolean IsExistParentID(List<LogicalCopyKuItemInfo> logItemInfos, string path)
        {
            bool result = false;
            if (logItemInfos.Count() > 0)
            {
                if (path != string.Empty && path.Contains("_"))
                {
                    string[] pathList = path.Split('_');

                    
                    if(pathList.Count() >= 2)
                    {
                        string groupName = pathList[pathList.Count() - 2];
                        
                        foreach(LogicalCopyKuItemInfo info in logItemInfos)
                        {
                            if(groupName == info.PHYITM_ItemName)
                            {
                                return true;
                            }
                        }                        
                    }

                    //var results = logItemInfos.Where(l => pathList.Any(m => l.PHYITM_Path.Contains(m)));
                    //if (!results.Any())
                    //{
                    //    return true;
                    //}
                    //else
                    //{
                    //    return false;
                    //}

                    //for (int i = 0; i <= pathList.Count(); i++)
                    //{
                    //    foreach (LogicalCopyKuItemInfo item in logItemInfos)
                    //    {
                    //        if (item.PHYITM_Path.Contains(pathList[i]))
                    //        {
                    //            return true;
                    //        }
                    //    }
                    //    //var res = logItemInfos.Where(l => l.PHYITM_Path.Contains(pathList[i]));

                    //    //if (!res.Any())
                    //    //{
                    //    //    return true;
                    //    //}
                    //    //else
                    //    //{
                    //    //    return false;
                    //    //}

                    //}
                }
            }
            else
            {
                return true;
            }
            return result;
        }

        /// <summary>
        /// セルの読み取り
        /// </summary>
        /// <param name="row">行</param>
        /// <param name="column">列</param>
        /// <returns>セルの値</returns>
        public string ReadCell(int row, int column, Excel.Range range)
        {
            try
            {
                object value = range.Cells[row, column].Value;
                if (value == null)
                {
                    return string.Empty;
                }
                return value.ToString();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// セルのアドレースを文字列に変更
        /// </summary>
        /// <param name="nCol"></param>
        /// <returns></returns>
        private string ColumnInt2String(int nCol)
        {
            if (nCol < 1) return string.Empty;

            string strCol = string.Empty;
            do
            {
                strCol = (char)((nCol - 1) % 26 + 'A') + strCol;
                nCol = (nCol - 1) / 26;
            } while (nCol > 0);

            return strCol;
        }

        /// <summary>
        /// 項目のデータ最大長チェック
        /// </summary>
        /// <param name="obj">コピー句情報</param>
        /// <returns></returns>
        public bool checkDatalengthData(object obj)
        {
            var validator = new ValidationContext(obj, null, null);
            List<ValidationResult> valres = new List<ValidationResult>();
            bool isVal = Validator.TryValidateObject(obj, validator, valres, true);

            if (valres.Count > 0 && isVal == false)
            {
                foreach (ValidationResult val in valres)
                {
                    logger.Error($"{version.User.USERID}" + val.ErrorMessage);
                }
            }
            return isVal;
        }

        private string RangeAddress(Excel.Range rng)
        {
            return rng.get_AddressLocal(false, false, Excel.XlReferenceStyle.xlA1,
                    System.Reflection.Missing.Value, System.Reflection.Missing.Value);
        }

        private string CellAddress(Excel.Worksheet sht, int row, int col)
        {
            return RangeAddress(sht.Cells[row, col]);
        }

        private Boolean LevelCheck(PhysicalCopyKuItemInfo preItemInfo, PhysicalCopyKuItemInfo currentItem, Excel.Worksheet xlWorkSheet, int x)
        {
            bool res = true;
            if (preItemInfo != null)
            {
                //前項目が集団項目の場合は、レベル差が１であること
                //前項目が単項目の場合は、  レベルが前項目以下であること
                if (string.IsNullOrEmpty(preItemInfo.PHYITM_CPYDTTYPE))
                {
                    if ((currentItem.PHYITM_Level - preItemInfo.PHYITM_Level) != 1)
                    {
                        //レベル番号は100以上の場合、ログに記録
                        logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00014_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, int.Parse(ConstantUtils.LEVEL_COL))));
                        return false;
                    }
                }
                else
                {
                    if (preItemInfo.PHYITM_Level < currentItem.PHYITM_Level)
                    {
                        //レベル番号は100以上の場合、ログに記録
                        logger.Error($"{version.User.USERID}" + String.Format(Resources.TSR00014_E, xlWorkSheet.Name, CellAddress(xlWorkSheet, x, int.Parse(ConstantUtils.LEVEL_COL))));
                        return false;
                    }
                }
            }
            return res;
        }

        private int getGroupSizeByCopyDataType(List<PhysicalCopyKuItemInfo> phyCopyItemInfoList)
        {
            int size = 0;
            int bitSize = 0;
            int bitCheckSize = 0;
            bool bitFlag = false;
            foreach (PhysicalCopyKuItemInfo item in phyCopyItemInfoList)
            {
                int itemSize = 0;
                int itemBitSize = 0;

                if (item.PHYITM_CPYDTTYPE != string.Empty)
                {
                    if (item.PHYITM_CPYDTTYPE.Contains("BIT"))
                    {
                        itemBitSize = item.Tmp_DTLEN;
                        bitFlag = true;
                    }
                    else
                    {
                        if (bitFlag)
                        {
                            //補正
                            bitSize += 8 - (bitCheckSize % 8);
                            bitCheckSize = 0;
                            bitFlag = false;
                        }
                        else
                        {
                            if (bitSize > 0)
                            {
                                size += bitSize / 8;
                                bitSize = 0;
                            }
                        }
                        itemSize = item.Tmp_DTLEN;
                    }
                    if (item.PHYITM_Occurs != 0 && item.PHYITM_Occurs > 1)
                    {
                        itemSize *= item.PHYITM_Occurs;
                        itemBitSize *= item.PHYITM_Occurs;
                    }
                }
                size += itemSize;
                bitSize += itemBitSize;
                bitCheckSize += itemBitSize;
            }
            bitSize += 8 - (bitCheckSize % 8);
            size += bitSize / 8;
            return size;
        }

        private int getGroupSizeByItemDataLen(List<PhysicalCopyKuItemInfo> phyCopyItemInfoList)
        {
            int size = 0;
            int bitSize = 0;
            int bitCheckSize = 0;
            bool bitFlag = false;
            foreach (PhysicalCopyKuItemInfo item in phyCopyItemInfoList)
            {
                int itemSize = 0;
                int itemBitSize = 0;

                if (item.PHYITM_DTTYPE != "GROUP")
                {
                    if (item.PHYITM_DTTYPE == "BIT")
                    {
                        itemBitSize = item.PHYITM_DTLEN;
                        bitFlag = true;
                    }
                    else
                    {
                        if (bitFlag)
                        {
                            //補正
                            bitSize += 8 - (bitCheckSize % 8);
                            bitCheckSize = 0;
                            bitFlag = false;
                        }
                        else
                        {
                            if (bitSize > 0)
                            {
                                size += bitSize / 8;
                                bitSize = 0;
                            }
                        }
                        itemSize = item.PHYITM_DTLEN;
                    }
                    if (item.PHYITM_Occurs != 0 && item.PHYITM_Occurs > 1)
                    {
                        itemSize *= item.PHYITM_Occurs;
                        itemBitSize *= item.PHYITM_Occurs;
                    }
                }
                size += itemSize;
                bitSize += itemBitSize;
                bitCheckSize += itemBitSize;
            }
            bitSize += 8 - (bitCheckSize % 8);
            size += bitSize / 8;
            return size;
        }
    }
}