﻿using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace MarsTool.Common
{
    /// <summary>
    /// 共通クラス
    /// </summary>
    public class Utils
    {
        public const string FILLER = "FILLER";
        private const string WIDE_NUMBERS = "０１２３４５６７８９";

        /// <summary>
        /// 文字列がNULL場合、空白にする。その以外、トリムする。
        /// </summary>
        public static string TrimString(string val)
        {
            return string.IsNullOrWhiteSpace(val) ? string.Empty : val.Trim();
        }

        /// <summary>
        /// 文字列がNULL場合、空白にする。その以外、先頭からトリムする。
        /// </summary>
        public static string TrimStart(string val)
        {
            return string.IsNullOrWhiteSpace(val) ? string.Empty : val.TrimStart();
        }

        /// <summary>
        /// 文字列がNULL場合、空白にする。その以外、末尾からトリムする。
        /// </summary>
        public static string TrimEnd(string val)
        {
            return string.IsNullOrWhiteSpace(val) ? string.Empty : val.TrimEnd();
        }

        /// <summary>
        /// 英字判定
        /// </summary>
        /// <param name="val"></param>
        /// <returns></returns>
        public static bool IsAlpah(string val)
        {
            if (string.IsNullOrEmpty(val)) return false;

            return Regex.IsMatch(val, @"^[a-zA-Z]*$");
        }

        /// <summary>
        /// 数字判定
        /// </summary>
        /// <param name="val"></param>
        /// <returns></returns>
        public static bool IsNum(string val)
        {
            if (string.IsNullOrEmpty(val)) return false;

            return Regex.IsMatch(val, @"^[0-9]*$");
        }

        /// <summary>
        /// 英数字判定
        /// </summary>
        /// <param name="val"></param>
        /// <returns></returns>
        public static bool IsAlpahNum(string val)
        {
            if (string.IsNullOrEmpty(val)) return false;

            return Regex.IsMatch(val, @"^([a-zA-Z]|[0-9])*$");
        }

        /// <summary>
        /// 半角から全角に変換
        /// </summary>
        public static string ToZenkaku(string input)
        {
            char[] c = input.ToCharArray();
            for (int i = 0; i < c.Length; i++)
            {
                if (c[i] == 32)
                {
                    c[i] = (char)12288;
                    continue;
                }
                if (c[i] < 127)
                    c[i] = (char)(c[i] + 65248);
            }
            return new string(c);
        }

        /// <summary>
        /// 全角から半角に変換
        /// </summary>
        public static string ToHankaku(string input)
        {
            char[] c = input.ToCharArray();
            for (int i = 0; i < c.Length; i++)
            {
                if (c[i] == 12288)
                {
                    c[i] = (char)32;
                    continue;
                }
                if (c[i] > 65280 && c[i] < 65375)
                    c[i] = (char)(c[i] - 65248);
            }
            return new string(c);
        }

        /// <summary>
        /// 予備判定
        /// </summary>
        /// <param name="itemNm"></param>
        /// <returns></returns>
        public static bool IsFiller(string itemNm)
        {
            if (string.IsNullOrWhiteSpace(itemNm)) return false;

            return new List<string>() {
                FILLER,
                "予備",
                "ヨビ",
                "ＦＩＬＬＥＲ",
                "ｆｉｌｌｅｒ" }.Contains(itemNm.ToUpper());
        }

        /// <summary>
        /// ＭＢ管理テーブル判定
        /// </summary>
        /// <param name="filename"></param>
        /// <returns></returns>
        public static bool IsMBTable(string filename)
        {
            if (filename == null) return false;
            return filename.Contains("DSTDMB");
        }
    }
}
