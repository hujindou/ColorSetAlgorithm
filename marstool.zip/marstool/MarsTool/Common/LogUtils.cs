﻿//-----------------------------------------------------------
// All Rights Reserved , Copyright (C) 2018, Hitachi , Ltd.
//-----------------------------------------------------------
using System;
using MarsTool.Common;
using MarsTool.Exceptions;
using MarsTool.Properties;
using System.Linq;
using NLog;

namespace MarsTool.Common
{
    /// <summary>
    /// LogUtils Class<br/>
    /// ログユーティリティクラス<br/>
    /// To write log info.<br/>
    /// ログ情報を書き込む<br/>
    /// </summary>
    /// <remarks>
    /// 2018/03/07 新規作成<br/>
    /// </remarks>
    class LogUtils
    {
        #region variable

        // Get logger
        // ロガーを取得
        private static readonly Logger log = LogManager.GetCurrentClassLogger();
        private static readonly string INFO = "[INFO ]";
        private static readonly string WARN = "[WARN ]";
        private static readonly string ERROR = "[ERROR]";
        #endregion

        #region public method

        /// <summary>
        /// Write LogInfo<br/>
        /// ログファイルにログ情報を書き込む<br/>
        /// </summary>
        /// <param name="logInfo">
        /// logInfo used to write log<br/>
        /// ログに記録するため、logInfoを使用<br/>
        /// </param>
        /// <param name="msgType">
        /// msgCode used to write log<br/>
        /// ログに記録するため、msgCodeを使用<br/>
        /// </param>
        /// <param name="errorExpection">
        /// errorExpection used to write log<br/>
        /// ログに記録するため、errorExpectionを使用<br/>
        /// </param>
        /// <exception cref="CodeCadidateRegException">
        /// Throw exception if exception occurs at writing logInfo.<br/>
        /// ログ情報を書き込む時に例外が発生した場合、例外をスローする<br/>
        /// </exception>
        /// <remarks>
        /// 2018/05/28 新規作成<br/>
        /// </remarks>
        public static void WriteLogInfo(string userID, string logInfo, string msgType, Exception errorExpection)
        {
            try
            {
                log.Error(userID + " " + String.Format(logInfo, errorExpection));
                
            }
            catch (Exception e)
            {
                //Throw Error SCT00099-E
                //SCT00099-E　エラーをスロー
                throw new CodeCadidateRegException(LogUtils.GetMsgInfo(Resources.CVR00099_E, e.Message), e);
            }
        }

        /// <summary>
        /// ログ情報の記録<br/>
        /// Write LogInfo<br/>
        /// ログファイルにログ情報を書き込む<br/>
        /// </summary>
        /// <param name="logInfo">
        /// logInfo used to write log<br/>
        /// ログに記録するため、logInfoを使用<br/>
        /// </param>
        /// <param name="msgType">
        /// msgCode used to write log<br/>
        /// ログに記録するため、msgCodeを使用<br/>
        /// </param>
        /// <exception cref="CodeCadidateRegException">
        /// Throw exception if exception occurs at writing logInfo.<br/>
        /// ログ情報を書き込んでいる時に例外が発生した場合、例外をスロー<br/>
        /// </exception>
        /// <remarks>
        /// 2018/05/28 新規作成<br/>
        /// </remarks>
        public static void WriteLogInfo(string userID, string logInfo, string msgType)
        {
            try
            {
                if (msgType.Equals(INFO))
                {
                    log.Info(userID + " " + logInfo);
                }
                if (msgType.Equals(ERROR))
                {
                    log.Error(userID + " " + logInfo);
                }
                if (msgType.Equals(WARN))
                {
                    log.Warn(userID + " " + logInfo);
                }
            }
            catch (Exception e)
            {
                //Throw Error SCT00099-E
                //SCT00099-E　エラーをスロー
                throw new CodeCadidateRegException(LogUtils.GetMsgInfo(Resources.CVR00099_E, e.Message), e);
            }
        }

        /// <summary>
        /// ログ情報メッセージフォーマット<br/>
        /// Format Log Info Message<br/>
        /// </summary>
        /// <param name="getMsgValue">
        /// getMsgValue used to get message.<br/>
        /// メッセージを取得するため、getMsgValueを使用<br/>
        /// </param>
        /// <param name="param">
        /// param used to replace parameter value of log message.<br/>
        /// ログメッセージのパラメータ値を置き換えるため、パラメータを使用<br/>
        /// </param>
        /// <returns>
        /// Return formatted log message.<br/>
        /// フォーメットしたログメッセージを返却<br/>
        /// </returns>
        /// <remarks>
        /// 2018/03/14 新規作成<br/>
        /// </remarks>
        public static string GetMsgInfo(string getMsgValue, params string[] param)
        {
            return String.Format(getMsgValue, param);
        }

        /// <summary>
        /// メッセージタイプを取得<br/>
        /// Get Message Type<br/>
        /// </summary>
        /// <param name="msgCode">
        /// msgCode used to get message code.<br/>
        /// メッセージコードを取得するために使用するmsgCode<br/>
        /// <returns>
        /// Return message type with format such as INFO or WARN or ERROR.<br/>
        /// 情報又は、警告又は、エラー等のフォーマットでメッセージを返す<br/>
        /// </returns>
        /// <remarks>
        /// 2018/05/24 新規作成<br/>
        /// </remarks>
        public static string GetMsgType(string msgCode)
        {
            return string.Format("[{0}]", ConstantUtils.LOG_TYPE.Where(x => x.StartsWith(msgCode.Substring(msgCode.Length - 1, 1))).First());
        }
        #endregion
    }
}
