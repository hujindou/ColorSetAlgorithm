﻿//-----------------------------------------------------------
// All Rights Reserved , Copyright (C) 2018 , Hitachi , Ltd.
//-----------------------------------------------------------
using System;
using System.Collections.Generic;

namespace MarsTool.Common
{
    /// <summary>
    /// ConstantUtils Class<br/>
    /// 固定ユーティリティクラス<br/>
    /// Declare Common variable.<br/>
    /// 共通変数を宣言<br/>
    /// </summary>
    /// <remarks>
    /// 2018/03/07 新規作成<br/>
    /// </remarks>
    class ConstantUtils
    {
        //共通部分
        public static readonly String FONTNAME = "ＭＳ Ｐゴシック";
        public static readonly String DATETIMEFORMAT = "yyyyMMddHHmmss";
        public static readonly String OUTPUTLOGFILENAME = "不一致情報";

        //コピー句読み込み処理                 
        public static readonly String CKR00001_E = "CKR00001-E";
        public static readonly String CKR00002_E = "CKR00002-E";
        public static readonly String CKR00003_E = "CKR00003-E";
        public static readonly String CKR00004_W = "CKR00004-W";
        public static readonly String CKR00005_I = "CKR00005-I";
        public static readonly String CKR00006_I = "CKR00006-I";
        public static readonly String CKR00007_I = "CKR00007-I";
        public static readonly String CKR00008_E = "CKR00008-E";
        public static readonly String CKR00009_E = "CKR00009-E";
        public static readonly String CKR00099_E = "CKR00099-E";

        public static readonly String CMM00002_E = "CMM00002-E";

        //アイテム説明書読み込み処理
        public static readonly String IDR00001_E = "IDR00001-E";
        public static readonly String IDR00002_E = "IDR00002-E";
        public static readonly String IDR00005_E = "IDR00005-E";
        public static readonly String IDR00008_E = "IDR00008-E";

        //ツール専用入力シート読み込み処理
        public static readonly String TSR00001_E = "TSR00001-E";
        public static readonly String TSR00002_E = "TSR00002-E";
        public static readonly String TSR00003_E = "TSR00003-E";
        public static readonly String TSR00004_I = "TSR00004-I";
        public static readonly String TSR00005_I = "TSR00005-I";
        public static readonly String TSR00006_E = "TSR00006-E";
        public static readonly String TSR00007_E = "TSR00007-E";
        public static readonly String TSR00008_E = "TSR00008-E";
        public static readonly String TSR00009_E = "TSR00009-E";
        public static readonly String TSR00010_E = "TSR00010-E";
        public static readonly String TSR00011_E = "TSR00011-E";
        public static readonly String TSR00012_E = "TSR00012-E";
        public static readonly String TSR00013_E = "TSR00013-E";
        public static readonly String TSR00099_E = "TSR00099-E";


        //専用入力シートのヘッダー部分のラベルセルアドレス
        public static readonly string TITLE_HCELLADD = "R1C1";
        public static readonly string SUBSYSID_HCELLADD = "R4C1";
        public static readonly string COPYKUID_HCELLADD = "R5C1";
        public static readonly string COPYKUNM_HCELLADD = "R6C1";
        public static readonly string PHYSICALID_HCELLADD = "R7C1";
        public static readonly string INFOID_HCELLADD = "R8C1";
        public static readonly string LOGICALID_HCELLADD = "R9C1";

        //専用入力シートのヘッダー部分の値セルアドレス      
        public static readonly string SUBSYSID_CELLADD = "A4";
        public static readonly string COPYKUID_CELLADD = "A5";
        public static readonly string COPYKUNM_CELLADD = "A6";
        public static readonly string PHYSICALID_CELLADD = "A7";
        public static readonly string INFOID_CELLADD = "A8";
        public static readonly string LOGICALID_CELLADD = "A9";

        //ツール専用入力シートラベル名
        public static readonly string TITLE = "ツール専用入力シート（コピー句情報入力用）";
        public static readonly string SUBSYSID = "サブシステムID";
        public static readonly string COPYKUID = "コピー句ID";
        public static readonly string COPYKUNAME = "コピー句名";        
        public static readonly string INFOID = "情報部ID";
        

        //専用入力シートの物理コピー句データ部分のセルアドレス
        public static readonly string LEVEL_COL = "1";
        public static readonly string ITEMNO_COL = "2";
        public static readonly string ITEM_NAME_COL = "3";        
        public static readonly string ITEMDES_DTYPE_COL = "4";
        public static readonly string ITEMDES_DLEN_COL = "5";       
        public static readonly string OCCURS_COL = "6";
        public static readonly string DESCRIPTION_COL = "7";
        public static readonly string NOTE_COL = "8";
        public static readonly string COPYKU_LEVNO_COL = "9";
        public static readonly string COPYKU_DTYPE_COL = "10";
        public static readonly string MCODE_COL = "10";
        public static readonly string　SETTING_COL = "11";

        //アイテム説明書のデーター部分のラベルセルアドレス
        public static readonly int SERIALNO_CELLADD = 1;
        public static readonly int ITEMNO_CELLADD = 7;
        public static readonly int ITEMNM_CELLADD = 8;
        public static readonly int DTYPE_CELLADD = 9;
        public static readonly int DSIZE_CELLADD = 10;
        public static readonly int DESCRIPTION_CELLADD = 12;
        public static readonly int MEMO_CELLADD = 52;

        //アイテム説明書のラベル名
        public static readonly string SERIALNO = "項　番";
        public static readonly string ITEMNO = "アイテム記号名称";
        public static readonly string ITEMNM = "ア　イ　テ　ム　名　称";
        public static readonly string DTYPE = "データ";
        public static readonly string DSIZE = "ﾃﾞｰﾀ長";
        public static readonly string DESCRIPTION = "ア　　イ　　テ　　ム　　内　　容";
        public static readonly string MEMO = "記　　　事";

        // 候補値用固定
        public static readonly string TABLENAME = "T_KOHO";
        public static readonly char UNDER_SCORE = '_';
        public static readonly string[] COLLIST = { "KOHO_GROUP", "KOHO_CODE", "KOHO_CONTENT", "KOHO_USERID" };
        public static readonly string ITEMNO_STR = "項番";
        public static readonly string GROUP_NAME = "候補値グループ名";
        public static readonly string CANDIDATEVALUE = "候補値コード";
        public static readonly string CANDIDATECONTENT = "候補値内容";
        public static readonly int DATASTART_ROW = 8;
        public static readonly string CVR00001_I = "CVR00001-I";
        public static readonly string CVR00002_I = "CVR00002-I";
        public static readonly string CVR00003_E = "CVR00003-E";
        public static readonly string CVR00004_W = "CVR00004-W";
        public static readonly string CVR00005_W = "CVR00005-W";
        public static readonly string CVR00006_E = "CVR00006-E";
        public static readonly string CVR00007_W = "CVR00007-W";
        public static readonly string CVR00008_W = "CVR00008-W";
        public static readonly string CVR00009_E = "CVR00009-E";
        public static readonly string CVR00010_E = "CVR00010-E";
        public static readonly string CVR00011_E = "CVR00011-E";
        public static readonly string CVR00012_W = "CVR00012-W";
        public static readonly string CVR00013_W = "CVR00013-W";
        public static readonly string CVR00014_W = "CVR00014-W";
        public static readonly string CVR00015_E = "CVR00015-E";
        public static readonly string CVR00099_E = "CVR00099-E";
        public static readonly string ITEMNO_CELLADD_STR = "A7";
        public static readonly string CANDIDATEVALUE_CELLADD = "B7";
        public static readonly string CANDIDATECONTENT_CELLADD = "C7";
        public static readonly string GROUP_CELLADD = "C4";
        public static readonly string CANDIDATEVALUE_COL = "B";
        public static readonly string CANDIDATECONTENT_COL = "C";
        public static readonly List<string> LOG_TYPE = new List<string> { "INFO ", "WARN ", "ERROR" };
        public static readonly int IDX_LOGTYPE_INFO = 0;
        public static readonly int IDX_LOGTYPE_WARN = 1;
        public static readonly int IDX_LOGTYPE_ERR = 2;

        // 設定条件表用固定
        public static readonly string OUTPUTFILENAME = "設定条件表";
        public static readonly string SHEETNAME = "コピー句名";
        // 「DATASTART_ROW」から「DATASTART_ROW_2」に変更
        public static readonly int DATASTART_ROW_2 = 9;
        public static readonly int DATASTART_COL = 1;
        public static readonly string SCT00001_I = "SCT00001-I";
        public static readonly string SCT00002_I = "SCT00002-I";
        public static readonly string SCT00003_E = "SCT00003-E";
        public static readonly string SCT00004_E = "SCT00004-E";
        public static readonly string SCT00005_E = "SCT00005-E";
        public static readonly string SCT00006_E = "SCT00006-E";
        public static readonly string SCT00007_E = "SCT00007-E";
        public static readonly string SCT00008_E = "SCT00008-E";
        public static readonly string SCT00009_E = "SCT00009-E";
        public static readonly string SCT00099_E = "SCT00099-E";
        public static readonly string TEMPLATE_FILENAME = "設定条件表出力フォーマット.xlsx";
        public static readonly string LEVEL_CELLADD = "B10";
        public static readonly string LEVEL_COLUMNADD = "B";
        // 「SUBSYSID_CELLADD」から「SUBSYSID_CELLADD_2」に変更
        public static readonly string SUBSYSID_CELLADD_2 = "C4";
        public static readonly string COPYCLAUSEID_CELLADD = "C5";
        public static readonly string COPYCLAUSENAME_CELLADD = "C6";
        public static readonly string SAMPLE_CELLADD = "A4";
        public static readonly int MAX_SHEETNAME_LENGTH = 31;

        // 物理/論理マッピング用固定
        public static readonly string MARU = "○";
        public static readonly string DASH = "-";
        // 「OUTPUTFILENAME」から「OUTPUTFILENAME_2」に変更
        public static readonly string OUTPUTFILENAME_2 = "物理／論理マッピング表";
        // 「SHEETNAME」から「SHEETNAME_2」に変更
        public static readonly string SHEETNAME_2 = "コピー句名";
        // 「DATASTART_ROW」から「DATASTART_ROW_3」に変更
        public static readonly int DATASTART_ROW_3 = 9;
        // 「DATASTART_COL」から「DATASTART_COL_1」に変更
        public static readonly int DATASTART_COL_1 = 1;
        public static readonly int LOGDATASTART_COL = 5;
        public static readonly string SIZE_COL = "D";
        public static readonly int ATTRIBUTE_COL = 3;
        public static readonly string PLM00001_I = "PLM00001-I";
        public static readonly string PLM00002_I = "PLM00002-I";
        public static readonly string PLM00003_E = "PLM00003-E";
        public static readonly string PLM00004_E = "PLM00004-E";
        public static readonly string PLM00005_E = "PLM00005-E";
        public static readonly string PLM00006_E = "PLM00006-E";
        public static readonly string PLM00007_E = "PLM00007-E";
        public static readonly string PLM00008_E = "PLM00008-E";
        public static readonly string PLM00009_E = "PLM00009-E";
        public static readonly string PLM00099_E = "PLM00099-E";
        // 「TEMPLATE_FILENAME」から「TEMPLATE_FILENAME_1」に変更
        public static readonly string TEMPLATE_FILENAME_1 = "物理／論理マッピング表出力フォーマット.xlsx";
        // 「SAMPLE_CELLADD」から「SAMPLE_CELLADD_1」に変更
        public static readonly string SAMPLE_CELLADD_1 = "A4";
        public static readonly string PHYSYSID_CELL = "C4";
        public static readonly string LOGSYSID_CELL = "C5";
        public static readonly string COPYCLAUSEID_CELL = "C6";
        public static readonly string COPYCLAUSENAME_CELL = "C7";
        // 「MAX_SHEETNAME_LENGTH」から「MAX_SHEETNAME_LENGTH_1」に変更
        public static readonly int MAX_SHEETNAME_LENGTH_1 = 31;

        public static readonly string FILLER = "FILLER";

        public static readonly string YOBI = "予備";

        public static readonly string STATUS_DELELTE = "1";
    }
}
