﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Drawing;

namespace MarsTool.Common
{
    class ExcelUtils : IDisposable
    {
        /// <summary>
        /// Dispose済みフラグ
        /// </summary>
        private bool disposed = false;
        /// <summary>
        /// Excelアプリケーションオブジェクト
        /// </summary>
        private dynamic ExcelObj = null;
        /// <summary>
        /// WorkBooksオブジェクト
        /// </summary>
        private dynamic WorkBooks = null;
        /// <summary>
        /// WorkBookオブジェクト
        /// </summary>
        private dynamic WorkBook = null;
        /// <summary>
        /// WorkSheetsオブジェクト
        /// </summary>
        private dynamic WorkSheets = null;
        /// <summary>
        /// WorkSheetオブジェクト
        /// </summary>
        private dynamic WorkSheet = null;
        /// <summary>
        /// Rangeオブジェクト
        /// </summary>
        private dynamic Range = null;
        /// <summary>
        /// ワークシートのインデックス番号
        /// </summary>
        private int sheetIndex = -1;

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public ExcelUtils()
        {
            try
            {
                Type t = Type.GetTypeFromProgID("Excel.Application");
                ExcelObj = Activator.CreateInstance(t);
                ExcelObj.DisplayAlerts = false;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// ファイナライザ
        /// </summary>
        ~ExcelUtils()
        {
            Dispose(false);
        }

        /// <summary>
        /// Dispose
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                disposed = true;

                if (disposing)
                {
                    // managed リソースの解放
                }

                // unmanaged リソースの解放
                ReleaseObj((object)Range);
                this.Close();
                foreach (dynamic wkbk in WorkBooks)
                {
                    ReleaseObj((object)wkbk);
                }
                ReleaseObj((object)WorkBooks);
                ExcelObj.Quit();
                ReleaseObj((object)ExcelObj);
            }
        }

        /// <summary>
        /// Dispose
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// COMオブジェクトを破棄
        /// </summary>
        private void ReleaseObj(object COMObj)
        {
            try
            {
                if (COMObj != null)
                {
                    Marshal.ReleaseComObject(COMObj);
                }

            }
            finally
            {
                COMObj = null;
            }
        }

        /// <summary>
        /// 対象となるExcelファイル
        /// </summary>
        public string FileName { get; set; }

        /// <summary>
        /// 水平方向の位置
        /// </summary>
        public enum HorizontalAlignment
        {
            xlRight = -4152,
            xlLeft = -4131,
            xlJustify = -4130,
            xlDistributed = -4117,
            xlCenter = -4108,
            xlGeneral = 1,
            xlFill = 5,
            xlCenterAcrossSelection = 7
        };

        /// <summary>
        /// 線種
        /// </summary>
        public enum MsoLineDashStyle
        {
            /// <summary>実線</summary>
            msoLineSolid = 1,
            /// <summary>点線 (角)</summary>
            msoLineSquareDot = 2,
            /// <summary>点線 (丸) </summary>
            msoLineRoundDot = 3,
            /// <summary>破線</summary>
            msoLineDash = 4,
            /// <summary>一点鎖線</summary>
            msoLineDashDot = 5,
            /// <summary>二点鎖線</summary>
            msoLineDashDotDot = 6,
            /// <summary>長破線</summary>
            msoLineLongDash = 7,
            /// <summary>長鎖線パターン</summary>
            msoLineLongDashDot = 8
        };

        
        /// <summary>
        /// 線の種類
        /// </summary>
        public enum MsoLineStyle
        {
            /// <summary>一重線</summary>
            msoLineSingle = 1,
            /// <summary>二重線</summary>
            msoLineThinThin =  2,
            /// <summary>細線＋太線</summary>
            msoLineThinThick = 3,
            /// <summary>太線＋細線</summary>
            msoLineThickThin = 4,
            /// <summary>細線＋太線＋細線</summary>
            msoLineThickBetweenThin = 5
        };

        /// <summary>
        /// 矢印
        /// </summary>
        public enum MsoArrowheadStyle
        {
            /// <summary>矢印なし</summary>
            msoArrowheadNone = 1,
            /// <summary>三角矢印</summary>
            msoArrowheadTriangle = 2,
            /// <summary>開いた矢印</summary>
            msoArrowheadOpen = 3,
            /// <summary>鋭い矢印</summary>
            msoArrowheadStealth = 4,
            /// <summary>ひし型</summary>
            msoArrowheadDiamond = 5,
            /// <summary>円形矢印</summary>
            msoArrowheadOval = 6
        };

        /// <summary>
        /// 矢印の幅
        /// </summary>
        public enum MsoArrowheadWidth
        {
            /// <summary>小</summary>
            msoArrowheadNarrow = 1,
            /// <summary>大</summary>
            msoArrowheadWide = 3,
            /// <summary>中</summary>
            msoArrowheadWidthMedium = 2
        };

        /// <summary>
        /// 矢印の長さ
        /// </summary>
        public enum MsoArrowheadLength
        {
            /// <summary>短い</summary>
            msoArrowheadShort = 1,
            /// <summary>普通</summary>
            msoArrowheadLengthMedium = 2,
            /// <summary>長い</summary>
            msoArrowheadLong = 3
        };

        /// <summary>
        /// 罫線の線種
        /// </summary>
        public enum XlLineStyle
        {
            /// <summary>実線</summary>
            xlContinuous = 1,
            /// <summary>破線</summary>
            xlDash = -4115,
            /// <summary>一点鎖線</summary>
            xlDashDot = 4,
            /// <summary>ニ点鎖線</summary>
            xlDashDotDot = 5,
            /// <summary>点線</summary>
            xlDot = -4118,
            /// <summary>2 本線</summary>
            xlDouble = -4119,
            /// <summary>線なしsummary>
            xlLineStyleNone = -4142,
            /// <summary>斜破線</summary>
            xlSlantDashDot = 13
        };

        /// <summary>
        /// 罫線の太さ
        /// </summary>
        public enum XlBorderWeight
        {
            /// <summary>細線</summary>
            xlHairline = 1,
            /// <summary>普通</summary>
            xlMedium = -4138,
            /// <summary>太線</summary>
            xlThick = 4,
            /// <summary>極細</summary>
            xlThin = 2
        };

        /// <summary>
        /// 罫線の場所
        /// </summary>
        public enum XlBordersIndex
        {
            /// <summary>左</summary>
            xlEdgeLeft = 7,
            /// <summary>上</summary>
            xlEdgeTop = 8,
            /// <summary>下</summary>
            xlEdgeBottom = 9,
            /// <summary>右</summary>
            xlEdgeRight = 10,
            /// <summary>内部・縦</summary>
            xlInsideVertical = 11,
            /// <summary>内部・横</summary>
            xlInsideHorizontal = 12,
            /// <summary>斜め（／）</summary>
            xlDiagonalUp = 6,
            /// <summary>斜め（＼）</summary>
            xlDiagonalDown = 5
        };

        /// <summary>
        /// 文字方向
        /// </summary>
        public enum MsoTextOrientation
        {
            /// <summary>水平方向</summary>
            msoTextOrientationHorizontal = 1,
            /// <summary>上方向</summary>
            msoTextOrientationUpward = 2,
            /// <summary>下方向</summary>
            msoTextOrientationDownward = 3,
            /// <summary>垂直方向（アジア言語のサポート）</summary>
            msoTextOrientationVerticalFarEast = 4,
            /// <summary>垂直方向</summary>
            msoTextOrientationVertical = 5,
            /// <summary>水平方向および回転（アジア言語のサポート）</summary>
            msoTextOrientationHorizontalRotatedFarEast = 6
        };

        /// <summary>
        /// 文字位置
        /// </summary>
        public enum MsoParagraphAlignment
        {
            /// <summary>左寄せ</summary>
            msoAlignLeft = 1,
            /// <summary>中央揃え</summary>
            msoAlignCenter = 2,
            /// <summary>右寄せ</summary>
            msoAlignRight = 3
        };

        /// <summary>
        /// 文字位置（垂直方向）
        /// </summary>
        public enum MsoVerticalAnchor
        {
            /// <summary>上揃え</summary>
            msoAnchorTop = 1,
            msoAnchorTopBaseline = 2,
            /// <summary>中央揃え</summary>
            msoAnchorMiddle = 3,
            /// <summary>下揃え</summary>
            msoAnchorBottom = 4,
            msoAnchorBottomBaseLine = 5
        };

        /// <summary>
        /// ３つの状態を取るBoolean値
        /// </summary>
        public enum MsoTriState
        {
            /// <summary>False</summary>
            msoFalse = 0,
            /// <summary>True</summary>
            msoTrue = 1
        };

        /// <summary>
        /// 対象となるWorkSheet名
        /// </summary>
        public string WorkSheetName
        {
            get
            {
                if (WorkSheet != null)
                {
                    return WorkSheet.Name;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                try
                {
                    int i = 0;
                    ReleaseObj((object)WorkSheet);
                    foreach (dynamic item in WorkSheets)
                    {
                        if (item.Name == value)
                        {
                            WorkSheet = item;
                            break;
                        }
                        i++;
                    }
                    sheetIndex = i;
                }
                catch
                {
                    sheetIndex = -1;
                    throw;
                }
            }
        }

        /// <summary>
        /// 対象となるWorkSheetのインデックス番号
        /// </summary>
        public int WorkSheetIndex
        {
            get
            {
                return sheetIndex;
            }
            set
            {
                try
                {
                    sheetIndex = 0;
                    ReleaseObj((object)WorkSheet);
                    foreach (dynamic item in WorkSheets)
                    {
                        if (sheetIndex == value)
                        {
                            WorkSheet = item;
                            break;
                        }
                        sheetIndex++;
                    }
                }
                catch
                {
                    sheetIndex = -1;
                    throw;
                }
            }
        }


        /// <summary>
        /// WorkSheet名を返す
        /// </summary>
        public IEnumerable<string> WorkSheetsName
        {
            get
            {
                foreach (dynamic item in WorkSheets)
                {
                    yield return item.Name;
                }
            }
        }

        /// <summary>
        /// Excelファイルを開く
        /// </summary>
        /// <returns></returns>
        public bool Open()
        {
            try
            {
                this.Close();
                WorkBooks = ExcelObj.Workbooks;
                WorkBook = WorkBooks.Open(this.FileName);
                WorkSheets = WorkBook.WorkSheets;
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// 新規
        /// </summary>
        /// <returns></returns>
        public bool New()
        {
            try
            {
                this.Close();
                WorkBook = WorkBooks.Add();
                WorkSheets = WorkBook.WorkSheets;
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Excelファイルを閉じる
        /// </summary>
        public void Close()
        {
            sheetIndex = -1;
            if (WorkBook != null)
            {
                try
                {
                    WorkBook.Close(false);
                }
                catch
                {
                    //途中で該当ファイルを開いた場合、Closeが失敗する場合がある為の措置
                }
                ReleaseObj((object)WorkSheet);
                ReleaseObj((object)WorkSheets);
                ReleaseObj((object)WorkBook);
            }
        }

        /// <summary>
        /// セルの読み取り
        /// </summary>
        /// <param name="row">行</param>
        /// <param name="column">列</param>
        /// <returns>セルの値</returns>
        public string ReadCell(int row, int column)
        {
            try
            {
                object value = WorkSheet.Cells[row, column].Value;
                if (value == null)
                {
                    return string.Empty;
                }
                return value.ToString();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// セルの読み取り
        /// </summary>
        /// <param name="Cell">対象セル</param>
        /// <returns>セルの値</returns>
        public string ReadCell(string Cell)
        {
            try
            {
                object value = WorkSheet.Range(Cell).Value;
                if (value == null)
                {
                    return string.Empty;
                }
                return value.ToString();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// セルの書き込み
        /// </summary>
        /// <param name="row">行</param>
        /// <param name="column">列</param>
        /// <param name="value">セルの値</param>
        public void WriteCell(int row, int column, string value)
        {
            try
            {
                WorkSheet.Cells[row, column].Value = value;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// セルの書き込み
        /// </summary>
        /// <param name="Cell">対象セル</param>
        /// <param name="value">セルの値</param>
        public void WriteCell(string Cell, string value)
        {
            try
            {
                WorkSheet.Range(Cell).Value = value;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// セルの色設定
        /// </summary>
        /// <param name="row">行</param>
        /// <param name="column">列</param>
        /// <param name="ForeColor">フォントの色</param>
        /// <param name="BackColor">セルの色</param>
        public void setCellColor(int row, int column, Color ForeColor, Color BackColor)
        {
            try
            {
                WorkSheet.Cells[row, column].Font.Color = GetColor(ForeColor);
                WorkSheet.Cells[row, column].Interior.Color = GetColor(BackColor);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// セルの色設定
        /// </summary>
        /// <param name="Cell">対象セル</param>
        /// <param name="ForeColor">フォントの色</param>
        /// <param name="BackColor">セルの色</param>
        public void setCellColor(string Cell, Color ForeColor, Color BackColor)
        {
            try
            {
                WorkSheet.Range(Cell).Font.Color = GetColor(ForeColor);
                WorkSheet.Range(Cell).Interior.Color = GetColor(BackColor);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// ワークシートの複製
        /// 複製したワークシートがアクティブになる
        /// </summary>
        /// <param name="NewSheetName">新しいワークシートのシート名</param>
        public void CopySheet(string NewSheetName)
        {
            WorkSheet.Copy(Type.Missing, WorkSheet);
            ReleaseObj((object)WorkSheet);
            WorkSheet = WorkBook.ActiveSheet;
            WorkSheet.Name = NewSheetName;
        }

        /// <summary>
        /// ワークシートの削除
        /// </summary>
        /// <param name="SheetName"></param>
        public void DeleteSheet(string SheetName)
        {
            if (WorkSheets.Count == 1) return;
            foreach (dynamic item in WorkSheets)
            {
                if (item.Name == SheetName)
                {
                    item.Delete();
                }
            }
        }

        /// <summary>
        /// 文字列の水平方向の位置（横位置）
        /// </summary>
        /// <param name="row">行</param>
        /// <param name="column">列</param>
        /// <param name="horizontalAlignment">水平方向の位置</param>
        public void SetHorizontalAlignment(int row, int column, HorizontalAlignment horizontalAlignment)
        {
            WorkSheet.Cells[row, column].HorizontalAlignment = horizontalAlignment;
        }
        /// <summary>
        /// 文字列の水平方向の位置（横位置）
        /// </summary>
        /// <param name="Cell">対象セル</param>
        /// <param name="horizontalAlignment">水平方向の位置</param>
        public void SetHorizontalAlignment(string Cell, HorizontalAlignment horizontalAlignment)
        {
            WorkSheet.Range(Cell).HorizontalAlignment = horizontalAlignment;
        }

        /// <summary>
        /// セルの結合
        /// </summary>
        /// <param name="startRow">開始行</param>
        /// <param name="startColumn">開始列</param>
        /// <param name="endRow">終端行</param>
        /// <param name="endColumn">終端列</param>
        public void CellMerge(int startRow, int startColumn, int endRow, int endColumn)
        {
            dynamic startCell = WorkSheet.Cells[startRow, startColumn];
            dynamic endCell = WorkSheet.Cells[endRow, endColumn];
            dynamic margeRange;
            margeRange = WorkSheet.Range(startCell, endCell);
            margeRange.Merge();
            ReleaseObj((object)margeRange);
            ReleaseObj((object)endCell);
            ReleaseObj((object)startCell);
        }
        /// <summary>
        /// セルの結合
        /// </summary>
        /// <param name="startCell">開始セル</param>
        /// <param name="endCell">終端セル</param>
        public void CellMerge(string startCell, string endCell)
        {
            dynamic margeRange;
            margeRange = WorkSheet.Range(startCell, endCell);
            margeRange.Merge();
            ReleaseObj((object)margeRange);

        }

        /// <summary>
        /// セルの囲い線
        /// </summary>
        /// <param name="startRow">開始セルの位置（行）</param>
        /// <param name="startColumn">開始セルの位置（桁）</param>
        /// <param name="endRow">終端セルの位置（行）</param>
        /// <param name="endColumn">終端セルの位置（桁）</param>
        /// <param name="lineStyle">線種</param>
        public void BorderAround(int startRow, int startColumn,int endRow, int endColumn, XlLineStyle lineStyle)
        {
            dynamic startCell = WorkSheet.Cells[startRow, startColumn];
            dynamic endCell = WorkSheet.Cells[endRow, endColumn];
            dynamic borderCell;
            borderCell = WorkSheet.Range(startCell, endCell);
            borderCell.BorderAround(lineStyle);
            ReleaseObj((object)borderCell);
            ReleaseObj((object)endCell);
            ReleaseObj((object)startCell);
        }

        /// <summary>
        /// セルの囲い線
        /// </summary>
        /// <param name="startCell">開始セル</param>
        /// <param name="endCell">終端セル</param>
        /// <param name="lineStyle">線種</param>
        public void BorderAround(string startCell, string endCell, XlLineStyle lineStyle)
        {
            dynamic borderCell;
            borderCell = WorkSheet.Range(startCell, endCell);
            borderCell.BorderAround(lineStyle);
            ReleaseObj((object)borderCell);
        }

        /// <summary>
        /// 罫線の設定
        /// </summary>
        /// <param name="startRow">開始行</param>
        /// <param name="startColumn">開始列</param>
        /// <param name="endRow">終端行</param>
        /// <param name="endColumn">終端列</param>
        /// <param name="bordersIndex">罫線位置</param>
        /// <param name="lineStyle">線種</param>
        public void SetBorderLine(int startRow, int startColumn, int endRow, int endColumn, XlBordersIndex bordersIndex, XlLineStyle lineStyle)
        {
            dynamic startCell = WorkSheet.Cells[startRow, startColumn];
            dynamic endCell = WorkSheet.Cells[endRow, endColumn];
            dynamic borderCell;
            borderCell = WorkSheet.Range(startCell, endCell);
            borderCell.Borders[bordersIndex].LineStyle = lineStyle;
            ReleaseObj((object)borderCell);
            ReleaseObj((object)endCell);
            ReleaseObj((object)startCell);
       }
        /// <summary>
        /// 罫線の設定
        /// </summary>
        /// <param name="startCell">開始セル</param>
        /// <param name="endCell">終端セル</param>
        /// <param name="bordersIndex">罫線の位置</param>
        /// <param name="lineStyle">線種</param>
        public void SetBorderLine(string startCell, string endCell, XlBordersIndex bordersIndex, XlLineStyle lineStyle)
        {
            dynamic borderCell;
            borderCell = WorkSheet.Range(startCell, endCell);
            borderCell.Borders[bordersIndex].LineStyle = lineStyle;
            ReleaseObj((object)borderCell);
        }
        /// <summary>
        /// テキストボックスに値を設定
        /// </summary>
        /// <param name="Name">設定するテキストボックスの名称</param>
        /// <param name="Value">設定する値</param>
        public void SetTextBoxValue(string Name, string Value)
        {
            dynamic textbox = WorkSheet.Shapes.Item(Name);
            textbox.TextFrame2.TextRange.Text = Value;
            ReleaseObj((object)textbox);
        }

        /// <summary>
        /// ライン（Shape）の追加
        /// </summary>
        /// <param name="BeginX">開始位置（Ｘ座標）</param>
        /// <param name="BeginY">開始位置（Ｙ座標）</param>
        /// <param name="EndX">終端位置（Ｘ座標）</param>
        /// <param name="EndY">終端位置（Ｙ座標）</param>
        /// <param name="color">線の色</param>
        /// <param name="weight">線の太さ</param>
        public void AddLine(Single BeginX, Single BeginY, Single EndX, Single EndY, Color color, float weight)
        {
            this.AddLine(BeginX, BeginY, EndX, EndY, color, MsoLineDashStyle.msoLineSolid, MsoLineStyle.msoLineSingle,
                            MsoArrowheadStyle.msoArrowheadNone, MsoArrowheadWidth.msoArrowheadWidthMedium, MsoArrowheadLength.msoArrowheadLengthMedium,
                            MsoArrowheadStyle.msoArrowheadNone, MsoArrowheadWidth.msoArrowheadWidthMedium, MsoArrowheadLength.msoArrowheadLengthMedium, 
                            weight);
        }
        /// <summary>
        /// ライン（Shape）の追加
        /// </summary>
        /// <param name="BeginX">開始位置（Ｘ座標）</param>
        /// <param name="BeginY">開始位置（Ｙ座標）</param>
        /// <param name="EndX">終端位置（Ｘ座標）</param>
        /// <param name="EndY">終端位置（Ｙ座標）</param>
        /// <param name="color">線の色</param>
        /// <param name="lineDashStyle">点線</param>
        /// <param name="lineStyle">二重線</param>
        /// <param name="weight">線の太さ</param>
        public void AddLine(Single BeginX, Single BeginY, Single EndX, Single EndY, Color color, MsoLineDashStyle lineDashStyle, MsoLineStyle lineStyle, float weight)
        {
            this.AddLine(BeginX, BeginY, EndX, EndY, color, lineDashStyle, lineStyle, 
                         MsoArrowheadStyle.msoArrowheadNone, MsoArrowheadWidth.msoArrowheadWidthMedium, MsoArrowheadLength.msoArrowheadLengthMedium,
                         MsoArrowheadStyle.msoArrowheadNone, MsoArrowheadWidth.msoArrowheadWidthMedium, MsoArrowheadLength.msoArrowheadLengthMedium,
                         weight);
        }
        /// <summary>
        /// ライン（Shape）の追加
        /// </summary>
        /// <param name="BeginX">開始位置（Ｘ座標）</param>
        /// <param name="BeginY">開始位置（Ｙ座標）</param>
        /// <param name="EndX">終端位置（Ｘ座標）</param>
        /// <param name="EndY">終端位置（Ｙ座標）</param>
        /// <param name="color">線の色</param>
        /// <param name="lineDashStyle">点線</param>
        /// <param name="lineStyle">二重線</param>
        /// <param name="beginArrowHead">矢印（開始）</param>
        /// <param name="endArrowHead">矢印（終端）</param>
        /// <param name="weight">線の太さ</param>
        public void AddLine(Single BeginX, Single BeginY, Single EndX, Single EndY, Color color, MsoLineDashStyle lineDashStyle, MsoLineStyle lineStyle, MsoArrowheadStyle beginArrowHead, MsoArrowheadStyle endArrowHead, float weight)
        {
            this.AddLine(BeginX, BeginY, EndX, EndY, color, lineDashStyle, lineStyle,
                         beginArrowHead, MsoArrowheadWidth.msoArrowheadWidthMedium, MsoArrowheadLength.msoArrowheadLengthMedium,
                         endArrowHead, MsoArrowheadWidth.msoArrowheadWidthMedium, MsoArrowheadLength.msoArrowheadLengthMedium,
                         weight);
        }
        /// <summary>
        /// ライン（Shape）の追加
        /// </summary>
        /// <param name="BeginX">開始位置（Ｘ座標）</param>
        /// <param name="BeginY">開始位置（Ｙ座標）</param>
        /// <param name="EndX">終端位置（Ｘ座標）</param>
        /// <param name="EndY">終端位置（Ｙ座標）</param>
        /// <param name="color">線の色</param>
        /// <param name="lineDashStyle">点線</param>
        /// <param name="lineStyle">二重線</param>
        /// <param name="beginArrowHead">矢印（開始）</param>
        /// <param name="beginArrowheadWidth">矢印（開始）の幅</param>
        /// <param name="beginArrowheadLength">矢印（開始）の長さ</param>
        /// <param name="endArrowHead">矢印（終端）</param>
        /// <param name="endArrowheadWidth">矢印（終端）の幅</param>
        /// <param name="endArrowheadLength">矢印（終端）の長さ</param>
        /// <param name="weight">線の太さ</param>
        public void AddLine(Single BeginX, Single BeginY, Single EndX, Single EndY, Color color, MsoLineDashStyle lineDashStyle, MsoLineStyle lineStyle, 
                                MsoArrowheadStyle beginArrowHead, MsoArrowheadWidth beginArrowheadWidth, MsoArrowheadLength beginArrowheadLength,
                                MsoArrowheadStyle endArrowHead, MsoArrowheadWidth endArrowheadWidth, MsoArrowheadLength endArrowheadLength,
                                float weight)
        {
            dynamic shp = WorkSheet.Shapes.AddLine(BeginX, BeginY, EndX, EndY);
            shp.Line.ForeColor.RGB = GetColor(color);
            shp.Line.DashStyle = lineDashStyle;
            shp.Line.Style = lineStyle;
            shp.Line.BeginArrowheadStyle = beginArrowHead;
            shp.Line.BeginArrowheadLength = beginArrowheadWidth;
            shp.Line.BeginArrowheadWidth = beginArrowheadLength;
            shp.Line.EndArrowheadStyle = endArrowHead;
            shp.Line.EndArrowheadLength = endArrowheadWidth;
            shp.Line.EndArrowheadWidth = endArrowheadLength;
            shp.Line.Weight = weight;
            ReleaseObj(shp);
        }

        /// <summary>
        /// テキストボックス（Shape）の追加
        /// </summary>
        /// <param name="left">開始位置（Ｘ座標）</param>
        /// <param name="top">開始位置（Ｘ座標）</param>
        /// <param name="width">テキストボックスのサイズ（横）</param>
        /// <param name="height">テキストボックスのサイズ（縦）</param>
        /// <param name="orientation">方向</param>
        /// <param name="font">フォント</param>
        /// <param name="fontColor">フォントの色</param>
        /// <param name="alignment">水平方向の位置</param>
        /// <param name="verticalAnchor">垂直方向の位置</param>
        /// <param name="value">テキストの値</param>
        public void AddTextBox(Single left, Single top, Single width, Single height, MsoTextOrientation orientation, Font font, Color fontColor, MsoParagraphAlignment alignment, MsoVerticalAnchor verticalAnchor, string value)
        {
            RectangleF margin = new RectangleF(0f, 0f, 0f, 0f); // マージン無し
            this.AddTextBox(left, top, width, height, margin, Color.Transparent, Color.Transparent, orientation, font, fontColor, alignment, verticalAnchor, value);
        }

        /// <summary>
        /// テキストボックス（Shape）の追加
        /// </summary>
        /// <param name="left">開始位置（Ｘ座標）</param>
        /// <param name="top">開始位置（Ｙ座標）</param>
        /// <param name="width">テキストボックスのサイズ（横）</param>
        /// <param name="height">テキストボックスのサイズ（縦）</param>
        /// <param name="margin">テキストマージン</param>
        /// <param name="lineColor">テキストボックスの線色</param>
        /// <param name="fillColor">テキストボックスの背景色</param>
        /// <param name="orientation">方向</param>
        /// <param name="font">フォント</param>
        /// <param name="fontColor">フォントの色</param>
        /// <param name="alignment">水平方向の位置</param>
        /// <param name="verticalAnchor">垂直方向の位置</param>
        /// <param name="value">テキストの値</param>
        public void AddTextBox(Single left, Single top, Single width, Single height, RectangleF margin, Color lineColor, Color fillColor, MsoTextOrientation orientation, Font font, Color fontColor, MsoParagraphAlignment alignment, MsoVerticalAnchor verticalAnchor, string value)
        {
            dynamic shp = WorkSheet.Shapes.AddTextbox(orientation, left, top, width, height);
            shp.TextFrame2.TextRange.Text = value;
            shp.TextFrame2.TextRange.Font.Name = font.FontFamily.Name;
            shp.TextFrame2.TextRange.Font.NameFarEast = font.FontFamily.Name;
            shp.TextFrame2.TextRange.Font.Size = font.Size;
            shp.TextFrame2.TextRange.Font.Bold = font.Bold;
            shp.TextFrame2.TextRange.Font.Italic = font.Italic;
            shp.TextFrame2.TextRange.Font.UnderlineStyle = font.Underline;
            shp.TextFrame2.TextRange.Font.Fill.Transparency = 1.0d - (double)(fontColor.A / 255d);
            shp.TextFrame2.TextRange.Font.Fill.ForeColor.RGB = this.GetColor(fontColor);
            shp.TextFrame2.TextRange.ParagraphFormat.Alignment = alignment;
            shp.TextFrame2.VerticalAnchor = verticalAnchor;
            shp.TextFrame2.MarginTop = margin.Top;
            shp.TextFrame2.MarginLeft = margin.Left;
            shp.TextFrame2.MarginBottom = margin.Bottom;
            shp.TextFrame2.MarginRight = margin.Right;
            shp.Fill.Transparency = 1.0d - (double)(fillColor.A / 255d);
            shp.Fill.ForeColor.RGB = this.GetColor(fillColor);
            shp.Line.Transparency = 1.0d - (double)(lineColor.A / 255d);
            shp.Line.ForeColor.RGB = this.GetColor(lineColor);
            ReleaseObj(shp);
        }

        /// <summary>
        /// 画像（Shape）の追加
        /// </summary>
        /// <param name="left">開始位置（Ｘ座標）</param>
        /// <param name="top">開始位置（Ｙ座標）</param>
        /// <param name="width">画像のサイズ（横）。-1で既存ファイルの幅</param>
        /// <param name="height">画像のサイズ（縦）。-1で既存ファイルの高さ</param>
        /// <param name="imageFile">画像ファイル</param>
        public void AddPicture(Single left, Single top, Single width, Single height, string imageFile)
        {
            dynamic shp = WorkSheet.Shapes.AddPicture(imageFile, MsoTriState.msoFalse, MsoTriState.msoTrue, left, top, width, height);
            ReleaseObj(shp);
        }

        /// <summary>
        /// セルの開始座標取得
        /// </summary>
        /// <param name="row">行</param>
        /// <param name="column">列</param>
        /// <returns></returns>
        public RectangleF GetRectangleF(int row, int column)
        {
            dynamic range = WorkSheet.Cells[row, column];
            range.Select();
            var x = range.Left;
            var y = range.Top;
            var w = range.Width;
            var h = range.Height;
            RectangleF rf = new RectangleF((float)x, (float)y, (float)w, (float)h);
            ReleaseObj(range);
            return rf;
        }
        /// <summary>
        /// セルの開始座標取得
        /// </summary>
        /// <param name="Cell">セル</param>
        /// <returns></returns>
        public PointF GetPointF(string Cell)
        {
            dynamic range = WorkSheet.Range(Cell);
            range.Select();
            PointF pf = new PointF(range.Left, range.Top);
            ReleaseObj(range);
            return pf;
        }

        /// <summary>
        /// ファイル保存
        /// </summary>
        /// <param name="FilePath">新しいファイルパス</param>
        public void SaveAs(string FilePath)
        {
            try
            {
                WorkBook.SaveAs(FilePath);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 上書き保存
        /// </summary>
        public void Save()
        {
            try
            {
                WorkBook.Save();
            }
            catch
            {
                throw;
            }
        }

        public float PixcelToPoint(int pix, int dpi)
        {
            return (pix * 72f) / dpi;
        }

        public int PointToPixcel(float Point, int dpi)
        {
            return (int)((Point / 72f) * dpi);
        }

        private int GetColor(Color color)
        {
            return color.R + color.G * 0x100 + color.B * 0x10000;
        }
    }
}
