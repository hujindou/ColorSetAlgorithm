﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MarsTool.Common;
using MarsTool.Models;
using MarsTool.Models.DB;
using System.Windows.Forms;

namespace MarsTool.Common
{
    /// <summary>
    /// インタフェース管理機能共通関数
    /// </summary>
    class IntefaceCommon
    {
        private static Dictionary<string, List<string>> dicPhysicType = new Dictionary<string, List<string>>();
        private static Dictionary<string, List<string>> dicParserType = new Dictionary<string, List<string>>();

        /// <summary>
        /// 文字列分割
        /// </summary>
        /// <param name="str"></param>
        /// <param name="Separator"></param>
        /// <param name="StartBracket"></param>
        /// <param name="EndBracket"></param>
        /// <returns></returns>
        private static List<string> split(string str, char Separator, char StartBracket, char EndBracket)
        {
            List<string> dist = new List<string>();
            bool flag = true;
            int s = 0;
            int cnt = 0;

            for (int i = 0; i < str.Length; i++)
            {
                cnt++;
                if (str[i] == StartBracket)
                {
                    flag = false;
                }
                else if (str[i] == EndBracket)
                {
                    flag = true;
                }
                else
                {
                    if (str[i] == Separator)
                    {
                        if (flag)
                        {
                            if (cnt == 1)
                            {
                                dist.Add(string.Empty);
                            }
                            else
                            {
                                dist.Add(str.Substring(s, cnt - 1));
                            }
                            cnt = 0;
                            s = i + 1;
                        }
                    }
                }
            }
            if (cnt > 0)
            {
                dist.Add(str.Substring(s, cnt));
            }
            else
            {
                dist.Add(string.Empty);
            }

            return dist;
        }

        /// <summary>
        /// 括弧の削除
        /// </summary>
        /// <remarks>
        /// 文字列の先頭、終端文字を括弧とみなし削除する
        /// </remarks>
        /// <returns>括弧が削除された文字列</returns>
        private static string RemoveBracket(string Text)
        {
            if (Text.Length <= 2) return Text;
            return Text.Substring(1, Text.Length - 2);
        }

        static private void LoadPhysicType()
        {
            if (dicPhysicType.Count == 0)
            {
                //属性辞書（データ属性：Ｍパーサ物理属性）の作成
                string str = System.Configuration.ConfigurationManager.AppSettings["PhysicParseType"];
                List<string> listStr = split(str, ',', '{', '}');
                foreach (string value in listStr)
                {
                    List<string> listTmp = split(RemoveBracket(value), ',', '(', ')');
                    List<string> listValue = RemoveBracket(listTmp[1]).Split(',').ToList();
                    dicPhysicType.Add(listTmp[0], listValue);
                }
            }
        }

        static private void LoadParserType()
        {
            if (dicParserType.Count == 0)
            {
                //属性辞書（Ｍパーサ物理属性：Ｍパーサ論理属性）の作成
                string str = System.Configuration.ConfigurationManager.AppSettings["LogicParseType"];
                List<string> listStr = split(str, ',', '{', '}');
                foreach (string value in listStr)
                {
                    List<string> listTmp = split(RemoveBracket(value), ',', '(', ')');
                    List<string> listValue = RemoveBracket(listTmp[1]).Split(',').ToList();
                    dicParserType.Add(listTmp[0], listValue);
                }
            }
        }


        static public Dictionary<string, List<string>> getDicPhysicType()
        {
            LoadPhysicType();

            return dicPhysicType;
        }

        /// <summary>
        /// データ形式 => Ｍパーサ属性
        /// </summary>
        /// <param name="type">データ形式</param>
        /// <returns></returns>
        static public List<string> getItemToParseType(string type)
        {
            LoadParserType();

            if (dicPhysicType.ContainsKey(type))
            {
                return dicPhysicType[type];
            }

            //空のリストを返す
            return new List<string>();
        }

        static public Dictionary<string, List<string>> getDicParseType()
        {
            LoadParserType();

            return dicParserType;
        }

        /// <summary>
        /// 物理Ｍパーサ属性 => 論理Ｍパーサ属性
        /// </summary>
        /// <param name="type">物理Ｍパーサ属性</param>
        /// <returns></returns>
        static public List<string> getParseToParseType(string type)
        {
            LoadParserType();

            if (dicParserType.ContainsKey(type))
            {
                return dicParserType[type];
            }

            //空のリストを返す
            return new List<string>();
        }

        /// <summary>
        /// Ｍパーサ属性毎のサイズ検定
        /// </summary>
        /// <param name="type">Ｍパーサ属性</param>
        /// <param name="size">サイズ</param>
        /// <returns></returns>
        static public bool checkParseSize(string type, int size)
        {
            //属性辞書（Ｍパーサ物理属性：Ｍパーサ論理属性）の作成
            Dictionary<string, List<int>> dicParserSize = new Dictionary<string, List<int>>
            {
                { "BIN", new List<int>(new int[] { 1, 2, 4, 8 }) },
                { "PAC0", new List<int>(new int[] { 2, 4, 8 }) },
                { "PACC", new List<int>(new int[] { 2, 4, 8 }) },
                { "PACF", new List<int>(new int[] { 2, 4, 8 }) },
                { "PACK", new List<int>(new int[] { 2, 4, 8 }) },
                { "DATE", new List<int>(new int[] { 8 }) },
                { "TIME", new List<int>(new int[] { 7 }) },
            };

            if (dicParserSize.ContainsKey(type))
            {
                return dicParserSize[type].Contains(size);
            }

            return true;
        }

        static private int preLevel { get; set; }
        static private string preType { get; set; }

        /// <summary>
        /// 親子関係検定
        /// </summary>
        /// <param name="Level">レベル</param>
        /// <param name="Type">属性（データ形式／コピー句データ形式）</param>
        /// <param name="isTop">最上位の場合はtrueを設定する。それ以外の場合はfalseを設定する</param>
        /// <returns></returns>
        static public bool checkParent(int Level, string Type, bool isTop)
        {
            if (isTop)  //最上位の場合は値を設定して抜ける
            {
                preLevel = Level;
                preType = Type;
                return true;
            }
            else
            {
                if (preLevel < Level)    //直前の項目よりもレベルが大きい（子項目となる場合）
                {
                    //直前の項目の属性が集団項目であるか検定する
                    if (preType != null || preType != string.Empty || preType != "GROUP")
                    {
                        return false;
                    }
                }
                else
                {
                    //直前の項目が集団項目の場合、子項目以外はＮＧである
                    if (preType == null || preType == string.Empty || preType == "GROUP")
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        /// <summary>
        /// 論理コピー句サイズの取得
        /// </summary>
        /// <param name="versionModel"></param>
        /// <param name="physicSubsys"></param>
        /// <param name="logicSubsys"></param>
        /// <param name="infoID"></param>
        /// <param name="logicCPID"></param>
        /// <returns></returns>
        static public int getLogicSize(VersionModel versionModel, string physicSubsys, string logicSubsys, string infoID, string logicCPID)
        {
            List<TreeNode> listNode = new List<TreeNode>();
            List<T_PHYITM> listPHYITM = versionModel.context.T_PHYITM.AsNoTracking().Where(r =>
                                                                                        r.PHYITM_SUBSYSID == physicSubsys &&
                                                                                        r.PHYITM_INFOID == infoID).OrderBy(r =>
                                                                                                                    r.PHYITM_ITEMNO).ToList();
            foreach(T_PHYITM phyitm in listPHYITM)
            {
                T_LOGITM logitm = versionModel.context.T_LOGITM.AsNoTracking().Where(r =>
                                                                                    r.LOGITM_SUBSYSIDL == logicSubsys &&
                                                                                    r.LOGITM_LCPID == logicCPID &&
                                                                                    r.LOGITM_SEQ == phyitm.PHYITM_SEQ).SingleOrDefault();
                if(logitm != null)
                {
                    TreeNode node = new TreeNode();
                    KeyValuePair<T_PHYITM, T_LOGITM> valuePair = new KeyValuePair<T_PHYITM, T_LOGITM>(phyitm, logitm);
                    node.Tag = valuePair;

                    //親子関係の作成
                    if (listNode.Count > 0)
                    {
                        int NodeIndex = listNode.Count - 1;
                        while (true)
                        {
                            KeyValuePair<T_PHYITM, T_LOGITM> chkValuePair = (KeyValuePair<T_PHYITM, T_LOGITM>)listNode[NodeIndex].Tag;
                            if (valuePair.Key.PHYITM_LEVEL > chkValuePair.Key.PHYITM_LEVEL)
                            {
                                listNode[NodeIndex].Nodes.Add(node);
                                break;
                            }
                            else
                            {
                                if (listNode[NodeIndex].Parent != null)
                                {
                                    NodeIndex = listNode.IndexOf(listNode[NodeIndex].Parent);
                                }
                                else
                                {
                                    break;
                                }
                            }
                        }
                    }
                    listNode.Add(node);
                }
            }
            //サイズの算出
            if(listNode.Count > 0)
            {
                return getChildSizeLogic(listNode[0]);
            }
            else
            {
                return 0;
            }

        }

        private static int getChildSizeLogic(TreeNode Node)
        {
            int size = 0;
            int bitSize = 0;
            int checkBitSize = 0;
            foreach (TreeNode childNode in Node.Nodes)
            {
                if(childNode.Nodes.Count > 0)
                {
                    if (checkBitSize % 8 > 0)
                    {
                        bitSize += 8 - checkBitSize % 8;
                    }
                    checkBitSize = 0;
                    size +=  getChildSizeLogic(childNode);
                }
                else
                {
                    KeyValuePair<T_PHYITM, T_LOGITM> valuePair = (KeyValuePair<T_PHYITM, T_LOGITM>)childNode.Tag;
                    int rep = 1;
                    if(valuePair.Key.PHYITM_OCCURS != null && valuePair.Key.PHYITM_OCCURS > 1)
                    {
                        rep = (int)valuePair.Key.PHYITM_OCCURS;
                    }
                    if(valuePair.Value.LOGITM_DATALEN != null && valuePair.Value.LOGITM_DATALEN > 0)
                    {
                        if (valuePair.Value.LOGITM_DTTYPE.IndexOf(" BIT") > 0)
                        {
                            bitSize += (int)valuePair.Value.LOGITM_DATALEN * rep;
                            checkBitSize += (int)valuePair.Value.LOGITM_DATALEN * rep;
                        }
                        else
                        {
                            if (checkBitSize % 8 > 0)
                            {
                                bitSize += 8 - checkBitSize % 8;
                            }
                            checkBitSize = 0;
                            size += (int)valuePair.Value.LOGITM_DATALEN * rep;
                        }
                    }
                }
            }
            if(checkBitSize % 8 > 0)
            {
                bitSize += 8 - checkBitSize % 8;
            }
            size += bitSize / 8;
            return size;
        }

        public static int getPhysicSize(VersionModel versionModel, string physicSubsys, string infoID)
        {
            List<TreeNode> listNode = new List<TreeNode>();
            List<T_PHYITM> listPHYITM = versionModel.context.T_PHYITM.AsNoTracking().Where(r =>
                                                                                        r.PHYITM_SUBSYSID == physicSubsys &&
                                                                                        r.PHYITM_INFOID == infoID).OrderBy(r =>
                                                                                                                    r.PHYITM_ITEMNO).ToList();
            foreach (T_PHYITM phyitm in listPHYITM)
            {
                TreeNode node = new TreeNode();
                node.Tag = phyitm;

                //親子関係の作成
                if (listNode.Count > 0)
                {
                    int NodeIndex = listNode.Count - 1;
                    while (true)
                    {
                        T_PHYITM chkValue = (T_PHYITM)listNode[NodeIndex].Tag;
                        if (phyitm.PHYITM_LEVEL > chkValue.PHYITM_LEVEL)
                        {
                            listNode[NodeIndex].Nodes.Add(node);
                            break;
                        }
                        else
                        {
                            if (listNode[NodeIndex].Parent != null)
                            {
                                NodeIndex = listNode.IndexOf(listNode[NodeIndex].Parent);
                            }
                            else
                            {
                                break;
                            }
                        }
                    }
                }
                listNode.Add(node);
            }
            //サイズの算出
            if (listNode.Count > 0)
            {
                return getChildSizePhysic(listNode[0]);
            }
            else
            {
                return 0;
            }
        }
        private static int getChildSizePhysic(TreeNode Node)
        {
            int size = 0;
            int bitSize = 0;
            int checkBitSize = 0;
            foreach (TreeNode childNode in Node.Nodes)
            {
                if (childNode.Nodes.Count > 0)
                {
                    if (checkBitSize % 8 > 0)
                    {
                        bitSize += 8 - checkBitSize % 8;
                    }
                    checkBitSize = 0;
                    T_PHYITM phyitm = (T_PHYITM)childNode.Tag;
                    int rep = 1;
                    if (phyitm.PHYITM_OCCURS != null && phyitm.PHYITM_OCCURS > 1)
                    {
                        rep = (int)phyitm.PHYITM_OCCURS;
                    }
                    size += (getChildSizePhysic(childNode) * rep);
                }
                else
                {
                    T_PHYITM phyitm = (T_PHYITM)childNode.Tag;
                    int rep = 1;
                    if (phyitm.PHYITM_OCCURS != null && phyitm.PHYITM_OCCURS > 1)
                    {
                        rep = (int)phyitm.PHYITM_OCCURS;
                    }
                    if (phyitm.PHYITM_DTLEN != null && phyitm.PHYITM_DTLEN > 0)
                    {
                        if (phyitm.PHYITM_DTTYPE == "BIT")
                        {
                            bitSize += (int)phyitm.PHYITM_DTLEN * rep;
                            checkBitSize += (int)phyitm.PHYITM_DTLEN * rep;
                        }
                        else
                        {
                            if (checkBitSize % 8 > 0)
                            {
                                bitSize += 8 - checkBitSize % 8;
                            }
                            checkBitSize = 0;
                            size += (int)phyitm.PHYITM_DTLEN * rep;
                        }
                    }
                }
            }
            if (checkBitSize % 8 > 0)
            {
                bitSize += 8 - checkBitSize % 8;
            }
            size += bitSize / 8;
            return size;
        }
    }
}
