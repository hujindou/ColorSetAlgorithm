﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace MarsTool.Common.Forms
{
    /// <summary>
    /// チェックボックス付けるデータグリッドクラス
    /// </summary>
    public class CheckDataGridView
    {
        public delegate void ChangeStatusEventHandler(bool nodata);
        public event ChangeStatusEventHandler ChangeStatus;

        /// <summary>
        /// 一覧
        /// </summary>
        private DataGridView Dgv { set; get; }
        /// <summary>
        /// 全チェック
        /// </summary>
        public CheckBox ChkAll { set; get; }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public CheckDataGridView(DataGridView dgView, CheckBox chkAll)
        {
            this.Dgv = dgView;
            this.ChkAll = chkAll;

            this.Dgv.CellMouseUp += CellMouseUp;
            this.ChkAll.CheckStateChanged += CheckStateChanged;
        }

        /// <summary>
        /// 一覧の行チェック状態変換イベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == 0)
            {
                var cells = this.Dgv.CurrentRow.Cells;
                cells[0].Value = ("1".Equals(cells[0].Value)) ? "0" : "1";

                var selectedVals = this.Dgv.Rows.Cast<DataGridViewRow>()
                    .Select(r => r.Cells[0].Value);

                var allSelected = selectedVals.All(value => "1".Equals(value));
                this.ChkAll.CheckStateChanged -= CheckStateChanged;
                this.ChkAll.Checked = allSelected;
                this.ChkAll.CheckStateChanged += CheckStateChanged;

                var allUnSelected = selectedVals.All(value => "0".Equals(value));
                if (ChangeStatus != null)
                {
                    ChangeStatus.Invoke(allUnSelected);
                }
            }
        }

        /// <summary>
        /// 全チェック状態変換イベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CheckStateChanged(object sender, EventArgs e)
        {
            if (this.Dgv.Rows.Count <= 0) return;

            foreach (DataGridViewRow row in this.Dgv.Rows)
            {
                row.Cells[0].Value = this.ChkAll.Checked ? "1" : "0";
            }

            if (ChangeStatus != null)
            {
                ChangeStatus.Invoke(!this.ChkAll.Checked);
            }
        }
    }
}
