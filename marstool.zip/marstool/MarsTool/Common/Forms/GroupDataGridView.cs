﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace MarsTool.Common.Forms
{
    public class GroupDataGridView : DataGridView
    {
        //コンストラクタ
        public GroupDataGridView()
        {
            this.GroupCells = new Collection<GroupCell>();
            this.VariableIndexs = new Collection<VariableIndex>();

            //セル描画イベントハンドラの追加
            this.CellPainting += new DataGridViewCellPaintingEventHandler(DataGridViewEx_CellPainting);

            this.MouseDown += new MouseEventHandler(DataGridViewEx_MouseDown);
            this.MouseUp += new MouseEventHandler(DataGridViewEx_MouseUp);
            this.ColumnHeaderMouseClick += new DataGridViewCellMouseEventHandler(DataGridViewEx_ColumnHeaderMouseClick);

            //ちらつき抑止の為、ダブルバッファを有効にする
            this.DoubleBuffered = true;
        }

        /// <summary>
        /// グループセルのクリックイベントハンドラ
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public delegate void GroupCellMouseEventHandler(object sender, GroupCellMouseEventArgs e);
        /// <summary>
        /// グループセルのクリックイベント
        /// </summary>
        public event GroupCellMouseEventHandler GroupCellMouseClick;
        /// <summary>
        /// グループセルのクリックイベント呼出
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnGroupCellMouseClick(GroupCellMouseEventArgs e)
        {
            if (GroupCellMouseClick != null)
            {
                GroupCellMouseClick(this, e);
            }
        }

        /// <summary>
        /// コラムセルクリック時の処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void DataGridViewEx_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            GroupCellMouseEventArgs args = null;

            //該当セルが結合対象か
            int Index = -1;
            if (this.GroupCells != null)
            {
                for (int i = 0; i < this.GroupCells.Count; i++)
                {
                    if (e.ColumnIndex >= this.GroupCells[i].Start && e.ColumnIndex <= (this.GroupCells[i].Start + this.GroupCells[i].Count - 1))
                    {
                        Index = i;
                        break;
                    }
                }
            }

            if (Index != -1)
            {
                GroupCell cell = this.GroupCells[Index];
                //段数を算出する
                int Level = GetLevel(1, cell) + 1;
                int Height = this.ColumnHeadersHeight / Level;
                if (e.Y <= Height)
                {
                    args = GroupCellMouseEventArgs.Create(e, cell);
                    this.OnGroupCellMouseClick(args);
                    return;
                }
                else
                {
                    //子セルをサーチする
                    args = GroupCellMouseEventArgs.Create(e, searchChildCell(e, Height * 2, cell.Start, cell));
                    this.OnGroupCellMouseClick(args);
                    return;
                }
            }
            else
            {
                args = GroupCellMouseEventArgs.Create(e, null);
                this.OnGroupCellMouseClick(args);
            }
        }

        /// <summary>
        /// 子セルの検索
        /// </summary>
        /// <param name="e">グループセルクリックイベントの引数</param>
        /// <param name="Height">子セルの位置（高さ）</param>
        /// <param name="RootIndex">グループセルの開始Index番号</param>
        /// <param name="InternalCell">子セルのサーチ対象となるセル</param>
        /// <returns></returns>
        private GroupCell searchChildCell(DataGridViewCellMouseEventArgs e, int Height, int RootIndex, GroupCell InternalCell)
        {
            foreach (GroupCell cell in InternalCell.ChildCells)
            {
                if (e.ColumnIndex >= (RootIndex + cell.Start) && e.ColumnIndex <= (RootIndex + cell.Start + cell.Count - 1))
                {
                    if (e.Y <= Height)
                    {
                        return cell;
                    }
                    else
                    {
                        RootIndex += cell.Start;
                        return searchChildCell(e, Height * 2, RootIndex, cell);
                    }
                }
            }
            //見つからない場合
            return null;
        }

        //ちらつき対策
        void DataGridViewEx_MouseUp(object sender, MouseEventArgs e)
        {
            //ちらつき抑止の為、ダブルバッファを有効にする
            this.DoubleBuffered = true;
        }
        void DataGridViewEx_MouseDown(object sender, MouseEventArgs e)
        {
            // ヘッダ部のサイズ変更のとき、境界線が描画されるようにダブルバッファを無効化する
            this.DoubleBuffered = false;
        }

        /// <summary>
        /// GroupCellマウスイベント引数
        /// </summary>
        public class GroupCellMouseEventArgs
        {
            public GroupCellMouseEventArgs()
            {
            }

            internal static GroupCellMouseEventArgs Create(DataGridViewCellMouseEventArgs args, GroupCell Cell)
            {
                GroupCellMouseEventArgs EventArgs = new GroupCellMouseEventArgs();

                EventArgs.X = args.X;
                EventArgs.Y = args.Y;
                EventArgs.Button = args.Button;
                EventArgs.Clicks = args.Clicks;
                EventArgs.ColumnIndex = args.ColumnIndex;
                EventArgs.Delta = args.Delta;
                EventArgs.Location = args.Location;
                EventArgs.RowIndex = args.RowIndex;
                EventArgs.groupCell = Cell;
                return EventArgs;
            }
            public int X { get; set; }
            public int Y { get; set; }
            public MouseButtons Button { get; set; }
            public int Clicks { get; set; }
            public int ColumnIndex { get; set; }
            public int Delta { get; set; }
            public Point Location { get; set; }
            public int RowIndex { get; set; }
            public GroupCell groupCell { get; set; }
        }

        /// <summary>
        /// 結合セル
        /// </summary>
        [Serializable()]
        public class GroupCell
        {
            /// <summary>
            /// 結合開始位置
            /// </summary>
            public int Start { get; set; }

            /// <summary>
            /// 結合セル数
            /// </summary>
            public int Count { get; set; }

            /// <summary>
            /// ヘッダテキスト
            /// </summary>
            public string Text { get; set; }

            /// <summary>
            /// 文字の水平方向の位置
            /// </summary>
            public StringAlignment Alignment { get; set; }

            /// <summary>
            /// 文字の垂直方向の位置
            /// </summary>
            public StringAlignment LineAlignment { get; set; }

            /// <summary>
            /// セルの背景色
            /// </summary>
            public Color BackColor { get; set; }

            /// <summary>
            /// セルの文字色
            /// </summary>
            public Color ForeColor { get; set; }

            /// <summary>
            /// 子セル
            /// </summary>
            public Collection<GroupCell> ChildCells { get; set; }

            /// <summary>
            /// タグ情報
            /// </summary>
            public object Tag { get; set; }

            //コンストラクタ
            public GroupCell()
            {
                this.Start = 0;
                this.Count = 0;
                this.Text = string.Empty;
                this.Alignment = StringAlignment.Near;
                this.LineAlignment = StringAlignment.Near;
                this.ChildCells = new Collection<GroupCell>();
                this.BackColor = SystemColors.Control;
                this.ForeColor = SystemColors.ControlText;
                this.Tag = null;
            }
            public GroupCell(int start, int count, string text)
            {
                this.Start = start;
                this.Count = count;
                this.Text = text;
                this.Alignment = StringAlignment.Near;
                this.ChildCells = new Collection<GroupCell>();
                this.BackColor = SystemColors.Control;
                this.ForeColor = SystemColors.ControlText;
                this.Tag = null;
            }
            //コンストラクタ
            public GroupCell(int start, int count, string text, StringAlignment alignment, StringAlignment lineAlignment)
            {
                this.Start = start;
                this.Count = count;
                this.Text = text;
                this.Alignment = alignment;
                this.LineAlignment = lineAlignment;
                this.ChildCells = new Collection<GroupCell>();
                this.BackColor = SystemColors.Control;
                this.ForeColor = SystemColors.ControlText;
                this.Tag = null;
            }
            //コンストラクタ
            public GroupCell(int start, int count, string text, StringAlignment alignment, StringAlignment lineAlignment, Color backColor, Color foreColor)
            {
                this.Start = start;
                this.Count = count;
                this.Text = text;
                this.Alignment = alignment;
                this.LineAlignment = lineAlignment;
                this.ChildCells = new Collection<GroupCell>();
                this.BackColor = backColor;
                this.ForeColor = foreColor;
                this.Tag = null;
            }
        }

        /// <summary>
        /// 可変コラム位置
        /// </summary>
        /// <remarks>
        /// コラム数が可変となるコラムの開始位置と個数を管理するクラス
        /// </remarks>
        [Serializable()]
        public class VariableIndex
        {
            public VariableIndex()
            {
                this.Index = 0;
                this.Count = 1;
                this.Tag = string.Empty;
            }
            public VariableIndex(int ColumnIndex)
            {
                this.Index = ColumnIndex;
                this.Count = 1;
                this.Tag = string.Empty;
            }
            public VariableIndex(int ColumnIndex, string tag)
            {
                this.Index = ColumnIndex;
                this.Count = 1;
                this.Tag = tag;
            }

            /// <summary>
            /// 開始位置
            /// </summary>
            public int Index { get; set; }
            /// <summary>
            /// 個数
            /// </summary>
            public int Count { get; set; }
            /// <summary>
            /// タグ名称
            /// </summary>
            public string Tag { get; set; }

        }

        /// <summary>
        /// 結合セルのリスト
        /// </summary>
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public Collection<GroupCell> GroupCells { get; set; }

        /// <summary>
        /// グループセルのリネーム
        /// </summary>
        /// <remarks>
        /// グループセルのグループ名称を変更する
        /// </remarks>
        /// <param name="ColumnIndex">グループセルを含む<c>ColumnIndex</c>の値</param>
        /// <param name="Level">リネーム対象となるグループの階層</param>
        /// <param name="Text">新しいグループ名称</param>
        public void RenameGroup(int ColumnIndex, int Level, string Text)
        {
            //該当セルが結合対象か
            int Index = -1;
            if (this.GroupCells != null)
            {
                for (int i = 0; i < this.GroupCells.Count; i++)
                {
                    if (ColumnIndex >= this.GroupCells[i].Start && ColumnIndex <= (this.GroupCells[i].Start + this.GroupCells[i].Count - 1))
                    {
                        Index = i;
                        break;
                    }
                }
            }
            if (Index != -1)
            {
                GroupCell cell = null;
                if (Level == 0)
                {
                    cell = this.GroupCells[Index];
                }
                else
                {
                    cell = GetGroupCell(ColumnIndex - this.GroupCells[Index].Start, this.GroupCells[Index], Level - 1);
                }
                if (cell == null) return;
                cell.Text = Text;
            }

        }

        /// <summary>
        /// 最大グループ階層取得
        /// </summary>
        /// <param name="ColumnIndex"></param>
        /// <returns></returns>
        public int GetGroupMaxLevel(int ColumnIndex)
        {
            int Max = -1;
            if (this.GroupCells == null) return -1;
            for (int i = 0; i < this.GroupCells.Count; i++)
            {
                if (ColumnIndex >= this.GroupCells[i].Start && ColumnIndex <= (this.GroupCells[i].Start + this.GroupCells[i].Count - 1))
                {
                    int l = SubGroupLevel(1, this.GroupCells[i].Start, ColumnIndex, this.GroupCells[i]);
                    if (l > Max) Max = l;
                }
            }
            return Max;
        }

        private int SubGroupLevel(int Level, int StartIndex, int ColumnIndex, GroupCell groupCell)
        {
            int Max = Level;
            for (int i = 0; i < groupCell.ChildCells.Count; i++)
            {
                if (ColumnIndex >= (StartIndex + groupCell.ChildCells[i].Start) && ColumnIndex <= (StartIndex + groupCell.ChildCells[i].Start + groupCell.ChildCells[i].Count - 1))
                {
                    int l = SubGroupLevel(Level + 1, StartIndex + groupCell.ChildCells[i].Start, ColumnIndex, groupCell.ChildCells[i]);
                    if (l > Max) Max = l;
                }
            }
            return Max;
        }

        /// <summary>
        /// グループセルの内容取得
        /// </summary>
        /// <param name="ColumnIndex">取得したいグループに含まれるColumnIndexの値</param>
        /// <param name="Level">取得したいグループセルの階層</param>
        /// <returns></returns>
        public string GetGroupCellText(int ColumnIndex, int Level)
        {
            int Index = -1;
            if (this.GroupCells == null) return string.Empty;
            for (int i = 0; i < this.GroupCells.Count; i++)
            {
                if (ColumnIndex >= this.GroupCells[i].Start && ColumnIndex <= (this.GroupCells[i].Start + this.GroupCells[i].Count - 1))
                {
                    Index = i;
                    break;
                }
            }
            if (Index == -1) return string.Empty;
            if (Level == 0) return this.GroupCells[Index].Text;

            GroupCell cell = this.GetGroupCell(ColumnIndex - GroupCells[Index].Start, GroupCells[Index], Level - 1);
            if (cell == null) return string.Empty;
            return cell.Text;
        }

        /// <summary>
        /// グループセルの取得
        /// </summary>
        /// <remarks>
        /// 特定のグループセルから指定階層のグループセルを取得する
        /// </remarks>
        /// <param name="ColumnIndex">取得したいグループを含む<c>ColumnIndex</c>の値</param>
        /// <param name="Level">取得するグループセルの階層</param>
        /// <returns></returns>
        public GroupCell GetGroupCell(int ColumnIndex, int Level)
        {
            for (int i = 0; i < this.GroupCells.Count; i++)
            {
                if (ColumnIndex >= this.GroupCells[i].Start && ColumnIndex <= (this.GroupCells[i].Start + this.GroupCells[i].Count - 1))
                {
                    return GetGroupCell(ColumnIndex - this.GroupCells[i].Start, this.GroupCells[i], Level - 1);
                }
            }
            return null;
        }

        /// <summary>
        /// グループセルの取得
        /// </summary>
        /// <remarks>
        /// 特定のグループセルから指定階層のグループセルを取得する
        /// </remarks>
        /// <param name="Index">取得したいグループを含む<c>ColumnIndex</c>の値</param>
        /// <param name="InternalCell">取得対象となるグループセル</param>
        /// <param name="Level">取得するグループセルの階層</param>
        /// <returns></returns>
        private GroupCell GetGroupCell(int Index, GroupCell InternalCell, int Level)
        {
            foreach (GroupCell cell in InternalCell.ChildCells)
            {
                if (Index >= cell.Start && Index <= (cell.Start + cell.Count - 1))
                {
                    if (Level == 0)
                    {
                        return cell;
                    }
                    return GetGroupCell(Index - cell.Start, cell, Level - 1);
                }
            }
            return null;
        }

        /// <summary>
        /// 可変コラムのリスト
        /// </summary>
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public Collection<VariableIndex> VariableIndexs { get; set; }

        /// <summary>
        /// 可変コラム項目数取得
        /// </summary>
        /// <param name="tag">対象となる可変コラム</param>
        /// <returns></returns>
        public int GetCountVariableColumn(string tag)
        {
            if (this.VariableIndexs == null)
            {
                return 0;
            }
            foreach (VariableIndex vi in this.VariableIndexs)
            {
                if (vi.Tag == tag)
                {
                    return vi.Count;
                }
            }
            return 0;
        }

        /// <summary>
        /// 可変コラム開始位置取得
        /// </summary>
        /// <param name="tag"></param>
        /// <returns></returns>
        public int GetIndexVariableColumn(string tag)
        {
            if (this.VariableIndexs == null)
            {
                return 0;
            }
            foreach (VariableIndex vi in this.VariableIndexs)
            {
                if (vi.Tag == tag)
                {
                    return vi.Index;
                }
            }
            return 0;
        }

        /// <summary>
        /// 可変コラムの削除
        /// </summary>
        /// <param name="tag">削除対象となる可変コラムのタグ名称</param>
        /// <param name="Index">該当タグ名称内の削除対象コラムを決定するIndex</param>
        public void RemoveVariableColumn(string tag, int Index)
        {
            int TargetIndex = -1;
            foreach (VariableIndex vi in this.VariableIndexs)
            {
                if (vi.Tag == tag)
                {
                    if (Index < vi.Count)
                    {
                        //削除対象あり
                        TargetIndex = vi.Index + Index;
                        int GIndex = -1;
                        //該当セルが結合対象か
                        if (this.GroupCells != null)
                        {
                            for (int i = 0; i < this.GroupCells.Count; i++)
                            {
                                if (TargetIndex >= this.GroupCells[i].Start && TargetIndex <= (this.GroupCells[i].Start + this.GroupCells[i].Count - 1))
                                {
                                    GIndex = i;
                                    break;
                                }
                            }
                            //結合セルの開始位置を更新する
                            for (int i = 0; i < this.GroupCells.Count; i++)
                            {
                                if (TargetIndex < this.GroupCells[i].Start)
                                {
                                    this.GroupCells[i].Start--;
                                }
                            }
                            if (GIndex != -1)
                            {
                                this.GroupCells[GIndex].Count--;
                                if (this.GroupCells[GIndex].Count == 0)
                                {
                                    this.GroupCells.RemoveAt(GIndex);
                                }
                                else
                                {
                                    //子セルの更新
                                    RemoveChild(TargetIndex - this.GroupCells[GIndex].Start, this.GroupCells[GIndex]);
                                }
                            }
                        }
                        this.Columns.RemoveAt(TargetIndex);
                        vi.Count--;
                    }
                }
            }
            //可変コラムのリストを更新する
            if (TargetIndex != -1)
            {
                foreach (VariableIndex vi in this.VariableIndexs)
                {
                    if (vi.Index > TargetIndex)
                    {
                        vi.Index--;
                    }
                }
            }
        }

        /// <summary>
        /// 子グループセルの削除
        /// </summary>
        /// <param name="Index"></param>
        /// <param name="InternalCell"></param>
        private void RemoveChild(int Index, GroupCell InternalCell)
        {
            GroupCell deleteCell = null;
            foreach (GroupCell cell in InternalCell.ChildCells)
            {
                if (Index >= cell.Start && Index <= (cell.Start + cell.Count - 1))
                {
                    cell.Count--;
                    if (cell.Count == 0)
                    {
                        deleteCell = cell;
                    }
                    else
                    {
                        if (cell.ChildCells.Count > 0)
                        {
                            this.RemoveChild(Index - cell.Start, cell);
                        }
                    }
                }
                else if (Index < cell.Start)
                {
                    cell.Start--;
                }
            }
            InternalCell.ChildCells.Remove(deleteCell);
        }

        /// <summary>
        /// 可変コラムの挿入
        /// </summary>
        /// <param name="tag">挿入先の可変コラムを識別するタグ</param>
        /// <param name="Level">挿入先のレベル</param>
        /// <param name="groupCell">挿入する可変コラムの結合セル</param>
        /// <param name="Offset">挿入先の相対位置</param>
        /// <param name="Count">コラムの個数</param>
        public void InsertVariableColumn(string tag, int Level, GroupCell groupCell, int Offset, int Count)
        {
            int TargetIndex = -1;
            foreach (VariableIndex vi in this.VariableIndexs)
            {
                if (vi.Tag == tag)
                {
                    //該当セルが結合対象か
                    int Index = -1;
                    if (this.GroupCells != null)
                    {
                        for (int i = 0; i < this.GroupCells.Count; i++)
                        {
                            if (vi.Index >= this.GroupCells[i].Start && vi.Index <= (this.GroupCells[i].Start + this.GroupCells[i].Count - 1))
                            {
                                Index = i;
                                break;
                            }
                        }
                        //結合セルの開始位置を更新する
                        for (int i = 0; i < this.GroupCells.Count; i++)
                        {
                            if ((vi.Index + vi.Count - 1) < this.GroupCells[i].Start)
                            {
                                this.GroupCells[i].Start += Count;
                            }
                        }
                        if (Index != -1)    // 結合セルなので、結合セルの情報を更新する
                        {
                            if (Level > 0)
                            {
                                this.GroupCells[Index].Count += Count;
                                //子セルも更新する
                                this.IndexCountAddChildCell(vi.Index - this.GroupCells[Index].Start + Offset, Count, 1, Level, groupCell, this.GroupCells[Index]);
                            }
                            else
                            {
                                //新たな結合セルとして追加する
                                if (groupCell != null)
                                {
                                    groupCell.Start = vi.Index + Offset + 1;
                                    this.GroupCells.Add(groupCell);
                                }
                            }
                        }
                    }
                    for (int i = 0; i < Count; i++)
                    {
                        DataGridViewColumn Column = (DataGridViewColumn)this.Columns[vi.Index + i].Clone();
                        this.Columns.Insert(vi.Index + Offset + i + 1, Column);
                        vi.Count++;
                    }
                    TargetIndex = vi.Index;
                    break;
                }
            }
            //可変コラムのリストを更新する
            if (TargetIndex != -1)
            {
                foreach (VariableIndex vi in this.VariableIndexs)
                {
                    if (vi.Index > TargetIndex)
                    {
                        vi.Index++;
                    }
                }
            }
        }
        public void InsertVariableColumn(string tag, int Level, int Offset)
        {
            this.InsertVariableColumn(tag, Level, null, Offset, 1);
        }
        public void InsertVariableColumn(string tag, int Offset)
        {
            this.InsertVariableColumn(tag, int.MaxValue, null, Offset, 1);
        }

        private void IndexCountAddChildCell(int Index, int Count, int CurrentLevel, int MaxLevel, GroupCell groupCell, GroupCell InternalCell)
        {
            foreach (GroupCell cell in InternalCell.ChildCells)
            {
                if (Index >= cell.Start && Index <= (cell.Start + cell.Count - 1))
                {
                    if (CurrentLevel < MaxLevel)
                    {
                        cell.Count += Count;
                        if (cell.ChildCells.Count > 0)
                        {
                            this.IndexCountAddChildCell(Index - cell.Start, Count, CurrentLevel + 1, MaxLevel, groupCell, cell);
                        }
                    }
                    else if (CurrentLevel == MaxLevel)
                    {
                        if (groupCell != null)
                        {
                            groupCell.Start = Index + 1;
                            InternalCell.ChildCells.Add(groupCell);
                            break;
                        }

                    }
                }
                else if (Index < cell.Start)
                {
                    cell.Start--;
                }
            }
        }
        private void IndexCountAddChildCell(int Index, int CurrentLevel, int MaxLevel, GroupCell groupCell, GroupCell InternalCell)
        {
            IndexCountAddChildCell(Index, 1, CurrentLevel, MaxLevel, groupCell, InternalCell);
        }

        /// <summary>
        /// セル描画イベントハンドラ
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DataGridViewEx_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            //このメソッドでは、ヘッダの描画のみを行う
            if (e.ColumnIndex >= 0 && e.RowIndex == -1)
            {
                //該当セルが結合対象か
                int Index = -1;
                if (this.GroupCells != null)
                {
                    for (int i = 0; i < this.GroupCells.Count; i++)
                    {
                        if (e.ColumnIndex >= this.GroupCells[i].Start && e.ColumnIndex <= (this.GroupCells[i].Start + this.GroupCells[i].Count - 1))
                        {
                            Index = i;
                            break;
                        }
                    }
                }

                //結合対象の場合
                if (Index != -1)
                {
                    GroupCell rootCell = this.GroupCells[Index];
                    //段数を算出する
                    int Level = GetLevel(1, rootCell) + 1;

                    //結合対象のセルの範囲を算出する
                    int X = e.CellBounds.X;
                    for (int i = e.ColumnIndex - 1; i >= rootCell.Start; i--)
                    {
                        if (this.Columns[i].Visible)
                        {
                            X -= this.Columns[i].Width;
                        }
                    }

                    int Width = 0;
                    for (int i = rootCell.Start; i < (rootCell.Start + rootCell.Count); i++)
                    {
                        if (this.Columns[i].Visible)
                        {
                            Width += this.Columns[i].Width;
                        }
                    }
                    int Y = e.CellBounds.Y;
                    int Height = e.CellBounds.Height;
                    Rectangle CellBounds = new Rectangle(X, Y, Width, Height);

                    //エリアのクリア
                    using (Brush b = new SolidBrush(e.CellStyle.BackColor))
                    {
                        e.Graphics.FillRectangle(b, CellBounds);
                    }

                    //上段を描画する
                    Rectangle rect = new Rectangle(CellBounds.X, CellBounds.Y, CellBounds.Width, CellBounds.Height / Level);
                    using (Brush b = new SolidBrush(rootCell.BackColor))
                    {
                        e.Graphics.FillRectangle(b, rect);
                    }
                    DrawCell(e.Graphics, rect);
                    using (Brush b = new SolidBrush(rootCell.ForeColor))
                    {
                        StringFormat sf = new StringFormat();
                        sf.Alignment = rootCell.Alignment;
                        sf.LineAlignment = rootCell.LineAlignment;
                        sf.Trimming = StringTrimming.Character;
                        sf.FormatFlags = StringFormatFlags.NoClip & StringFormatFlags.NoWrap;
                        e.Graphics.DrawString(rootCell.Text, e.CellStyle.Font, b, new Rectangle(rect.X + 2, rect.Y + 2, rect.Width - 2, rect.Height - 2), sf);
                    }

                    //２段目以降を描画
                    DrawChild(e.Graphics, 1, Level, CellBounds, rootCell.Start, e.CellStyle, rootCell);

                    // 結合セルの元の内容を描画
                    int height = e.CellBounds.Height / Level;
                    int CellX = CellBounds.X;
                    int y = e.CellBounds.Y + height * (Level - 1);

                    for (int i = 0; i < rootCell.Count; i++)
                    {
                        if (this.Columns[i + rootCell.Start].Visible)
                        {
                            Rectangle cellrect = new Rectangle(CellX, y, this.Columns[i + rootCell.Start].Width, height);
                            //クリア
                            using (Brush b = new SolidBrush(e.CellStyle.BackColor))
                            {
                                e.Graphics.FillRectangle(b, cellrect);
                            }
                            //境界線
                            DrawCell(e.Graphics, cellrect);
                            //文字列
                            using (Brush b = new SolidBrush(e.CellStyle.ForeColor))
                            {
                                StringFormat sf = new StringFormat();
                                sf.Alignment = rootCell.Alignment;
                                sf.LineAlignment = rootCell.LineAlignment;
                                sf.Trimming = StringTrimming.Character;
                                sf.FormatFlags = StringFormatFlags.NoClip & StringFormatFlags.NoWrap;
                                e.Graphics.DrawString(this.Columns[i + rootCell.Start].HeaderText, e.CellStyle.Font, b, new Rectangle(cellrect.X + 2, cellrect.Y + 2, cellrect.Width - 2, cellrect.Height - 2), sf);
                            }
                            //境界線
                            using (Pen pen = new Pen(SystemColors.ControlDark))
                            {
                                e.Graphics.DrawLine(pen, CellX,
                                                         e.CellBounds.Y + height * Level - 1,
                                                         CellX + this.Columns[i + rootCell.Start].Width,
                                                         e.CellBounds.Y + height * Level - 1
                                                   );
                            }
                            CellX += this.Columns[i + rootCell.Start].Width;
                        }
                    }
                }
                else
                {
                    //エリアのクリア
                    using (Brush b = new SolidBrush(e.CellStyle.BackColor))
                    {
                        e.Graphics.FillRectangle(b, e.CellBounds);
                    }
                    DrawCell(e.Graphics, e.CellBounds);
                    using (Brush b = new SolidBrush(e.CellStyle.ForeColor))
                    {
                        e.Graphics.DrawString(e.Value.ToString(), e.CellStyle.Font, b, e.CellBounds.X + 2, e.CellBounds.Y + 2);
                    }
                    //境界線
                    using (Pen pen = new Pen(SystemColors.ControlDark))
                    {
                        e.Graphics.DrawLine(pen, e.CellBounds.X,
                                                 e.CellBounds.Y + e.CellBounds.Height - 1,
                                                 e.CellBounds.X + e.CellBounds.Width,
                                                 e.CellBounds.Y + e.CellBounds.Height - 1
                                           );
                    }
                }

                //描画が完了したことを知らせる
                e.Handled = true;

            }
        }

        internal void CommitEdit(object p)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// 子セルの描画
        /// </summary>
        /// <param name="g">描画先</param>
        /// <param name="level">対象段落</param>
        /// <param name="MaxLevel">段落の最大値</param>
        /// <param name="CellBounds">結合セルの範囲</param>
        /// <param name="Index">結合セルの開始位置</param>
        /// <param name="CellStyle">セルの描画スタイル</param>
        /// <param name="internalCell">結合内容</param>
        private void DrawChild(Graphics g, int level, int MaxLevel, Rectangle CellBounds, int Index, DataGridViewCellStyle CellStyle, GroupCell internalCell)
        {
            // 描画範囲の算出
            int height = CellBounds.Height / MaxLevel;
            int y = CellBounds.Y + height * level;

            // 子セル分描画する
            for (int n = 0; n < internalCell.ChildCells.Count; n++)
            {
                GroupCell ChildCell = internalCell.ChildCells[n];
                if (this.Columns[Index + n].Visible)
                {
                    int x = CellBounds.X;
                    for (int i = Index; i < (Index + ChildCell.Start); i++)
                    {
                        if (this.Columns[i].Visible)
                        {
                            x += this.Columns[i].Width;
                        }
                    }
                    int width = 0;
                    for (int i = (Index + ChildCell.Start); i < ((Index + ChildCell.Start) + ChildCell.Count); i++)
                    {
                        if (this.Columns[i].Visible)
                        {
                            width += this.Columns[i].Width;
                        }
                    }

                    Rectangle rect = new Rectangle(x, y, width, height);
                    using (Brush b = new SolidBrush(ChildCell.BackColor))
                    {
                        g.FillRectangle(b, rect);
                    }
                    DrawCell(g, rect);
                    using (Brush b = new SolidBrush(ChildCell.ForeColor))
                    {
                        StringFormat sf = new StringFormat();
                        sf.Alignment = ChildCell.Alignment;
                        sf.LineAlignment = ChildCell.LineAlignment;
                        sf.Trimming = StringTrimming.Character;
                        sf.FormatFlags = StringFormatFlags.NoClip & StringFormatFlags.NoWrap;
                        g.DrawString(ChildCell.Text, CellStyle.Font, b, new Rectangle(rect.X + 2, rect.Y + 2, rect.Width - 2, rect.Height - 2), sf);
                    }
                    // 子セルがさらに分割している場合は、再帰的に呼び出す
                    if (ChildCell.ChildCells.Count > 0)
                    {
                        DrawChild(g, level + 1, MaxLevel, new Rectangle(x, CellBounds.Y, width, CellBounds.Height), Index + ChildCell.Start, CellStyle, ChildCell);
                    }
                    else
                    {
                        if (level < MaxLevel)
                        {
                            // 境界線を描画
                            rect = new Rectangle(x, y, width, height * (MaxLevel - level));
                            DrawCell(g, rect);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 階層チェック
        /// </summary>
        /// <param name="Level"></param>
        /// <param name="internalCell"></param>
        /// <returns></returns>
        private int GetLevel(int Level, GroupCell internalCell)
        {
            int iLevel = Level;
            foreach (GroupCell ChildCell in internalCell.ChildCells)
            {
                int l = GetLevel(Level + 1, ChildCell);
                if (l > iLevel)
                {
                    iLevel = l;
                }
            }
            return iLevel;
        }

        /// <summary>
        /// 分割セルの境界線描画
        /// </summary>
        /// <param name="g"></param>
        /// <param name="rect"></param>
        private void DrawCell(Graphics g, Rectangle rect)
        {
            using (Pen pen = new Pen(SystemColors.ControlDark))
            {
                g.DrawLine(pen, rect.Left - 1, rect.Top, rect.Right - 2, rect.Top);           //上
                g.DrawLine(pen, rect.Left - 1, rect.Top, rect.Left - 1, rect.Bottom - 1);     //左 
                g.DrawLine(pen, rect.Right - 1, rect.Top, rect.Right - 1, rect.Bottom - 1);   //右 
            }
        }
    }
}
