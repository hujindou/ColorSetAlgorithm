﻿using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MarsTool.Common.Forms
{
    /// <summary>
    /// データグリッド行共通処理クラス
    /// </summary>
    public class RowUtils
    {
        /// <summary>
        /// 削除状態
        /// </summary>
        private const int DELETE = 1;

        /// <summary>
        /// 新規状態
        /// </summary>
        private const int NEW = 2;

        /// <summary>
        /// データグリッド行から値を取得
        /// </summary>
        /// <param name="row"></param>
        /// <param name="col"></param>
        /// <returns></returns>
        public static string GetValue(DataGridViewRow row, string col)
        {
            if (row == null || string.IsNullOrEmpty(col)) return string.Empty;

            var rows = row.Cells.Cast<DataGridViewCell>();
            if (rows.All(c => !c.OwningColumn.Name.Equals(col))) return string.Empty;

            if (row.Cells[col].Value == null) return string.Empty;

            return row.Cells[col].Value.ToString();
        }

        /// <summary>
        /// データグリッド行から値を取得
        /// </summary>
        /// <param name="row"></param>
        /// <param name="col"></param>
        /// <returns></returns>
        public static string GetValue(DataGridViewRow row, int col)
        {
            if (row == null || col < 0 || col >= row.Cells.Count) return string.Empty;

            if (row.Cells[col].Value == null) return string.Empty;

            return row.Cells[col].Value.ToString().Trim();
        }

        /// <summary>
        /// データグリッド行から整数型値を取得
        /// </summary>
        /// <param name="row"></param>
        /// <param name="col"></param>
        /// <returns></returns>
        public static int GetIntValue(DataGridViewRow row, string col)
        {
            return int.TryParse(GetValue(row, col), out int iValue) ? iValue : 0;
        }

        /// <summary>
        /// データグリッド行から整数型値を取得
        /// </summary>
        /// <param name="row"></param>
        /// <param name="col"></param>
        /// <returns></returns>
        public static int GetIntValue(DataGridViewRow row, int col)
        {
            return int.TryParse(GetValue(row, col), out int iValue) ? iValue : 0;
        }

        /// <summary>
        /// データグリッド行から関連オブジェクトを取得
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        private static RowTag GetTag(DataGridViewRow row)
        {
            if (row == null) return null;

            return row.Tag as RowTag;
        }

        /// <summary>
        /// データグリッド行から関連オブジェクトを取得
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        private static RowTag SetTag(DataGridViewRow row)
        {
            if (row == null) return null;

            if (row.Tag == null)
            {
                row.Tag = new RowTag();
            }

            return GetTag(row);
        }

        /// <summary>
        /// データグリッド行から関連データを取得
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="row"></param>
        /// <returns></returns>
        public static T GetData<T>(DataGridViewRow row)
        {
            var tag = GetTag(row);

            if (tag == null || !(tag.Data is T)) return default(T);

            return (T)tag.Data;
        }

        /// <summary>
        /// データグリッド行へ関連データを設定
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="row"></param>
        /// <param name="data"></param>
        public static void SetData<T>(DataGridViewRow row, T data)
        {
            var tag = SetTag(row);
            if (tag == null) return;
            tag.Data = data;
        }

        /// <summary>
        /// データグリッド行の状態を設定
        /// </summary>
        /// <param name="row"></param>
        private static void SetStatus(DataGridViewRow row, int status)
        {
            var tag = SetTag(row);
            if (tag == null) return;
            tag.Status = status;
        }

        /// <summary>
        /// データグリッド行の状態を取得
        /// </summary>
        /// <param name="row"></param>
        private static int GetStatus(DataGridViewRow row)
        {
            var tag = SetTag(row);
            if (tag == null) return 0;
            return tag.Status;
        }

        /// <summary>
        /// データグリッド行が削除状態に設定
        /// </summary>
        /// <param name="row"></param>
        public static void SetDelete(DataGridViewRow row)
        {
            SetStatus(row, GetStatus(row) | DELETE);
            row.DefaultCellStyle.BackColor = Color.Gray;
        }

        /// <summary>
        /// データグリッド行が削除状態を回復
        /// </summary>
        /// <param name="row"></param>
        public static void UnDelete(DataGridViewRow row)
        {
            if (IsDelete(row))
            {
                SetStatus(row, GetStatus(row) & ~DELETE);
                row.DefaultCellStyle.BackColor = Color.White;
            }
        }

        /// <summary>
        /// データグリッド行が新規状態に設定
        /// </summary>
        /// <param name="row"></param>
        public static void SetNew(DataGridViewRow row)
        {
            SetStatus(row, NEW);
        }

        /// <summary>
        /// データグリッド行が削除状態を判定
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        public static bool IsDelete(DataGridViewRow row)
        {
            return (GetStatus(row) & DELETE) > 0;
        }

        /// <summary>
        /// データグリッド行が新規状態を判定
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        public static bool IsNew(DataGridViewRow row)
        {
            if (IsDelete(row)) return false;
            return (GetStatus(row) & NEW) > 0;
        }

        /// <summary>
        /// データグリッド行が関連するデータがあるかどうか
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        public static bool HasData(DataGridViewRow row)
        {
            return GetData<object>(row) != null;
        }
    }

    class RowTag
    {
        /// <summary>
        /// 行の状態
        /// </summary>
        public int Status { get; set; }

        /// <summary>
        /// 行の関連データ
        /// </summary>
        public object Data { get; set; }
    }
}
