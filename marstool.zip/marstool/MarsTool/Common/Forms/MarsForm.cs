﻿using MarsTool.Models;
using MarsTool.Models.DB;
using NLog;
using System.Windows.Forms;

namespace MarsTool.Common.Forms
{
    /// <summary>
    /// マルス画面ベースクラス
    /// </summary>
    public class MarsForm : Form
    {
        /// <summary>
        /// バージョンモデル
        /// </summary>
        public VersionModel Version { get; private set; }

        /// <summary>
        /// DB連続
        /// </summary>
        public mysqlcontext Context
        {
            get
            {
                return this.Version.context;
            }
        }

        /// <summary>
        /// ログオブジェクト
        /// </summary>
        private Logger _logger = LogManager.GetCurrentClassLogger();
        public Logger Logger
        {
            get
            {
                return this._logger;
            }
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public MarsForm()
        {
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public MarsForm(VersionModel version) : this()
        {
            this.Version = version;
        }
    }
}
