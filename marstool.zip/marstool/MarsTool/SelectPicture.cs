﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace MarsTool
{
    public partial class SelectPicture : Form
    {
        public enum DialogAction { Set, UnSet};

        /// <summary>
        /// 図表名称
        /// </summary>
        public string PictureName { get; set; }

        /// <summary>
        /// ファイルパス
        /// </summary>
        public string FilePath { get; set; }

        /// <summary>
        /// 図表のイメージデータ
        /// </summary>
        public Byte[] ImageData { get; set; }

        /// <summary>
        /// 行ったアクション
        /// </summary>
        public DialogAction Action { get; private set; }
        
        /// <summary>
        /// ファイルサイズの上限（０ならInt.MaxValue）
        /// </summary>
        public int LimitFileSize { private get; set; }

        /// <summary>
        /// 図表名称サイズの上限
        /// </summary>
        public int LimitNameSize { private get; set; }
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public SelectPicture()
        {
            InitializeComponent();
        }

        /// <summary>
        /// ダイアログ表示
        /// </summary>
        /// <returns></returns>
        public new DialogResult ShowDialog()
        {
            if (this.LimitFileSize == 0) this.LimitFileSize = int.MaxValue;
            if(this.FilePath != null && this.FilePath != string.Empty)
            {
                txtFile.Text = this.FilePath;
                try
                {
                    if (File.Exists(this.FilePath))
                    {
                        picPreview.Image = Image.FromFile(this.FilePath);
                    }
                }
                catch
                {
                    MessageBox.Show("{0}は画像ファイルではありません", Path.GetFileName(this.FilePath));
                    txtFile.Text = string.Empty;
                }
            }
            else
            {
                txtFile.Text = this.PictureName;
                if ((this.PictureName != null && this.PictureName != string.Empty) && this.ImageData != null)
                {
                    try
                    {
                        MemoryStream ms = new MemoryStream(this.ImageData);
                        picPreview.Image = Image.FromStream(ms);
                    }
                    catch
                    {
                        MessageBox.Show(string.Format("図表({0})が壊れています\n処理を続行します", this.PictureName));
                    }
                }
            }
            if (txtFile.Text != string.Empty)
            {
                btnUnSet.Enabled = true;
            }
            else
            {
                btnUnSet.Enabled = false;
            }
            return base.ShowDialog();
        }

        private void btnRef_Click(object sender, EventArgs e)
        {
            string filepath;
            if (txtFile.Text != null && txtFile.Text != string.Empty)
            {
                filepath = Path.GetFullPath(txtFile.Text);
            }
            else
            {
                filepath = String.Empty;
            }

            OpenFileDialog dialog = new OpenFileDialog
            {
                FileName = filepath,
                Filter = "Image File|*.jpg;*.png;*.bmp|All File|*",
                FilterIndex = 0
            };
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    if(this.LimitNameSize != 0 && dialog.FileName.Length > this.LimitNameSize)
                    {
                        MessageBox.Show(string.Format("{0} は ファイル名が長すぎます（Name={1:d}, Max={2:d}）",
                                                            Path.GetFileName(dialog.FileName), dialog.FileName.Length, this.LimitNameSize));
                        btnSet.Enabled = false;
                        return;
                    }
                    FileInfo fileInfo = new FileInfo(dialog.FileName);
                    long FileSize = fileInfo.Length;
                    if (FileSize > int.MaxValue || (this.LimitFileSize != 0 && FileSize > this.LimitFileSize))
                    {
                        MessageBox.Show(string.Format("{0} は ファイルサイズが大き過ぎます（File={1:d}, Max={2:d}）", 
                                                            Path.GetFileName(dialog.FileName), FileSize, this.LimitFileSize));
                        btnSet.Enabled = false;
                        return;
                    }
                    txtFile.Text = dialog.FileName;
                    this.FilePath = dialog.FileName;
                    this.PictureName = Path.GetFileNameWithoutExtension(dialog.FileName);
                    btnSet.Enabled = true;
                    btnUnSet.Enabled = false;
                    picPreview.Image = Image.FromFile(this.FilePath);
                    using (FileStream fsr = new FileStream(this.FilePath, FileMode.Open, FileAccess.Read))
                    {
                        byte[] buf = new byte[FileSize];
                        fsr.Read(buf, 0, (int)FileSize);
                        this.ImageData = buf;
                    }
                }
                catch
                {
                    //ファイルの読込に失敗
                    MessageBox.Show("ファイルの読込に失敗しました");
                }

            }
        }

        private void btnSet_Click(object sender, EventArgs e)
        {
            this.Action = DialogAction.Set;
        }

        private void btnUnSet_Click(object sender, EventArgs e)
        {
            this.Action = DialogAction.UnSet;
        }
    }
}
