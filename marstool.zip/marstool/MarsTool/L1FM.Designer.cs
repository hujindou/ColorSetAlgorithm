﻿namespace MarsTool
{
    partial class L1FM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button2 = new System.Windows.Forms.Button();
            this.request = new System.Windows.Forms.RadioButton();
            this.response = new System.Windows.Forms.RadioButton();
            this.cancel = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.DialogResult = System.Windows.Forms.DialogResult.Ignore;
            this.button2.Location = new System.Drawing.Point(295, 35);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 3;
            this.button2.Text = "決定";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // request
            // 
            this.request.AutoSize = true;
            this.request.Location = new System.Drawing.Point(26, 38);
            this.request.Name = "request";
            this.request.Size = new System.Drawing.Size(47, 16);
            this.request.TabIndex = 5;
            this.request.TabStop = true;
            this.request.Text = "要求";
            this.request.UseVisualStyleBackColor = true;
            this.request.CheckedChanged += new System.EventHandler(this.request_CheckedChanged);
            // 
            // response
            // 
            this.response.AutoSize = true;
            this.response.Location = new System.Drawing.Point(107, 38);
            this.response.Name = "response";
            this.response.Size = new System.Drawing.Size(47, 16);
            this.response.TabIndex = 6;
            this.response.TabStop = true;
            this.response.Text = "回答";
            this.response.UseVisualStyleBackColor = true;
            this.response.CheckedChanged += new System.EventHandler(this.response_CheckedChanged);
            // 
            // cancel
            // 
            this.cancel.AutoSize = true;
            this.cancel.Location = new System.Drawing.Point(192, 38);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(71, 16);
            this.cancel.TabIndex = 7;
            this.cancel.TabStop = true;
            this.cancel.Text = "設定取消";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.CheckedChanged += new System.EventHandler(this.cancel_CheckedChanged);
            // 
            // L1FM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(387, 97);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.response);
            this.Controls.Add(this.request);
            this.Controls.Add(this.button2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "L1FM";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "要求回答設定";
            this.Load += new System.EventHandler(this.OtherFM_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.RadioButton request;
        private System.Windows.Forms.RadioButton response;
        private System.Windows.Forms.RadioButton cancel;
    }
}