﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarsTool
{
    public partial class SelectTable : Form
    {
        public SelectTable()
        {
            InitializeComponent();
        }

        public bool IsMBTable
        {
            get
            {
                return this.rdoMB.Checked;
            }
        }
    }
}
